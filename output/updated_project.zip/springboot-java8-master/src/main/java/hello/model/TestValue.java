Here are some unit tests for the `Value` class in the `hello.model` package:

```java
package hello.model;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ValueTest {

    @Test
    public void testGetId() {
        Value value = new Value();
        Long id = 123L;
        value.setId(id);
        assertEquals(id, value.getId());
    }

    @Test
    public void testGetQuote() {
        Value value = new Value();
        String quote = "Test Quote";
        value.setQuote(quote);
        assertEquals(quote, value.getQuote());
    }

    @Test
    public void testToString() {
        Value value = new Value();
        value.setId(456L);
        value.setQuote("Another Quote");
        String expected = "Value{id=456, quote='Another Quote'}";
        assertEquals(expected, value.toString());
    }

    @Test
    public void testDefaultConstructor() {
        Value value = new Value();
        assertNull(value.getId());
        assertNull(value.getQuote());
    }

    @Test
    public void testSetId() {
        Value value = new Value();
        Long id = 789L;
        value.setId(id);
        assertEquals(id, value.getId());
    }

    @Test
    public void testSetQuote() {
        Value value = new Value();
        String quote = "New Quote";
        value.setQuote(quote);
        assertEquals(quote, value.getQuote());
    }
}
```

These tests cover the basic functionality of the `Value` class including getters, setters, `toString` method, and the default constructor. Make sure to add JUnit to your project dependencies to run these tests.