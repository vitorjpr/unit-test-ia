Here are some unit tests for the `Customer` class in Java:

```java
package hello.model;

import org.junit.Test;
import static org.junit.Assert.*;

public class CustomerTest {

    @Test
    public void testConstructorAndGetters() {
        Customer customer = new Customer(1, "John", "Doe");
        assertEquals(1, customer.getId());
        assertEquals("John", customer.getFirstName());
        assertEquals("Doe", customer.getLastName());
    }

    @Test
    public void testSetters() {
        Customer customer = new Customer(1, "John", "Doe");
        customer.setId(2);
        customer.setFirstName("Jane");
        customer.setLastName("Smith");
        assertEquals(2, customer.getId());
        assertEquals("Jane", customer.getFirstName());
        assertEquals("Smith", customer.getLastName());
    }

    @Test
    public void testToString() {
        Customer customer = new Customer(1, "John", "Doe");
        String expected = "Customer{id=1, firstName='John', lastName='Doe'}";
        assertEquals(expected, customer.toString());
    }
}
```

These tests cover the constructor, getters, setters, and the `toString()` method of the `Customer` class. You can run these tests using a testing framework like JUnit to ensure the correctness of the class implementation.