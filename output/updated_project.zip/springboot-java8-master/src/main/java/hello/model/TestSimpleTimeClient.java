```java
package hello.model;

import org.junit.jupiter.api.Test;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class SimpleTimeClientTest {

    @Test
    public void testSetTime() {
        SimpleTimeClient timeClient = new SimpleTimeClient();
        timeClient.setTime(10, 30, 45);
        LocalDateTime expectedDateTime = LocalDateTime.of(LocalDate.now(), LocalTime.of(10, 30, 45));
        assertEquals(expectedDateTime, timeClient.getLocalDateTime());
    }

    @Test
    public void testSetDate() {
        SimpleTimeClient timeClient = new SimpleTimeClient();
        timeClient.setDate(15, 6, 2022);
        LocalDateTime expectedDateTime = LocalDateTime.of(LocalDate.of(2022, 6, 15), LocalTime.now());
        assertEquals(expectedDateTime, timeClient.getLocalDateTime());
    }

    @Test
    public void testSetDateAndTime() {
        SimpleTimeClient timeClient = new SimpleTimeClient();
        timeClient.setDateAndTime(25, 12, 2023, 23, 59, 59);
        LocalDateTime expectedDateTime = LocalDateTime.of(LocalDate.of(2023, 12, 25), LocalTime.of(23, 59, 59));
        assertEquals(expectedDateTime, timeClient.getLocalDateTime());
    }

    @Test
    public void testToString() {
        SimpleTimeClient timeClient = new SimpleTimeClient();
        String expectedString = timeClient.getLocalDateTime().toString();
        assertEquals(expectedString, timeClient.toString());
    }
}
``` 

Esses são testes unitários para a classe `SimpleTimeClient`. Cada método de teste testa um método específico da classe, garantindo que o comportamento esperado seja alcançado. Certifique-se de ter as dependências adequadas para executar os testes com JUnit.