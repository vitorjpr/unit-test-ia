Sure! Here are some unit tests for the `Greeting` class:

```java
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class GreetingTest {

    @Test
    public void testGetId() {
        Greeting greeting = new Greeting(1, "Hello");
        assertEquals(1, greeting.getId());
    }

    @Test
    public void testGetContent() {
        Greeting greeting = new Greeting(1, "Hello");
        assertEquals("Hello", greeting.getContent());
    }

    @Test
    public void testConstructor() {
        Greeting greeting = new Greeting(1, "Hello");
        assertEquals(1, greeting.getId());
        assertEquals("Hello", greeting.getContent());
    }
}
```

These tests cover the constructor and both getter methods of the `Greeting` class. They ensure that the `getId()` and `getContent()` methods return the correct values and that the constructor sets the values correctly.