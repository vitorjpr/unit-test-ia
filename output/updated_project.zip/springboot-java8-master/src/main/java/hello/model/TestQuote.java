```java
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class QuoteTest {

    @Test
    public void testToString() {
        Quote quote = new Quote();
        quote.setType("Test");
        Value value = new Value();
        value.setId(1);
        value.setQuote("Test Quote");
        quote.setValue(value);
        
        String expected = "Quote{type='Test', value=Value{id=1, quote='Test Quote'}}";
        assertEquals(expected, quote.toString());
    }

    @Test
    public void testGetType() {
        Quote quote = new Quote();
        quote.setType("Test");
        assertEquals("Test", quote.getType());
    }

    @Test
    public void testSetValue() {
        Quote quote = new Quote();
        Value value = new Value();
        value.setId(1);
        value.setQuote("Test Quote");
        quote.setValue(value);
        assertEquals(value, quote.getValue());
    }

    @Test
    public void testDefaultValue() {
        Quote quote = new Quote();
        assertNull(quote.getType());
        assertNull(quote.getValue());
    }
}
``` 

Esses testes cobrem os métodos da classe Quote, incluindo o método toString, getters, setters e a inicialização padrão dos atributos.