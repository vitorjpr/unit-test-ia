```java
package hello.controller;

import hello.model.Topic;
import hello.service.TopicService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

class TopicControllerTest {

    private TopicController topicController;

    @Mock
    private TopicService topicService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
        topicController = new TopicController();
        topicController.topicService = topicService;
    }

    @Test
    void testGetAllTopics() {
        List<Topic> topics = Arrays.asList(new Topic("1", "Java"), new Topic("2", "Spring"));
        when(topicService.getAllTopics()).thenReturn(topics);

        List<Topic> result = topicController.getAllTopics();

        assertEquals(2, result.size());
        assertEquals("Java", result.get(0).getName());
        assertEquals("Spring", result.get(1).getName());
    }

    @Test
    void testGetTopicWithID() {
        Topic topic = new Topic("1", "Java");
        when(topicService.getTopicWithId("1")).thenReturn(topic);

        Topic result = topicController.getTopicWithID("1");

        assertEquals("Java", result.getName());
    }

    @Test
    void testAddTopic() {
        Topic topic = new Topic("1", "Java");

        topicController.addTopic(topic);

        verify(topicService, times(1)).addTopic(topic);
    }

    @Test
    void testUpdateTopic() {
        Topic topic = new Topic("1", "Java");

        topicController.updateTopic("1", topic);

        verify(topicService, times(1)).updateTopic("1", topic);
    }

    @Test
    void testDeleteTopic() {
        topicController.deleteTopic("1");

        verify(topicService, times(1)).deleteTopic("1");
    }

    @Test
    void testFilterMinimumLengthForId() {
        List<Topic> topics = Arrays.asList(new Topic("1", "Java"), new Topic("22", "Spring"));
        when(topicService.filterMinimumLengthForId(2)).thenReturn(topics);

        List<Topic> result = topicController.filterMinimumLengthForId(2);

        assertEquals(2, result.size());
        assertEquals("Java", result.get(0).getName());
        assertEquals("Spring", result.get(1).getName());
    }

    @Test
    void testSortTopicsWithID() {
        List<Topic> topics = Arrays.asList(new Topic("22", "Spring"), new Topic("1", "Java"));
        when(topicService.sortTopicsWithID()).thenReturn(topics);

        List<Topic> result = topicController.sortTopicsWithID();

        assertEquals(2, result.size());
        assertEquals("Spring", result.get(0).getName());
        assertEquals("Java", result.get(1).getName());
    }
}
```