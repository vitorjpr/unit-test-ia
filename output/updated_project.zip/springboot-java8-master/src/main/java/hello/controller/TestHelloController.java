Here are some unit tests for the provided Java code:

```java
package hello.controller;

import hello.declaration.TimeClient;
import hello.model.SimpleTimeClient;
import hello.service.TopicService;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.InjectMocks;
import org.springframework.boot.test.context.SpringBootTest;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@SpringBootTest
public class HelloControllerTests {

    @InjectMocks
    private HelloController helloController;

    @Mock
    private TopicService topicService;

    @Test
    public void testDateTimeEndpoint() {
        TimeClient myTimeClient = new SimpleTimeClient();
        when(topicService.returnAllTopicIDWithStringSlicing()).thenReturn("topic1:topic2:java:topic3");

        String result = helloController.index();

        assertEquals("Greetings from Spring Boot! ----------------------" +
                "Datetime now is " + myTimeClient.toString() + "----------------------" +
                "Datetime tomorrow will be " + myTimeClient.getLocalDateTime().plusDays(1) + "----------------------" +
                "Datetime of previous month was " + myTimeClient.getLocalDateTime().minus(1, ChronoUnit.MONTHS) + "----------------------" +
                "Is this a leap year ?  " + LocalDate.now().isLeapYear() + "----------------------" +
                "Default system zone id   " + ZoneId.systemDefault() + "-------------------" +
                "Time in California: " + myTimeClient.getZonedDateTime("Canada/Central").toString(), result);
    }

    @Test
    public void testStringOperationEndpoint() {
        when(topicService.returnAllTopicIDWithStringSlicing()).thenReturn("topic1:topic2:java:topic3");
        when(topicService.makeDistinctAndSortCharacters("topic1:topic2:java:topic3")).thenReturn("a:java:k:o:p:t");
        when(topicService.splitAllIdWithColonSelectIDWithJavaKeywordThenSortThenJoin("topic1:topic2:java:topic3")).thenReturn("java");

        String result = helloController.showStringOperation();

        assertEquals("Joining All String ID's with JOIN method: topic1:topic2:java:topic3" +
                "-------------Get all ID characters, select distict and sort with ID=   a:java:k:o:p:t" +
                "-------------Split All Id With Colon,Select ID With \"Java\" Keyword, Then Sort Then Join java" +
                "-------------Return All ID having character 'g' in it:  java", result);
    }

    @Test
    public void testFileOperationEndpoint() {
        when(topicService.findAllFilesInPathAndSort()).thenReturn("file1.txt:file2.txt:file3.txt");
        when(topicService.findParticularFileInPathAndSort()).thenReturn("gradle.txt");
        when(topicService.findParticularFileInPathAndSortWithWalkFunction()).thenReturn("gradle.txt");
        when(topicService.readFileWithStreamFunction()).thenReturn("content");

        String result = helloController.showFileOperation();

        assertEquals("---------Find all files in path and sort:    file1.txt:file2.txt:file3.txt" +
                "----------Find File in present directory which strats with \"grad\",provided maximum depth=25 and sort : gradle.txt" +
                "----------Find File in present directory which strats with \"grad\",provided maximum depth=25 and sort :  with walk function gradle.txt" +
                "---------Read \"temp.txt\" file with stream functions, having \"print\" witin it:  content", result);
    }
}
```

These tests cover the endpoints in the `HelloController` class and mock the `TopicService` to simulate the behavior of the service methods. Make sure to include the necessary dependencies for mocking and testing in your project.