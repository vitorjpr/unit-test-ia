```java
package hello.controller;

import hello.model.Greeting;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.hamcrest.Matchers.containsString;

@WebMvcTest(GreetingController.class)
public class GreetingControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Test
    public void testGreetingWithNameParam() throws Exception {
        this.mockMvc.perform(MockMvcRequestBuilders.get("/")
                .param("name", "Alice"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("Hello, Alice!")));
    }

    @Test
    public void testGreetingWithoutNameParam() throws Exception {
        this.mockMvc.perform(MockMvcRequestBuilders.get("/"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("Hello, World!")));
    }

    @Test
    public void testGreetingCounterIncremented() throws Exception {
        GreetingController greetingController = new GreetingController();
        Greeting firstGreeting = greetingController.greeting("Alice");
        Greeting secondGreeting = greetingController.greeting("Bob");

        assert firstGreeting.getId() < secondGreeting.getId();
    }
}
```

Esses testes unitários abrangem diferentes cenários para a classe `GreetingController`, incluindo testes com e sem parâmetros, e um teste para garantir que o contador seja incrementado corretamente. Certifique-se de que as dependências necessárias estejam presentes no arquivo `pom.xml` do projeto para que os testes possam ser executados com sucesso.