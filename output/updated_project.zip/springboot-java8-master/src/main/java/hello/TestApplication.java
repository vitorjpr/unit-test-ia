Here are some unit tests for the provided Java code:

```java
package hello;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;

import hello.model.Customer;
import hello.model.Quote;
import org.junit.jupiter.api.Test;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.client.RestTemplate;

public class ApplicationTest {

    @Test
    public void testRestTemplate() {
        RestTemplate restTemplate = mock(RestTemplate.class);
        Quote expectedQuote = new Quote("Spring is fun!");
        when(restTemplate.getForObject("http://gturnquist-quoters.cfapps.io/api/random", Quote.class))
                .thenReturn(expectedQuote);

        Quote actualQuote = restTemplate.getForObject("http://gturnquist-quoters.cfapps.io/api/random", Quote.class);

        assertEquals(expectedQuote, actualQuote);
    }

    @Test
    public void testJdbcTemplate() {
        JdbcTemplate jdbcTemplate = mock(JdbcTemplate.class);

        Application app = new Application();
        app.jdbcTemplate = jdbcTemplate;

        // Mocking the behavior of jdbcTemplate.execute
        when(jdbcTemplate.execute("DROP TABLE customers IF EXISTS")).thenReturn(null);
        when(jdbcTemplate.execute("CREATE TABLE customers(id SERIAL, first_name VARCHAR(255), last_name VARCHAR(255)"))
                .thenReturn(null);

        List<Object[]> splitUpNames = Arrays.asList(new Object[]{"John", "Woo"}, new Object[]{"Jeff", "Dean"});

        // Mocking the behavior of jdbcTemplate.batchUpdate
        when(jdbcTemplate.batchUpdate("INSERT INTO customers(first_name, last_name) VALUES (?,?)", splitUpNames))
                .thenReturn(new int[]{1, 1});

        // Mocking the behavior of jdbcTemplate.query
        List<Customer> expectedCustomers = Arrays.asList(new Customer(1L, "Josh", "Bloch"), new Customer(2L, "Josh", "Long"));
        when(jdbcTemplate.query(
                "SELECT id, first_name, last_name FROM customers WHERE first_name = ?", new Object[]{"Josh"},
                (rs, rowNum) -> new Customer(rs.getLong("id"), rs.getString("first_name"), rs.getString("last_name"))
        )).thenReturn(expectedCustomers);

        app.run();

        // Add assertions here if needed
    }
}
```

Please note that the provided unit tests are basic and cover some parts of the code. You may need to enhance them based on the specific requirements and functionalities of your application.