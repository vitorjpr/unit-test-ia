```java
package hello.service;

import hello.model.Topic;
import hello.declaration.CustomPredicate;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class TopicServiceTest {

    private TopicService topicService;

    @BeforeEach
    void setUp() {
        topicService = new TopicService();
    }

    @Test
    void testGetAllTopics() {
        List<Topic> topics = topicService.getAllTopics();
        assertEquals(3, topics.size());
    }

    @Test
    void testGetTopicWithId() {
        Topic topic = topicService.getTopicWithId("java");
        assertEquals("Core Java", topic.getName());
    }

    @Test
    void testAddTopic() {
        Topic newTopic = new Topic("python", "Python Programming", "Python Description");
        topicService.addTopic(newTopic);
        List<Topic> topics = topicService.getAllTopics();
        assertTrue(topics.contains(newTopic));
    }

    @Test
    void testUpdateTopic() {
        Topic updatedTopic = new Topic("java", "Updated Java", "Updated Java Description");
        topicService.updateTopic("java", updatedTopic);
        Topic retrievedTopic = topicService.getTopicWithId("java");
        assertEquals("Updated Java", retrievedTopic.getName());
    }

    @Test
    void testDeleteTopic() {
        topicService.deleteTopic("java");
        List<Topic> topics = topicService.getAllTopics();
        assertEquals(2, topics.size());
    }

    @Test
    void testFilterMinimumLengthForId() {
        List<Topic> filteredTopics = topicService.filterMinimumLengthForId(4);
        assertEquals(2, filteredTopics.size());
    }

    // Add more tests for the remaining methods

}
```