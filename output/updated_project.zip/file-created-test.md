# Arquivos de Teste Criados

- TestApplication.java
- TestHelloController.java
- TestTopicController.java
- TestGreetingController.java
- TestTimeClient.java
- TestCustomPredicate.java
- TestTopicService.java
- TestTopic.java
- TestValue.java
- TestGreeting.java
- TestQuote.java
- TestSimpleTimeClient.java
- TestCustomer.java
