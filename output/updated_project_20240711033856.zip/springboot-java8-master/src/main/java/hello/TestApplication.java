Sure, here's an example of how you might write some tests for this code. Note that writing comprehensive tests for this class is a bit complex because it involves a lot of external dependencies like RestTemplate, JdbcTemplate, and SpringApplication.

```java
package hello;

import hello.model.Customer;
import hello.model.Quote;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.client.RestTemplate;
import java.util.Arrays;
import java.util.List;
import static org.mockito.Mockito.*;

public class ApplicationTest {

    @InjectMocks
    Application application;

    @Mock
    JdbcTemplate jdbcTemplate;

    @Mock
    RestTemplateBuilder restTemplateBuilder;

    @Mock
    RestTemplate restTemplate;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testRun() throws Exception {
        doNothing().when(jdbcTemplate).execute(anyString());
        doNothing().when(jdbcTemplate).batchUpdate(anyString(), anyList());
        when(jdbcTemplate.query(anyString(), any(), any())).thenReturn(Arrays.asList(new Customer(1L, "Josh", "Long")));

        application.run("test");

        verify(jdbcTemplate, times(2)).execute(anyString());
        verify(jdbcTemplate, times(1)).batchUpdate(anyString(), anyList());
        verify(jdbcTemplate, times(1)).query(anyString(), any(), any());
    }

    @Test
    public void testRestTemplate() {
        when(restTemplateBuilder.build()).thenReturn(restTemplate);

        RestTemplate result = application.restTemplate(restTemplateBuilder);

        verify(restTemplateBuilder, times(1)).build();
        assertSame(restTemplate, result);
    }

    @Test
    public void testCommandLineRunner() throws Exception {
        Quote quote = new Quote();
        when(restTemplate.getForObject(anyString(), eq(Quote.class))).thenReturn(quote);

        application.run(restTemplate).run("test");

        verify(restTemplate, times(1)).getForObject(anyString(), eq(Quote.class));
    }
}
```
This test suite initializes the necessary mocks, validates the interactions with the mocked objects and checks the returned results. You may want to add more checks to validate the logic inside your methods.