Sure, here is a comprehensive set of JUnit tests for your Java code:

```java
package hello.declaration;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

public class TimeClientTest {

    private TimeClient timeClient;
    private LocalDateTime localDateTime;

    @BeforeEach
    public void setup() {
        timeClient = Mockito.mock(TimeClient.class);
        localDateTime = LocalDateTime.of(2022, 3, 1, 12, 0);
        when(timeClient.getLocalDateTime()).thenReturn(localDateTime);
    }

    @Test
    public void testGetZoneId_validZone() {
        ZoneId zoneId = TimeClient.getZoneId("Europe/Paris");
        assertNotNull(zoneId);
        assertEquals("Europe/Paris", zoneId.getId());
    }

    @Test
    public void testGetZoneId_invalidZone() {
        ZoneId zoneId = TimeClient.getZoneId("Invalid/Zone");
        assertNotNull(zoneId);
        assertEquals(ZoneId.systemDefault().getId(), zoneId.getId());
    }

    @Test
    public void testGetZonedDateTime() {
        ZonedDateTime zonedDateTime = timeClient.getZonedDateTime("Europe/Paris");
        assertNotNull(zonedDateTime);
        assertEquals(localDateTime, zonedDateTime.toLocalDateTime());
        assertEquals("Europe/Paris", zonedDateTime.getZone().getId());
    }
}
```
This test class includes tests for both the static and default methods in your interface. Before each test, a TimeClient instance is mocked and a LocalDateTime instance is created. The mock TimeClient's getLocalDateTime method is set to return this LocalDateTime instance. 

The testGetZoneId_validZone test checks that TimeClient.getZoneId returns a valid ZoneId for a valid zone string. 

The testGetZoneId_invalidZone test checks that TimeClient.getZoneId returns the system default ZoneId for an invalid zone string. 

The testGetZonedDateTime test checks that the ZonedDateTime returned by getZonedDateTime has the expected LocalDateTime and ZoneId.