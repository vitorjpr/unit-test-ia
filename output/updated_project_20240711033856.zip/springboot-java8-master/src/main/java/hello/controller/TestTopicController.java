Here are the JUnit tests for your Java code:

```java
package hello.controller;

import hello.model.Topic;
import hello.service.TopicService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

@SpringBootTest
public class TopicControllerTest {

    @InjectMocks
    private TopicController topicController;

    @Mock
    private TopicService topicService;

    @BeforeEach
    public void init() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void getAllTopicsTest() {
        when(topicService.getAllTopics()).thenReturn(Arrays.asList(new Topic("1", "Java", "Java Description")));
        List<Topic> topics = topicController.getAllTopics();
        assertEquals(1, topics.size());
        verify(topicService, times(1)).getAllTopics();
    }

    @Test
    public void getTopicWithIdTest() {
        when(topicService.getTopicWithId("1")).thenReturn(new Topic("1", "Java", "Java Description"));
        Topic topic = topicController.getTopicWithID("1");
        assertEquals("1", topic.getId());
        verify(topicService, times(1)).getTopicWithId("1");
    }

    @Test
    public void addTopicTest() {
        Topic topic = new Topic("2", "Python", "Python Description");
        topicController.addTopic(topic);
        verify(topicService, times(1)).addTopic(topic);
    }

    @Test
    public void updateTopicTest() {
        Topic topic = new Topic("1", "Java", "Updated Description");
        topicController.updateTopic("1", topic);
        verify(topicService, times(1)).updateTopic("1", topic);
    }

    @Test
    public void deleteTopicTest() {
        topicController.deleteTopic("1");
        verify(topicService, times(1)).deleteTopic("1");
    }

    @Test
    public void filterMinimumLengthForIdTest() {
        when(topicService.filterMinimumLengthForId(1)).thenReturn(Arrays.asList(new Topic("1", "Java", "Java Description")));
        List<Topic> topics = topicController.filterMinimumLengthForId(1);
        assertEquals(1, topics.size());
        verify(topicService, times(1)).filterMinimumLengthForId(1);
    }

    @Test
    public void sortTopicsWithIdTest() {
        when(topicService.sortTopicsWithID()).thenReturn(Arrays.asList(new Topic("1", "Java", "Java Description")));
        List<Topic> topics = topicController.sortTopicsWithID();
        assertEquals(1, topics.size());
        verify(topicService, times(1)).sortTopicsWithID();
    }
}
```

In these tests, we are using Mockito to mock the `TopicService` and verify that the correct methods are called with the correct arguments. We are also checking the returned values from the `TopicController` methods to ensure they match our expectations.