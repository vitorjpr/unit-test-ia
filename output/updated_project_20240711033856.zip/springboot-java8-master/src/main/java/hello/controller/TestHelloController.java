Here are the JUnit tests for the provided Java code:

```java
package hello.controller;

import hello.declaration.TimeClient;
import hello.model.SimpleTimeClient;
import hello.service.TopicService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;

@SpringBootTest
public class HelloControllerTest {

    private MockMvc mockMvc;

    @Mock
    private TopicService topicService;

    @InjectMocks
    private HelloController helloController;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.initMocks(this);
        this.mockMvc = MockMvcBuilders.standaloneSetup(helloController).build();
    }

    @Test
    public void testIndex() throws Exception {
        mockMvc.perform(get("/datetime"))
                .andExpect(status().isOk())
                .andExpect(content().string(helloController.index()));
    }

    @Test
    public void testShowStringOperation() throws Exception {
        when(topicService.returnAllTopicIDWithStringSlicing()).thenReturn("test");
        when(topicService.makeDistinctAndSortCharacters("test")).thenReturn("test");
        when(topicService.splitAllIdWithColonSelectIDWithJavaKeywordThenSortThenJoin("test")).thenReturn("test");
        when(topicService.findIdHavingCharacter()).thenReturn("test");
        mockMvc.perform(get("/topic/string/operation"))
                .andExpect(status().isOk())
                .andExpect(content().string(helloController.showStringOperation()));
    }

    @Test
    public void testShowFileOperation() throws Exception {
        when(topicService.findAllFilesInPathAndSort()).thenReturn("test");
        when(topicService.findParticularFileInPathAndSort()).thenReturn("test");
        when(topicService.findParticularFileInPathAndSortWithWalkFunction()).thenReturn("test");
        when(topicService.readFileWithStreamFunction()).thenReturn("test");
        mockMvc.perform(get("/topic/file/operation"))
                .andExpect(status().isOk())
                .andExpect(content().string(helloController.showFileOperation()));
    }

}
```
In these tests, we are mocking the `TopicService` and injecting it into `HelloController` using `@InjectMocks`. We use `MockMvc` to perform HTTP requests to our controller. In each test, we use `Mockito` to specify the behavior of the `TopicService` when its methods are called, then we perform a GET request to the corresponding endpoint and verify that the status is OK and the content matches what we expect.