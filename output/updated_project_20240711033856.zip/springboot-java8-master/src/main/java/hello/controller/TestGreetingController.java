Here is a comprehensive JUnit test for the GreetingController class:

```java
package hello.controller;

import hello.model.Greeting;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
public class GreetingControllerTest {

    @Autowired
    private MockMvc mockMvc;

    private long counter = 1;

    @BeforeEach
    public void resetCounter() {
        counter = 1;
    }

    @Test
    public void greetingDefaultTest() throws Exception {
        MvcResult mvcResult = this.mockMvc.perform(get("/")
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        Greeting expectedGreeting = new Greeting(counter, "Hello, World!");
        assertEquals(expectedGreeting.toString(), mvcResult.getResponse().getContentAsString());
    }

    @Test
    public void greetingWithNameTest() throws Exception {
        String name = "John";
        MvcResult mvcResult = this.mockMvc.perform(get("/")
                .param("name", name)
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        Greeting expectedGreeting = new Greeting(counter, "Hello, " + name + "!");
        assertEquals(expectedGreeting.toString(), mvcResult.getResponse().getContentAsString());
    }
}
```

This test class includes two tests: `greetingDefaultTest` and `greetingWithNameTest`. 

The `greetingDefaultTest` method tests the `/` endpoint without any parameters, which should return a greeting with the default name "World". 

The `greetingWithNameTest` method tests the `/` endpoint with a "name" parameter, which should return a greeting with the provided name.

In both tests, we are asserting that the returned HTTP status is 200 (OK) and that the returned greeting is as expected. The counter is reset before each test to ensure consistent results.