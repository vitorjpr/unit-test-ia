Here is the JUnit test for the provided Java code:

```java
package hello.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

public class ValueTest {
    private Value value;

    @BeforeEach
    public void setUp() {
        value = new Value();
    }

    @Test
    public void testGetIdInitiallyNull() {
        assertNull(value.getId());
    }

    @Test
    public void testSetAndGetId() {
        Long id = 123L;
        value.setId(id);
        assertEquals(id, value.getId());
    }

    @Test
    public void testGetQuoteInitiallyNull() {
        assertNull(value.getQuote());
    }

    @Test
    public void testSetAndGetQuote() {
        String quote = "Hello, World!";
        value.setQuote(quote);
        assertEquals(quote, value.getQuote());
    }

    @Test
    public void testToString() {
        Long id = 123L;
        String quote = "Hello, World!";
        value.setId(id);
        value.setQuote(quote);
        String expectedString = "Value{" +
                "id=" + id +
                ", quote='" + quote + '\'' +
                '}';
        assertEquals(expectedString, value.toString());
    }
}
```

This test class covers all the getter and setter methods as well as the `toString` method of the `Value` class. The `setUp` method is used to initialize the `value` object before each test. The `testGetIdInitiallyNull` and `testGetQuoteInitiallyNull` methods ensure that the initial values of `id` and `quote` are `null`. The `testSetAndGetId` and `testSetAndGetQuote` methods test the setter and getter methods of `id` and `quote`. Finally, the `testToString` method verifies the `toString` method of the `Value` class.