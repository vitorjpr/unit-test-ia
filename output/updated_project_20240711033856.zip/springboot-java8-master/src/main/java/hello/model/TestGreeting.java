Sure, here are the JUnit tests for the Greeting class:

```java
package hello.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class GreetingTest {

    private Greeting greeting;

    @BeforeEach
    public void setUp() {
        greeting = new Greeting(1, "Hello, World!");
    }

    @Test
    public void testGetId() {
        assertEquals(1, greeting.getId(), "The ID must be 1");
    }

    @Test
    public void testGetContent() {
        assertEquals("Hello, World!", greeting.getContent(), "The content must be 'Hello, World!'");
    }
}
```

In this test class, I'm using the `@BeforeEach` annotation to create a new instance of Greeting before each test. This helps to ensure that each test is run in isolation.

The `testGetId` and `testGetContent` methods are testing the `getId` and `getContent` methods of the Greeting class, respectively. The `assertEquals` method is used to check that the expected and actual values are the same. If they're not, the test will fail and the message provided as the third argument to `assertEquals` will be printed.