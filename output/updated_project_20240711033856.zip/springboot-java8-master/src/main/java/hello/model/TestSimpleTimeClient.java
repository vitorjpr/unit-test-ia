Here are some JUnit tests for the SimpleTimeClient class:

```java
package hello.model;

import hello.declaration.TimeClient;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class SimpleTimeClientTest {
    private SimpleTimeClient client;

    @BeforeEach
    public void setup() {
        client = new SimpleTimeClient();
    }

    @Test
    public void testSetTime() {
        client.setTime(15, 30, 45);
        LocalDateTime dateTime = client.getLocalDateTime();
        assertEquals(15, dateTime.getHour());
        assertEquals(30, dateTime.getMinute());
        assertEquals(45, dateTime.getSecond());
    }

    @Test
    public void testSetDate() {
        client.setDate(15, 10, 2020);
        LocalDateTime dateTime = client.getLocalDateTime();
        assertEquals(15, dateTime.getDayOfMonth());
        assertEquals(10, dateTime.getMonthValue());
        assertEquals(2020, dateTime.getYear());
    }

    @Test
    public void testSetDateAndTime() {
        client.setDateAndTime(15, 10, 2020, 15, 30, 45);
        LocalDateTime dateTime = client.getLocalDateTime();
        assertEquals(15, dateTime.getDayOfMonth());
        assertEquals(10, dateTime.getMonthValue());
        assertEquals(2020, dateTime.getYear());
        assertEquals(15, dateTime.getHour());
        assertEquals(30, dateTime.getMinute());
        assertEquals(45, dateTime.getSecond());
    }

    @Test
    public void testToString() {
        client.setDateAndTime(15, 10, 2020, 15, 30, 45);
        String expectedString = "2020-10-15T15:30:45";
        assertEquals(expectedString, client.toString());
    }
}
```

These tests cover the main functionalities of the SimpleTimeClient class, including setting the time, date, both date and time, and converting the date and time to a string. Each test first sets the time or date, then retrieves the date and time from the client and checks if it matches the expected values.