Sure, here is a comprehensive JUnit test suite for the Customer class:

```java
package hello.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class CustomerTest {
    private Customer customer;

    @BeforeEach
    public void setUp() {
        customer = new Customer(1L, "John", "Doe");
    }

    @Test
    public void testId() {
        customer.setId(2L);
        assertEquals(2L, customer.getId());
    }

    @Test
    public void testFirstName() {
        customer.setFirstName("Jane");
        assertEquals("Jane", customer.getFirstName());
    }

    @Test
    public void testLastName() {
        customer.setLastName("Smith");
        assertEquals("Smith", customer.getLastName());
    }

    @Test
    public void testToString() {
        String expected = "Customer{id=1, firstName='John', lastName='Doe'}";
        assertEquals(expected, customer.toString());
    }
}
```

This test suite includes a test for each getter and setter method, as well as the toString method. The setUp method is used to create a new Customer object before each test, ensuring that each test is isolated and does not affect the others. The assertEquals method is used to check that the method being tested returns the expected result.