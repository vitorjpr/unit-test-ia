Here are the JUnit tests for the provided Java code:

```java
package hello.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class QuoteTest {

    private Quote quote;

    @BeforeEach
    public void setup() {
        quote = new Quote();
    }

    @Test
    public void testNewQuote() {
        assertNotNull(quote);
    }

    @Test
    public void testGetType() {
        String type = "TestType";
        quote.setType(type);
        assertEquals(type, quote.getType());
    }

    @Test
    public void testSetValue() {
        Value value = new Value();
        quote.setValue(value);
        assertEquals(value, quote.getValue());
    }

    @Test
    public void testToString() {
        String type = "TestType";
        Value value = new Value();
        quote.setType(type);
        quote.setValue(value);
        String expected = "Quote{" +
                "type='" + type + '\'' +
                ", value=" + value +
                '}';
        assertEquals(expected, quote.toString());
    }
}
```

These tests cover the basic functionality of the Quote class, including the creation of a new instance, getting and setting the type and value, and the toString method.