Here is a JUnit test class for your TimeClient interface:

```java
package hello.declaration;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class TestTimeClient {

    private TimeClient timeClient;

    @BeforeEach
    public void setup() {
        timeClient = new TimeClient() {
            private LocalDateTime localDateTime;

            @Override
            public void setTime(int hour, int minute, int second) {
                localDateTime = LocalDateTime.of(localDateTime.getYear(), localDateTime.getMonth(), localDateTime.getDayOfMonth(), hour, minute, second);
            }

            @Override
            public void setDate(int day, int month, int year) {
                localDateTime = LocalDateTime.of(year, month, day, localDateTime.getHour(), localDateTime.getMinute(), localDateTime.getSecond());
            }

            @Override
            public void setDateAndTime(int day, int month, int year, int hour, int minute, int second) {
                localDateTime = LocalDateTime.of(year, month, day, hour, minute, second);
            }

            @Override
            public LocalDateTime getLocalDateTime() {
                return localDateTime;
            }
        };
    }

    @Test
    public void testSetTime() {
        // Test setting the time
        timeClient.setTime(10, 30, 50);
        assertEquals(LocalDateTime.now().withHour(10).withMinute(30).withSecond(50).withNano(0), timeClient.getLocalDateTime());
    }

    @Test
    public void testSetDate() {
        // Test setting the date
        timeClient.setDate(15, 10, 2020);
        assertEquals(LocalDateTime.now().withDayOfMonth(15).withMonth(10).withYear(2020), timeClient.getLocalDateTime());
    }

    @Test
    public void testSetDateAndTime() {
        // Test setting the date and time
        timeClient.setDateAndTime(15, 10, 2020, 10, 30, 50);
        assertEquals(LocalDateTime.of(2020, 10, 15, 10, 30, 50), timeClient.getLocalDateTime());
    }

    @Test
    public void testGetLocalDateTime() {
        // Test getting the local date time
        assertNotNull(timeClient.getLocalDateTime());
    }

    @Test
    public void testGetZoneId() {
        // Test getting the zone id
        assertEquals(ZoneId.of("Europe/Paris"), TimeClient.getZoneId("Europe/Paris"));
    }

    @Test
    public void testGetZonedDateTime() {
        // Test getting the zoned date time
        assertNotNull(timeClient.getZonedDateTime("Europe/Paris"));
    }
}
```
Please note that since TimeClient is an interface, I've created an anonymous class in the setup method to provide the implementation for the methods. Also, the test methods for setTime, setDate, and setDateAndTime are based on the current date and time, so they may fail if the test execution takes longer than a second.