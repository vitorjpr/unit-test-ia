```java
package hello.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class TestTopic {

    private Topic topic;

    // This method is executed before each test. It is used to setup the test environment (e.g., read input data, initialize the class)
    @BeforeEach
    public void setup() {
        topic = new Topic();
    }

    // Test the setId method
    @Test
    public void testSetId() {
        String id = "1";
        topic.setId(id);
        assertEquals(id, topic.getId(), "The id must be the same as the one set");
    }

    // Test the getId method
    @Test
    public void testGetId() {
        String id = "1";
        topic.setId(id);
        assertEquals(id, topic.getId(), "The id must be the same as the one set");
    }

    // Test the setSubjectName method
    @Test
    public void testSetSubjectName() {
        String subjectName = "Math";
        topic.setSubjectName(subjectName);
        assertEquals(subjectName, topic.getSubjectName(), "The subject name must be the same as the one set");
    }

    // Test the getSubjectName method
    @Test
    public void testGetSubjectName() {
        String subjectName = "Math";
        topic.setSubjectName(subjectName);
        assertEquals(subjectName, topic.getSubjectName(), "The subject name must be the same as the one set");
    }

    // Test the setSubjectDescription method
    @Test
    public void testSetSubjectDescription() {
        String subjectDescription = "Mathematics is the study of numbers, shapes and patterns.";
        topic.setSubjectDescription(subjectDescription);
        assertEquals(subjectDescription, topic.getSubjectDescription(), "The subject description must be the same as the one set");
    }

    // Test the getSubjectDescription method
    @Test
    public void testGetSubjectDescription() {
        String subjectDescription = "Mathematics is the study of numbers, shapes and patterns.";
        topic.setSubjectDescription(subjectDescription);
        assertEquals(subjectDescription, topic.getSubjectDescription(), "The subject description must be the same as the one set");
    }

    // Test the constructor
    @Test
    public void testConstructor() {
        String id = "1";
        String subjectName = "Math";
        String subjectDescription = "Mathematics is the study of numbers, shapes and patterns.";
        Topic topic = new Topic(id, subjectName, subjectDescription);
        assertEquals(id, topic.getId(), "The id must be the same as the one set");
        assertEquals(subjectName, topic.getSubjectName(), "The subject name must be the same as the one set");
        assertEquals(subjectDescription, topic.getSubjectDescription(), "The subject description must be the same as the one set");
    }
}
```