```java
package hello.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TestCustomer {
    private Customer customer;

    // This method will be executed before each test method,
    // to set up the test environment (known as fixture)
    @BeforeEach
    public void setUp() {
        customer = new Customer(1L, "John", "Doe");
    }

    // Test the constructor and toString method
    @Test
    public void testConstructorAndToString() {
        String expected = "Customer{id=1, firstName='John', lastName='Doe'}";
        assertEquals(expected, customer.toString(), "Customer should be initialized with correct values and toString should return the correct representation");
    }

    // Test the getId method
    @Test
    public void testGetId() {
        assertEquals(1L, customer.getId(), "getId should return the correct id");
    }

    // Test the setId method
    @Test
    public void testSetId() {
        customer.setId(2L);
        assertEquals(2L, customer.getId(), "setId should correctly update the id");
    }

    // Test the getFirstName method
    @Test
    public void testGetFirstName() {
        assertEquals("John", customer.getFirstName(), "getFirstName should return the correct first name");
    }

    // Test the setFirstName method
    @Test
    public void testSetFirstName() {
        customer.setFirstName("Jane");
        assertEquals("Jane", customer.getFirstName(), "setFirstName should correctly update the first name");
    }

    // Test the getLastName method
    @Test
    public void testGetLastName() {
        assertEquals("Doe", customer.getLastName(), "getLastName should return the correct last name");
    }

    // Test the setLastName method
    @Test
    public void testSetLastName() {
        customer.setLastName("Smith");
        assertEquals("Smith", customer.getLastName(), "setLastName should correctly update the last name");
    }
}
```