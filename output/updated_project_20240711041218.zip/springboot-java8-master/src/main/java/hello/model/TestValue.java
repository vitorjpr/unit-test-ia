```java
package hello.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class TestValue {

    private Value value;

    // This method is executed before each test. It is used to setup the test environment (e.g., read input data, initialize the class)
    @BeforeEach
    public void setUp() {
        value = new Value();
    }

    // Test case for the getId method
    @Test
    public void testGetId() {
        Long expectedId = 123L;
        value.setId(expectedId);
        assertEquals(expectedId, value.getId(), "The ID returned by getId() does not match the expected value");
    }

    // Test case for the setId method
    @Test
    public void testSetId() {
        Long expectedId = 123L;
        value.setId(expectedId);
        assertEquals(expectedId, value.getId(), "The ID set by setId() does not match the expected value");
    }

    // Test case for the getQuote method
    @Test
    public void testGetQuote() {
        String expectedQuote = "Hello, World!";
        value.setQuote(expectedQuote);
        assertEquals(expectedQuote, value.getQuote(), "The quote returned by getQuote() does not match the expected value");
    }

    // Test case for the setQuote method
    @Test
    public void testSetQuote() {
        String expectedQuote = "Hello, World!";
        value.setQuote(expectedQuote);
        assertEquals(expectedQuote, value.getQuote(), "The quote set by setQuote() does not match the expected value");
    }

    // Test case for the toString method
    @Test
    public void testToString() {
        Long expectedId = 123L;
        String expectedQuote = "Hello, World!";
        value.setId(expectedId);
        value.setQuote(expectedQuote);
        String expectedString = "Value{" +
                "id=" + expectedId +
                ", quote='" + expectedQuote + '\'' +
                '}';
        assertEquals(expectedString, value.toString(), "The string returned by toString() does not match the expected value");
    }
}
```