Here is the JUnit test class for your Java code:

```java
package hello.model;

import hello.declaration.TimeClient;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class TestSimpleTimeClient {
    private SimpleTimeClient simpleTimeClient;

    @BeforeEach
    public void setup() {
        simpleTimeClient = new SimpleTimeClient();
    }

    // Test to check if setTime method sets the time correctly
    @Test
    public void testSetTime() {
        simpleTimeClient.setTime(10, 30, 45);
        LocalDateTime dateTime = simpleTimeClient.getLocalDateTime();
        assertEquals(10, dateTime.getHour());
        assertEquals(30, dateTime.getMinute());
        assertEquals(45, dateTime.getSecond());
    }

    // Test to check if setDate method sets the date correctly
    @Test
    public void testSetDate() {
        simpleTimeClient.setDate(15, 8, 2022);
        LocalDateTime dateTime = simpleTimeClient.getLocalDateTime();
        assertEquals(15, dateTime.getDayOfMonth());
        assertEquals(8, dateTime.getMonthValue());
        assertEquals(2022, dateTime.getYear());
    }

    // Test to check if setDateAndTime method sets the date and time correctly
    @Test
    public void testSetDateAndTime() {
        simpleTimeClient.setDateAndTime(15, 8, 2022, 10, 30, 45);
        LocalDateTime dateTime = simpleTimeClient.getLocalDateTime();
        assertEquals(15, dateTime.getDayOfMonth());
        assertEquals(8, dateTime.getMonthValue());
        assertEquals(2022, dateTime.getYear());
        assertEquals(10, dateTime.getHour());
        assertEquals(30, dateTime.getMinute());
        assertEquals(45, dateTime.getSecond());
    }

    // Test to check if getLocalDateTime method returns the correct date and time
    @Test
    public void testGetLocalDateTime() {
        simpleTimeClient.setDateAndTime(15, 8, 2022, 10, 30, 45);
        LocalDateTime dateTime = simpleTimeClient.getLocalDateTime();
        assertEquals(LocalDateTime.of(15, 8, 2022, 10, 30, 45), dateTime);
    }
}
```

This test class includes a setup method to initialize the `SimpleTimeClient` object before each test. It also includes a test method for each public method in the `SimpleTimeClient` class. Each test method uses the JUnit `assertEquals` method to verify that the method being tested produces the expected result.