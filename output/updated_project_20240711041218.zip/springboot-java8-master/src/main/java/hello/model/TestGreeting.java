```java
package hello.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class TestGreeting {
    private Greeting greeting;

    // This method is executed before each test. It is used to setup the test environment (e.g., read input data, initialize the class).
    @BeforeEach
    public void setUp() {
        greeting = new Greeting(1L, "Hello, World!");
    }

    // Test method for 'hello.model.Greeting.getId()'
    @Test
    public void testGetId() {
        // Assert that the expected id matches the actual id.
        assertEquals(1L, greeting.getId(), "The id should be 1");
    }

    // Test method for 'hello.model.Greeting.getContent()'
    @Test
    public void testGetContent() {
        // Assert that the expected content matches the actual content.
        assertEquals("Hello, World!", greeting.getContent(), "The content should be 'Hello, World!'");
    }
}
```