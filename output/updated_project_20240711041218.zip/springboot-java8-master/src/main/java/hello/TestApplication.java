```java
package hello;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.client.RestTemplate;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.*;

public class TestApplication {

    @InjectMocks
    Application application;

    @Mock
    JdbcTemplate jdbcTemplate;

    @Mock
    RestTemplateBuilder restTemplateBuilder;

    @Mock
    RestTemplate restTemplate;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.initMocks(this);
    }

    // Test for restTemplate Bean
    @Test
    public void restTemplateTest() {
        when(restTemplateBuilder.build()).thenReturn(restTemplate);
        RestTemplate result = application.restTemplate(restTemplateBuilder);
        assertNotNull(result);
    }

    // Test for run Bean
    @Test
    public void runBeanTest() throws Exception {
        assertNotNull(application.run(restTemplate));
    }

    // Test for run method
    @Test
    public void runTest() throws Exception {
        doNothing().when(jdbcTemplate).execute(anyString());
        doNothing().when(jdbcTemplate).batchUpdate(anyString(), anyList());
        when(jdbcTemplate.query(anyString(), any(), any())).thenReturn(null);
        application.run();
        verify(jdbcTemplate, times(2)).execute(anyString());
        verify(jdbcTemplate, times(1)).batchUpdate(anyString(), anyList());
        verify(jdbcTemplate, times(1)).query(anyString(), any(), any());
    }
}
```
This test class uses Mockito to mock dependencies and verify interactions. It tests the `restTemplate` and `run` beans, as well as the `run` method. The `main` method is not tested because it is static and involves system-level interactions that are not suitable for unit testing.