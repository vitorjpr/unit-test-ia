```java
package hello.controller;

import hello.model.Greeting;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@SpringBootTest
public class TestGreetingController {

    @Autowired
    private GreetingController greetingController;

    @MockBean
    private Greeting greeting;

    private String name = "Test";
    private String template = "Hello, %s!";
    private long counter = 1;

    @BeforeEach
    public void setup() {
        when(greeting.getId()).thenReturn(counter);
        when(greeting.getContent()).thenReturn(String.format(template, name));
    }

    // Test method for greeting method in GreetingController
    @Test
    public void testGreeting() {
        // Mocking the request parameter
        @RequestParam(value="name", defaultValue="World") String name = "Test";

        // Call the method to test
        Greeting result = greetingController.greeting(name);

        // Assert the results
        assertEquals(counter, result.getId());
        assertEquals(String.format(template, name), result.getContent());
    }
}
```
Please note that this test class assumes that you have a mock setup for the `Greeting` class. If you don't have one, you might need to create it or adjust the test accordingly. Also, this test is using Spring Boot's `@SpringBootTest` annotation for integration testing. If you want to do a unit test, you might need to adjust the test setup.