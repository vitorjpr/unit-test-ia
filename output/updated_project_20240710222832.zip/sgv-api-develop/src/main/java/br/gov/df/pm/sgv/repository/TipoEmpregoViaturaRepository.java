package br.gov.df.pm.sgv.repository;

import br.gov.df.pm.sgv.domain.TipoEmpregoViaturaEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface TipoEmpregoViaturaRepository extends JpaRepository<TipoEmpregoViaturaEntity, Integer> {

	public List<TipoEmpregoViaturaEntity> findByAtivo(int i);

	public TipoEmpregoViaturaEntity getOne(Integer id);

	public Optional<TipoEmpregoViaturaEntity> findByNomeIgnoreCase(String nome);


}
