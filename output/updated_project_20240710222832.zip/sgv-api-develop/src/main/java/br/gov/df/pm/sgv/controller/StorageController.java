package br.gov.df.pm.sgv.controller;

import br.gov.df.pm.sgv.service.StorageService;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;


import java.util.UUID;

@RestController
@RequestMapping("/storage")
public class StorageController {

    @Autowired
    private StorageService storageService;

    @GetMapping("/{id}")
    @ResponseBody
    public ResponseEntity<Resource> getFile(@PathVariable("id") UUID id) {
     return storageService.baixarImagemAI(id);
    }

    @PostMapping(consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<UUID> sendFile(@RequestPart("arquivo") @Schema(type = "file") MultipartFile arquivo) {
        return storageService.salvarImagem(arquivo);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteFile(@PathVariable("id") UUID id) {
        storageService.removerImagem(id);
        return ResponseEntity.ok("Arquivo excluído com sucesso");
    }
}
