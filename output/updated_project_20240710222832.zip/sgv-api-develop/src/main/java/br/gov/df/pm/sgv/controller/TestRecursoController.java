Here are the unit tests for the provided Java code:

```java
package br.gov.df.pm.sgv.controller;

import br.gov.df.pm.sgv.dto.root.RecursoDTO;
import br.gov.df.pm.sgv.repository.sgpol.RecursoRepository;
import br.gov.df.pm.sgv.security.UserProvider;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import static org.junit.jupiter.api.Assertions.assertEquals;

class RecursoControllerTest {

    private RecursoController recursoController;

    @Mock
    private UserProvider userProvider;

    @Mock
    private RecursoRepository repository;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        recursoController = new RecursoController();
        recursoController.userProvider = userProvider;
        recursoController.repository = repository;
    }

    @Test
    void testFindRecursosLogado() {
        List<RecursoDTO> recursos = Arrays.asList(
                new RecursoDTO("Recurso1"),
                new RecursoDTO("Recurso2")
        );

        Mockito.when(userProvider.getRecursosPolicialAutenticado()).thenReturn(recursos);

        List<String> expected = Arrays.asList("Recurso1", "Recurso2");
        List<String> result = recursoController.findRecursosLogado();

        assertEquals(expected, result);
    }
}
```

In this unit test class, we use Mockito to mock the dependencies `UserProvider` and `RecursoRepository`. We then test the `findRecursosLogado` method of the `RecursoController` class by mocking the behavior of `userProvider.getRecursosPolicialAutenticado()` to return a list of `RecursoDTO` objects. The test checks if the method properly maps the names of the `RecursoDTO` objects and collects them into a list of strings.

Make sure to include the necessary dependencies for Mockito in your project to run these tests successfully.