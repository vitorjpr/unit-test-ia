```java
package br.gov.df.pm.sgv.configurations;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import org.junit.jupiter.api.Test;
import org.springdoc.core.GroupedOpenApi;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class SwaggerConfigTest {

    @Test
    public void testGreetingApi() {
        SwaggerConfig swaggerConfig = new SwaggerConfig();
        GroupedOpenApi groupedOpenApi = swaggerConfig.greetingApi();

        assertEquals("vistoria-api", groupedOpenApi.getGroup());
        assertEquals(2, groupedOpenApi.getPathsToMatch().length);
        assertEquals("/**", groupedOpenApi.getPathsToMatch()[0]);
        assertEquals("/vistoria/**", groupedOpenApi.getPathsToMatch()[1]);
    }

    @Test
    public void testMetaData() {
        SwaggerConfig swaggerConfig = new SwaggerConfig();
        OpenAPI openAPI = swaggerConfig.metaData();

        assertEquals("API VISTORIA", openAPI.getInfo().getTitle());
        assertEquals("API VISTORIA", openAPI.getInfo().getDescription());
        assertEquals("V1", openAPI.getInfo().getVersion());
    }
}
``` 

Esses são testes unitários para a classe `SwaggerConfig`. Eles verificam se o método `greetingApi()` retorna um `GroupedOpenApi` com os paths corretos e se o método `metaData()` retorna um `OpenAPI` com as informações corretas. Certifique-se de adicionar as dependências necessárias para os testes JUnit em seu projeto.