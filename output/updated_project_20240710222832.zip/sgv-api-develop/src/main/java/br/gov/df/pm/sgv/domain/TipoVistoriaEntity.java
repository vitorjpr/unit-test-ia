package br.gov.df.pm.sgv.domain;

import lombok.*;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDate;

@Entity
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(of = "id")
@Table(name = "TIPOVISTORIA", schema = "sgv")
public class TipoVistoriaEntity implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "tiv_Codigo", unique = true, nullable = false)
    private Long id;

    @Column(name = "tiv_Nome")
    private String nome;

    @Column(name = "tiv_Descricao")
    private String descricao;

    @Column(name = "tiv_StatusAnterior")
    private String statusAnterior;

    @Column(name = "tiv_StatusPosterior")
    private String statusPosterior;

    @Column(name = "tiv_ativo")
    private Boolean ativo;

    @DateTimeFormat(pattern="dd/MM/yyyy")
    @Column(name = "tiv_DtInclusao")
    private LocalDate dataInclusao;
}
