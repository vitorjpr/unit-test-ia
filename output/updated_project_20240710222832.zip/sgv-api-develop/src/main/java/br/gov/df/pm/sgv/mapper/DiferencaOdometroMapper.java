package br.gov.df.pm.sgv.mapper;

import br.gov.df.pm.sgv.domain.DiferencaOdometroEntity;
import br.gov.df.pm.sgv.dto.DiferencaOdometroDTO;

public class DiferencaOdometroMapper {
    public DiferencaOdometroEntity convertEntity(DiferencaOdometroDTO diferencaOdometro) {
        return DiferencaOdometroEntity.builder()
                .referenciaInicial(diferencaOdometro.getReferenciaInicial())
                .referenciaFinal(diferencaOdometro.getReferenciaFinal())
                .diferencaOdometro(diferencaOdometro.getDiferencaOdometro())
                .dataModificacao(diferencaOdometro.getDataModificacao())
                .dataInclusao(diferencaOdometro.getDataInclusao())
                .build();
    }

    public DiferencaOdometroDTO convertDTO(DiferencaOdometroEntity diferencaOdometro) {
        return DiferencaOdometroDTO.builder()
                .referenciaInicial(diferencaOdometro.getReferenciaInicial())
                .referenciaFinal(diferencaOdometro.getReferenciaFinal())
                .diferencaOdometro(diferencaOdometro.getDiferencaOdometro())
                .dataModificacao(diferencaOdometro.getDataModificacao())
                .dataInclusao(diferencaOdometro.getDataInclusao())
                .build();
    }
}
