Here are the unit tests for the `TipoEmpregoMapper` class:

```java
package br.gov.df.pm.sgv.mapper;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

import br.gov.df.pm.sgv.domain.TipoEmpregoViaturaEntity;
import br.gov.df.pm.sgv.dto.TipoEmpregoViaturaDto;

public class TipoEmpregoMapperTest {

    @Test
    public void testConvertEntity() {
        TipoEmpregoViaturaDto dto = TipoEmpregoViaturaDto.builder()
                .ativo(true)
                .id(1L)
                .nome("Teste")
                .build();

        TipoEmpregoMapper mapper = new TipoEmpregoMapper();
        TipoEmpregoViaturaEntity entity = mapper.convertEntity(dto);

        assertEquals(dto.getAtivo(), entity.getAtivo());
        assertEquals(dto.getId(), entity.getId());
        assertEquals(dto.getNome(), entity.getNome());
    }

    @Test
    public void testConvertDTO() {
        TipoEmpregoViaturaEntity entity = TipoEmpregoViaturaEntity.builder()
                .ativo(true)
                .id(1L)
                .nome("Teste")
                .build();

        TipoEmpregoMapper mapper = new TipoEmpregoMapper();
        TipoEmpregoViaturaDto dto = mapper.convertDTO(entity);

        assertEquals(entity.getAtivo(), dto.getAtivo());
        assertEquals(entity.getId(), dto.getId());
        assertEquals(entity.getNome(), dto.getNome());
    }
}
```

These unit tests cover the conversion methods `convertEntity` and `convertDTO` of the `TipoEmpregoMapper` class. The tests ensure that the conversion between `TipoEmpregoViaturaEntity` and `TipoEmpregoViaturaDto` is done correctly by comparing the attributes of the input and output objects.