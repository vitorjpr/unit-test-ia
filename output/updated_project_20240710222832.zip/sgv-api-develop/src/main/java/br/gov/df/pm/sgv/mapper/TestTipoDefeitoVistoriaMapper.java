Here are some unit tests for the `TipoDefeitoVistoriaMapper` class:

```java
package br.gov.df.pm.sgv.mapper;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Test;

import br.gov.df.pm.sgv.domain.TipoDefeitoVistoriaEntity;
import br.gov.df.pm.sgv.dto.TipoDefeitoVistoriaDTO;

public class TipoDefeitoVistoriaMapperTest {

    @Test
    public void testConvertEntity() {
        TipoDefeitoVistoriaDTO dto = new TipoDefeitoVistoriaDTO("Nome", "Descrição", "01-01-2022", true);
        TipoDefeitoVistoriaMapper mapper = new TipoDefeitoVistoriaMapper();
        TipoDefeitoVistoriaEntity entity = mapper.convertEntity(dto);

        assertNotNull(entity);
        assertEquals(dto.getNome(), entity.getNome());
        assertEquals(dto.getDescricao(), entity.getDescricao());
        assertEquals(dto.getDataInclusao(), entity.getDataInclusao());
        assertEquals(dto.getAtivo(), entity.getAtivo());
    }

    @Test
    public void testConvertDTO() {
        TipoDefeitoVistoriaEntity entity = new TipoDefeitoVistoriaEntity("Nome", "Descrição", "01-01-2022", true, 1L);
        TipoDefeitoVistoriaMapper mapper = new TipoDefeitoVistoriaMapper();
        TipoDefeitoVistoriaDTO dto = mapper.convertDTO(entity);

        assertNotNull(dto);
        assertEquals(entity.getNome(), dto.getNome());
        assertEquals(entity.getDescricao(), dto.getDescricao());
        assertEquals(entity.getDataInclusao(), dto.getDataInclusao());
        assertEquals(entity.getAtivo(), dto.getAtivo());
        assertEquals(entity.getId(), dto.getId());
    }
}
```

These tests cover the conversion methods `convertEntity` and `convertDTO` of the `TipoDefeitoVistoriaMapper` class. The tests ensure that the conversion is done correctly and that the properties are mapped correctly between the DTO and Entity objects.