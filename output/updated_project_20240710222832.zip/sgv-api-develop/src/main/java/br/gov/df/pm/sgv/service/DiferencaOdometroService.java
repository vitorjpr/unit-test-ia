package br.gov.df.pm.sgv.service;

import br.gov.df.pm.sgv.domain.DiferencaOdometroEntity;
import br.gov.df.pm.sgv.domain.TipoVistoriaEntity;
import br.gov.df.pm.sgv.dto.DiferencaOdometroDTO;
import br.gov.df.pm.sgv.dto.DiferencaDTO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;

import java.util.List;

public interface DiferencaOdometroService {
    ResponseEntity<DiferencaOdometroDTO> buscarId(Long id);
    Page<DiferencaOdometroEntity> buscar(String filter, Pageable pageable);
    ResponseEntity<DiferencaOdometroDTO> salvar(DiferencaOdometroDTO itemVistoriaDTO);
    ResponseEntity<?> editar(Long id, DiferencaOdometroDTO edicao);
    ResponseEntity<?> excluir(Long id);
    ResponseEntity<?> desativar(Long id);
    ResponseEntity<?> ativar(Long id);
    ResponseEntity<List<TipoVistoriaEntity>> findAllTipoVistoria();
    DiferencaOdometroDTO buscarDiferenca(DiferencaDTO diferencaDTO);
}
