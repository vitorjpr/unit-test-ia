```java
package br.gov.df.pm.sgv.feign;

import feign.Response;
import feign.Util;
import feign.codec.ErrorDecoder;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class FeignSkipExceptionConfigurationTest {

    private FeignSkipExceptionConfiguration feignSkipExceptionConfiguration;

    @BeforeEach
    public void setup() {
        feignSkipExceptionConfiguration = new FeignSkipExceptionConfiguration();
    }

    @Test
    public void testErrorDecoderBadRequestWithNoBody() {
        ErrorDecoder errorDecoder = feignSkipExceptionConfiguration.errorDecoder();
        Response response = mock(Response.class);
        when(response.status()).thenReturn(HttpStatus.BAD_REQUEST.value());
        when(response.body()).thenReturn(null);

        ResponseStatusException exception = assertThrows(ResponseStatusException.class,
                () -> errorDecoder.decode("", response));

        assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
        assertEquals("Verifique o corpo da Requisição, dados recebidos inválidos.", exception.getReason());
    }

    @Test
    public void testErrorDecoderWithBody() {
        ErrorDecoder errorDecoder = feignSkipExceptionConfiguration.errorDecoder();
        Response response = mock(Response.class);
        when(response.status()).thenReturn(HttpStatus.INTERNAL_SERVER_ERROR.value());
        when(response.body()).thenReturn(Response.Body.empty());

        ResponseStatusException exception = assertThrows(ResponseStatusException.class,
                () -> errorDecoder.decode("", response));

        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, exception.getStatus());
        assertEquals("", exception.getReason());
    }

    @Test
    public void testGetResponseBodyAsStringWithNonNullBody() {
        Response.Body body = mock(Response.Body.class);
        when(body.asReader()).thenReturn(Util.emptyReader());

        String responseBody = feignSkipExceptionConfiguration.getResponseBodyAsString(body);

        assertEquals("", responseBody);
    }

    @Test
    public void testGetResponseBodyAsStringWithNullBody() {
        String responseBody = feignSkipExceptionConfiguration.getResponseBodyAsString(null);

        assertEquals(null, responseBody);
    }
}
``` 

Esses são testes abrangentes para a classe `FeignSkipExceptionConfiguration`. Eles cobrem a lógica do método `errorDecoder` e `getResponseBodyAsString`, garantindo que o comportamento esperado seja verificado. Certifique-se de ter as dependências corretas para JUnit e Mockito em seu projeto.