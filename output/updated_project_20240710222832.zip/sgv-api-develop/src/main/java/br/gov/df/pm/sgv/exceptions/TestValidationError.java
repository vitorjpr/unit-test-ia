Sure! Here are some unit tests for the `ValidationError` class:

```java
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class ValidationErrorTest {

    @Test
    public void testConstructorWithMessage() {
        String message = "Validation error message";
        ValidationError error = new ValidationError(message);
        assertEquals(message, error.getMessage());
    }

    @Test
    public void testConstructorWithEmptyMessage() {
        ValidationError error = new ValidationError("");
        assertEquals("", error.getMessage());
    }

    @Test
    public void testConstructorWithNullMessage() {
        ValidationError error = new ValidationError(null);
        assertEquals(null, error.getMessage());
    }
}
```

These tests cover the constructor behavior for `ValidationError` when passing a non-empty message, an empty message, and a `null` message.