Here are the unit tests for the provided Java code:

```java
package br.gov.df.pm.sgv.assembler;

import br.gov.df.pm.sgv.dto.ItemVistoriaDTO;
import br.gov.df.pm.sgv.domain.ItemVistoriaEntity;
import org.junit.jupiter.api.Test;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.RepresentationModelAssembler;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class ItemVistoriaAssemblerTest {

    private final ItemVistoriaAssembler assembler = new ItemVistoriaAssembler();

    @Test
    public void testToModel() {
        // Given
        ItemVistoriaEntity entity = new ItemVistoriaEntity(1L, "Teste", "Descrição", LocalDateTime.now(), true);

        // When
        EntityModel<ItemVistoriaDTO> model = assembler.toModel(entity);

        // Then
        assertNotNull(model, "Model should not be null");
        ItemVistoriaDTO dto = model.getContent();
        assertNotNull(dto, "DTO should not be null");
        assertEquals(entity.getId(), dto.getId(), "ID should match");
        assertEquals(entity.getNome(), dto.getNome(), "Nome should match");
        assertEquals(entity.getDescricao(), dto.getDescricao(), "Descrição should match");
        assertEquals(entity.getDataInclusao(), dto.getDataInclusao(), "Data de inclusão should match");
        assertEquals(entity.getAtivo(), dto.isAtivo(), "Ativo should match");
    }
}
```

Make sure to include the necessary imports for the test class. These tests cover the `toModel` method of the `ItemVistoriaAssembler` class by creating a mock `ItemVistoriaEntity` instance, calling the method, and then asserting the correctness of the generated `EntityModel<ItemVistoriaDTO>`.