```java
package br.gov.df.pm.sgv.service.impl;

import br.gov.df.pm.sgv.dto.EdicaoTipoDefeitoVistoriaDTO;
import br.gov.df.pm.sgv.dto.TipoDefeitoVistoriaDTO;
import br.gov.df.pm.sgv.domain.TipoDefeitoVistoriaEntity;
import br.gov.df.pm.sgv.exceptions.TipoDefeitoVistoriaException;
import br.gov.df.pm.sgv.exceptions.VistoriaExceptions;
import br.gov.df.pm.sgv.mapper.TipoDefeitoVistoriaMapper;
import br.gov.df.pm.sgv.repository.DefeitosVistoriaRepository;
import br.gov.df.pm.sgv.repository.TipoDefeitoVistoriaRepository;
import br.gov.df.pm.sgv.shared.utils.StringUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class TipoDefeitoVistoriaServiceImplTest {

    @Mock
    private TipoDefeitoVistoriaRepository tipoDefeitoVistoriaRepository;

    @Mock
    private DefeitosVistoriaRepository defeitosVistoriaRepository;

    @InjectMocks
    private TipoDefeitoVistoriaServiceImpl tipoDefeitoVistoriaService;

    private TipoDefeitoVistoriaEntity tipoDefeitoVistoriaEntity;

    @BeforeEach
    void setUp() {
        tipoDefeitoVistoriaEntity = new TipoDefeitoVistoriaEntity();
        tipoDefeitoVistoriaEntity.setId(1L);
        tipoDefeitoVistoriaEntity.setNome("Teste");
        tipoDefeitoVistoriaEntity.setDescricao("Descrição de teste");
        tipoDefeitoVistoriaEntity.setAtivo(true);
    }

    @Test
    void testBuscarId() {
        when(tipoDefeitoVistoriaRepository.findById(1L)).thenReturn(java.util.Optional.of(tipoDefeitoVistoriaEntity));

        ResponseEntity<TipoDefeitoVistoriaDTO> response = tipoDefeitoVistoriaService.buscarId(1L);

        assertNotNull(response.getBody());
        assertEquals(1L, response.getBody().getId());
        assertEquals("Teste", response.getBody().getNome());
        assertEquals("Descrição de teste", response.getBody().getDescricao());
    }

    @Test
    void testBuscar() {
        Pageable pageable = Pageable.unpaged();
        when(tipoDefeitoVistoriaRepository.findAll(any(), eq(pageable))).thenReturn(Page.empty());

        Page<TipoDefeitoVistoriaEntity> result = tipoDefeitoVistoriaService.buscar("filtro", pageable);

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    // Add tests for other methods

}
```

Este é um exemplo de teste unitário para a classe `TipoDefeitoVistoriaServiceImpl`. Você pode adicionar mais testes para os outros métodos da classe seguindo a mesma estrutura. Certifique-se de adicionar os testes para os casos de sucesso e também para os casos de exceção lançados pela classe.