package br.gov.df.pm.sgv.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Data
@AllArgsConstructor
@Builder
public class TipoEmpregoViaturaDto {

    private Integer id;
    private String nome;
    private Integer ativo;
}
