Here are some unit tests for the `VistoriaService` interface:

```java
package br.gov.df.pm.sgv.service;

import br.gov.df.pm.sgv.domain.ChecklistVistoriaEntity;
import br.gov.df.pm.sgv.domain.VistoriaViaturaEntity;
import br.gov.df.pm.sgv.dto.FiltroVistoria;
import org.junit.jupiter.api.Test;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;

class VistoriaServiceTest {

    private VistoriaService vistoriaService;

    @Test
    void buscarTest() {
        FiltroVistoria filtro = mock(FiltroVistoria.class);
        Pageable pageable = mock(Pageable.class);

        Page<VistoriaViaturaEntity> result = vistoriaService.buscar(filtro, pageable);

        assertNotNull(result);
    }

    @Test
    void vistoriaByViaturaTest() {
        Long viaturaId = 1L;

        ResponseEntity<VistoriaViaturaEntity> result = vistoriaService.vistoriaByViatura(viaturaId);

        assertNotNull(result);
    }

    @Test
    void salvarTest() {
        String vistoria = "Test";
        List<MultipartFile> arquivos = mock(List.class);

        ResponseEntity<VistoriaViaturaEntity> result = vistoriaService.salvar(vistoria, arquivos);

        assertNotNull(result);
    }

    // Add tests for other methods in VistoriaService interface as needed
}
```

These tests cover the basic functionality of the methods in the `VistoriaService` interface. You can add more tests to cover edge cases or specific scenarios for each method. Make sure to use mocking frameworks like Mockito to mock dependencies and isolate the unit tests.