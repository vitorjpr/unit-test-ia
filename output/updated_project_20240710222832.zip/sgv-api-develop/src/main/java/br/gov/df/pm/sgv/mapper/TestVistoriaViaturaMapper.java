Here are some unit tests for the `VistoriaViaturaMapper` class:

```java
package br.gov.df.pm.sgv.mapper;

import br.gov.df.pm.sgv.domain.VistoriaViaturaEntity;
import br.gov.df.pm.sgv.domain.enums.VistoriaViaturaStatusEnum;
import br.gov.df.pm.sgv.dto.VistoriaDTO;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
import java.util.Collections;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class VistoriaViaturaMapperTest {

    @Test
    public void testConvertEntity() {
        VistoriaDTO vistoriaDTO = new VistoriaDTO();
        vistoriaDTO.setId(1L);
        vistoriaDTO.setViatura("ViaturaTest");
        vistoriaDTO.setTipoVistoria("TipoTest");
        vistoriaDTO.setVistoriaViaturaHistorico("HistoricoTest");
        vistoriaDTO.setDataVistoria(LocalDateTime.now());
        vistoriaDTO.setDiferencaVistoria(10);
        vistoriaDTO.setDiferencaOdometro(100);
        vistoriaDTO.setOdometroInicial(5000);
        vistoriaDTO.setOdometroFinal(5100);
        vistoriaDTO.setVistoriaArquivoList(Collections.emptyList());

        VistoriaViaturaEntity entity = new VistoriaViaturaMapper().convertEntity(vistoriaDTO);

        assertEquals(vistoriaDTO.getId(), entity.getId());
        assertEquals(vistoriaDTO.getViatura(), entity.getViatura());
        assertEquals(vistoriaDTO.getTipoVistoria(), entity.getTipoVistoria());
        assertEquals(vistoriaDTO.getVistoriaViaturaHistorico(), entity.getVistoriaViaturaHistorico());
        assertEquals(VistoriaViaturaStatusEnum.EM_VISTORIA, entity.getStatus());
        assertEquals(vistoriaDTO.getDataVistoria(), entity.getDataVistoria());
        assertEquals(vistoriaDTO.getDiferencaVistoria(), entity.getDiferencaVistoria());
        assertEquals(vistoriaDTO.getDiferencaOdometro(), entity.getDiferencaOdometro());
        assertEquals(vistoriaDTO.getOdometroInicial(), entity.getOdometroInicial());
        assertEquals(vistoriaDTO.getOdometroFinal(), entity.getOdometroFinal());
        assertEquals(vistoriaDTO.getVistoriaArquivoList(), entity.getVistoriaArquivoList());
    }

    @Test
    public void testConvertDTO() {
        VistoriaViaturaEntity entity = new VistoriaViaturaEntity();
        entity.setId(1L);
        entity.setViatura("ViaturaTest");
        entity.setTipoVistoria("TipoTest");
        entity.setVistoriaViaturaHistorico("HistoricoTest");
        entity.setDataVistoria(LocalDateTime.now());
        entity.setDiferencaVistoria(10);
        entity.setDiferencaOdometro(100);
        entity.setOdometroInicial(5000);
        entity.setOdometroFinal(5100);
        entity.setVistoriaArquivoList(Collections.emptyList());
        entity.setStatus(VistoriaViaturaStatusEnum.EM_VISTORIA);

        VistoriaDTO vistoriaDTO = new VistoriaViaturaMapper().convertDTO(entity);

        assertEquals(entity.getId(), vistoriaDTO.getId());
        assertEquals(entity.getViatura(), vistoriaDTO.getViatura());
        assertEquals(entity.getTipoVistoria(), vistoriaDTO.getTipoVistoria());
        assertEquals(entity.getVistoriaViaturaHistorico(), vistoriaDTO.getVistoriaViaturaHistorico());
        assertEquals(entity.getDataVistoria(), vistoriaDTO.getDataVistoria());
        assertEquals(entity.getDiferencaOdometro(), vistoriaDTO.getDiferencaOdometro());
        assertEquals(entity.getDiferencaVistoria(), vistoriaDTO.getDiferencaVistoria());
        assertEquals(entity.getOdometroFinal(), vistoriaDTO.getOdometroFinal());
        assertEquals(entity.getOdometroInicial(), vistoriaDTO.getOdometroInicial());
        assertEquals(entity.getVistoriaArquivoList(), vistoriaDTO.getVistoriaArquivoList());
        assertEquals(entity.getStatus(), vistoriaDTO.getStatus());
    }
}
```

These tests cover the `convertEntity` and `convertDTO` methods of the `VistoriaViaturaMapper` class, ensuring that the mapping between `VistoriaDTO` and `VistoriaViaturaEntity` is correct.