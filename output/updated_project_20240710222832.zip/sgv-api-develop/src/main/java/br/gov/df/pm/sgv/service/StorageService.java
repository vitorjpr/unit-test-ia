package br.gov.df.pm.sgv.service;

import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.util.DefaultUriBuilderFactory;
import org.springframework.http.MediaType;
import java.util.UUID;
import org.springframework.core.io.Resource;


@Service
public interface StorageService {

    ResponseEntity<UUID> salvarImagem(MultipartFile arquivoImagem);
    ResponseEntity<Resource> baixarImagemAI(UUID id);
    void removerImagem(UUID idImagem) throws RestClientException;

}
