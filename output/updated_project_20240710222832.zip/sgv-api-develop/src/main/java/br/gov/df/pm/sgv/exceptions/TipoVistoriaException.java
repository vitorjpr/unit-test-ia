package br.gov.df.pm.sgv.exceptions;

public class TipoVistoriaException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public TipoVistoriaException() {
    }

    public TipoVistoriaException(String message) {
        super(message);
    }

    public TipoVistoriaException(String message, Throwable cause) {
        super(message, cause);
    }
}