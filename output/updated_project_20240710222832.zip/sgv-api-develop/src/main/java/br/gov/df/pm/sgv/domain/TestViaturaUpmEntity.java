Here are some unit tests for the provided Java code using JUnit 5:

```java
package br.gov.df.pm.sgv.domain;

import br.gov.df.pm.sgv.domain.sgpol.UnidadePolicialMilitar;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;
import java.util.Date;

public class ViaturaUpmEntityTest {

    @Test
    public void testGetSetId() {
        ViaturaUpmEntity viaturaUpmEntity = new ViaturaUpmEntity();
        viaturaUpmEntity.setId(1);
        assertEquals(1, viaturaUpmEntity.getId());
    }

    @Test
    public void testGetSetViatura() {
        ViaturaEntity viatura = new ViaturaEntity();
        ViaturaUpmEntity viaturaUpmEntity = new ViaturaUpmEntity();
        viaturaUpmEntity.setViatura(viatura);
        assertEquals(viatura, viaturaUpmEntity.getViatura());
    }

    @Test
    public void testGetSetUpmCodigo() {
        UnidadePolicialMilitar upm = new UnidadePolicialMilitar();
        ViaturaUpmEntity viaturaUpmEntity = new ViaturaUpmEntity();
        viaturaUpmEntity.setUpmCodigo(upm);
        assertEquals(upm, viaturaUpmEntity.getUpmCodigo());
    }

    // Add more tests for other properties and methods as needed
}
```

In the tests above, we are testing the getter and setter methods for the `id`, `viatura`, and `upmCodigo` properties of the `ViaturaUpmEntity` class. You can add more tests for other properties and methods as needed to ensure comprehensive test coverage.