```java
package br.gov.df.pm.sgv.repository;

import br.gov.df.pm.sgv.domain.ItemVistoriaEntity;
import br.gov.df.pm.sgv.domain.SubitemVistoriaEntity;
import br.gov.df.pm.sgv.domain.SubitensVistoriaEntity;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@SpringBootTest
public class SubitensVistoriaRepositoryTest {

    @InjectMocks
    private SubitensVistoriaRepository subitensVistoriaRepository;

    @Mock
    private JpaRepository<SubitensVistoriaEntity, Long> jpaRepository;

    @Test
    public void testFindAllByCodSubitem() {
        SubitemVistoriaEntity subitem = new SubitemVistoriaEntity();
        List<SubitensVistoriaEntity> expectedList = new ArrayList<>();
        when(jpaRepository.findAllByCodSubitem(subitem)).thenReturn(expectedList);

        List<SubitensVistoriaEntity> resultList = subitensVistoriaRepository.findAllByCodSubitem(subitem);

        assertEquals(expectedList, resultList);
    }

    @Test
    public void testFindAllByCodItem() {
        ItemVistoriaEntity item = new ItemVistoriaEntity();
        List<SubitensVistoriaEntity> expectedList = new ArrayList<>();
        when(jpaRepository.findAllByCodItem(item)).thenReturn(expectedList);

        List<SubitensVistoriaEntity> resultList = subitensVistoriaRepository.findAllByCodItem(item);

        assertEquals(expectedList, resultList);
    }

    @Test
    public void testFindByCodItemAndCodSubitem() {
        ItemVistoriaEntity item = new ItemVistoriaEntity();
        SubitemVistoriaEntity subitem = new SubitemVistoriaEntity();
        Optional<SubitensVistoriaEntity> expectedEntity = Optional.of(new SubitensVistoriaEntity());
        when(jpaRepository.findByCodItemAndCodSubitem(item, subitem)).thenReturn(expectedEntity);

        Optional<SubitensVistoriaEntity> resultEntity = subitensVistoriaRepository.findByCodItemAndCodSubitem(item, subitem);

        assertEquals(expectedEntity, resultEntity);
    }

    @Test
    public void testFindAllByCodItemAndAtivo() {
        ItemVistoriaEntity item = new ItemVistoriaEntity();
        Boolean ativo = true;
        List<SubitensVistoriaEntity> expectedList = new ArrayList<>();
        when(jpaRepository.findAllByCodItemAndAtivo(item, ativo)).thenReturn(expectedList);

        List<SubitensVistoriaEntity> resultList = subitensVistoriaRepository.findAllByCodItemAndAtivo(item, ativo);

        assertEquals(expectedList, resultList);
    }
}
``` 

Este é um exemplo de teste unitário para a classe `SubitensVistoriaRepository`. Certifique-se de ajustar os testes de acordo com a lógica específica do seu projeto e adicionar mais casos de teste se necessário.