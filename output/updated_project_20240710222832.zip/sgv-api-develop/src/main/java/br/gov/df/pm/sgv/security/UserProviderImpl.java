package br.gov.df.pm.sgv.security;

import br.gov.df.pm.sgv.domain.sgpol.Policial;
import br.gov.df.pm.sgv.domain.sgpol.UnidadePolicialMilitar;
import br.gov.df.pm.sgv.dto.root.PerfilDTO;
import br.gov.df.pm.sgv.dto.root.RecursoDTO;
import br.gov.df.pm.sgv.service.sgpol.PolicialService;
import org.keycloak.KeycloakPrincipal;
import org.keycloak.adapters.springsecurity.token.KeycloakAuthenticationToken;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import java.security.Principal;
import java.util.List;

@Component
public class UserProviderImpl implements UserProvider {

   private final PolicialService policialService;

   public UserProviderImpl(PolicialService policialService) {
       this.policialService = policialService;
   }

   private String getMatricula() {
       var principal = lookupPrincipal();
       final var keycloakPrincipal = (KeycloakAuthenticationToken) principal;
       final var token = keycloakPrincipal.getAccount().getKeycloakSecurityContext().getToken();
       var posicao = token.getGivenName().indexOf(" ");
       return token.getGivenName().substring(0, posicao).trim();
   }

   private Principal lookupPrincipal() {
       var attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
       return attributes.getRequest().getUserPrincipal();
   }

    @Override
    public List<PerfilDTO> getPerfisPolicialAutenticado() {
        return policialService.getPerfilDtoPolicialAutenticado(getMatriculaOrCpf());
    }

    @Override
    public Policial getPolicialAutenticado() {
        return policialService.findPolicialByPessoaMatricula(getMatricula());
    }

    @Override
    public  List<RecursoDTO> getRecursosPolicialAutenticado(){
   	    return policialService.getRecursoDtoPolicialAutenticado(getMatricula());
    }

    @Override
    public UnidadePolicialMilitar getUnidadePolicialAutenticado() {
        return policialService.getUnidadePolicialAutenticado(getMatricula());
    }

    @Override
    public Boolean possuiRecursos(String... args){
       List<RecursoDTO> recursosUsuario = getRecursosPolicialAutenticado();
       for (String arg :args){
           if (recursosUsuario.contains(new RecursoDTO(arg))) {
               return true;
           }
       }
       return false;
    }

        private String getMatriculaOrCpf() {
        var principal = lookupPrincipal();
        final var keycloakPrincipal = (KeycloakAuthenticationToken) principal;
        final var token = keycloakPrincipal.getAccount().getKeycloakSecurityContext().getToken();
        return token.getGivenName().substring(0, 8).trim();
    }
}