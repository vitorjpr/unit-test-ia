Here are some unit tests for the provided Java code:

```java
package br.gov.df.pm.sgv.shared.utils;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class StringUtilsTest {

    @Test
    void testIsEmptyOrNull() {
        assertTrue(StringUtils.isEmptyOrNull(null));
        assertTrue(StringUtils.isEmptyOrNull(""));
        assertFalse(StringUtils.isEmptyOrNull(" "));
        assertFalse(StringUtils.isEmptyOrNull("abc"));
    }

    @Test
    void testRemoverCaracteresEspeciaisCPF() {
        assertEquals("12345678901", StringUtils.removerCaracteresEspeciaisCPF("123.456.789-01"));
        assertEquals("12345678901", StringUtils.removerCaracteresEspeciaisCPF("12345678901"));
        assertEquals("", StringUtils.removerCaracteresEspeciaisCPF(""));
    }

    @Test
    void testFormatarCpf() {
        assertEquals("123.456.789-01", StringUtils.formatarCpf("12345678901"));
        assertEquals("123.456.789-01", StringUtils.formatarCpf("123.456.789-01"));
        assertEquals("123.456.789-01", StringUtils.formatarCpf("123 456 789 01"));
    }
}
```

These tests cover the three public methods in the StringUtils class. The first test checks the isEmptyOrNull method, the second test checks the removerCaracteresEspeciaisCPF method, and the third test checks the formatarCpf method. Each test includes multiple test cases to ensure comprehensive coverage.