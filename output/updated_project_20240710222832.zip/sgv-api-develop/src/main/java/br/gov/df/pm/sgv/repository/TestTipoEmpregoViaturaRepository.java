Here are the unit tests for the provided Java code:

```java
package br.gov.df.pm.sgv.repository;

import br.gov.df.pm.sgv.domain.TipoEmpregoViaturaEntity;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

@DataJpaTest
public class TipoEmpregoViaturaRepositoryTest {

    @Autowired
    private TipoEmpregoViaturaRepository tipoEmpregoViaturaRepository;

    @Autowired
    private TestEntityManager testEntityManager;

    @Test
    public void testFindByAtivo() {
        TipoEmpregoViaturaEntity entity = new TipoEmpregoViaturaEntity();
        entity.setAtivo(1);
        testEntityManager.persist(entity);

        List<TipoEmpregoViaturaEntity> result = tipoEmpregoViaturaRepository.findByAtivo(1);

        assertEquals(1, result.size());
        assertEquals(entity, result.get(0));
    }

    @Test
    public void testGetOne() {
        TipoEmpregoViaturaEntity entity = new TipoEmpregoViaturaEntity();
        entity.setNome("Test");
        TipoEmpregoViaturaEntity savedEntity = testEntityManager.persist(entity);

        TipoEmpregoViaturaEntity result = tipoEmpregoViaturaRepository.getOne(savedEntity.getId());

        assertEquals(savedEntity, result);
    }

    @Test
    public void testFindByNomeIgnoreCase() {
        TipoEmpregoViaturaEntity entity = new TipoEmpregoViaturaEntity();
        entity.setNome("TestNome");
        testEntityManager.persist(entity);

        Optional<TipoEmpregoViaturaEntity> result = tipoEmpregoViaturaRepository.findByNomeIgnoreCase("testnome");

        assertTrue(result.isPresent());
        assertEquals(entity, result.get());
    }
}
```

These unit tests cover the three methods in the `TipoEmpregoViaturaRepository` interface. The tests use an in-memory H2 database provided by `@DataJpaTest` annotation and `TestEntityManager` for managing test data. Each test case validates the expected behavior of the respective repository method.