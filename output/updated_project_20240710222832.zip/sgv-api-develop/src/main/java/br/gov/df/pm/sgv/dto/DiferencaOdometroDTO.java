package br.gov.df.pm.sgv.dto;

import br.gov.df.pm.sgv.domain.TipoVistoriaEntity;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDate;

@Data
@Builder
public class DiferencaOdometroDTO {
    private TipoVistoriaEntity referenciaInicial;
    private TipoVistoriaEntity referenciaFinal;
    private Double diferencaOdometro;
    private LocalDate dataInclusao;
    private LocalDate dataModificacao;
    private Boolean diferencaPermitido;
}
