package br.gov.df.pm.sgv.service.impl;

import br.gov.df.pm.sgv.domain.VistoriaArquivo;
import br.gov.df.pm.sgv.domain.VistoriaViaturaEntity;
import br.gov.df.pm.sgv.exceptions.ResourceNotFoundException;
import br.gov.df.pm.sgv.repository.VIstoriaArquivoRepository;
import br.gov.df.pm.sgv.service.StorageService;
import br.gov.df.pm.sgv.service.VistoriaArquivoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class VistoriaArquivoServiceImpl implements VistoriaArquivoService {

    @Autowired
    private VIstoriaArquivoRepository vistoriaArquivoRepository;

    @Autowired
    private StorageService storageService;

    @Override
    public ResponseEntity<VistoriaArquivo> deletarPorId(Long id) {
        VistoriaArquivo vistoriaArquivo = entityExists(id);
        UUID uuid = UUID.fromString(vistoriaArquivo.getIdentidade());
        storageService.removerImagem(uuid);
        vistoriaArquivoRepository.delete(vistoriaArquivo);
        return ResponseEntity.ok(vistoriaArquivo);
    }

    @Override
    public ResponseEntity<List<VistoriaArquivo>> deletarPorLista(List<Long> ids) {
        List<VistoriaArquivo> vistoriaArquivoList = new ArrayList<>();
         for(Long id: ids){
            VistoriaArquivo vistoriaArquivo = entityExists(id);
            vistoriaArquivoList.add(vistoriaArquivo);
            UUID uuid = UUID.fromString(vistoriaArquivo.getIdentidade());
            storageService.removerImagem(uuid);
            vistoriaArquivoRepository.delete(vistoriaArquivo);
        }
        return ResponseEntity.ok(vistoriaArquivoList);
    }


    private VistoriaArquivo entityExists(Long id) {
        Optional<VistoriaArquivo> vistoriaArquivo = vistoriaArquivoRepository.findById(id);
        return vistoriaArquivo.orElseThrow(() -> new ResourceNotFoundException("Arquivo de vistoria não encontrado"));
    }
}
