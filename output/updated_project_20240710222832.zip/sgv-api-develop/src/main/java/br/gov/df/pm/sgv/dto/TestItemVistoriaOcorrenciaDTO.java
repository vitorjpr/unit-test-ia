```java
package br.gov.df.pm.sgv.dto;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class ItemVistoriaOcorrenciaDTOTest {

    @Test
    public void testConstructorAndGetters() {
        Long id = 1L;
        String nome = "Teste";
        String descricao = "Descrição do teste";
        LocalDate dataInclusao = LocalDate.now();
        Boolean ativo = true;
        List<SubitemVistoriaDTO> subitems = new ArrayList<>();

        ItemVistoriaOcorrenciaDTO item = new ItemVistoriaOcorrenciaDTO(id, nome, descricao, dataInclusao, ativo, subitems);

        assertNotNull(item);
        assertEquals(id, item.getId());
        assertEquals(nome, item.getNome());
        assertEquals(descricao, item.getDescricao());
        assertEquals(dataInclusao, item.getDataInclusao());
        assertEquals(ativo, item.getAtivo());
        assertEquals(subitems, item.getSubitemVistoriaDTOS());
    }

    @Test
    public void testBuilder() {
        Long id = 1L;
        String nome = "Teste";
        String descricao = "Descrição do teste";
        LocalDate dataInclusao = LocalDate.now();
        Boolean ativo = true;
        List<SubitemVistoriaDTO> subitems = new ArrayList<>();

        ItemVistoriaOcorrenciaDTO item = ItemVistoriaOcorrenciaDTO.builder()
                .id(id)
                .nome(nome)
                .descricao(descricao)
                .dataInclusao(dataInclusao)
                .ativo(ativo)
                .subitemVistoriaDTOS(subitems)
                .build();

        assertNotNull(item);
        assertEquals(id, item.getId());
        assertEquals(nome, item.getNome());
        assertEquals(descricao, item.getDescricao());
        assertEquals(dataInclusao, item.getDataInclusao());
        assertEquals(ativo, item.getAtivo());
        assertEquals(subitems, item.getSubitemVistoriaDTOS());
    }

    // Add more tests as needed for comprehensive coverage
}
```