package br.gov.df.pm.sgv.domain.sgpol;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import java.io.Serializable;

/**
* @author CB Wallace - wallace.silva@pm.df.gov.br
* Brasília-DF, 1 de fev de 2017 às 14:33:45
*
* @author CB Wallace - wallace.silva@pm.df.gov.br
* Brasília-DF, 20 de fev de 2017 às 09:20:45
* Anotação -> que define o ativo com o valor default = 1
*  		   e validação de campos obrigatórios
*/

@Getter @Setter
@Entity
@Table(name = "PERFIL", schema = "dbo", catalog = "sgpol")
public class Perfil implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="pef_Codigo",unique=true, nullable=false)
	private int id;

	@Column(name = "pef_Ativo", nullable = false,  columnDefinition = "int default 1", insertable = false, updatable = true)
	private Integer ativo;

	@NotBlank(message="Nome é obrigatório")

	@Column(name="pef_Nome",nullable=false, length=150)
	private String nome;

	@Column(name="pef_Descricao")
	private String descricao;
//
//
//	@NotBlank(message="Descrição é obrigatório")
//	@Lob
//	@Column(name="pef_Descricao",nullable=false)
//	private String descricao;
//
//	//bi-directional many-to-one association to PessoaPerfil
//	@OneToMany(mappedBy="idPerfil")
//	private List<PessoaPerfil> pessoaPerfils;
//
//	//bi-directional many-to-one association to PessoaPerfil
//	@OneToMany(mappedBy="perfil")
//	private List<UpmPerfil> upmPerfil;
//
//
//	@OneToMany(mappedBy = "idPerfil", fetch = FetchType.LAZY)
//	private List<PerfilRecurso> listPerfilRecurso;
//
//	@Transient
//	private int totalPessoasPorPerfil=0;
//
//	@Transient
//	private UnidadePolicialMilitar upm;
//
//
//	@Transient
//	private boolean associado;
//
//	public int getTotalPessoasPorPerfil() {
//		int cont= 0;
//
//
//
//		return cont;
//	}
//
//
//
//	public boolean isAssociado() {
//		return associado;
//	}
//
//
//
//	public void setAssociado(boolean associado) {
//		this.associado = associado;
//	}
//
//
//
//
//
//
//	public void setTotalPessoasPorPerfil(int totalPessoasPorPerfil) {
//		this.totalPessoasPorPerfil = totalPessoasPorPerfil;
//	}
//
//	public int getId() {
//		return id;
//	}
//
//	public void setId(int id) {
//		this.id = id;
//	}
//
//	public Integer getAtivo() {
//		return ativo;
//	}
//
//	public void setAtivo(Integer ativo) {
//		this.ativo = ativo;
//	}
//
//	public String getNome() {
//		return nome;
//	}
//
//	public void setNome(String nome) {
//		this.nome = nome;
//	}
//
//	public String getDescricao() {
//		return descricao;
//	}
//
//	public void setDescricao(String descricao) {
//		this.descricao = descricao;
//	}
//
//	public List<PessoaPerfil> getPessoaPerfils() {
//		return pessoaPerfils;
//	}
//
//	public void setPessoaPerfils(List<PessoaPerfil> pessoaPerfils) {
//		this.pessoaPerfils = pessoaPerfils;
//	}
//
//	public List<PerfilRecurso> getListPerfilRecurso() {
//		return listPerfilRecurso;
//	}
//
//	public void setListPerfilRecurso(List<PerfilRecurso> listPerfilRecurso) {
//		this.listPerfilRecurso = listPerfilRecurso;
//	}
//
//	public List<Recurso> getRecursos(){
//		List<Recurso> recursos = new ArrayList<Recurso>();
//
//		for(PerfilRecurso perfilrecurso: this.listPerfilRecurso){
//			recursos.add(perfilrecurso.getIdRecurso());
//		}
//		return recursos;
//
//	}
//
//	public PerfilRecurso addPerfilRecurso(PerfilRecurso perfilRecurso) {
//		getListPerfilRecurso().add(perfilRecurso);
//
//		return perfilRecurso;
//	}
//
//	public PerfilRecurso removePerfilRecurso(PerfilRecurso perfilRecurso) {
//		getListPerfilRecurso().remove(perfilRecurso);
//
//		return perfilRecurso;
//	}
//
//
//	public boolean isNovo(){
//		return this.id == 0;
//	}
//
//
//	public List<UpmPerfil> getUpmPerfil() {
//		return upmPerfil;
//	}
//
//	public void setUpmPerfil(List<UpmPerfil> upmPerfil) {
//		this.upmPerfil = upmPerfil;
//	}
//
//	public UnidadePolicialMilitar getUpm() {
//		return upm;
//	}
//
//
//
//	public UnidadePolicialMilitar getUpmPorUpm(int id) {
//		UnidadePolicialMilitar upm = new UnidadePolicialMilitar();
//		if(upmPerfil!=null) {
//			for (UpmPerfil obj : upmPerfil) {
//				if(obj.getUpm().getId()==id) {
//					upm = obj.getUpm();
//				}
//			}
//		}
//
//		return upm;
//	}
//
//	public void setUpm(UnidadePolicialMilitar upm) {
//		this.upm = upm;
//	}
//
//	public List<Pessoa> getPessoas() {
//		List<Pessoa> retorno = new ArrayList<Pessoa>();
//
//		for (PessoaPerfil pessoaPerfil : pessoaPerfils) {
//			retorno.add(pessoaPerfil.getIdPessoa());
//		}
//
//		return retorno;
//	}
//
//	@Override
//	public int hashCode() {
//		final int prime = 31;
//		int result = 1;
//		result = prime * result + id;
//		return result;
//	}
//
//	@Override
//	public boolean equals(Object obj) {
//		if (this == obj)
//			return true;
//		if (obj == null)
//			return false;
//		if (getClass() != obj.getClass())
//			return false;
//		Perfil other = (Perfil) obj;
//		if (id != other.id)
//			return false;
//		return true;
//	}
//
//	@Override
//	public String toString() {
//		return "Perfil [id=" + id + ", ativo=" + ativo + ", nome=" + nome + ", descricao=" + descricao
//				+ ", pessoaPerfils=" + pessoaPerfils + ", listPerfilRecurso=" + listPerfilRecurso
//				+ ", totalPessoasPorPerfil=" + totalPessoasPorPerfil + "]";
//	}
//
//
//
//
//
//
//
//
}