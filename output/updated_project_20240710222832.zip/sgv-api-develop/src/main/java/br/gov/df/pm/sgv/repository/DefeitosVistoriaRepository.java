package br.gov.df.pm.sgv.repository;

import br.gov.df.pm.sgv.domain.DefeitosVistoriaEntity;
import br.gov.df.pm.sgv.domain.SubitemVistoriaEntity;
import br.gov.df.pm.sgv.domain.TipoDefeitoVistoriaEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface DefeitosVistoriaRepository extends JpaRepository<DefeitosVistoriaEntity, Long> {
    List<DefeitosVistoriaEntity> findAllByCodSubitem(SubitemVistoriaEntity id);
    List<DefeitosVistoriaEntity> findAllByCodTipoDefeito(TipoDefeitoVistoriaEntity id);
    Optional<DefeitosVistoriaEntity> findByCodSubitemAndCodTipoDefeito(SubitemVistoriaEntity subitem, TipoDefeitoVistoriaEntity tipoDefeito);
    List<DefeitosVistoriaEntity> findAllByCodSubitemAndAtivo(SubitemVistoriaEntity id, Boolean ativo);

}
