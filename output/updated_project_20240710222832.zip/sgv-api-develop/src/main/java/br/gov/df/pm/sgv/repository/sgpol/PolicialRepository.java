package br.gov.df.pm.sgv.repository.sgpol;

import br.gov.df.pm.sgv.domain.sgpol.Policial;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;


@Repository
public interface PolicialRepository extends JpaRepository<Policial, Long> {

    Policial findByMatricula(String cpf);
    Optional<Policial> findById(Integer id);

    // @Query("select policial from Policial policial " +
   	// 	" inner join UpmPolicial upmPolicial on upmPolicial.idPolicial = policial " +
   	// 	" where upmPolicial.idUpm = :unidade and upmPolicial.dataDodf is null " +
   	// 	" order by policial.matricula")
    // List<Policial> findAllByUnidade(UnidadePolicialMilitar unidade);
}