package br.gov.df.pm.sgv.repository.sgpol;


import br.gov.df.pm.sgv.domain.sgpol.Perfil;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PerfilRepository extends JpaRepository<Perfil, Long> {

  @Query(" Select perfil From Policial policial Inner join policial.idPessoa pessoa Inner join pessoa.perfis perfil where policial.matricula = :matricula and perfil.ativo = 1 and perfil.nome like '%SGV%' ")
  List<Perfil> findPerfilPessoaByMatricula(String matricula);

//  @Query(" Select perfil From Perfil perfil where perfil.nome like 'SGF%' ")
//  List<Perfil> findAllSGF();

}
