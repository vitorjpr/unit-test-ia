Here are the unit tests for the provided Java code:

```java
package br.gov.df.pm.sgv.repository.sgpol;

import br.gov.df.pm.sgv.domain.sgpol.Perfil;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class PerfilRepositoryTest {

    @Mock
    private PerfilRepository perfilRepository;

    @InjectMocks
    private PerfilRepository perfilRepositoryImpl;

    @Test
    void testFindPerfilPessoaByMatricula() {
        // Given
        String matricula = "123456";
        Perfil perfil1 = new Perfil("Perfil1", 1, "SGV");
        Perfil perfil2 = new Perfil("Perfil2", 1, "SGV");
        List<Perfil> expectedPerfis = new ArrayList<>();
        expectedPerfis.add(perfil1);
        expectedPerfis.add(perfil2);

        // When
        when(perfilRepository.findPerfilPessoaByMatricula(anyString())).thenReturn(expectedPerfis);
        List<Perfil> actualPerfis = perfilRepositoryImpl.findPerfilPessoaByMatricula(matricula);

        // Then
        assertEquals(expectedPerfis.size(), actualPerfis.size());
        assertEquals(expectedPerfis.get(0).getNome(), actualPerfis.get(0).getNome());
        assertEquals(expectedPerfis.get(1).getNome(), actualPerfis.get(1).getNome());
    }

    // Add more test cases as needed
}
```

In the provided unit test, I have mocked the `PerfilRepository` interface using Mockito to test the `findPerfilPessoaByMatricula` method. I have also included necessary imports and assertions to ensure the test is comprehensive. You can add more test cases based on your requirements.