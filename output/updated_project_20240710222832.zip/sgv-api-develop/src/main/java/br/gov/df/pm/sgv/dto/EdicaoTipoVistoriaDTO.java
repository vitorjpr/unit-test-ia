package br.gov.df.pm.sgv.dto;

import br.gov.df.pm.sgv.domain.ItemVistoriaEntity;
import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class EdicaoTipoVistoriaDTO {
    private String nome;
    private String descricao;
    private String statusAnterior;
    private String statusPosterior;
    private List<ItemVistoriaEntity> itens;
}
