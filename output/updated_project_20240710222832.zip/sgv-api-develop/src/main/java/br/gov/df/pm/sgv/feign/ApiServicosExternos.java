package br.gov.df.pm.sgv.feign;

import br.gov.df.pm.sgv.feign.dto.AuthKeycloakDTO;
import br.gov.df.pm.sgv.feign.dto.MessageAuthKeycloak;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(
        name = "ApiServicosExternos",
        url = "${api.host.externo.url}",
        configuration = {FeignSkipExceptionConfiguration.class}
)
public interface ApiServicosExternos {
    @PostMapping(value = "/api/keycloak/authentication", consumes = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<MessageAuthKeycloak> authentication(@RequestBody AuthKeycloakDTO keycloakRequest);
}
