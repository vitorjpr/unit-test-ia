package br.gov.df.pm.sgv.service;

import br.gov.df.pm.sgv.domain.VistoriaArquivo;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface VistoriaArquivoService {

    ResponseEntity<VistoriaArquivo> deletarPorId(Long id);
    ResponseEntity<List<VistoriaArquivo>> deletarPorLista(List<Long> ids);
}
