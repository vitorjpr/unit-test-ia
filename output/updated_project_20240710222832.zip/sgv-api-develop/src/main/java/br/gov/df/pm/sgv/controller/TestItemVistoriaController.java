```java
package br.gov.df.pm.sgv.controller;

import br.gov.df.pm.sgv.assembler.ItemVistoriaAssembler;
import br.gov.df.pm.sgv.dto.EdicaoItemVistoriaDTO;
import br.gov.df.pm.sgv.dto.ItemVistoriaDTO;
import br.gov.df.pm.sgv.domain.ItemVistoriaEntity;
import br.gov.df.pm.sgv.domain.SubitensVistoriaEntity;
import br.gov.df.pm.sgv.domain.SubitemVistoriaEntity;
import br.gov.df.pm.sgv.service.ItemVistoriaService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.PagedModel;
import org.springframework.http.ResponseEntity;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

class ItemVistoriaControllerTest {

    @Mock
    private ItemVistoriaService service;

    @Mock
    private ItemVistoriaAssembler itemVistoriaAssembler;

    @Mock
    private PagedResourcesAssembler<ItemVistoriaEntity> pagedResourcesAssembler;

    @InjectMocks
    private ItemVistoriaController controller;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testBuscarId() {
        Long id = 1L;
        ItemVistoriaDTO expected = new ItemVistoriaDTO();
        when(service.buscarId(id)).thenReturn(ResponseEntity.ok(expected));
        ResponseEntity<ItemVistoriaDTO> result = controller.buscarId(id);
        assertEquals(expected, result.getBody());
    }

    @Test
    void testBuscar() {
        String filter = "test";
        Pageable pageable = Pageable.unpaged();
        List<ItemVistoriaEntity> entityList = List.of(new ItemVistoriaEntity());
        PagedModel<EntityModel<ItemVistoriaEntity>> pagedModel = PagedModel.of(List.of(EntityModel.of(new ItemVistoriaEntity())));
        when(service.buscar(filter, pageable)).thenReturn(entityList);
        when(pagedResourcesAssembler.toModel(entityList)).thenReturn(pagedModel);
        when(itemVistoriaAssembler.toModel(any())).thenReturn(EntityModel.of(new ItemVistoriaEntity()));
        PagedModel<EntityModel<ItemVistoriaDTO>> result = controller.buscar(filter, pageable);
        assertEquals(1, result.getContent().size());
    }

    @Test
    void testSalvar() {
        ItemVistoriaDTO itemVistoriaDTO = new ItemVistoriaDTO();
        when(service.salvar(itemVistoriaDTO)).thenReturn(ResponseEntity.ok().build());
        ResponseEntity<?> result = controller.salvar(itemVistoriaDTO);
        assertEquals(ResponseEntity.ok().build(), result);
    }

    @Test
    void testEditar() {
        Long id = 1L;
        EdicaoItemVistoriaDTO edicao = new EdicaoItemVistoriaDTO();
        when(service.editar(id, edicao)).thenReturn(ResponseEntity.ok().build());
        ResponseEntity<?> result = controller.editar(id, edicao);
        assertEquals(ResponseEntity.ok().build(), result);
    }

    @Test
    void testFindAllSubitensVistoria() {
        List<SubitensVistoriaEntity> expected = List.of(new SubitensVistoriaEntity());
        when(service.findAllSubitensVistoria()).thenReturn(ResponseEntity.ok(expected));
        ResponseEntity<List<SubitensVistoriaEntity>> result = controller.findAllSubitensVistoria();
        assertEquals(expected, result.getBody());
    }

    @Test
    void testExcluir() {
        Long id = 1L;
        when(service.excluir(id)).thenReturn(ResponseEntity.ok().build());
        ResponseEntity<?> result = controller.excluir(id);
        assertEquals(ResponseEntity.ok().build(), result);
    }

    @Test
    void testDesativar() {
        Long id = 1L;
        when(service.desativar(id)).thenReturn(ResponseEntity.ok().build());
        ResponseEntity<?> result = controller.desativar(id);
        assertEquals(ResponseEntity.ok().build(), result);
    }

    @Test
    void testAtivar() {
        Long id = 1L;
        when(service.ativar(id)).thenReturn(ResponseEntity.ok().build());
        ResponseEntity<?> result = controller.ativar(id);
        assertEquals(ResponseEntity.ok().build(), result);
    }

    @Test
    void testFindAllSubitemVistoriaById() {
        String nome = "test";
        List<SubitemVistoriaEntity> expected = List.of(new SubitemVistoriaEntity());
        when(service.findAllSubitemVistoriaById(nome)).thenReturn(ResponseEntity.ok(expected));
        ResponseEntity<List<SubitemVistoria