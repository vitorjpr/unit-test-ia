package br.gov.df.pm.sgv.repository;

import br.gov.df.pm.sgv.domain.ChecklistVistoriaEntity;
import br.gov.df.pm.sgv.domain.VistoriaViaturaEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ChecklistVistoriaRepository extends JpaRepository<ChecklistVistoriaEntity, Long> {
    List<ChecklistVistoriaEntity> findByVistoria(VistoriaViaturaEntity vistoriaViatura);
}
