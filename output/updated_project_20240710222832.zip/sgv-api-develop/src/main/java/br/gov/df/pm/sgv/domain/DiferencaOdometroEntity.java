package br.gov.df.pm.sgv.domain;

import lombok.*;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDate;

@Entity
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(of = "id")
@Table(name = "DIFERENCAODOMETRO", schema = "sgv")
public class DiferencaOdometroEntity implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "do_Codigo", unique = true, nullable = false)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "do_ReferenciaInicial")
    private TipoVistoriaEntity referenciaInicial;

    @ManyToOne
    @JoinColumn(name = "do_ReferenciaFinal")
    private TipoVistoriaEntity referenciaFinal;

    @Column(name = "do_DiferencaOdometro")
    private Double diferencaOdometro;

    @DateTimeFormat(pattern="dd/MM/yyyy")
    @Column(name = "do_DataInclusao")
    private LocalDate dataInclusao;

    @DateTimeFormat(pattern="dd/MM/yyyy")
    @Column(name = "do_DataModificaco")
    private LocalDate dataModificacao;
}
