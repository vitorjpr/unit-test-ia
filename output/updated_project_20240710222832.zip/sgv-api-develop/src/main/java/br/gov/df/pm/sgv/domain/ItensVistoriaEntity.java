package br.gov.df.pm.sgv.domain;

import lombok.*;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDate;

@Entity
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(of = "id")
@Table(name = "ITENSVISTORIA", schema = "sgv")
public class ItensVistoriaEntity implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "itv_Codigo", unique = true, nullable = false)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "itv_CodTipo")
    private TipoVistoriaEntity codTipo;

    @ManyToOne
    @JoinColumn(name = "itv_CodItem")
    private ItemVistoriaEntity codItem;

    @Column(name = "itv_ativo")
    private Boolean ativo;

    @DateTimeFormat(pattern="dd/MM/yyyy")
    @Column(name = "itv_DtInclusao")
    private LocalDate dataInclusao;
}
