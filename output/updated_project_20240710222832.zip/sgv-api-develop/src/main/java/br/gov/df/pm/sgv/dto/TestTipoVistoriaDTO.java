Here are the unit tests for the `TipoVistoriaDTO` class:

```java
package br.gov.df.pm.sgv.dto;

import br.gov.df.pm.sgv.domain.ItemVistoriaEntity;
import org.junit.jupiter.api.Test;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class TipoVistoriaDTOTest {

    @Test
    public void testTipoVistoriaDTOFields() {
        TipoVistoriaDTO tipoVistoriaDTO = TipoVistoriaDTO.builder()
                .id(1L)
                .nome("Vistoria1")
                .descricao("Descrição da vistoria")
                .statusAnterior("Anterior")
                .statusPosterior("Posterior")
                .dataInclusao(LocalDate.now())
                .ativo(true)
                .itens(new ArrayList<>())
                .build();

        assertEquals(1L, tipoVistoriaDTO.getId());
        assertEquals("Vistoria1", tipoVistoriaDTO.getNome());
        assertEquals("Descrição da vistoria", tipoVistoriaDTO.getDescricao());
        assertEquals("Anterior", tipoVistoriaDTO.getStatusAnterior());
        assertEquals("Posterior", tipoVistoriaDTO.getStatusPosterior());
        assertEquals(LocalDate.now(), tipoVistoriaDTO.getDataInclusao());
        assertEquals(true, tipoVistoriaDTO.getAtivo());
        assertEquals(new ArrayList<>(), tipoVistoriaDTO.getItens());
    }

    @Test
    public void testTipoVistoriaDTOToString() {
        TipoVistoriaDTO tipoVistoriaDTO = TipoVistoriaDTO.builder()
                .id(1L)
                .nome("Vistoria1")
                .descricao("Descrição da vistoria")
                .statusAnterior("Anterior")
                .statusPosterior("Posterior")
                .dataInclusao(LocalDate.now())
                .ativo(true)
                .itens(new ArrayList<>())
                .build();

        String expectedToString = "TipoVistoriaDTO(id=1, nome=Vistoria1, descricao=Descrição da vistoria, " +
                "statusAnterior=Anterior, statusPosterior=Posterior, dataInclusao=" + LocalDate.now() + ", " +
                "ativo=true, itens=[])";

        assertEquals(expectedToString, tipoVistoriaDTO.toString());
    }
}
```

Make sure to add the necessary imports for `@Test`, `assertEquals`, `ArrayList`, and `LocalDate`. These tests cover the initialization of `TipoVistoriaDTO` fields and the `toString` method.