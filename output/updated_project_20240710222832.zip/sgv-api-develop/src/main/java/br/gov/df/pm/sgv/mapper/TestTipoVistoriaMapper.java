Sure! Here are some unit tests for the `TipoVistoriaMapper` class:

```java
package br.gov.df.pm.sgv.mapper;

import org.junit.jupiter.api.Test;
import br.gov.df.pm.sgv.dto.TipoVistoriaDTO;
import br.gov.df.pm.sgv.domain.TipoVistoriaEntity;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class TipoVistoriaMapperTest {

    @Test
    public void testConvertEntity() {
        TipoVistoriaDTO tipoVistoriaDTO = TipoVistoriaDTO.builder()
                .nome("Teste")
                .descricao("Descrição de teste")
                .dataInclusao("01/01/2022")
                .statusAnterior("Anterior")
                .statusPosterior("Posterior")
                .ativo(true)
                .build();

        TipoVistoriaEntity tipoVistoriaEntity = TipoVistoriaMapper.convertEntity(tipoVistoriaDTO);

        assertEquals(tipoVistoriaDTO.getNome(), tipoVistoriaEntity.getNome());
        assertEquals(tipoVistoriaDTO.getDescricao(), tipoVistoriaEntity.getDescricao());
        assertEquals(tipoVistoriaDTO.getDataInclusao(), tipoVistoriaEntity.getDataInclusao());
        assertEquals(tipoVistoriaDTO.getStatusAnterior(), tipoVistoriaEntity.getStatusAnterior());
        assertEquals(tipoVistoriaDTO.getStatusPosterior(), tipoVistoriaEntity.getStatusPosterior());
        assertEquals(tipoVistoriaDTO.getAtivo(), tipoVistoriaEntity.getAtivo());
    }

    @Test
    public void testConvertDTO() {
        TipoVistoriaEntity tipoVistoriaEntity = TipoVistoriaEntity.builder()
                .nome("Teste")
                .descricao("Descrição de teste")
                .dataInclusao("01/01/2022")
                .statusAnterior("Anterior")
                .statusPosterior("Posterior")
                .ativo(true)
                .build();

        TipoVistoriaDTO tipoVistoriaDTO = TipoVistoriaMapper.convertDTO(tipoVistoriaEntity);

        assertEquals(tipoVistoriaEntity.getNome(), tipoVistoriaDTO.getNome());
        assertEquals(tipoVistoriaEntity.getDescricao(), tipoVistoriaDTO.getDescricao());
        assertEquals(tipoVistoriaEntity.getDataInclusao(), tipoVistoriaDTO.getDataInclusao());
        assertEquals(tipoVistoriaEntity.getStatusAnterior(), tipoVistoriaDTO.getStatusAnterior());
        assertEquals(tipoVistoriaEntity.getStatusPosterior(), tipoVistoriaDTO.getStatusPosterior());
        assertEquals(tipoVistoriaEntity.getAtivo(), tipoVistoriaDTO.getAtivo());
    }
}
```

These tests cover the conversion from `TipoVistoriaDTO` to `TipoVistoriaEntity` and vice versa. Make sure to adjust the test data according to your specific requirements.