```java
package br.gov.df.pm.sgv.service.impl;

import br.gov.df.pm.sgv.domain.VistoriaArquivo;
import br.gov.df.pm.sgv.exceptions.ResourceNotFoundException;
import br.gov.df.pm.sgv.repository.VIstoriaArquivoRepository;
import br.gov.df.pm.sgv.service.StorageService;
import br.gov.df.pm.sgv.service.VistoriaArquivoService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class VistoriaArquivoServiceImplTest {

    private VistoriaArquivoServiceImpl vistoriaArquivoService;

    @Mock
    private VIstoriaArquivoRepository vistoriaArquivoRepository;

    @Mock
    private StorageService storageService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        vistoriaArquivoService = new VistoriaArquivoServiceImpl();
        vistoriaArquivoService.vistoriaArquivoRepository = vistoriaArquivoRepository;
        vistoriaArquivoService.storageService = storageService;
    }

    @Test
    void testDeletarPorId() {
        Long id = 1L;
        VistoriaArquivo vistoriaArquivo = new VistoriaArquivo();
        vistoriaArquivo.setIdentidade("123-456-789");
        when(vistoriaArquivoRepository.findById(id)).thenReturn(Optional.of(vistoriaArquivo));

        ResponseEntity<VistoriaArquivo> response = vistoriaArquivoService.deletarPorId(id);

        assertNotNull(response);
        assertEquals(vistoriaArquivo, response.getBody());
        verify(storageService, times(1)).removerImagem(UUID.fromString(vistoriaArquivo.getIdentidade()));
        verify(vistoriaArquivoRepository, times(1)).delete(vistoriaArquivo);
    }

    @Test
    void testDeletarPorLista() {
        List<Long> ids = new ArrayList<>();
        ids.add(1L);
        ids.add(2L);

        VistoriaArquivo vistoriaArquivo1 = new VistoriaArquivo();
        vistoriaArquivo1.setIdentidade("123-456-789");
        VistoriaArquivo vistoriaArquivo2 = new VistoriaArquivo();
        vistoriaArquivo2.setIdentidade("987-654-321");
        when(vistoriaArquivoRepository.findById(1L)).thenReturn(Optional.of(vistoriaArquivo1));
        when(vistoriaArquivoRepository.findById(2L)).thenReturn(Optional.of(vistoriaArquivo2));

        ResponseEntity<List<VistoriaArquivo>> response = vistoriaArquivoService.deletarPorLista(ids);

        assertNotNull(response);
        List<VistoriaArquivo> deletedList = response.getBody();
        assertEquals(2, deletedList.size());
        assertTrue(deletedList.contains(vistoriaArquivo1));
        assertTrue(deletedList.contains(vistoriaArquivo2));
        verify(storageService, times(2)).removerImagem(any(UUID.class));
        verify(vistoriaArquivoRepository, times(2)).delete(any(VistoriaArquivo.class));
    }

    @Test
    void testEntityExists() {
        Long id = 1L;
        VistoriaArquivo vistoriaArquivo = new VistoriaArquivo();
        when(vistoriaArquivoRepository.findById(id)).thenReturn(Optional.of(vistoriaArquivo));

        VistoriaArquivo result = vistoriaArquivoService.entityExists(id);

        assertNotNull(result);
        assertEquals(vistoriaArquivo, result);
    }

    @Test
    void testEntityExistsResourceNotFoundException() {
        Long id = 1L;
        when(vistoriaArquivoRepository.findById(id)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> vistoriaArquivoService.entityExists(id));
    }
}
```