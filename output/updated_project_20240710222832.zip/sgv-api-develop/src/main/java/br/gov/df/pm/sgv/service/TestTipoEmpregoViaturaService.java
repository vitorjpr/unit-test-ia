Sure! Here are the unit tests for the provided Java code:

```java
package br.gov.df.pm.sgv.service;

import br.gov.df.pm.sgv.dto.TipoEmpregoViaturaDto;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@SpringBootTest
public class TipoEmpregoViaturaServiceTest {

    @MockBean
    private TipoEmpregoViaturaService tipoEmpregoViaturaService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testListTipoEmpregoViaturaAtivo() {
        // Given
        List<TipoEmpregoViaturaDto> tipoEmpregoViaturaList = new ArrayList<>();
        tipoEmpregoViaturaList.add(new TipoEmpregoViaturaDto("Emprego 1", true));
        tipoEmpregoViaturaList.add(new TipoEmpregoViaturaDto("Emprego 2", true));
        
        // When
        when(tipoEmpregoViaturaService.listTipoEmpregoViaturaAtivo()).thenReturn(tipoEmpregoViaturaList);
        
        // Then
        List<TipoEmpregoViaturaDto> result = tipoEmpregoViaturaService.listTipoEmpregoViaturaAtivo();
        assertEquals(2, result.size());
        assertEquals("Emprego 1", result.get(0).getNome());
        assertEquals("Emprego 2", result.get(1).getNome());
        assertEquals(true, result.get(0).isAtivo());
        assertEquals(true, result.get(1).isAtivo());
    }
}
```

These unit tests use Mockito to mock the `TipoEmpregoViaturaService` interface and test the `listTipoEmpregoViaturaAtivo` method. The tests cover the scenario where the method returns a list of active `TipoEmpregoViaturaDto` objects.