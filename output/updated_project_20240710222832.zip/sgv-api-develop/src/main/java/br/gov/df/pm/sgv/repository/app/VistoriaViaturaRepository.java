package br.gov.df.pm.sgv.repository.app;

import br.gov.df.pm.sgv.domain.ViaturaEntity;
import br.gov.df.pm.sgv.domain.VistoriaViaturaEntity;
import br.gov.df.pm.sgv.dto.FiltroVistoria;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface VistoriaViaturaRepository extends JpaRepository<VistoriaViaturaEntity, Long>, JpaSpecificationExecutor<VistoriaViaturaEntity> {
    Optional<VistoriaViaturaEntity> findByViatura(ViaturaEntity viatura);
    List<VistoriaViaturaEntity>  findAllByViaturaId(Long id);
    List<VistoriaViaturaEntity> findAllByViatura(ViaturaEntity viatura);

    @Query("select vistoria from VistoriaViaturaEntity vistoria "
            + "inner join vistoria.viatura viatura"
            + " where 1=1 "
            + " AND (:#{#filter?.dataFim} is null or vistoria.dataVistoria <= :#{#filter?.dataFim}) "
            + " AND (:#{#filter?.unidade} = 0 or vistoria.idUpm = :#{#filter?.unidade}) "
            + " AND (:#{#filter?.dataInicio} is null or vistoria.dataVistoria >= :#{#filter?.dataInicio}) "
            + " AND (:#{#filter?.tipoVistoria} is null or vistoria.tipoVistoria.id = :#{#filter?.tipoVistoria}) "
            + " AND (:#{#filter?.placa} is null or viatura.placa like :#{#filter?.placa}) "
            + " AND (:#{#filter?.prefixo} is null or viatura.prefixo like :#{#filter?.prefixo}) "
    )
    Page<VistoriaViaturaEntity> findAllByFiltro(FiltroVistoria filter, Pageable pageable);
}
