package br.gov.df.pm.sgv.dto;

import br.gov.df.pm.sgv.domain.DiferencaOdometroEntity;
import br.gov.df.pm.sgv.domain.TipoVistoriaEntity;
import br.gov.df.pm.sgv.domain.VistoriaViaturaHistoricoEntity;
import br.gov.df.pm.sgv.domain.enums.VistoriaViaturaStatusEnum;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;

@Data
@Builder
public class VistoriaViaturaDTO {
    private TipoVistoriaEntity tipoVistoria;
    private List<VistoriaViaturaHistoricoEntity> vistoriaViaturaHistorico;
    private DiferencaOdometroEntity diferencaOdometro;
    private VistoriaViaturaStatusEnum status;
    private LocalDateTime dataVistoria;
}
