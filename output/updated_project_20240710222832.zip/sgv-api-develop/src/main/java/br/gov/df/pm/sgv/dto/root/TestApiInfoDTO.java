```java
package br.gov.df.pm.sgv.dto.root;

import br.gov.df.pm.sgv.domain.sgpol.Policial;
import org.junit.jupiter.api.Test;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class ApiInfoDTOTest {

    @Test
    public void testApiInfoDTOConstructor() {
        // Given
        String buildVersion = "1.0";
        Policial policial = new Policial();
        List<PerfilDTO> perfis = new ArrayList<>();

        // When
        ApiInfoDTO apiInfoDTO = new ApiInfoDTO(buildVersion, policial, perfis);

        // Then
        assertEquals(buildVersion, apiInfoDTO.getBuildVersion());
        assertEquals(policial, apiInfoDTO.getPolicial());
        assertEquals(perfis, apiInfoDTO.getPerfis());
    }
}
```

Neste teste unitário, é verificado se o construtor da classe `ApiInfoDTO` está atribuindo corretamente os valores passados como parâmetros e se os métodos `get` estão retornando os valores esperados.