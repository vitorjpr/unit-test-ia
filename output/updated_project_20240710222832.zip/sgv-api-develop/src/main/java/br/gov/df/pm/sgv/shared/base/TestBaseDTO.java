Sure! Here are the unit tests for the provided Java code:

```java
package br.gov.df.pm.sgv.shared.base;

import org.junit.Test;

import static org.junit.Assert.*;

public class BaseDTOTest {

    @Test
    public void testSerialVersionUID() {
        assertEquals(1357668119881911675L, BaseDTO.serialVersionUID);
    }

    @Test
    public void testEquals() {
        BaseDTO dto1 = new BaseDTO();
        BaseDTO dto2 = new BaseDTO();

        assertTrue(dto1.equals(dto2));
    }

    @Test
    public void testHashCode() {
        BaseDTO dto1 = new BaseDTO();
        BaseDTO dto2 = new BaseDTO();

        assertEquals(dto1.hashCode(), dto2.hashCode());
    }

    @Test
    public void testToString() {
        BaseDTO dto = new BaseDTO();
        assertNotNull(dto.toString());
    }
}
```

Make sure to have the Lombok dependency in your project to use the `@Data` annotation. These tests cover the `serialVersionUID`, `equals`, `hashCode`, and `toString` methods inherited from `BaseDTO`.