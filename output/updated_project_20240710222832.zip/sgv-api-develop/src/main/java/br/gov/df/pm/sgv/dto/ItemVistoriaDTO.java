package br.gov.df.pm.sgv.dto;

import br.gov.df.pm.sgv.domain.SubitemVistoriaEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ItemVistoriaDTO {
    private Long id;
    private String nome;
    private String descricao;
    private LocalDate dataInclusao;
    private Boolean ativo;
    private List<SubitemVistoriaEntity> subitens;
}
