```java
package br.gov.df.pm.sgv.configurations;

import org.junit.jupiter.api.Test;
import org.springframework.mock.web.MockFilterChain;
import org.springframework.mock.web.MockFilterConfig;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;

import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletResponse;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class CorsConfigTest {

    @Test
    public void testDoFilter_WhenMethodIsOPTIONS() throws IOException, ServletException {
        // Given
        CorsConfig corsConfig = new CorsConfig();
        MockHttpServletRequest request = new MockHttpServletRequest("OPTIONS", "/path");
        MockHttpServletResponse response = new MockHttpServletResponse();
        MockFilterChain filterChain = new MockFilterChain();

        // When
        corsConfig.doFilter(request, response, filterChain);

        // Then
        assertEquals("POST, GET, DELETE, PUT, OPTIONS, HEAD", response.getHeader("Access-Control-Allow-Methods"));
        assertEquals("Access-Control-Allow-Credentials, Authorization, Content-Type", response.getHeader("Access-Control-Allow-Headers"));
        assertEquals("3600", response.getHeader("Access-Control-Max-Age"));
        assertEquals(HttpServletResponse.SC_OK, response.getStatus());
    }

    @Test
    public void testDoFilter_WhenMethodIsNotOPTIONS() throws IOException, ServletException {
        // Given
        CorsConfig corsConfig = new CorsConfig();
        MockHttpServletRequest request = new MockHttpServletRequest("GET", "/path");
        MockHttpServletResponse response = new MockHttpServletResponse();
        MockFilterChain filterChain = new MockFilterChain();

        // When
        corsConfig.doFilter(request, response, filterChain);

        // Then
        assertTrue(response.containsHeader("Access-Control-Allow-Origin"));
        assertTrue(response.containsHeader("Access-Control-Allow-Credentials"));
    }

    @Test
    public void testInit() {
        // Given
        CorsConfig corsConfig = new CorsConfig();
        FilterConfig filterConfig = new MockFilterConfig();

        // When
        corsConfig.init(filterConfig);

        // No assertion needed for init method
    }

    @Test
    public void testDestroy() {
        // Given
        CorsConfig corsConfig = new CorsConfig();

        // When
        corsConfig.destroy();

        // No assertion needed for destroy method
    }
}
```

Esses testes cobrem os diferentes cenários possíveis do método `doFilter`, além de testar os métodos `init` e `destroy` da classe `CorsConfig`. Certifique-se de adicionar as dependências necessárias para os testes mock, como o `spring-test`.