package br.gov.df.pm.sgv.exceptions;

public class OperationException extends RuntimeException {
    private static final long serialVersionUID = 1L;

    public OperationException(String msg) {
        super(msg);
    }

    public OperationException(String msg, Throwable cause) {
        super(msg, cause);
    }
}
