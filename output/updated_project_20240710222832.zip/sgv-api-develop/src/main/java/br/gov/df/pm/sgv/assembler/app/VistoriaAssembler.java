package br.gov.df.pm.sgv.assembler.app;

import br.gov.df.pm.sgv.domain.ChecklistVistoriaEntity;
import br.gov.df.pm.sgv.domain.VistoriaViaturaEntity;
import br.gov.df.pm.sgv.domain.sgpol.UnidadePolicialMilitar;
import br.gov.df.pm.sgv.dto.ViaturaDTO;
import br.gov.df.pm.sgv.dto.VistoriaDTO;
import br.gov.df.pm.sgv.repository.ChecklistVistoriaRepository;
import br.gov.df.pm.sgv.service.sgpol.PolicialService;
import br.gov.df.pm.sgv.service.sgpol.UnidadePolicialMilitarService;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.RepresentationModelAssembler;
import org.springframework.stereotype.Component;

@Component
public class VistoriaAssembler implements RepresentationModelAssembler<VistoriaViaturaEntity, EntityModel<VistoriaDTO>> {

    private final PolicialService policialService;
    private final UnidadePolicialMilitarService unidadePolicialMilitarService;
    private final ChecklistVistoriaRepository checklistVistoriaRepository;

    public VistoriaAssembler(PolicialService policialService, UnidadePolicialMilitarService unidadePolicialMilitarService, ChecklistVistoriaRepository checklistVistoriaRepository) {
        this.policialService = policialService;
        this.unidadePolicialMilitarService = unidadePolicialMilitarService;
        this.checklistVistoriaRepository = checklistVistoriaRepository;
    }

    @Override
    public EntityModel<VistoriaDTO> toModel(VistoriaViaturaEntity entity) {
        return EntityModel.of(VistoriaDTO.builder()
                .id(entity.getId())
                .upm(unidadePolicialMilitarService.findUPMById(entity.getIdUpm()).getNome())
                .motorista(policialService.findPolicialById(entity.getIdPolicial()).getNomeGuerra())
                .tipoVistoria(entity.getTipoVistoria())
                .diferencaVistoria(entity.getDiferencaVistoria())
                .viatura(entity.getViatura())
                .status(entity.getStatus())
                .dataVistoria(entity.getDataVistoria())
                .odometroInicial(entity.getOdometroInicial())
                .odometroFinal(entity.getOdometroFinal())
                .vistoriaViaturaHistorico(entity.getVistoriaViaturaHistorico())
                .vistoriaArquivoList(entity.getVistoriaArquivoList())
                .checkLists(checklistVistoriaRepository.findByVistoria(entity))
                .build());
    }

}
