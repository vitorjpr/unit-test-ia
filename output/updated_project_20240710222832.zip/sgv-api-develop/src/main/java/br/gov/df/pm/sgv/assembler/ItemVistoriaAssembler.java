package br.gov.df.pm.sgv.assembler;

import br.gov.df.pm.sgv.dto.ItemVistoriaDTO;
import br.gov.df.pm.sgv.domain.ItemVistoriaEntity;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.RepresentationModelAssembler;
import org.springframework.stereotype.Component;

@Component
public class ItemVistoriaAssembler implements RepresentationModelAssembler<ItemVistoriaEntity, EntityModel<ItemVistoriaDTO>> {
    @Override
    public EntityModel<ItemVistoriaDTO> toModel(ItemVistoriaEntity entity) {
        return EntityModel.of(ItemVistoriaDTO.builder()
                .id(entity.getId())
                .nome(entity.getNome())
                .descricao(entity.getDescricao())
                .dataInclusao(entity.getDataInclusao())
                .ativo(entity.getAtivo())
                .build());
    }
}
