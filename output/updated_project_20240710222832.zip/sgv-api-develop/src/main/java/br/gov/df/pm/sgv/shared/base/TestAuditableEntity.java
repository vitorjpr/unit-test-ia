Here are some unit tests for the provided Java code:

```java
package br.gov.df.pm.sgv.shared.base;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

@SpringBootTest
public class AuditableEntityTest {

    @MockBean
    private AuditableEntity<Long, Long> auditableEntity;

    @Test
    public void testGetSetCriadoPor() {
        auditableEntity.setCriadoPor(1L);
        assertNotNull(auditableEntity.getCriadoPor());
    }

    @Test
    public void testGetDataCriacao() {
        auditableEntity.setDataCriacao(LocalDateTime.now());
        assertNotNull(auditableEntity.getDataCriacao());
    }

    @Test
    public void testGetSetModificadoPor() {
        auditableEntity.setModificadoPor(2L);
        assertNotNull(auditableEntity.getModificadoPor());
    }

    @Test
    public void testGetUltimaAtualizacao() {
        auditableEntity.setUltimaAtualizacao(LocalDateTime.now());
        assertNotNull(auditableEntity.getUltimaAtualizacao());
    }

    @Test
    public void testNullCriadoPor() {
        auditableEntity.setCriadoPor(null);
        assertNull(auditableEntity.getCriadoPor());
    }

    @Test
    public void testNullDataCriacao() {
        auditableEntity.setDataCriacao(null);
        assertNull(auditableEntity.getDataCriacao());
    }

    @Test
    public void testNullModificadoPor() {
        auditableEntity.setModificadoPor(null);
        assertNull(auditableEntity.getModificadoPor());
    }

    @Test
    public void testNullUltimaAtualizacao() {
        auditableEntity.setUltimaAtualizacao(null);
        assertNull(auditableEntity.getUltimaAtualizacao());
    }

}
```

Make sure to include the necessary imports for the classes used in the tests. These tests cover basic scenarios for setting and getting the properties of the `AuditableEntity` class. You can expand these tests further based on your specific requirements and business logic.