package br.gov.df.pm.sgv.repository;

import br.gov.df.pm.sgv.domain.TipoVistoriaEntity;
import br.gov.df.pm.sgv.domain.VistoriaArquivo;
import br.gov.df.pm.sgv.domain.VistoriaViaturaEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.util.List;

public interface VIstoriaArquivoRepository extends JpaRepository<VistoriaArquivo, Long> {
    List<VistoriaArquivo> findByVistoriaViatura(VistoriaViaturaEntity vistoriaViatura);
}
