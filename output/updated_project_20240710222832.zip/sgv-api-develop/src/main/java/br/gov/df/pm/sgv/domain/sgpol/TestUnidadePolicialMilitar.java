```java
package br.gov.df.pm.sgv.domain.sgpol;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class UnidadePolicialMilitarTest {

    @Test
    public void testGetId() {
        UnidadePolicialMilitar upm = new UnidadePolicialMilitar();
        upm.setId(1);
        assertEquals(1, upm.getId());
    }

    @Test
    public void testGetSigla() {
        UnidadePolicialMilitar upm = new UnidadePolicialMilitar();
        upm.setSigla("SIGLA");
        assertEquals("SIGLA", upm.getSigla());
    }

    @Test
    public void testGetNome() {
        UnidadePolicialMilitar upm = new UnidadePolicialMilitar();
        upm.setNome("Nome");
        assertEquals("Nome", upm.getNome());
    }

    @Test
    public void testGetNomeHistorico() {
        UnidadePolicialMilitar upm = new UnidadePolicialMilitar();
        upm.setNomeHistorico("Nome Histórico");
        assertEquals("Nome Histórico", upm.getNomeHistorico());
    }

    @Test
    public void testGetAtivo() {
        UnidadePolicialMilitar upm = new UnidadePolicialMilitar();
        upm.setAtivo(1);
        assertEquals(1, upm.getAtivo());
    }

    @Test
    public void testIsComandoRegional() {
        UnidadePolicialMilitar upm = new UnidadePolicialMilitar();
        upm.setComandoRegional(true);
        assertTrue(upm.isComandoRegional());
    }

    // Add more tests for other methods as needed

}
```

Esses testes unitários cobrem os métodos `getId()`, `getSigla()`, `getNome()`, `getNomeHistorico()`, `getAtivo()` e `isComandoRegional()` da classe `UnidadePolicialMilitar`. Você pode adicionar mais testes para outros métodos conforme necessário.