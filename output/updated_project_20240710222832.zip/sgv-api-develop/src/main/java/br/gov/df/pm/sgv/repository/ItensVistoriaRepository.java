package br.gov.df.pm.sgv.repository;

import br.gov.df.pm.sgv.domain.ItemVistoriaEntity;
import br.gov.df.pm.sgv.domain.ItensVistoriaEntity;
import br.gov.df.pm.sgv.domain.TipoVistoriaEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ItensVistoriaRepository extends JpaRepository<ItensVistoriaEntity, Long> {
    List<ItensVistoriaEntity> findAllByCodTipo(TipoVistoriaEntity id);
    List<ItensVistoriaEntity> findAllByCodItem(ItemVistoriaEntity id);
    Optional<ItensVistoriaEntity> findByCodTipoAndCodItem(TipoVistoriaEntity idTipo, ItemVistoriaEntity idItem);
    List<ItensVistoriaEntity> findBycodTipoAndAtivo(TipoVistoriaEntity id, Boolean ativo);
}
