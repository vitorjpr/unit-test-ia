package br.gov.df.pm.sgv.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ItemVistoriaOcorrenciaDTO {
    private Long id;
    private String nome;
    private String descricao;
    private LocalDate dataInclusao;
    private Boolean ativo;
    private List<SubitemVistoriaDTO> subitemVistoriaDTOS;
}
