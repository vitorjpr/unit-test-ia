Here are some unit tests for the provided Java code:

```java
package br.gov.df.pm.sgv.dto;

import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class ViaturaDTOTest {

    @Test
    public void testViaturaDTOConstructor() {
        ViaturaDTO viaturaDTO = new ViaturaDTO(1L, "Prefixo", "NR123", "ABC1234", "Ativo", "T123", "R123", LocalDateTime.now(), LocalDateTime.now(), 1000.0, new ArrayList<>(), true);

        assertNotNull(viaturaDTO);
        assertEquals(1L, viaturaDTO.getId());
        assertEquals("Prefixo", viaturaDTO.getPrefixo());
        assertEquals("NR123", viaturaDTO.getNrSei());
        assertEquals("ABC1234", viaturaDTO.getPlaca());
        assertEquals("Ativo", viaturaDTO.getStatus());
        assertEquals("T123", viaturaDTO.getTombamento());
        assertEquals("R123", viaturaDTO.getRenavam());
        assertNotNull(viaturaDTO.getDataInclusao());
        assertNotNull(viaturaDTO.getDataAtualizacao());
        assertEquals(1000.0, viaturaDTO.getUltimoOdometro());
        assertNotNull(viaturaDTO.getVistoriaViatura());
        assertEquals(true, viaturaDTO.getAtivo());
    }

    @Test
    public void testViaturaDTOBuilder() {
        ViaturaDTO viaturaDTO = ViaturaDTO.builder()
                .id(1L)
                .prefixo("Prefixo")
                .nrSei("NR123")
                .placa("ABC1234")
                .status("Ativo")
                .tombamento("T123")
                .renavam("R123")
                .dataInclusao(LocalDateTime.now())
                .dataAtualizacao(LocalDateTime.now())
                .ultimoOdometro(1000.0)
                .vistoriaViatura(new ArrayList<>())
                .ativo(true)
                .build();

        assertNotNull(viaturaDTO);
        assertEquals(1L, viaturaDTO.getId());
        assertEquals("Prefixo", viaturaDTO.getPrefixo());
        assertEquals("NR123", viaturaDTO.getNrSei());
        assertEquals("ABC1234", viaturaDTO.getPlaca());
        assertEquals("Ativo", viaturaDTO.getStatus());
        assertEquals("T123", viaturaDTO.getTombamento());
        assertEquals("R123", viaturaDTO.getRenavam());
        assertNotNull(viaturaDTO.getDataInclusao());
        assertNotNull(viaturaDTO.getDataAtualizacao());
        assertEquals(1000.0, viaturaDTO.getUltimoOdometro());
        assertNotNull(viaturaDTO.getVistoriaViatura());
        assertEquals(true, viaturaDTO.getAtivo());
    }

    // Additional tests can be added here for other methods or behaviors of the ViaturaDTO class

}
```

These tests cover the constructor and builder methods of the `ViaturaDTO` class, ensuring that the object is properly initialized and its attributes are set correctly. You can add more tests to cover other methods or behaviors of the class as needed.