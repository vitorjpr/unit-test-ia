```java
package br.gov.df.pm.sgv.domain;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class VistoriaViaturaEntityTest {

    @Test
    public void testGettersAndSetters() {
        VistoriaViaturaEntity vistoriaViatura = new VistoriaViaturaEntity();

        vistoriaViatura.setId(1L);
        assertEquals(1L, vistoriaViatura.getId());

        vistoriaViatura.setIdPolicial(100);
        assertEquals(100, vistoriaViatura.getIdPolicial());

        vistoriaViatura.setIdUpm(200);
        assertEquals(200, vistoriaViatura.getIdUpm());

        ViaturaEntity viatura = new ViaturaEntity();
        vistoriaViatura.setViatura(viatura);
        assertEquals(viatura, vistoriaViatura.getViatura());

        TipoVistoriaEntity tipoVistoria = new TipoVistoriaEntity();
        vistoriaViatura.setTipoVistoria(tipoVistoria);
        assertEquals(tipoVistoria, vistoriaViatura.getTipoVistoria());

        List<VistoriaViaturaHistoricoEntity> historicoList = new ArrayList<>();
        vistoriaViatura.setVistoriaViaturaHistorico(historicoList);
        assertEquals(historicoList, vistoriaViatura.getVistoriaViaturaHistorico());

        List<VistoriaArquivo> arquivoList = new ArrayList<>();
        vistoriaViatura.setVistoriaArquivoList(arquivoList);
        assertEquals(arquivoList, vistoriaViatura.getVistoriaArquivoList());

        DiferencaOdometroEntity diferencaOdometro = new DiferencaOdometroEntity();
        vistoriaViatura.setDiferencaOdometro(diferencaOdometro);
        assertEquals(diferencaOdometro, vistoriaViatura.getDiferencaOdometro());

        vistoriaViatura.setStatus(VistoriaViaturaStatusEnum.PENDENTE);
        assertEquals(VistoriaViaturaStatusEnum.PENDENTE, vistoriaViatura.getStatus());

        vistoriaViatura.setOdometroInicial(1000.0f);
        assertEquals(1000.0f, vistoriaViatura.getOdometroInicial());

        vistoriaViatura.setOdometroFinal(1200.0f);
        assertEquals(1200.0f, vistoriaViatura.getOdometroFinal());

        vistoriaViatura.setDiferencaVistoria(true);
        assertTrue(vistoriaViatura.getDiferencaVistoria());

        LocalDateTime now = LocalDateTime.now();
        vistoriaViatura.setDataVistoria(now);
        assertEquals(now, vistoriaViatura.getDataVistoria());

        List<ChecklistVistoriaEntity> checkLists = new ArrayList<>();
        vistoriaViatura.setCheckLists(checkLists);
        assertEquals(checkLists, vistoriaViatura.getCheckLists());
    }

    // Add more tests as needed for other functionalities of the VistoriaViaturaEntity class

}
```