Sure! Here are the unit tests for the provided Java code:

```java
package br.gov.df.pm.sgv.exceptions;

import org.junit.Test;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class ItemVistoriaExceptionTest {

    @Test
    public void testDefaultConstructor() {
        ItemVistoriaException exception = new ItemVistoriaException();
        assertNotNull(exception);
    }

    @Test
    public void testConstructorWithMessage() {
        String message = "Test message";
        ItemVistoriaException exception = new ItemVistoriaException(message);
        assertNotNull(exception);
        assertEquals(message, exception.getMessage());
    }

    @Test
    public void testConstructorWithMessageAndCause() {
        String message = "Test message";
        Throwable cause = new RuntimeException("Test cause");
        ItemVistoriaException exception = new ItemVistoriaException(message, cause);
        assertNotNull(exception);
        assertEquals(message, exception.getMessage());
        assertEquals(cause, exception.getCause());
    }
}
```

These unit tests cover all three constructors of the `ItemVistoriaException` class, ensuring that they behave as expected.