package br.gov.df.pm.sgv.mapper;

import br.gov.df.pm.sgv.dto.SubitemVistoriaDTO;
import br.gov.df.pm.sgv.domain.SubitemVistoriaEntity;

public class SubitemVistoriaMapper {
    public SubitemVistoriaEntity convertEntity(SubitemVistoriaDTO subitemVistoriaDTO) {
        return SubitemVistoriaEntity.builder()
                .nome(subitemVistoriaDTO.getNome())
                .descricao(subitemVistoriaDTO.getDescricao())
                .dataInclusao(subitemVistoriaDTO.getDataInclusao())
                .ativo(subitemVistoriaDTO.getAtivo())
                .build();
    }

    public SubitemVistoriaDTO convertDTO(SubitemVistoriaEntity subitemVistoriaEntity) {
        return SubitemVistoriaDTO.builder()
                .nome(subitemVistoriaEntity.getNome())
                .descricao(subitemVistoriaEntity.getDescricao())
                .dataInclusao(subitemVistoriaEntity.getDataInclusao())
                .build();
    }
}
