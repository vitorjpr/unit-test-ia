package br.gov.df.pm.sgv.dto;

import br.gov.df.pm.sgv.domain.ItemVistoriaEntity;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDate;
import java.util.List;

@Data
@Builder
public class TipoVistoriaDTO {
    private Long id;
    private String nome;
    private String descricao;
    private String statusAnterior;
    private String statusPosterior;
    private LocalDate dataInclusao;
    private Boolean ativo;
    private List<ItemVistoriaEntity> itens;
}
