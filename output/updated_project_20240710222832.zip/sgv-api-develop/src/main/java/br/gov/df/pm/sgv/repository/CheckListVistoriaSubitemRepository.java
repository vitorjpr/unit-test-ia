package br.gov.df.pm.sgv.repository;

import br.gov.df.pm.sgv.domain.ChecklistVistoriaEntity;
import br.gov.df.pm.sgv.domain.ChecklistVistoriaSubItemEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CheckListVistoriaSubitemRepository extends JpaRepository<ChecklistVistoriaSubItemEntity, Long> {
}
