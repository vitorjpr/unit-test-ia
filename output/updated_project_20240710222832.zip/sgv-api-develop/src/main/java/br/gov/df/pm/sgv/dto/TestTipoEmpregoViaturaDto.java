Here are some unit tests for the provided Java code:

```java
package br.gov.df.pm.sgv.dto;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class TipoEmpregoViaturaDtoTest {

    @Test
    public void testConstructorAndGetters() {
        TipoEmpregoViaturaDto tipoEmpregoViaturaDto = new TipoEmpregoViaturaDto(1, "Teste", 1);

        assertEquals(1, tipoEmpregoViaturaDto.getId());
        assertEquals("Teste", tipoEmpregoViaturaDto.getNome());
        assertEquals(1, tipoEmpregoViaturaDto.getAtivo());
    }

    @Test
    public void testBuilder() {
        TipoEmpregoViaturaDto tipoEmpregoViaturaDto = TipoEmpregoViaturaDto.builder()
                .id(2)
                .nome("Teste2")
                .ativo(0)
                .build();

        assertEquals(2, tipoEmpregoViaturaDto.getId());
        assertEquals("Teste2", tipoEmpregoViaturaDto.getNome());
        assertEquals(0, tipoEmpregoViaturaDto.getAtivo());
    }

    @Test
    public void testSetter() {
        TipoEmpregoViaturaDto tipoEmpregoViaturaDto = new TipoEmpregoViaturaDto();
        tipoEmpregoViaturaDto.setId(3);
        tipoEmpregoViaturaDto.setNome("Teste3");
        tipoEmpregoViaturaDto.setAtivo(1);

        assertEquals(3, tipoEmpregoViaturaDto.getId());
        assertEquals("Teste3", tipoEmpregoViaturaDto.getNome());
        assertEquals(1, tipoEmpregoViaturaDto.getAtivo());
    }
}
```

Make sure to have the Lombok dependency in your project to properly run these tests. These tests cover the constructor, builder, and setters of the `TipoEmpregoViaturaDto` class.