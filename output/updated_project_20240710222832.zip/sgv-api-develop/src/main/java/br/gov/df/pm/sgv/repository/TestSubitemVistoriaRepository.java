Sure! Here are some unit tests for the `SubitemVistoriaRepository` class:

```java
package br.gov.df.pm.sgv.repository;

import br.gov.df.pm.sgv.domain.SubitemVistoriaEntity;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@DataJpaTest
public class SubitemVistoriaRepositoryTest {

    @Autowired
    private SubitemVistoriaRepository subitemVistoriaRepository;

    @Autowired
    private TestEntityManager entityManager;

    @Test
    public void testFindByNome() {
        // Given
        SubitemVistoriaEntity subitem = new SubitemVistoriaEntity();
        subitem.setNome("Test Subitem");
        entityManager.persist(subitem);
        entityManager.flush();

        // When
        Optional<SubitemVistoriaEntity> foundSubitem = subitemVistoriaRepository.findByNome("Test Subitem");

        // Then
        assertEquals(subitem, foundSubitem.orElse(null));
    }

    @Test
    public void testFindByNome_NotFound() {
        // Given
        SubitemVistoriaEntity subitem = new SubitemVistoriaEntity();
        subitem.setNome("Test Subitem");
        entityManager.persist(subitem);
        entityManager.flush();

        // When
        Optional<SubitemVistoriaEntity> foundSubitem = subitemVistoriaRepository.findByNome("Nonexistent Subitem");

        // Then
        assertEquals(Optional.empty(), foundSubitem);
    }
}
```

These tests cover the `findByNome` method of the `SubitemVistoriaRepository` class. The first test checks if the method returns the correct entity when searching by name, and the second test checks if it returns an empty optional when the entity is not found.

Make sure to include the necessary dependencies in your project to run these tests, such as JUnit, Mockito, and Spring Boot test dependencies. Let me know if you need further assistance!