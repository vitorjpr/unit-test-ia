package br.gov.df.pm.sgv.controller.v1;

import br.gov.df.pm.sgv.domain.ChecklistVistoriaEntity;
import br.gov.df.pm.sgv.domain.TipoVistoriaEntity;
import br.gov.df.pm.sgv.domain.ViaturaEntity;
import br.gov.df.pm.sgv.domain.VistoriaViaturaEntity;
import br.gov.df.pm.sgv.domain.sgpol.UnidadePolicialMilitar;
import br.gov.df.pm.sgv.dto.*;
import br.gov.df.pm.sgv.feign.dto.MessageAuthKeycloak;
import br.gov.df.pm.sgv.service.*;
import br.gov.df.pm.sgv.service.sgpol.UnidadePolicialMilitarService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/v1/aplicativo")
public class AplicativoVistoriaV1 {

    @Autowired
    private UnidadePolicialMilitarService unidadePolicialMilitarService;

    @Autowired
    private TipoEmpregoViaturaService tipoEmpregoViaturaService;

    @Autowired
    private ViaturaService viaturaService;

    @Autowired
    private TipoDefeitoVistoriaService tipoDefeitoVistoriaService;

    @Autowired
    private TipoVistoriaService tipoVistoriaService;

    @Autowired
    private ItemVistoriaService itemVistoriaService;

    @Autowired
    private SubitemVistoriaService subitemVistoriaService;

    @Autowired
    private VistoriaService vistoriaService;

    @Autowired
    private AuthService authService;

    @GetMapping("/listUnidades")
    public List<UnidadePolicialMilitar> findAllUnidades() {
        List<UnidadePolicialMilitar> unidadePolicialMilitars = new ArrayList<>();
        List<UnidadePolicialMilitar> upms = unidadePolicialMilitarService.listar();
        upms.forEach(unidadePolicialMilitar -> {
            if (unidadePolicialMilitar.getAtivo() == 1) {
                unidadePolicialMilitars.add(unidadePolicialMilitar);
            }

        });
        return unidadePolicialMilitars;
    }

    @GetMapping("/listTipoViatura")
    public List<TipoEmpregoViaturaDto> findAllTipoViatura() {
        return tipoEmpregoViaturaService.listTipoEmpregoViaturaAtivo();
    }

    @GetMapping("/buscarViatura")
    public Page<ViaturaEntity> buscar(@RequestParam(value = "upmCodigo", required = false) Integer upmCodigo,
                                      @RequestParam(value = "prefixo", required = false) String prefixo,
                                      @RequestParam(value = "placa", required = false) String placa,
                                      @RequestParam(value = "tipoEmpregoViatura", required = false) Integer tepCodigo,
                                      Pageable pageable) {
        return viaturaService.buscarViatura(upmCodigo, prefixo, placa, tepCodigo, pageable);
    }

    @GetMapping("/buscarViaturaAtivas")
    public Page<ViaturaEntity> buscar(Pageable pageable) {
        return viaturaService.buscarViaturasAtivas(pageable);
    }

    @GetMapping("/listTipoDefeitosAtivos")
    public List<TipoDefeitoVistoriaDTO> listAllAtivos() {
        return tipoDefeitoVistoriaService.listAllAtivos();
    }

    @GetMapping("/listTipoVistoriaAtivos")
    public List<TipoVistoriaDTO> listAllTipoVistoriaAtivos() {
        return tipoVistoriaService.listAllTipoVistoriaAtivos();
    }

    @GetMapping("/listOcorrencias/{tipoVistoria}")
    public OcorrenciasDTO listOcorrenciaByTipoVistoria(@PathVariable Long tipoVistoria) {
        return itemVistoriaService.listAllAtivosByTipoVistoria(tipoVistoria);
    }

    @PostMapping(value = "/cadastrarVistoria", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    ResponseEntity<VistoriaViaturaEntity> salvar(@RequestPart("vistoria") String vistoria,
                                                 @RequestPart(required = false, name = "arquivos") List<MultipartFile> arquivos) {


        return vistoriaService.salvar(vistoria, arquivos);
    }

    @GetMapping("/buscarVistoriaByViatura/{viaturaId}")
    public ResponseEntity<VistoriaViaturaEntity> vistoriaByViatura(@PathVariable Long viaturaId) {
        return vistoriaService.vistoriaByViatura(viaturaId);
    }

    @GetMapping("/buscarVistoriaById/{id}")
    public ResponseEntity<VistoriaViaturaEntity> findVistoriaById(@PathVariable Long id) {
        return vistoriaService.findVistoriaById(id);
    }


    @PatchMapping(value = "/editarVistoria", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<VistoriaViaturaEntity> editById(@RequestPart("vistoria") String vistoria,
                                                          @RequestPart(required = false, name = "arquivos") List<MultipartFile> arquivos) {
        return vistoriaService.editVistoriaById(vistoria, arquivos);
    }

    @GetMapping("/montarChecklist/{idTipoVistoria}")
    public ResponseEntity<ChecklistVistoriaEntity> makeChecklistByIdTipoVistoria(@PathVariable Long idTipoVistoria) {
        return vistoriaService.makeChecklistByTipoVistoria(idTipoVistoria);
    }

    @PostMapping("/iniciarVistoria/{idViatura}/{idTipoVistoria}")
    public ResponseEntity<VistoriaViaturaEntity> iniciarVistoria(@PathVariable("idViatura") Long idViatura, @PathVariable("idTipoVistoria") Long idTipoVistoria) {
        return vistoriaService.iniciarVistoria(idViatura, idTipoVistoria);
    }

    @PostMapping("/finalizar/{idVistoria}")
    public ResponseEntity<VistoriaViaturaEntity> finalizar(@PathVariable("idVistoria") Long idVistoria) {
        return vistoriaService.finalizarVistoria(idVistoria);
    }
    @GetMapping("/listar/{idViatura}")
    public List<TipoVistoriaEntity> buscaTiposVistoriaByStatusViatura(@PathVariable("idViatura") Long idViatura) {
        return tipoVistoriaService.listAllTipoVistoriaByStatusViatura(idViatura);
    }

    @PostMapping("/auth")
    public ResponseEntity<MessageAuthKeycloak> auth(@RequestBody AuthDTO auth) {
        return authService.authentication(auth);
    }
}
