```java
package br.gov.df.pm.sgv.configurations.security;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class KeyCloakPropertiesTest {

    @Test
    public void testGetAuthServerUrl() {
        KeyCloakProperties properties = new KeyCloakProperties();
        properties.setAuthServerUrl("http://example.com/auth");
        assertEquals("http://example.com/auth", properties.getAuthServerUrl());
    }

    @Test
    public void testSetAuthServerUrl() {
        KeyCloakProperties properties = new KeyCloakProperties();
        properties.setAuthServerUrl("http://example.com/auth");
        assertEquals("http://example.com/auth", properties.getAuthServerUrl());
    }

    @Test
    public void testGetRealm() {
        KeyCloakProperties properties = new KeyCloakProperties();
        properties.setRealm("myrealm");
        assertEquals("myrealm", properties.getRealm());
    }

    @Test
    public void testSetRealm() {
        KeyCloakProperties properties = new KeyCloakProperties();
        properties.setRealm("myrealm");
        assertEquals("myrealm", properties.getRealm());
    }
}
``` 

Esses testes garantem que os métodos `getAuthServerUrl`, `setAuthServerUrl`, `getRealm` e `setRealm` da classe `KeyCloakProperties` funcionam corretamente.