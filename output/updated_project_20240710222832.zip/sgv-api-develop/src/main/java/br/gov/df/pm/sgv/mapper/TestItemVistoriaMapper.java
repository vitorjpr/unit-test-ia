Here are some unit tests for the `ItemVistoriaMapper` class:

```java
package br.gov.df.pm.sgv.mapper;

import br.gov.df.pm.sgv.dto.ItemVistoriaDTO;
import br.gov.df.pm.sgv.domain.ItemVistoriaEntity;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class ItemVistoriaMapperTest {

    @Test
    public void testConvertEntity() {
        ItemVistoriaDTO dto = ItemVistoriaDTO.builder()
                .nome("Teste")
                .descricao("Descrição de teste")
                .build();

        ItemVistoriaEntity entity = new ItemVistoriaMapper().convertEntity(dto);

        assertNotNull(entity);
        assertEquals("Teste", entity.getNome());
        assertEquals("Descrição de teste", entity.getDescricao());
        assertEquals(LocalDate.now(), entity.getDataInclusao());
        assertEquals(true, entity.getAtivo());
    }

    @Test
    public void testConvertDTO() {
        ItemVistoriaEntity entity = ItemVistoriaEntity.builder()
                .nome("Teste")
                .descricao("Descrição de teste")
                .dataInclusao(LocalDate.now())
                .ativo(true)
                .id(1L)
                .build();

        ItemVistoriaDTO dto = new ItemVistoriaMapper().convertDTO(entity);

        assertNotNull(dto);
        assertEquals("Teste", dto.getNome());
        assertEquals("Descrição de teste", dto.getDescricao());
        assertEquals(LocalDate.now(), dto.getDataInclusao());
        assertEquals(true, dto.getAtivo());
        assertEquals(1L, dto.getId());
    }
}
```

These tests cover the conversion methods `convertEntity` and `convertDTO` of the `ItemVistoriaMapper` class, ensuring that the mapping between `ItemVistoriaDTO` and `ItemVistoriaEntity` is performed correctly.