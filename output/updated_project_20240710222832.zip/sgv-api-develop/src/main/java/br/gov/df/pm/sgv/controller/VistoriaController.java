package br.gov.df.pm.sgv.controller;

import br.gov.df.pm.sgv.assembler.app.VistoriaAssembler;
import br.gov.df.pm.sgv.domain.VistoriaArquivo;
import br.gov.df.pm.sgv.domain.VistoriaViaturaEntity;
import br.gov.df.pm.sgv.domain.sgpol.Policial;
import br.gov.df.pm.sgv.domain.sgpol.UnidadePolicialMilitar;
import br.gov.df.pm.sgv.dto.FiltroVistoria;
import br.gov.df.pm.sgv.dto.ViaturaDTO;
import br.gov.df.pm.sgv.dto.VistoriaDTO;
import br.gov.df.pm.sgv.service.VistoriaService;
import br.gov.df.pm.sgv.service.sgpol.PolicialService;
import br.gov.df.pm.sgv.service.sgpol.UnidadePolicialMilitarService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springdoc.core.converters.models.PageableAsQueryParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.PagedModel;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/vistoria")
public class VistoriaController {
    @Autowired
    private final VistoriaService vistoriaService;
    @Autowired
    private final VistoriaAssembler vistoriaAssembler;
    @Autowired
    private final PolicialService policialService;
    @Autowired
    private final UnidadePolicialMilitarService unidadePolicialMilitarService;
    @Autowired
    private final PagedResourcesAssembler<VistoriaViaturaEntity> pagedResourcesAssembler;

    public VistoriaController(VistoriaService vistoriaService,
                              VistoriaAssembler vistoriaAssembler,
                              PolicialService policialService,
                              UnidadePolicialMilitarService unidadePolicialMilitarService,
                              PagedResourcesAssembler<VistoriaViaturaEntity> pagedResourcesAssembler) {
        this.vistoriaService = vistoriaService;
        this.vistoriaAssembler = vistoriaAssembler;
        this.policialService = policialService;
        this.unidadePolicialMilitarService = unidadePolicialMilitarService;
        this.pagedResourcesAssembler = pagedResourcesAssembler;
    }

    @PostMapping("/buscar")
    @PageableAsQueryParam
    public PagedModel<EntityModel<VistoriaDTO>> buscar(
            @RequestBody(required = false) FiltroVistoria filtro,
            @PageableDefault(sort = "id", direction = Sort.Direction.DESC, size = 10)
            Pageable pageable) {
        var result = pagedResourcesAssembler.toModel(vistoriaService.buscar(filtro, pageable));
        return PagedModel.of(result.getContent().stream().map(e ->
                vistoriaAssembler.toModel(Objects.requireNonNull(e.getContent()))).collect(Collectors.toList()), result.getMetadata());
    }

    @PostMapping(value = "/salvar", consumes = MediaType.MULTIPART_FORM_DATA_VALUE )
    ResponseEntity<VistoriaViaturaEntity> salvar(@RequestPart("vistoria") String vistoria,
                                                 @RequestPart(required = false, name = "arquivos") List<MultipartFile> arquivos) {


        return vistoriaService.salvar(vistoria, arquivos);
    }

    @GetMapping("/vistoriaByViatura/{viaturaId}")
    public ResponseEntity<VistoriaViaturaEntity> vistoriaByViatura(@PathVariable Long viaturaId) {
        return vistoriaService.vistoriaByViatura(viaturaId);
    }

    @GetMapping("/{id}")
    public ResponseEntity<VistoriaViaturaEntity> findVistoriaById(@PathVariable Long id) {
        return vistoriaService.findVistoriaById(id);
    }
    @GetMapping("vistoria/{id}")
    public EntityModel<VistoriaDTO> findById(@PathVariable Long id) {
        return vistoriaAssembler.toModel(vistoriaService.findById(id));
    }

    @PatchMapping(value = "/editar", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<VistoriaViaturaEntity> editById(@RequestPart("vistoria") String vistoria,
                                                          @RequestPart(required = false, name = "arquivos") List<MultipartFile> arquivos) {
        return vistoriaService.editVistoriaById(vistoria, arquivos);
    }

    @PostMapping("/finalizar/{idVistoria}")
    public ResponseEntity<VistoriaViaturaEntity> finalizar(@PathVariable("idVistoria") Long idVistoria) {
        return vistoriaService.finalizarVistoria(idVistoria);
    }

    @GetMapping("/listUnidades")
    public List<UnidadePolicialMilitar> findAllUnidades(){
        List<UnidadePolicialMilitar> unidadePolicialMilitars = new ArrayList<>();
        List<UnidadePolicialMilitar> upms = unidadePolicialMilitarService.listar();
        upms.forEach(unidadePolicialMilitar -> {
            if(unidadePolicialMilitar.getAtivo() == 1){
                unidadePolicialMilitars.add(unidadePolicialMilitar);
            }

        });
        return unidadePolicialMilitars;
    }
}
