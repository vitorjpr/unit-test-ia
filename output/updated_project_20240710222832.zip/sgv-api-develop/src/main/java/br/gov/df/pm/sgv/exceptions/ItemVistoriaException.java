package br.gov.df.pm.sgv.exceptions;

public class ItemVistoriaException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public ItemVistoriaException() {
    }

    public ItemVistoriaException(String message) {
        super(message);
    }

    public ItemVistoriaException(String message, Throwable cause) {
        super(message, cause);
    }
}
