```java
package br.gov.df.pm.sgv.controller.v1;

import br.gov.df.pm.sgv.domain.ChecklistVistoriaEntity;
import br.gov.df.pm.sgv.domain.TipoVistoriaEntity;
import br.gov.df.pm.sgv.domain.ViaturaEntity;
import br.gov.df.pm.sgv.domain.VistoriaViaturaEntity;
import br.gov.df.pm.sgv.domain.sgpol.UnidadePolicialMilitar;
import br.gov.df.pm.sgv.dto.AuthDTO;
import br.gov.df.pm.sgv.dto.OcorrenciasDTO;
import br.gov.df.pm.sgv.dto.TipoDefeitoVistoriaDTO;
import br.gov.df.pm.sgv.dto.TipoVistoriaDTO;
import br.gov.df.pm.sgv.feign.dto.MessageAuthKeycloak;
import br.gov.df.pm.sgv.service.*;
import br.gov.df.pm.sgv.service.sgpol.UnidadePolicialMilitarService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class AplicativoVistoriaV1Test {

    @InjectMocks
    private AplicativoVistoriaV1 aplicativoVistoriaV1;

    @Mock
    private UnidadePolicialMilitarService unidadePolicialMilitarService;

    @Mock
    private TipoEmpregoViaturaService tipoEmpregoViaturaService;

    @Mock
    private ViaturaService viaturaService;

    @Mock
    private TipoDefeitoVistoriaService tipoDefeitoVistoriaService;

    @Mock
    private TipoVistoriaService tipoVistoriaService;

    @Mock
    private ItemVistoriaService itemVistoriaService;

    @Mock
    private VistoriaService vistoriaService;

    @Mock
    private AuthService authService;

    @Test
    public void testFindAllUnidades() {
        // Mock data
        UnidadePolicialMilitar upm = new UnidadePolicialMilitar();
        upm.setAtivo(1);
        List<UnidadePolicialMilitar> upms = new ArrayList<>();
        upms.add(upm);
        when(unidadePolicialMilitarService.listar()).thenReturn(upms);

        // Test
        List<UnidadePolicialMilitar> result = aplicativoVistoriaV1.findAllUnidades();

        // Verify
        assertEquals(1, result.size());
    }

    // Add tests for other methods in a similar manner

    // Note: Add tests for all methods in AplicativoVistoriaV1 class

}
``` 

Este é um exemplo de teste unitário para a classe `AplicativoVistoriaV1`. Certifique-se de adicionar testes para todos os métodos da classe, seguindo a mesma abordagem de mockar os serviços e verificar os resultados esperados.