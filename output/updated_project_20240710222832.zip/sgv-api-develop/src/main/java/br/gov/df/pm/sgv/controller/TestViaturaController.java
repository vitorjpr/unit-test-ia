Here are some unit tests for the provided Java code using JUnit 5:

```java
package br.gov.df.pm.sgv.controller;

import br.gov.df.pm.sgv.assembler.app.ViaturaAssembler;
import br.gov.df.pm.sgv.domain.ViaturaEntity;
import br.gov.df.pm.sgv.dto.TipoEmpregoViaturaDto;
import br.gov.df.pm.sgv.dto.ViaturaDTO;
import br.gov.df.pm.sgv.service.ViaturaService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.PagedModel;
import org.springframework.http.ResponseEntity;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class ViaturaControllerTest {

    private ViaturaController viaturaController;
    private ViaturaService viaturaService;
    private ViaturaAssembler viaturaAssembler;
    private PagedResourcesAssembler<ViaturaEntity> pagedResourcesAssembler;

    @BeforeEach
    void setUp() {
        viaturaService = mock(ViaturaService.class);
        viaturaAssembler = mock(ViaturaAssembler.class);
        pagedResourcesAssembler = mock(PagedResourcesAssembler.class);
        viaturaController = new ViaturaController(viaturaService, viaturaAssembler, pagedResourcesAssembler);
    }

    @Test
    void testBuscar() {
        // Mocking data
        Pageable pageable = Pageable.unpaged();
        Page<ViaturaEntity> viaturaPage = mock(Page.class);
        when(viaturaService.buscar(null, null, null, pageable)).thenReturn(viaturaPage);

        PagedModel<EntityModel<ViaturaDTO>> expectedModel = mock(PagedModel.class);
        when(pagedResourcesAssembler.toModel(viaturaPage)).thenReturn(expectedModel);

        // Test
        PagedModel<EntityModel<ViaturaDTO>> result = viaturaController.buscar(null, null, null, pageable);

        assertEquals(expectedModel, result);
    }

    @Test
    void testFindPaginado() {
        // Mocking data
        Pageable pageable = Pageable.unpaged();
        Page<ViaturaEntity> expectedPage = mock(Page.class);
        when(viaturaService.findPaginado(pageable)).thenReturn(expectedPage);

        // Test
        Page<ViaturaEntity> result = viaturaController.findPaginado(pageable);

        assertEquals(expectedPage, result);
    }

    @Test
    void testListarUpm() {
        // Mocking data
        List<UnidadePolicialMilitar> expectedList = mock(List.class);
        ResponseEntity<List<UnidadePolicialMilitar>> expectedResponse = ResponseEntity.ok(expectedList);
        when(viaturaService.listarUpm()).thenReturn(expectedResponse);

        // Test
        ResponseEntity<List<UnidadePolicialMilitar>> result = viaturaController.listarUpm();

        assertEquals(expectedResponse, result);
    }

    @Test
    void testListarTipoEmprego() {
        // Mocking data
        List<TipoEmpregoViaturaDto> expectedList = mock(List.class);
        ResponseEntity<List<TipoEmpregoViaturaDto>> expectedResponse = ResponseEntity.ok(expectedList);
        when(viaturaService.listar()).thenReturn(expectedResponse);

        // Test
        ResponseEntity<List<TipoEmpregoViaturaDto>> result = viaturaController.listAll();

        assertEquals(expectedResponse, result);
    }
}
```

Please note that the above tests are just a starting point and may need further refinement based on the specific behavior of your application and the requirements of your project.