package br.gov.df.pm.sgv.service.impl;

import br.gov.df.pm.sgv.domain.*;
import br.gov.df.pm.sgv.domain.enums.VistoriaViaturaStatusEnum;
import br.gov.df.pm.sgv.domain.sgpol.Policial;
import br.gov.df.pm.sgv.domain.sgpol.UnidadePolicialMilitar;
import br.gov.df.pm.sgv.dto.FiltroVistoria;
import br.gov.df.pm.sgv.dto.VistoriaDTO;
import br.gov.df.pm.sgv.exceptions.ResourceNotFoundException;
import br.gov.df.pm.sgv.exceptions.ViaturaException;
import br.gov.df.pm.sgv.exceptions.VistoriaExceptions;
import br.gov.df.pm.sgv.mapper.VistoriaViaturaMapper;
import br.gov.df.pm.sgv.repository.*;
import br.gov.df.pm.sgv.repository.app.ViaturaRepository;
import br.gov.df.pm.sgv.repository.app.VistoriaViaturaHistoricoRepository;
import br.gov.df.pm.sgv.repository.app.VistoriaViaturaRepository;
import br.gov.df.pm.sgv.security.UserProvider;
import br.gov.df.pm.sgv.service.StorageService;
import br.gov.df.pm.sgv.service.VistoriaService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDateTime;
import java.util.*;

@Service
public class VistoriaServiceImpl implements VistoriaService {

    @Autowired
    private VistoriaViaturaRepository vistoriaRepository;
    @Autowired
    private VistoriaViaturaHistoricoRepository vistoriaViaturaHistoricoRepository;
    @Autowired
    private VIstoriaArquivoRepository vIstoriaArquivoRepository;
    @Autowired
    private ViaturaRepository viaturaRepository;
    @Autowired
    private UserProvider userProvider;
    @Autowired
    private StorageService storageService;
    @Autowired
    private ChecklistVistoriaRepository checklistVistoriaRepository;
    @Autowired
    private ChecklistVistoriaItemRepository checklistVistoriaItemRepository;
    @Autowired
    private CheckListVistoriaSubitemRepository checkListVistoriaSubitemRepository;
    @Autowired
    private ItensVistoriaRepository itensVistoriaRepository;
    @Autowired
    private TipoVistoriaRepository tipoVistoriaRepository;
    @Autowired
    private ItemVistoriaRepository itemVistoriaRepository;
    @Autowired
    private SubitensVistoriaRepository subitensVistoriaRepository;
    @Autowired
    private SubitemVistoriaRepository subitemVistoriaRepository;
    @Autowired
    private TipoDefeitoVistoriaRepository tipoDefeitoVistoriaRepository;
    @Autowired
    private DefeitosVistoriaRepository defeitosVistoriaRepository;

    @Override
    public ResponseEntity<VistoriaViaturaEntity> salvar(String vistoriaString, List<MultipartFile> arquivos) {
        VistoriaDTO vistoriaDTO = convertStringVistoriaDTO(vistoriaString);

        if (vistoriaDTO != null) {
            UnidadePolicialMilitar unidadePolicialMilitar = new UnidadePolicialMilitar();
            unidadePolicialMilitar.setId(642);
            Policial policial = new Policial();
            policial.setId(9278);

            var vistoriaToSave = new VistoriaViaturaMapper().convertEntity(vistoriaDTO);
            vistoriaToSave.setIdPolicial(userProvider.getPolicialAutenticado().getId());
            vistoriaToSave.setIdUpm(userProvider.getUnidadePolicialAutenticado().getId());
            vistoriaToSave.setDataVistoria(LocalDateTime.now());
            vistoriaToSave.getViatura().setStatus(vistoriaToSave.getTipoVistoria().getStatusPosterior());

            ViaturaEntity viatura = viaturaRepository.findById(vistoriaToSave.getViatura().getId()).orElseThrow(()-> new ViaturaException("Viatura não encontrada."));
            ViaturaEntity viaturaToSave =  ViaturaEntity.builder()
                    .id(viatura.getId())
                    .status(vistoriaToSave.getTipoVistoria().getStatusPosterior())
                    .prefixo(viatura.getPrefixo())
                    .nrSei(viatura.getNrSei())
                    .placa(viatura.getPlaca())
                    .tombamento(viatura.getTombamento())
                    .renavam(viatura.getRenavam())
                    .dataInclusao(viatura.getDataInclusao())
                    .dataAtualizacao(viatura.getDataAtualizacao())
                    .ativo(viatura.getAtivo())
                    .tipoEmpregoViatura(viatura.getTipoEmpregoViatura())
                    .listaUpm(viatura.getListaUpm())
                    .marcaModelo(viatura.getMarcaModelo())
                    .build();
            viaturaRepository.save(viaturaToSave);

            VistoriaViaturaEntity savedVistoriaViatura = vistoriaRepository.save(vistoriaToSave);



            if (vistoriaDTO.getCheckLists() != null) {
                List<ChecklistVistoriaEntity> checklistVistoriaList = new ArrayList<>();
                for (ChecklistVistoriaEntity checklist : vistoriaDTO.getCheckLists()) {
                    ChecklistVistoriaEntity checklistVistoria = new ChecklistVistoriaEntity();
                    checklistVistoria.setObservacao(checklist.getObservacao());
                    checklistVistoria.setDataCriacao(new Date());
                    checklistVistoria.setVistoria(savedVistoriaViatura);
                    checklistVistoria.setItemVistoria(checklist.getItemVistoria());

                    ChecklistVistoriaEntity savedChecklist = checklistVistoriaRepository.save(checklistVistoria);

                    if (checklist.getChecklistItens() != null) {
                        List<ChecklistItemVistoriaEntity> checklistItemVistoriaList = new ArrayList<>();

                        for (ChecklistItemVistoriaEntity item : checklist.getChecklistItens()) {
                            ChecklistItemVistoriaEntity checklistItemVistoria = new ChecklistItemVistoriaEntity();
                            //checklistItemVistoria.setDataCriacao(new Date());
                            checklistItemVistoria.setChecklistVistoria(savedChecklist);
                            checklistItemVistoria.setSubitemVistoria(item.getSubitemVistoria());
                            ChecklistItemVistoriaEntity checklistItemVistoriaSaved = checklistVistoriaItemRepository.save(checklistItemVistoria);


                            if(item.getChecklistVistoriaSubItem() != null){

                                List<ChecklistVistoriaSubItemEntity> checklistVistoriaSubItemList = new ArrayList<>();

                                for(ChecklistVistoriaSubItemEntity itemSubItem:item.getChecklistVistoriaSubItem()){
                                    ChecklistVistoriaSubItemEntity checklistVistoriaSubItem = new ChecklistVistoriaSubItemEntity();
                                    checklistVistoriaSubItem.setSelecionado(itemSubItem.getSelecionado());
                                    checklistVistoriaSubItem.setTipoDefeitoVistoria(itemSubItem.getTipoDefeitoVistoria());
                                    checklistVistoriaSubItem.setDataCriacao(new Date());
                                    checklistVistoriaSubItem.setChecklistItemVistoria(checklistItemVistoriaSaved);
                                    ChecklistVistoriaSubItemEntity checklistVistoriaSubItemSaved = checkListVistoriaSubitemRepository.save(checklistVistoriaSubItem);
                                    checklistVistoriaSubItemList.add(checklistVistoriaSubItemSaved);
                                }
                                checklistItemVistoriaSaved.setChecklistVistoriaSubItem(checklistVistoriaSubItemList);
                            }

                            checklistItemVistoriaList.add(checklistItemVistoriaSaved);
                        }
                        savedChecklist.setChecklistItens(checklistItemVistoriaList);
                    }

                    checklistVistoriaList.add(savedChecklist);
                }
                savedVistoriaViatura.setCheckLists(checklistVistoriaList);
            }

            VistoriaViaturaHistoricoEntity vistoriaViaturaHistorico = new VistoriaViaturaHistoricoEntity();
            vistoriaViaturaHistorico.setUnidadePolicialMilitar(unidadePolicialMilitar);
            vistoriaViaturaHistorico.setPolicial(policial);
            vistoriaViaturaHistorico.setData(new Date());
            vistoriaViaturaHistorico.setStatus(VistoriaViaturaStatusEnum.EM_VISTORIA);
            vistoriaViaturaHistorico.setVistoriaViatura(savedVistoriaViatura);
            vistoriaViaturaHistoricoRepository.save(vistoriaViaturaHistorico);

            // Salva os arquivos relacionados
            if (arquivos != null) {
                List<VistoriaArquivo> vistoriaArquivoList = new ArrayList<>();
                for (MultipartFile arquivo : arquivos) {
                    ResponseEntity<UUID> response = storageService.salvarImagem(arquivo);
                    if (response.getStatusCode().is2xxSuccessful()) {
                        UUID idImagem = response.getBody();
                        VistoriaArquivo vistoriaArquivo = new VistoriaArquivo();
                        vistoriaArquivo.setIdentidade(idImagem.toString());
                        vistoriaArquivo.setNomeImagem(arquivo.getOriginalFilename());
                        vistoriaArquivo.setDataCriacao(new Date());
                        vistoriaArquivo.setVistoriaViatura(savedVistoriaViatura);
                        VistoriaArquivo vistoriaArquivoSaved = vIstoriaArquivoRepository.save(vistoriaArquivo);
                        vistoriaArquivoList.add(vistoriaArquivoSaved);
                    } else {
                        throw new RuntimeException("Erro ao salvar imagem");
                    }
                }
                savedVistoriaViatura.setVistoriaArquivoList(vistoriaArquivoList);

            }
            return ResponseEntity.ok(savedVistoriaViatura);
        } else {
            throw new RuntimeException("Vistoria não encontrada");
        }
    }

    @Override
    public ResponseEntity<VistoriaViaturaEntity> findVistoriaById(Long id) {
        VistoriaViaturaEntity vistoriaViaturaEntity = entityExists(id);
        return ResponseEntity.ok(vistoriaViaturaEntity);
    }
    @Override
    public VistoriaViaturaEntity findById(Long id) {
        return entityExists(id);
    }

    @Override
    public ResponseEntity<VistoriaViaturaEntity> editVistoriaById(String vistoriaString, List<MultipartFile> arquivos) {
        VistoriaDTO vistoriaDTO = convertStringVistoriaDTO(vistoriaString);

        if(vistoriaDTO != null) {

            VistoriaViaturaEntity vistoriaViaturaEntity = entityExists(vistoriaDTO.getId());

            if(arquivos != null){

                for (MultipartFile arquivo : arquivos) {
                    ResponseEntity<UUID> response = storageService.salvarImagem(arquivo);

                    if (response.getStatusCode().is2xxSuccessful()) {
                        UUID idImagem = response.getBody();
                        VistoriaArquivo vistoriaArquivo = new VistoriaArquivo();
                        vistoriaArquivo.setIdentidade(idImagem.toString());
                        vistoriaArquivo.setNomeImagem(arquivo.getOriginalFilename());
                        vistoriaArquivo.setDataCriacao(new Date());
                        vistoriaArquivo.setVistoriaViatura(vistoriaViaturaEntity);
                        VistoriaArquivo vistoriaArquivoSaved =  vIstoriaArquivoRepository.save(vistoriaArquivo);
                        vistoriaViaturaEntity.getVistoriaArquivoList().add(vistoriaArquivoSaved);

                    } else {
                        throw new RuntimeException("Erro ao salvar imagem");
                    }
                }


            }

            if (vistoriaDTO.getDataVistoria() != null) {
                vistoriaViaturaEntity.setDataVistoria(vistoriaDTO.getDataVistoria());
            }
            if (vistoriaDTO.getDiferencaVistoria() != null) {
                vistoriaViaturaEntity.setDiferencaVistoria(vistoriaDTO.getDiferencaVistoria());
            }
            if (vistoriaDTO.getTipoVistoria() != null) {
                vistoriaViaturaEntity.setTipoVistoria(vistoriaDTO.getTipoVistoria());
            }
            if (vistoriaDTO.getViatura() != null) {
                vistoriaViaturaEntity.setViatura(vistoriaDTO.getViatura());
            }
            if (vistoriaDTO.getDiferencaOdometro() != null) {
                vistoriaViaturaEntity.setDiferencaOdometro(vistoriaDTO.getDiferencaOdometro());
            }
            if (vistoriaDTO.getOdometroInicial() != null) {
                vistoriaViaturaEntity.setOdometroInicial(vistoriaDTO.getOdometroInicial());
            }
            if (vistoriaDTO.getOdometroFinal() != null) {
                vistoriaViaturaEntity.setOdometroFinal(vistoriaDTO.getOdometroFinal());
            }
            if (vistoriaDTO.getStatus() != null) {
                vistoriaViaturaEntity.setStatus(vistoriaDTO.getStatus());
            }
            if(vistoriaDTO.getCheckLists() != null){
                vistoriaViaturaEntity.setCheckLists(vistoriaDTO.getCheckLists());
            }
            VistoriaViaturaEntity vistoriaViatura = vistoriaRepository.save(vistoriaViaturaEntity);


            return ResponseEntity.ok(vistoriaViatura);

        } else {
            throw new VistoriaExceptions("Problema ao converter String vistoria para objeto Vistoria DTO");
        }

    }

    @Override
    public ResponseEntity<VistoriaViaturaEntity> finalizarVistoria(Long idVistoria) {
        VistoriaViaturaEntity vistoriaViaturaEntity = entityExists(idVistoria);
        vistoriaViaturaEntity.setStatus(VistoriaViaturaStatusEnum.valueOfEnum(vistoriaViaturaEntity.getTipoVistoria().getStatusPosterior()));

        ViaturaEntity viaturaEntity = viaturaRepository.findById(vistoriaViaturaEntity.getViatura().getId()).orElseThrow(() -> new ViaturaException("Viatura não encontrada"));
        viaturaEntity.setStatus(vistoriaViaturaEntity.getStatus().getDescricao().toUpperCase());
        viaturaRepository.save(viaturaEntity);

        VistoriaViaturaEntity vistoriaViatura = vistoriaRepository.save(vistoriaViaturaEntity);

         return ResponseEntity.ok(vistoriaViatura);
    }


    @Override
    public Page<VistoriaViaturaEntity> buscar(FiltroVistoria filtro, Pageable pageable) {
        return vistoriaRepository.findAllByFiltro(filtro, pageable);
    }

    @Override
    public ResponseEntity<VistoriaViaturaEntity> vistoriaByViatura(Long viaturaId) {
        var viatura = viaturaRepository.findById(viaturaId).orElseThrow();
        return ResponseEntity.ok(vistoriaRepository.findByViatura(viatura).orElseThrow());
    }


    private VistoriaViaturaEntity entityExists(Long id) {
        Optional<VistoriaViaturaEntity> vistoriaViaturaEntity = vistoriaRepository.findById(id);
        return vistoriaViaturaEntity.orElseThrow(() -> new ResourceNotFoundException("Vistoria não encontrada"));
    }

    private VistoriaDTO convertStringVistoriaDTO(String vistoriaString) {
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.registerModule(new JavaTimeModule());
        objectMapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

        VistoriaDTO vistoriaDTO = null;
        try {
            vistoriaDTO = objectMapper.readValue(vistoriaString, VistoriaDTO.class);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }

        return vistoriaDTO;
    }

    @Override
    public ResponseEntity<ChecklistVistoriaEntity> makeChecklistByTipoVistoria(Long id) {
        ChecklistVistoriaEntity checklistVistoria = new ChecklistVistoriaEntity();

        Optional<TipoVistoriaEntity> tipoVistoriaEntity = tipoVistoriaRepository.findById(id);
        TipoVistoriaEntity tipoVistoria = tipoVistoriaEntity.orElseThrow(() -> new ResourceNotFoundException("Tipo Vistoria não encontrado"));

        List<ItensVistoriaEntity> itensVistoriaEntityList = itensVistoriaRepository.findAllByCodTipo(tipoVistoria);

        List<ChecklistItemVistoriaEntity> checklistItemVistoriaList = new ArrayList<>();

        for (ItensVistoriaEntity itensVistoriaEntity : itensVistoriaEntityList) {
            Optional<ItemVistoriaEntity> itemVistoriaEntity = itemVistoriaRepository.findById(itensVistoriaEntity.getCodItem().getId());
            ItemVistoriaEntity itemVistoria = itemVistoriaEntity.orElseThrow(() -> new ResourceNotFoundException("Item Vistoria não encontrado"));

            checklistVistoria.setItemVistoria(itemVistoria);

            List<SubitensVistoriaEntity> subitensVistoriaList = subitensVistoriaRepository.findAllByCodItem(itemVistoria);

            for (SubitensVistoriaEntity subitensVistoriaEntity : subitensVistoriaList) {
                ChecklistItemVistoriaEntity checklistItemVistoria = new ChecklistItemVistoriaEntity();
                Optional<SubitemVistoriaEntity> subitemVistoriaEntity = subitemVistoriaRepository.findById(subitensVistoriaEntity.getCodSubitem().getId());
                SubitemVistoriaEntity subitemVistoria = subitemVistoriaEntity.orElseThrow(() -> new ResourceNotFoundException("Subitem Vistoria não encontrado"));

                checklistItemVistoria.setSubitemVistoria(subitemVistoria);
                checklistItemVistoria.setChecklistVistoria(checklistVistoria);

                List<DefeitosVistoriaEntity> defeitosVistoriaList = defeitosVistoriaRepository.findAllByCodSubitem(subitemVistoria);
                List<ChecklistVistoriaSubItemEntity> checklistVistoriaSubItemEntities = new ArrayList<>();

                for (DefeitosVistoriaEntity defeitosVistoriaEntity : defeitosVistoriaList) {
                    ChecklistVistoriaSubItemEntity checklistVistoriaSubItemEntity = new ChecklistVistoriaSubItemEntity();
                    Optional<TipoDefeitoVistoriaEntity> tipoDefeitoVistoriaEntity = tipoDefeitoVistoriaRepository.findById(defeitosVistoriaEntity.getCodTipoDefeito().getId());
                    TipoDefeitoVistoriaEntity tipoDefeitoVistoria = tipoDefeitoVistoriaEntity.orElseThrow(() -> new ResourceNotFoundException("Tipo Defeito Vistoria não encontrado"));

                    checklistVistoriaSubItemEntity.setTipoDefeitoVistoria(tipoDefeitoVistoria);
                    checklistVistoriaSubItemEntity.setChecklistItemVistoria(checklistItemVistoria);
                    checklistVistoriaSubItemEntities.add(checklistVistoriaSubItemEntity);
                }

                checklistItemVistoria.setChecklistVistoriaSubItem(checklistVistoriaSubItemEntities);
                checklistItemVistoriaList.add(checklistItemVistoria);
            }
        }

        checklistVistoria.setChecklistItens(checklistItemVistoriaList);

        return ResponseEntity.ok(checklistVistoria);
    }

    @Override
    public ResponseEntity<VistoriaViaturaEntity> iniciarVistoria(Long idViatura, Long idTipoVistoria) {
        VistoriaViaturaEntity vistoriaViatura = new VistoriaViaturaEntity();
        var viatura = viaturaRepository.findById(idViatura).orElseThrow(() -> new ViaturaException("Viatura não encontrada"));
        viatura.setStatus("EM VISTORIA");
        ViaturaEntity save = viaturaRepository.save(viatura);

        ChecklistVistoriaEntity checklistVistoriaEntity = this.checklistVistoria(idTipoVistoria);
        vistoriaViatura.setViatura(save);
        vistoriaViatura.setCheckLists(List.of(checklistVistoriaEntity));
        return ResponseEntity.ok(vistoriaViatura);
    }

    private ChecklistVistoriaEntity checklistVistoria(Long id) {
        ChecklistVistoriaEntity checklistVistoria = new ChecklistVistoriaEntity();

        Optional<TipoVistoriaEntity> tipoVistoriaEntity = tipoVistoriaRepository.findById(id);
        TipoVistoriaEntity tipoVistoria = tipoVistoriaEntity.orElseThrow(() -> new ResourceNotFoundException("Tipo Vistoria não encontrado"));

        List<ItensVistoriaEntity> itensVistoriaEntityList = itensVistoriaRepository.findAllByCodTipo(tipoVistoria);

        List<ChecklistItemVistoriaEntity> checklistItemVistoriaList = new ArrayList<>();

        for (ItensVistoriaEntity itensVistoriaEntity : itensVistoriaEntityList) {
            Optional<ItemVistoriaEntity> itemVistoriaEntity = itemVistoriaRepository.findById(itensVistoriaEntity.getCodItem().getId());
            ItemVistoriaEntity itemVistoria = itemVistoriaEntity.orElseThrow(() -> new ResourceNotFoundException("Item Vistoria não encontrado"));

            checklistVistoria.setItemVistoria(itemVistoria);

            List<SubitensVistoriaEntity> subitensVistoriaList = subitensVistoriaRepository.findAllByCodItem(itemVistoria);

            for (SubitensVistoriaEntity subitensVistoriaEntity : subitensVistoriaList) {
                ChecklistItemVistoriaEntity checklistItemVistoria = new ChecklistItemVistoriaEntity();
                Optional<SubitemVistoriaEntity> subitemVistoriaEntity = subitemVistoriaRepository.findById(subitensVistoriaEntity.getCodSubitem().getId());
                SubitemVistoriaEntity subitemVistoria = subitemVistoriaEntity.orElseThrow(() -> new ResourceNotFoundException("Subitem Vistoria não encontrado"));

                checklistItemVistoria.setSubitemVistoria(subitemVistoria);
                checklistItemVistoria.setChecklistVistoria(checklistVistoria);

                List<DefeitosVistoriaEntity> defeitosVistoriaList = defeitosVistoriaRepository.findAllByCodSubitem(subitemVistoria);
                List<ChecklistVistoriaSubItemEntity> checklistVistoriaSubItemEntities = new ArrayList<>();

                for (DefeitosVistoriaEntity defeitosVistoriaEntity : defeitosVistoriaList) {
                    ChecklistVistoriaSubItemEntity checklistVistoriaSubItemEntity = new ChecklistVistoriaSubItemEntity();
                    Optional<TipoDefeitoVistoriaEntity> tipoDefeitoVistoriaEntity = tipoDefeitoVistoriaRepository.findById(defeitosVistoriaEntity.getCodTipoDefeito().getId());
                    TipoDefeitoVistoriaEntity tipoDefeitoVistoria = tipoDefeitoVistoriaEntity.orElseThrow(() -> new ResourceNotFoundException("Tipo Defeito Vistoria não encontrado"));

                    checklistVistoriaSubItemEntity.setTipoDefeitoVistoria(tipoDefeitoVistoria);
                    checklistVistoriaSubItemEntity.setChecklistItemVistoria(checklistItemVistoria);
                    checklistVistoriaSubItemEntities.add(checklistVistoriaSubItemEntity);
                }

                checklistItemVistoria.setChecklistVistoriaSubItem(checklistVistoriaSubItemEntities);
                checklistItemVistoriaList.add(checklistItemVistoria);
            }
        }

        checklistVistoria.setChecklistItens(checklistItemVistoriaList);
        return checklistVistoria;
    }


}
