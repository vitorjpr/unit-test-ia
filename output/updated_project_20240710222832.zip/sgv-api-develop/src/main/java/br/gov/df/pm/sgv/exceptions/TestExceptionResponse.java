```java
package br.gov.df.pm.sgv.exceptions;

import org.junit.Test;
import static org.junit.Assert.*;
import java.util.Date;

public class ExceptionResponseTest {

    @Test
    public void testGetTimestamp() {
        Date timestamp = new Date();
        ExceptionResponse exceptionResponse = new ExceptionResponse(timestamp, "Test Message", "Test Details");
        assertEquals(timestamp, exceptionResponse.getTimestamp());
    }

    @Test
    public void testGetMessage() {
        String message = "Test Message";
        ExceptionResponse exceptionResponse = new ExceptionResponse(new Date(), message, "Test Details");
        assertEquals(message, exceptionResponse.getMessage());
    }

    @Test
    public void testGetDetails() {
        String details = "Test Details";
        ExceptionResponse exceptionResponse = new ExceptionResponse(new Date(), "Test Message", details);
        assertEquals(details, exceptionResponse.getDetails());
    }

    @Test
    public void testConstructor() {
        Date timestamp = new Date();
        String message = "Test Message";
        String details = "Test Details";
        ExceptionResponse exceptionResponse = new ExceptionResponse(timestamp, message, details);
        assertEquals(timestamp, exceptionResponse.getTimestamp());
        assertEquals(message, exceptionResponse.getMessage());
        assertEquals(details, exceptionResponse.getDetails());
    }
}
``` 

Esses são testes unitários simples para a classe `ExceptionResponse`. Eles cobrem os métodos `getTimestamp()`, `getMessage()`, `getDetails()` e o construtor da classe. Certifique-se de ter o JUnit no seu classpath para executar esses testes.