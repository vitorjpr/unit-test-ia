```java
package br.gov.df.pm.sgv.service.sgpol.implementacao;

import br.gov.df.pm.sgv.domain.sgpol.Perfil;
import br.gov.df.pm.sgv.domain.sgpol.Policial;
import br.gov.df.pm.sgv.domain.sgpol.Recurso;
import br.gov.df.pm.sgv.domain.sgpol.UnidadePolicialMilitar;
import br.gov.df.pm.sgv.dto.root.PerfilDTO;
import br.gov.df.pm.sgv.dto.root.RecursoDTO;
import br.gov.df.pm.sgv.repository.sgpol.PerfilRepository;
import br.gov.df.pm.sgv.repository.sgpol.PolicialRepository;
import br.gov.df.pm.sgv.repository.sgpol.RecursoRepository;
import br.gov.df.pm.sgv.repository.sgpol.UnidadePolicialMilitarRepository;
import br.gov.df.pm.sgv.service.sgpol.PolicialService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

class PolicialServiceImplTest {

    @Mock
    private PolicialRepository policialRepository;

    @Mock
    private RecursoRepository recursoRepository;

    @Mock
    private PerfilRepository perfilRepository;

    @Mock
    private UnidadePolicialMilitarRepository unidadePoliciaMilitarRepository;

    @InjectMocks
    private PolicialServiceImpl policialService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetPerfilDtoPolicialAutenticado() {
        // Mock data
        String matricula = "123456";
        List<Perfil> perfis = new ArrayList<>();
        perfis.add(new Perfil("Perfil1"));

        when(perfilRepository.findPerfilPessoaByMatricula(matricula)).thenReturn(perfis);

        // Test method
        List<PerfilDTO> result = policialService.getPerfilDtoPolicialAutenticado(matricula);

        // Verify
        assertEquals(1, result.size());
        assertEquals("Perfil1", result.get(0).getNome());
    }

    @Test
    void testFindPolicialById() {
        // Mock data
        Policial policial = new Policial();

        when(policialRepository.findById(1)).thenReturn(java.util.Optional.of(policial));

        // Test method
        Policial result = policialService.findPolicialById(1);

        // Verify
        assertEquals(policial, result);
    }

    @Test
    void testFindPolicialByPessoaMatricula() {
        // Mock data
        String matricula = "123456";
        Policial policial = new Policial();

        when(policialRepository.findByMatricula(matricula)).thenReturn(policial);

        // Test method
        Policial result = policialService.findPolicialByPessoaMatricula(matricula);

        // Verify
        assertEquals(policial, result);
    }

    @Test
    void testGetRecursoDtoPolicialAutenticado() {
        // Mock data
        String matricula = "123456";
        List<Recurso> recursos = new ArrayList<>();
        recursos.add(new Recurso("Recurso1"));

        when(recursoRepository.findRecursoPessoaByMatricula(matricula)).thenReturn(recursos);

        // Test method
        List<RecursoDTO> result = policialService.getRecursoDtoPolicialAutenticado(matricula);

        // Verify
        assertEquals(1, result.size());
        assertEquals("Recurso1", result.get(0).getNome());
    }

    @Test
    void testGetUnidadePolicialAutenticado() {
        // Mock data
        String matricula = "123456";
        UnidadePolicialMilitar unidadePolicialMilitar = new UnidadePolicialMilitar();

        when(unidadePoliciaMilitarRepository.findUnidadeByPolicial(matricula)).thenReturn(unidadePolicialMilitar);

        // Test method
        UnidadePolicialMilitar result = policialService.getUnidadePolicialAutenticado(matricula);

        // Verify
        assertEquals(unidadePolicialMilitar, result);
    }

    @Test
    void testFindById() {
        // Mock data
        Policial policial = new Policial();

        when(policialRepository.findById(1)).thenReturn(java.util.Optional.of(policial));

        // Test method
        ResponseEntity<Policial> result = policialService.findById(1);

        // Verify
        assertEquals(policial, result.getBody());
    }
}
```

Este é um exemplo de testes unitários para a classe `PolicialServiceImpl`. Certifique-se de adicionar as dependências do Mockito e JUnit em seu projeto para executar ess