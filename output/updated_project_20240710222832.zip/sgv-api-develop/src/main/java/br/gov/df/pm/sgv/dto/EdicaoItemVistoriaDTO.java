package br.gov.df.pm.sgv.dto;

import br.gov.df.pm.sgv.domain.SubitemVistoriaEntity;
import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class EdicaoItemVistoriaDTO {
    private String nome;
    private String descricao;
    private List<SubitemVistoriaEntity> subitens;
}
