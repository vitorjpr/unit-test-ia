Here are unit tests for the provided Java code:

```java
package br.gov.df.pm.sgv.service;

import br.gov.df.pm.sgv.domain.DiferencaOdometroEntity;
import br.gov.df.pm.sgv.domain.TipoVistoriaEntity;
import br.gov.df.pm.sgv.dto.DiferencaOdometroDTO;
import br.gov.df.pm.sgv.dto.DiferencaDTO;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class DiferencaOdometroServiceTest {

    @InjectMocks
    private DiferencaOdometroService service;

    @Test
    public void testBuscarId() {
        ResponseEntity<DiferencaOdometroDTO> response = service.buscarId(1L);
        assertNotNull(response);
        // Add more assertions based on expected behavior
    }

    @Test
    public void testBuscar() {
        Pageable pageable = mock(Pageable.class);
        Page<DiferencaOdometroEntity> page = service.buscar("filter", pageable);
        assertNotNull(page);
        // Add more assertions based on expected behavior
    }

    @Test
    public void testSalvar() {
        DiferencaOdometroDTO dto = new DiferencaOdometroDTO();
        ResponseEntity<DiferencaOdometroDTO> response = service.salvar(dto);
        assertNotNull(response);
        // Add more assertions based on expected behavior
    }

    @Test
    public void testEditar() {
        ResponseEntity<?> response = service.editar(1L, new DiferencaOdometroDTO());
        assertNotNull(response);
        // Add more assertions based on expected behavior
    }

    @Test
    public void testExcluir() {
        ResponseEntity<?> response = service.excluir(1L);
        assertNotNull(response);
        // Add more assertions based on expected behavior
    }

    @Test
    public void testDesativar() {
        ResponseEntity<?> response = service.desativar(1L);
        assertNotNull(response);
        // Add more assertions based on expected behavior
    }

    @Test
    public void testAtivar() {
        ResponseEntity<?> response = service.ativar(1L);
        assertNotNull(response);
        // Add more assertions based on expected behavior
    }

    @Test
    public void testFindAllTipoVistoria() {
        List<TipoVistoriaEntity> tipoVistorias = service.findAllTipoVistoria();
        assertNotNull(tipoVistorias);
        // Add more assertions based on expected behavior
    }

    @Test
    public void testBuscarDiferenca() {
        DiferencaDTO diferencaDTO = new DiferencaDTO();
        DiferencaOdometroDTO response = service.buscarDiferenca(diferencaDTO);
        assertNotNull(response);
        // Add more assertions based on expected behavior
    }
}
```

These unit tests cover each method in the `DiferencaOdometroService` interface with basic assertions for response validation. Feel free to add more specific assertions based on the expected behavior of each method.