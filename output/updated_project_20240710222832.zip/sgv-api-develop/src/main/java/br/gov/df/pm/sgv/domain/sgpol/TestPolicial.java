Here are some unit tests for the provided Java code:

```java
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PolicialTest {

    @Test
    public void testNomeGuerraNotBlank() {
        Policial policial = new Policial();
        policial.setNomeGuerra("");
        assertThrows(javax.validation.ConstraintViolationException.class, () -> {
            ValidatorUtil.validate(policial);
        });
    }

    @Test
    public void testMatriculaSize() {
        Policial policial = new Policial();
        policial.setMatricula("123456");
        assertThrows(javax.validation.ConstraintViolationException.class, () -> {
            ValidatorUtil.validate(policial);
        });
    }

    @Test
    public void testIdentificacaoUnicaSize() {
        Policial policial = new Policial();
        policial.setIdentificacaoUnica("1234567890");
        assertThrows(javax.validation.ConstraintViolationException.class, () -> {
            ValidatorUtil.validate(policial);
        });
    }

    @Test
    public void testAssistenciaMedicaNotNull() {
        Policial policial = new Policial();
        policial.setAssistenciaMedica(null);
        assertThrows(javax.validation.ConstraintViolationException.class, () -> {
            ValidatorUtil.validate(policial);
        });
    }

    @Test
    public void testDataPrevisaoFimAssistenciaMedicaNotNull() {
        Policial policial = new Policial();
        policial.setDataPrevisaoFimAssistenciaMedica(null);
        assertThrows(javax.validation.ConstraintViolationException.class, () -> {
            ValidatorUtil.validate(policial);
        });
    }

    @Test
    public void testDataSuspensaoAssistenciaMedicaNotNull() {
        Policial policial = new Policial();
        policial.setDataSuspensaoAssistenciaMedica(null);
        assertThrows(javax.validation.ConstraintViolationException.class, () -> {
            ValidatorUtil.validate(policial);
        });
    }

    // Add more test cases as needed

}
```

In the provided unit tests, we are testing some constraints such as `@NotBlank`, `@Size`, and `@NotNull`. Make sure to include the necessary imports and adjust the test cases according to your specific requirements.