Here are the unit tests for the provided Java code:

```java
package br.gov.df.pm.sgv.repository;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import br.gov.df.pm.sgv.domain.VistoriaArquivo;
import br.gov.df.pm.sgv.domain.VistoriaViaturaEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.ArrayList;
import java.util.List;

@ExtendWith(MockitoExtension.class)
public class VistoriaArquivoRepositoryTest {

    @Mock
    private VistoriaArquivoRepository vistoriaArquivoRepository;

    @Test
    public void testFindByVistoriaViatura() {
        VistoriaViaturaEntity vistoriaViatura = new VistoriaViaturaEntity();
        List<VistoriaArquivo> expectedList = new ArrayList<>();
        VistoriaArquivo vistoriaArquivo1 = new VistoriaArquivo();
        VistoriaArquivo vistoriaArquivo2 = new VistoriaArquivo();
        expectedList.add(vistoriaArquivo1);
        expectedList.add(vistoriaArquivo2);

        when(vistoriaArquivoRepository.findByVistoriaViatura(vistoriaViatura)).thenReturn(expectedList);

        List<VistoriaArquivo> actualList = vistoriaArquivoRepository.findByVistoriaViatura(vistoriaViatura);

        assertEquals(expectedList.size(), actualList.size());
        assertEquals(expectedList.get(0), actualList.get(0));
        assertEquals(expectedList.get(1), actualList.get(1));
    }
}
```

These unit tests cover the `findByVistoriaViatura` method of the `VistoriaArquivoRepository` interface. The tests use Mockito to mock the repository and verify that the method returns the expected list of `VistoriaArquivo` objects based on the provided `VistoriaViaturaEntity`.

Make sure to include the necessary dependencies for Mockito and JUnit in your project to run these tests successfully.