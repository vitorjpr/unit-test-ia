package br.gov.df.pm.sgv.mapper;

import br.gov.df.pm.sgv.dto.TipoVistoriaDTO;
import br.gov.df.pm.sgv.domain.TipoVistoriaEntity;

public class TipoVistoriaMapper {
    public TipoVistoriaEntity convertEntity(TipoVistoriaDTO itemVistoriaDTO) {
        return TipoVistoriaEntity.builder()
                .nome(itemVistoriaDTO.getNome())
                .descricao(itemVistoriaDTO.getDescricao())
                .dataInclusao(itemVistoriaDTO.getDataInclusao())
                .statusAnterior(itemVistoriaDTO.getStatusAnterior())
                .statusPosterior(itemVistoriaDTO.getStatusPosterior())
                .ativo(itemVistoriaDTO.getAtivo())
                .build();
    }

    public TipoVistoriaDTO convertDTO(TipoVistoriaEntity tipoVistoriaEntity) {
        return TipoVistoriaDTO.builder()
                .nome(tipoVistoriaEntity.getNome())
                .descricao(tipoVistoriaEntity.getDescricao())
                .dataInclusao(tipoVistoriaEntity.getDataInclusao())
                .id(tipoVistoriaEntity.getId())
                .statusAnterior(tipoVistoriaEntity.getStatusAnterior())
                .statusPosterior(tipoVistoriaEntity.getStatusPosterior())
                .ativo(tipoVistoriaEntity.getAtivo())
                .build();
    }
}
