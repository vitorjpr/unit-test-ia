package br.gov.df.pm.sgv.service.impl;

import br.gov.df.pm.sgv.service.StorageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.util.DefaultUriBuilderFactory;

import java.util.UUID;

@Service
public class StorageServiceImpl implements StorageService {

    @Autowired
    private RestTemplate restTemplate;

    @Value("${api.storage}")
    private String apiStorage;

    @Value("${storage.bucket}")
    private String bucket;



    public void removerImagem(UUID idImagem) throws RestClientException {
        var uriBuilder = new DefaultUriBuilderFactory(apiStorage).builder();
        var request = RequestEntity
                .delete(uriBuilder.path("/{bucket}/{id}").build(bucket, idImagem))
                .accept(MediaType.APPLICATION_JSON)
//                .header("Authorization", token)
                .build();
        restTemplate.exchange(request, Resource.class);
    }

    //    @GetMapping("/{idTalonario}/{numeroAutoInfracao}/imagem")
    public ResponseEntity<Resource> baixarImagemAI(UUID id) {
//        var autoInfracao = autoInfracaoService.findById(idTalonario, numeroAutoInfracao);
//        if (autoInfracao.isPresent() && autoInfracao.get().getCodigoImagem() != null) {
        var uriBuilder = new DefaultUriBuilderFactory(apiStorage).builder();
        var request = RequestEntity
                .get(uriBuilder.path("/{bucket}/{id}").build(bucket,id))
                .accept(MediaType.APPLICATION_JSON)
//                .header("Authorization", token)
                .build();
        ResponseEntity<Resource> exchange = restTemplate.exchange(request, Resource.class);
        return exchange;
//        }
//        return ResponseEntity.notFound().build();
    }

    public ResponseEntity<UUID> salvarImagem(MultipartFile arquivoImagem) {
        try {
            var headers = new HttpHeaders();
            headers.setContentType(MediaType.MULTIPART_FORM_DATA);
//            headers.set("Authorization", token);
            var body = new LinkedMultiValueMap<>();
            body.add("arquivo", arquivoImagem.getResource());
            var requestEntity = new HttpEntity<>(body, headers);
            var response = restTemplate.postForEntity(apiStorage + "/" + bucket, requestEntity, UUID.class);
            return response;
        } catch (RestClientException e) {
            // log
            throw e;
        }
    }
}
