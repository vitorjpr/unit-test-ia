Sure! Here are the unit tests for the provided Java code:

```java
package br.gov.df.pm.sgv.exceptions;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

public class SubItemVistoriaExceptionTest {

    @Test
    public void testConstructorWithoutMessage() {
        SubItemVistoriaException exception = new SubItemVistoriaException();
        assertNull(exception.getMessage());
        assertNull(exception.getCause());
    }

    @Test
    public void testConstructorWithMessage() {
        String message = "Test message";
        SubItemVistoriaException exception = new SubItemVistoriaException(message);
        assertEquals(message, exception.getMessage());
        assertNull(exception.getCause());
    }

    @Test
    public void testConstructorWithMessageAndCause() {
        String message = "Test message";
        Throwable cause = new RuntimeException("Test cause");
        SubItemVistoriaException exception = new SubItemVistoriaException(message, cause);
        assertEquals(message, exception.getMessage());
        assertEquals(cause, exception.getCause());
    }
}
```

These unit tests cover the three constructors of the `SubItemVistoriaException` class, ensuring that they correctly set the message and cause when provided.