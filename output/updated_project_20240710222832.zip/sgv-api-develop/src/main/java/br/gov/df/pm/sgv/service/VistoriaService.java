package br.gov.df.pm.sgv.service;

import br.gov.df.pm.sgv.domain.ChecklistVistoriaEntity;
import br.gov.df.pm.sgv.domain.VistoriaViaturaEntity;
import br.gov.df.pm.sgv.dto.FiltroVistoria;
import br.gov.df.pm.sgv.dto.VistoriaDTO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

public interface VistoriaService {

    Page<VistoriaViaturaEntity> buscar(FiltroVistoria filtro, Pageable pageable);

    ResponseEntity<VistoriaViaturaEntity> vistoriaByViatura(Long viaturaId);

    ResponseEntity<VistoriaViaturaEntity> salvar(String vistoria, List<MultipartFile> arquivos);

    ResponseEntity<VistoriaViaturaEntity> findVistoriaById(Long id);

    VistoriaViaturaEntity findById(Long id);

    ResponseEntity<VistoriaViaturaEntity> editVistoriaById(String vistoria, List<MultipartFile> arquivos);

    ResponseEntity<VistoriaViaturaEntity> finalizarVistoria(Long idVistoria);

    ResponseEntity<ChecklistVistoriaEntity> makeChecklistByTipoVistoria(Long id);

    ResponseEntity<VistoriaViaturaEntity> iniciarVistoria(Long idViatura, Long idTipoVistoria);
}
