Here are unit tests for the provided `ChecklistVistoriaSubItemEntity` class:

```java
package br.gov.df.pm.sgv.domain;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

public class ChecklistVistoriaSubItemEntityTest {

    private ChecklistVistoriaSubItemEntity checklistVistoriaSubItem;

    @BeforeEach
    public void setUp() {
        checklistVistoriaSubItem = new ChecklistVistoriaSubItemEntity();
    }

    @Test
    public void testIdGetterAndSetter() {
        Long id = 1L;
        checklistVistoriaSubItem.setId(id);
        assertEquals(id, checklistVistoriaSubItem.getId());
    }

    @Test
    public void testSelecionadoGetterAndSetter() {
        Boolean selecionado = true;
        checklistVistoriaSubItem.setSelecionado(selecionado);
        assertEquals(selecionado, checklistVistoriaSubItem.getSelecionado());
    }

    @Test
    public void testDataCriacaoGetterAndSetter() {
        Date dataCriacao = new Date();
        checklistVistoriaSubItem.setDataCriacao(dataCriacao);
        assertEquals(dataCriacao, checklistVistoriaSubItem.getDataCriacao());
    }

    @Test
    public void testChecklistItemVistoriaGetterAndSetter() {
        ChecklistItemVistoriaEntity checklistItemVistoria = new ChecklistItemVistoriaEntity();
        checklistVistoriaSubItem.setChecklistItemVistoria(checklistItemVistoria);
        assertEquals(checklistItemVistoria, checklistVistoriaSubItem.getChecklistItemVistoria());
    }

    @Test
    public void testTipoDefeitoVistoriaGetterAndSetter() {
        TipoDefeitoVistoriaEntity tipoDefeitoVistoria = new TipoDefeitoVistoriaEntity();
        checklistVistoriaSubItem.setTipoDefeitoVistoria(tipoDefeitoVistoria);
        assertEquals(tipoDefeitoVistoria, checklistVistoriaSubItem.getTipoDefeitoVistoria());
    }
}
```

These tests cover the getter and setter methods for the fields in the `ChecklistVistoriaSubItemEntity` class. You can further expand the tests to include more scenarios like testing the `@Builder`, `@EqualsAndHashCode`, and other annotations if needed.