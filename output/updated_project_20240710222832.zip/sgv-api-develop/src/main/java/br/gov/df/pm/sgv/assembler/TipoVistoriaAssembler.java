package br.gov.df.pm.sgv.assembler;

import br.gov.df.pm.sgv.dto.TipoVistoriaDTO;
import br.gov.df.pm.sgv.domain.TipoVistoriaEntity;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.RepresentationModelAssembler;
import org.springframework.stereotype.Component;

@Component
public class TipoVistoriaAssembler implements RepresentationModelAssembler<TipoVistoriaEntity, EntityModel<TipoVistoriaDTO>> {
    @Override
    public EntityModel<TipoVistoriaDTO> toModel(TipoVistoriaEntity entity) {
        return EntityModel.of(TipoVistoriaDTO.builder()
                .id(entity.getId())
                .nome(entity.getNome())
                .descricao(entity.getDescricao())
                .statusAnterior(entity.getStatusAnterior())
                .statusPosterior(entity.getStatusPosterior())
                .dataInclusao(entity.getDataInclusao())
                .ativo(entity.getAtivo())
                .build());
    }
}
