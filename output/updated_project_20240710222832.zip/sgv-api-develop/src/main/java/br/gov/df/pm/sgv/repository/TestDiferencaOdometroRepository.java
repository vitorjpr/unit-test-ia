Here are the unit tests for the provided Java code:

```java
package br.gov.df.pm.sgv.repository;

import br.gov.df.pm.sgv.domain.DiferencaOdometroEntity;
import br.gov.df.pm.sgv.domain.TipoVistoriaEntity;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@DataJpaTest
public class DiferencaOdometroRepositoryTest {

    @Autowired
    private DiferencaOdometroRepository repository;

    @Autowired
    private TestEntityManager entityManager;

    @Test
    public void testFindByReferenciaInicialAndReferenciaFinal() {
        // Given
        TipoVistoriaEntity referenciaInicial = new TipoVistoriaEntity();
        TipoVistoriaEntity referenciaFinal = new TipoVistoriaEntity();
        DiferencaOdometroEntity diferencaOdometro = new DiferencaOdometroEntity();
        diferencaOdometro.setReferenciaInicial(referenciaInicial);
        diferencaOdometro.setReferenciaFinal(referenciaFinal);
        entityManager.persist(diferencaOdometro);
        entityManager.flush();

        // When
        Optional<DiferencaOdometroEntity> result = repository.findByReferenciaInicialAndReferenciaFinal(referenciaInicial, referenciaFinal);

        // Then
        assertTrue(result.isPresent());
        assertEquals(diferencaOdometro, result.get());
    }

    @Test
    public void testFindAllByReferenciaInicial() {
        // Given
        TipoVistoriaEntity referenciaInicial = new TipoVistoriaEntity();
        DiferencaOdometroEntity diferencaOdometro1 = new DiferencaOdometroEntity();
        DiferencaOdometroEntity diferencaOdometro2 = new DiferencaOdometroEntity();
        diferencaOdometro1.setReferenciaInicial(referenciaInicial);
        diferencaOdometro2.setReferenciaInicial(referenciaInicial);
        entityManager.persist(diferencaOdometro1);
        entityManager.persist(diferencaOdometro2);
        entityManager.flush();

        // When
        List<DiferencaOdometroEntity> result = repository.findAllByReferenciaInicial(referenciaInicial);

        // Then
        assertEquals(2, result.size());
        assertTrue(result.contains(diferencaOdometro1));
        assertTrue(result.contains(diferencaOdometro2));
    }
}
```

These unit tests cover the `findByReferenciaInicialAndReferenciaFinal` and `findAllByReferenciaInicial` methods of the `DiferencaOdometroRepository`. The tests use Mockito for mocking dependencies and the TestEntityManager for managing test data in an in-memory database.