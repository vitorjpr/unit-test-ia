Aqui estão os testes unitários para a classe `MessageAuthKeycloak`:

```java
package br.gov.df.pm.sgv.feign.dto;

import org.junit.Test;
import static org.junit.Assert.*;

public class MessageAuthKeycloakTest {

    @Test
    public void testGetSetAccessToken() {
        MessageAuthKeycloak message = new MessageAuthKeycloak();
        message.setAccess_token("testToken");
        assertEquals("testToken", message.getAccess_token());
    }

    @Test
    public void testGetSetRefreshExpiresIn() {
        MessageAuthKeycloak message = new MessageAuthKeycloak();
        message.setRefresh_expires_in(100L);
        assertEquals(100L, message.getRefresh_expires_in().longValue());
    }

    @Test
    public void testGetSetRefreshToken() {
        MessageAuthKeycloak message = new MessageAuthKeycloak();
        message.setRefresh_token("testRefreshToken");
        assertEquals("testRefreshToken", message.getRefresh_token());
    }

    @Test
    public void testGetSetTokenType() {
        MessageAuthKeycloak message = new MessageAuthKeycloak();
        message.setToken_type("testTokenType");
        assertEquals("testTokenType", message.getToken_type());
    }
}
```

Esses testes garantem que os métodos `get` e `set` para cada campo da classe `MessageAuthKeycloak` estão funcionando corretamente. Certifique-se de adicionar o framework de testes JUnit ao seu projeto para executar esses testes.