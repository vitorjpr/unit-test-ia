```java
package br.gov.df.pm.sgv.assembler.app;

import br.gov.df.pm.sgv.domain.ViaturaEntity;
import br.gov.df.pm.sgv.dto.ViaturaDTO;
import br.gov.df.pm.sgv.service.ViaturaService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.hateoas.EntityModel;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

class ViaturaAssemblerTest {

    @Mock
    private ViaturaService viaturaService;

    private ViaturaAssembler viaturaAssembler;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
        viaturaAssembler = new ViaturaAssembler();
        viaturaAssembler.viaturaService = viaturaService;
    }

    @Test
    void testToModel() {
        ViaturaEntity viaturaEntity = new ViaturaEntity();
        viaturaEntity.setId(1L);
        viaturaEntity.setNrSei("12345");
        viaturaEntity.setPlaca("ABC1234");
        viaturaEntity.setAtivo(true);
        viaturaEntity.setDataAtualizacao(LocalDate.now());
        viaturaEntity.setRenavam("67890");
        viaturaEntity.setDataInclusao(LocalDate.now());
        viaturaEntity.setPrefixo("PRE");
        viaturaEntity.setTombamento("T123");

        when(viaturaService.getUltimoOdometroByViatura(1L)).thenReturn(10000);
        when(viaturaService.getVistoriaViaturaByViatura(1L)).thenReturn("OK");

        EntityModel<ViaturaDTO> result = viaturaAssembler.toModel(viaturaEntity);

        assertEquals(1L, result.getContent().getId());
        assertEquals("12345", result.getContent().getNrSei());
        assertEquals("ABC1234", result.getContent().getPlaca());
        assertEquals(true, result.getContent().isAtivo());
        assertEquals(LocalDate.now().atStartOfDay(), result.getContent().getDataAtualizacao());
        assertEquals("67890", result.getContent().getRenavam());
        assertEquals(LocalDate.now().atStartOfDay(), result.getContent().getDataInclusao());
        assertEquals("PRE", result.getContent().getPrefixo());
        assertEquals(10000, result.getContent().getUltimoOdometro());
        assertEquals("T123", result.getContent().getTombamento());
        assertEquals("OK", result.getContent().getVistoriaViatura());
    }
}
```

Neste teste unitário, foi utilizado o framework Mockito para simular o comportamento do `ViaturaService`, permitindo definir os valores de retorno esperados para os métodos `getUltimoOdometroByViatura` e `getVistoriaViaturaByViatura`. Em seguida, o método `toModel` da classe `ViaturaAssembler` é testado para garantir que a conversão de uma `ViaturaEntity` para um `EntityModel<ViaturaDTO>` está sendo feita corretamente, verificando se os valores dos atributos são esperados no objeto resultante.