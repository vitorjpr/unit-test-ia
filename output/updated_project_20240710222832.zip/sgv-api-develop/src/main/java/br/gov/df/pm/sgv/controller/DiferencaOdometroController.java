package br.gov.df.pm.sgv.controller;

import br.gov.df.pm.sgv.assembler.DiferencaOdometroAssembler;
import br.gov.df.pm.sgv.domain.DiferencaOdometroEntity;
import br.gov.df.pm.sgv.dto.DiferencaOdometroDTO;
import br.gov.df.pm.sgv.dto.DiferencaDTO;
import br.gov.df.pm.sgv.service.DiferencaOdometroService;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.PagedModel;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Objects;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/diferenca-odometro")
public class DiferencaOdometroController {

    private DiferencaOdometroService service;

    private final DiferencaOdometroAssembler diferencaOdometroAssembler;

    private final PagedResourcesAssembler<DiferencaOdometroEntity> pagedResourcesAssembler;

    public DiferencaOdometroController(DiferencaOdometroService service,
                                       PagedResourcesAssembler<DiferencaOdometroEntity> pagedResourcesAssembler,
                                       DiferencaOdometroAssembler diferencaOdometroAssembler) {
        this.service = service;
        this.pagedResourcesAssembler = pagedResourcesAssembler;
        this.diferencaOdometroAssembler = diferencaOdometroAssembler;
    }

    @GetMapping("/buscar/{id}")
    public ResponseEntity<DiferencaOdometroDTO> buscarId(@PathVariable("id") Long id) {
        return service.buscarId(id);
    }

    @GetMapping("/buscar")
    public PagedModel<EntityModel<DiferencaOdometroEntity>> buscar(String filter, Pageable pageable) {
        var result = pagedResourcesAssembler.toModel(service.buscar(filter, pageable));
        return PagedModel.of(result.getContent().stream().map(e ->
                diferencaOdometroAssembler.toModel(Objects.requireNonNull(e.getContent()))).collect(Collectors.toList()), result.getMetadata());
    }

    @PostMapping("/salvar")
    public ResponseEntity<DiferencaOdometroDTO> salvar(@RequestBody DiferencaOdometroDTO diferencaOdometroDTO) {
        return service.salvar(diferencaOdometroDTO);
    }

    @PutMapping("/editar/{id}")
    public ResponseEntity<?> editar(@PathVariable("id") Long id, @RequestBody DiferencaOdometroDTO edicao) {
        return service.editar(id, edicao);
    }

    @DeleteMapping("/excluir/{id}")
    public ResponseEntity<?> excluir(@PathVariable("id") Long id) {
        return service.excluir(id);
    }

    @DeleteMapping("/desativar/{id}")
    public ResponseEntity<?> desativar(@PathVariable("id") Long id) {
        return service.desativar(id);
    }

    @PostMapping("/ativar/{id}")
    public ResponseEntity<?> ativar(@PathVariable("id") Long id) {
        return service.ativar(id);
    }

    @GetMapping("/findAllTipoVistoria")
    public ResponseEntity<?> findAllTipoVistoria() {return service.findAllTipoVistoria();}

    @GetMapping("/diferenca")
    public DiferencaOdometroDTO findDiferenca(@RequestBody DiferencaDTO dto) {
        return service.buscarDiferenca(dto);
    }

}
