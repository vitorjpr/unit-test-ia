package br.gov.df.pm.sgv.service.sgpol.implementacao;

import br.gov.df.pm.sgv.domain.sgpol.Perfil;
import br.gov.df.pm.sgv.domain.sgpol.Policial;
import br.gov.df.pm.sgv.domain.sgpol.Recurso;
import br.gov.df.pm.sgv.domain.sgpol.UnidadePolicialMilitar;
import br.gov.df.pm.sgv.dto.root.PerfilDTO;
import br.gov.df.pm.sgv.dto.root.RecursoDTO;
import br.gov.df.pm.sgv.repository.sgpol.PerfilRepository;
import br.gov.df.pm.sgv.repository.sgpol.PolicialRepository;
import br.gov.df.pm.sgv.repository.sgpol.RecursoRepository;
import br.gov.df.pm.sgv.repository.sgpol.UnidadePolicialMilitarRepository;
import br.gov.df.pm.sgv.service.sgpol.PolicialService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class PolicialServiceImpl implements PolicialService {

   @Autowired
   private PolicialRepository policialRepository;

   @Autowired
   private RecursoRepository recursoRepository;

    @Autowired
    private PerfilRepository perfilRepository;

   @Autowired
   private UnidadePolicialMilitarRepository unidadePoliciaMilitarRepository;

	public PolicialServiceImpl(PolicialRepository policialRepository, RecursoRepository recursoRepository, UnidadePolicialMilitarRepository unidadePoliciaMilitarRepository) {
       this.policialRepository = policialRepository;
       this.recursoRepository = recursoRepository;
       this.unidadePoliciaMilitarRepository = unidadePoliciaMilitarRepository;
   }

    public List<PerfilDTO> getPerfilDtoPolicialAutenticado(String matricula) {
        List<Perfil> perfis = new ArrayList<>(perfilRepository.findPerfilPessoaByMatricula(matricula));
        return perfis.stream().map(p -> PerfilDTO.builder().nome(p.getNome()).build()).collect(Collectors.toList());
    }

    @Override
    public Policial findPolicialById(Integer id) {
        return policialRepository.findById(id).orElseThrow();
    }
    @Override
    public ResponseEntity<Policial> findById(Integer id) {
        return ResponseEntity.ok(policialRepository.findById(id).orElseThrow());
    }

    @Override
   public Policial findPolicialByPessoaMatricula(String matricula) {
       return policialRepository.findByMatricula(matricula);
   }

   @Override
   public List<RecursoDTO> getRecursoDtoPolicialAutenticado(String matricula) {
       List<Recurso> recursos = new ArrayList<>();

       recursos.addAll(recursoRepository.findRecursoPessoaByMatricula(matricula));
    //    recursos.addAll(recursoRepository.findRecursoPessoaPerfilByMatricula(matricula));
       if (recursos != null && !recursos.isEmpty() ) {
           return (List<RecursoDTO>) recursos.stream().map(r -> new RecursoDTO(r.getNome())).collect(Collectors.toList());
       }

       return new ArrayList<>();
   }

   @Override
   public UnidadePolicialMilitar getUnidadePolicialAutenticado(String matricula) {
       return unidadePoliciaMilitarRepository.findUnidadeByPolicial(matricula);
   }


   /*public List<RecursoDTO> MockRecurso(){
       List<RecursoDTO> recursoDTOS = new ArrayList<>();

       recursoDTOS.add(new RecursoDTO("ALTERAR_ESCALA_GESTOR_GERAL"));
       recursoDTOS.add(new RecursoDTO("ALTERAR_ESCALA_GESTOR_SETORIAL"));
       recursoDTOS.add(new RecursoDTO("ALTERAR_ESCALA_GESTOR_LOCAL"));
       recursoDTOS.add(new RecursoDTO("VISUALIZAR_ESCALA__GESTOR_GERAL"));
       recursoDTOS.add(new RecursoDTO("VISUALIZAR_ESCALA__GESTOR_SETORIAL"));
       recursoDTOS.add(new RecursoDTO("ENCERRAR_SERVICO"));
       return recursoDTOS;
   }*/
}