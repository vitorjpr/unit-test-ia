package br.gov.df.pm.sgv.domain.enums;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
@JsonFormat(shape = JsonFormat.Shape.OBJECT)
public enum VistoriaViaturaStatusEnum {
    DISPONIVEL("D", "Disponivel"),
    EM_VISTORIA("V", "Em Vistoria"),
    EM_USO("U", "Em Uso"),
    INDISPONIVEL("I", "Indisponivel");

    private final String id;
    private final String descricao;

    public static VistoriaViaturaStatusEnum valueOfEnum(String descricao) {
        for (VistoriaViaturaStatusEnum item : VistoriaViaturaStatusEnum.values()) {
            if (descricao.equals(item.descricao.toUpperCase())) {
                return item;
            }
        }
        return null;
    }


}
