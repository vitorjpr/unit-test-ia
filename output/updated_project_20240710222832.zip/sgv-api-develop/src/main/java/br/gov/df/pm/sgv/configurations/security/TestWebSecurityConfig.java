```java
package br.gov.df.pm.sgv.configurations.security;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.core.authority.mapping.SimpleAuthorityMapper;
import org.springframework.security.web.authentication.session.RegisterSessionAuthenticationStrategy;
import org.springframework.security.web.authentication.session.SessionAuthenticationStrategy;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class WebSecurityConfigTest {

    @Mock
    private AuthenticationManagerBuilder auth;

    @Test
    public void testConfigureGlobal() throws Exception {
        // Given
        WebSecurityConfig webSecurityConfig = new WebSecurityConfig();
        webSecurityConfig.configureGlobal(auth);

        // When
        when(auth.authenticationProvider(webSecurityConfig.keycloakAuthenticationProvider())).thenReturn(auth);

        // Then
        verify(auth).authenticationProvider(webSecurityConfig.keycloakAuthenticationProvider());
    }

    @Test
    public void testSessionAuthenticationStrategy() {
        // Given
        WebSecurityConfig webSecurityConfig = new WebSecurityConfig();

        // When
        SessionAuthenticationStrategy strategy = webSecurityConfig.sessionAuthenticationStrategy();

        // Then
        assert strategy instanceof RegisterSessionAuthenticationStrategy;
    }

    @Test
    public void testConfigureHttpSecurity() throws Exception {
        // Given
        WebSecurityConfig webSecurityConfig = new WebSecurityConfig();
        HttpSecurity http = new HttpSecurity(webSecurityConfig.authenticationBuilder);

        // When
        webSecurityConfig.configure(http);

        // Then
        // Add assertions here based on your specific requirements
    }
}
```

Neste exemplo de testes unitários, foram criados testes para os métodos `configureGlobal`, `sessionAuthenticationStrategy` e `configureHttpSecurity` da classe `WebSecurityConfig`. Esses testes utilizam o framework Mockito para simular o comportamento dos objetos e verificar se os métodos estão sendo executados corretamente. Lembre-se de adicionar as dependências necessárias para o uso do Mockito em seu projeto.