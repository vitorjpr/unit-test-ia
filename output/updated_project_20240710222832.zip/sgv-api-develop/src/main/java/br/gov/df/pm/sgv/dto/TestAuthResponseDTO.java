Sure! Here are some unit tests for the AuthResponseDTO class:

```java
package br.gov.df.pm.sgv.dto;

import org.junit.Test;
import static org.junit.Assert.*;

public class AuthResponseDTOTest {

    @Test
    public void testGetToken() {
        AuthResponseDTO authResponseDTO = new AuthResponseDTO();
        String token = "testToken";
        authResponseDTO.setToken(token);
        assertEquals(token, authResponseDTO.getToken());
    }

    @Test
    public void testSetToken() {
        AuthResponseDTO authResponseDTO = new AuthResponseDTO();
        String token = "testToken";
        authResponseDTO.setToken(token);
        assertEquals(token, authResponseDTO.getToken());
    }

    @Test
    public void testEquals() {
        AuthResponseDTO authResponseDTO1 = new AuthResponseDTO();
        authResponseDTO1.setToken("token1");

        AuthResponseDTO authResponseDTO2 = new AuthResponseDTO();
        authResponseDTO2.setToken("token1");

        assertEquals(authResponseDTO1, authResponseDTO2);
    }

    @Test
    public void testNotEquals() {
        AuthResponseDTO authResponseDTO1 = new AuthResponseDTO();
        authResponseDTO1.setToken("token1");

        AuthResponseDTO authResponseDTO2 = new AuthResponseDTO();
        authResponseDTO2.setToken("token2");

        assertNotEquals(authResponseDTO1, authResponseDTO2);
    }
}
```

Make sure to have the Lombok library in your project dependencies to use the `@Data` annotation. These tests cover the getter, setter, equals, and not equals methods for the AuthResponseDTO class.