package br.gov.df.pm.sgv.service.sgpol.implementacao;

import br.gov.df.pm.sgv.domain.sgpol.UnidadePolicialMilitar;
import br.gov.df.pm.sgv.exceptions.ResourceNotFoundException;
import br.gov.df.pm.sgv.repository.sgpol.UnidadePolicialMilitarRepository;
import br.gov.df.pm.sgv.service.sgpol.UnidadePolicialMilitarService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UnidadePolicialMilitarServiceImpl implements UnidadePolicialMilitarService {

    private static final String ERROUPMNAOENCONTRADA = "A UPM informada não foi encontrada.";
    @Autowired
    UnidadePolicialMilitarRepository unidadePolicialMilitarRepository;

    @Override
    public UnidadePolicialMilitar findUPMById(Integer id) {
        return unidadePolicialMilitarRepository.findById(id).orElseThrow();
    }

    @Override
    public List<UnidadePolicialMilitar> listar() {
        return unidadePolicialMilitarRepository.findAllByAtivoOrderBySigla(1);
    }

    public UnidadePolicialMilitar entityExists(int id) {
        Optional<UnidadePolicialMilitar> upm = unidadePolicialMilitarRepository.findById(id);
        return upm.orElseThrow(() -> new ResourceNotFoundException(ERROUPMNAOENCONTRADA));
    }
}
