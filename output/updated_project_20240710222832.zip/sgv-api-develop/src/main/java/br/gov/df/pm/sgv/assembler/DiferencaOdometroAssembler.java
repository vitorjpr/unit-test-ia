package br.gov.df.pm.sgv.assembler;

import br.gov.df.pm.sgv.domain.DiferencaOdometroEntity;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.RepresentationModelAssembler;
import org.springframework.stereotype.Component;

@Component
public class DiferencaOdometroAssembler implements RepresentationModelAssembler<DiferencaOdometroEntity, EntityModel<DiferencaOdometroEntity>> {
    @Override
    public EntityModel<DiferencaOdometroEntity> toModel(DiferencaOdometroEntity entity) {
        return EntityModel.of(entity);
    }
}
