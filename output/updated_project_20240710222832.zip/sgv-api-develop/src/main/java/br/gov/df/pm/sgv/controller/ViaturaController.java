package br.gov.df.pm.sgv.controller;

import br.gov.df.pm.sgv.assembler.app.ViaturaAssembler;
import br.gov.df.pm.sgv.domain.ViaturaEntity;
import br.gov.df.pm.sgv.domain.sgpol.UnidadePolicialMilitar;
import br.gov.df.pm.sgv.dto.TipoEmpregoViaturaDto;
import br.gov.df.pm.sgv.dto.ViaturaDTO;
import br.gov.df.pm.sgv.service.ViaturaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.PagedModel;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/viatura")
public class ViaturaController {

    @Autowired
    private final ViaturaService viaturaService;
    @Autowired
    private final ViaturaAssembler viaturaAssembler;
    @Autowired
    private final PagedResourcesAssembler<ViaturaEntity> pagedResourcesAssembler;

    public ViaturaController(ViaturaService viaturaService,
                             ViaturaAssembler viaturaAssembler,
                             PagedResourcesAssembler<ViaturaEntity> pagedResourcesAssembler) {
        this.viaturaService = viaturaService;
        this.viaturaAssembler = viaturaAssembler;
        this.pagedResourcesAssembler = pagedResourcesAssembler;
    }

    @GetMapping("/buscar")
    public PagedModel<EntityModel<ViaturaDTO>> buscar(@RequestParam(value = "upmCodigo", required = false) Integer upmCodigo,
                                                      @RequestParam(value = "prefixo", required = false) String prefixo,
                                                      @RequestParam(value = "placa", required = false) String placa,
                                                      Pageable pageable) {
        var result = pagedResourcesAssembler.toModel(viaturaService.buscar(upmCodigo, prefixo, placa, pageable));
        return PagedModel.of(result.getContent().stream().map(e ->
                viaturaAssembler.toModel(Objects.requireNonNull(e.getContent()))).collect(Collectors.toList()), result.getMetadata());
    }

    @GetMapping("/paginado")
    public Page<ViaturaEntity> findPaginado(Pageable pageable) {
        return viaturaService.findPaginado(pageable);
    }

    @GetMapping("/listarUpm")
    private ResponseEntity<List<UnidadePolicialMilitar>> listarUpm() {
       return viaturaService.listarUpm();
    }

    @GetMapping("/listarTipoEmprego")
    public ResponseEntity<List<TipoEmpregoViaturaDto>> listAll(){
        return this.viaturaService.listar();
    }
}
