Here are some unit tests for the `DiferencaOdometroEntity` class:

```java
package br.gov.df.pm.sgv.domain;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class DiferencaOdometroEntityTest {

    @Test
    public void testGetterAndSetter() {
        DiferencaOdometroEntity entity = new DiferencaOdometroEntity();

        entity.setId(1L);
        assertEquals(1L, entity.getId());

        TipoVistoriaEntity referenciaInicial = new TipoVistoriaEntity();
        entity.setReferenciaInicial(referenciaInicial);
        assertEquals(referenciaInicial, entity.getReferenciaInicial());

        TipoVistoriaEntity referenciaFinal = new TipoVistoriaEntity();
        entity.setReferenciaFinal(referenciaFinal);
        assertEquals(referenciaFinal, entity.getReferenciaFinal());

        entity.setDiferencaOdometro(100.0);
        assertEquals(100.0, entity.getDiferencaOdometro());

        entity.setDataInclusao(LocalDate.now());
        assertEquals(LocalDate.now(), entity.getDataInclusao());

        entity.setDataModificacao(LocalDate.now());
        assertEquals(LocalDate.now(), entity.getDataModificacao());
    }

    @Test
    public void testEqualsAndHashCode() {
        DiferencaOdometroEntity entity1 = DiferencaOdometroEntity.builder().id(1L).build();
        DiferencaOdometroEntity entity2 = DiferencaOdometroEntity.builder().id(1L).build();
        DiferencaOdometroEntity entity3 = DiferencaOdometroEntity.builder().id(2L).build();

        assertEquals(entity1, entity2);
        assertNotEquals(entity1, entity3);

        assertEquals(entity1.hashCode(), entity2.hashCode());
        assertNotEquals(entity1.hashCode(), entity3.hashCode());
    }
}
```

These tests cover the getter and setter methods of the `DiferencaOdometroEntity` class, as well as the `equals` and `hashCode` methods based on the `id` field.