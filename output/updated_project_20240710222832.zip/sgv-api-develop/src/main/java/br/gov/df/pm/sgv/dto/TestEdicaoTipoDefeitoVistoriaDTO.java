Sure! Here are the unit tests for the provided Java code:

```java
package br.gov.df.pm.sgv.dto;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class EdicaoTipoDefeitoVistoriaDTOTest {

    @Test
    public void testGetNome() {
        EdicaoTipoDefeitoVistoriaDTO dto = EdicaoTipoDefeitoVistoriaDTO.builder().nome("Teste").build();
        assertEquals("Teste", dto.getNome());
    }

    @Test
    public void testGetDescricao() {
        EdicaoTipoDefeitoVistoriaDTO dto = EdicaoTipoDefeitoVistoriaDTO.builder().descricao("Descrição de teste").build();
        assertEquals("Descrição de teste", dto.getDescricao());
    }

    @Test
    public void testSetNome() {
        EdicaoTipoDefeitoVistoriaDTO dto = new EdicaoTipoDefeitoVistoriaDTO();
        dto.setNome("Novo nome");
        assertEquals("Novo nome", dto.getNome());
    }

    @Test
    public void testSetDescricao() {
        EdicaoTipoDefeitoVistoriaDTO dto = new EdicaoTipoDefeitoVistoriaDTO();
        dto.setDescricao("Nova descrição");
        assertEquals("Nova descrição", dto.getDescricao());
    }
}
```

Make sure to add the necessary imports for `@Test` and `Assertions` from JUnit. These tests cover the getter and setter methods for the `nome` and `descricao` fields of the `EdicaoTipoDefeitoVistoriaDTO` class.