Sure! Here are some unit tests for the provided Java code:

```java
package br.gov.df.pm.sgv.service;

import br.gov.df.pm.sgv.dto.EdicaoTipoDefeitoVistoriaDTO;
import br.gov.df.pm.sgv.dto.TipoDefeitoVistoriaDTO;
import br.gov.df.pm.sgv.domain.TipoDefeitoVistoriaEntity;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;

public class TipoDefeitoVistoriaServiceTest {

    @Mock
    private TipoDefeitoVistoriaService tipoDefeitoVistoriaService;

    @Test
    public void testBuscarId() {
        ResponseEntity<TipoDefeitoVistoriaDTO> response = tipoDefeitoVistoriaService.buscarId(1L);
        assertNotNull(response);
    }

    @Test
    public void testBuscar() {
        Page<TipoDefeitoVistoriaEntity> page = tipoDefeitoVistoriaService.buscar("filter", Pageable.unpaged());
        assertNotNull(page);
    }

    @Test
    public void testSalvar() {
        TipoDefeitoVistoriaDTO tipoDefeito = mock(TipoDefeitoVistoriaDTO.class);
        ResponseEntity<?> response = tipoDefeitoVistoriaService.salvar(tipoDefeito);
        assertNotNull(response);
    }

    @Test
    public void testEditar() {
        EdicaoTipoDefeitoVistoriaDTO edicao = mock(EdicaoTipoDefeitoVistoriaDTO.class);
        ResponseEntity<?> response = tipoDefeitoVistoriaService.editar(1L, edicao);
        assertNotNull(response);
    }

    @Test
    public void testDesativar() {
        ResponseEntity<?> response = tipoDefeitoVistoriaService.desativar(1L);
        assertNotNull(response);
    }

    @Test
    public void testExcluir() {
        ResponseEntity<?> response = tipoDefeitoVistoriaService.excluir(1L);
        assertNotNull(response);
    }

    @Test
    public void testAtivar() {
        ResponseEntity<?> response = tipoDefeitoVistoriaService.ativar(1L);
        assertNotNull(response);
    }

    @Test
    public void testListAllAtivos() {
        List<TipoDefeitoVistoriaDTO> list = tipoDefeitoVistoriaService.listAllAtivos();
        assertNotNull(list);
        assertTrue(list.isEmpty());
    }
}
```

These unit tests cover each method of the `TipoDefeitoVistoriaService` interface. Make sure to add appropriate dependencies like JUnit and Mockito to your project to run these tests successfully.