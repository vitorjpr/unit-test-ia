Claro! Abaixo estão os testes unitários para a classe `AuthDTO`:

```java
package br.gov.df.pm.sgv.dto;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class AuthDTOTest {

    @Test
    public void testGetUsername() {
        AuthDTO authDTO = new AuthDTO();
        authDTO.setUsername("john.doe");
        assertEquals("john.doe", authDTO.getUsername());
    }

    @Test
    public void testGetPassword() {
        AuthDTO authDTO = new AuthDTO();
        authDTO.setPassword("pass123");
        assertEquals("pass123", authDTO.getPassword());
    }

    @Test
    public void testSetUsername() {
        AuthDTO authDTO = new AuthDTO();
        authDTO.setUsername("jane.smith");
        assertEquals("jane.smith", authDTO.getUsername());
    }

    @Test
    public void testSetPassword() {
        AuthDTO authDTO = new AuthDTO();
        authDTO.setPassword("securePwd");
        assertEquals("securePwd", authDTO.getPassword());
    }

    @Test
    public void testEquals() {
        AuthDTO authDTO1 = new AuthDTO();
        authDTO1.setUsername("user1");
        authDTO1.setPassword("pass1");

        AuthDTO authDTO2 = new AuthDTO();
        authDTO2.setUsername("user1");
        authDTO2.setPassword("pass1");

        assertEquals(authDTO1, authDTO2);
    }

    @Test
    public void testNotEquals() {
        AuthDTO authDTO1 = new AuthDTO();
        authDTO1.setUsername("user1");
        authDTO1.setPassword("pass1");

        AuthDTO authDTO2 = new AuthDTO();
        authDTO2.setUsername("user2");
        authDTO2.setPassword("pass2");

        assertNotEquals(authDTO1, authDTO2);
    }
}
```

Certifique-se de adicionar a dependência do JUnit no seu projeto para executar os testes com sucesso. Esses testes cobrem os métodos `getUsername`, `getPassword`, `setUsername`, `setPassword`, `equals` e `notEquals` da classe `AuthDTO`.