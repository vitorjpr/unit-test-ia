package br.gov.df.pm.sgv.controller;

import br.gov.df.pm.sgv.domain.VistoriaArquivo;
import br.gov.df.pm.sgv.service.VistoriaArquivoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/vistoria-arquivo")
public class VistoriaArquivoController {

    @Autowired
    private VistoriaArquivoService vistoriaArquivoService;

    @DeleteMapping("/deleteImage/{id}")
    public ResponseEntity<VistoriaArquivo> deleteImageByid(@PathVariable Long id){
       return vistoriaArquivoService.deletarPorId(id);
    }


    @DeleteMapping("/deleteListImage")
    public  ResponseEntity<List<VistoriaArquivo>> deleteImageBylist(@RequestBody List<Long> ids){
        return  vistoriaArquivoService.deletarPorLista(ids);
    }

}
