package br.gov.df.pm.sgv.service.sgpol;

import br.gov.df.pm.sgv.domain.sgpol.UnidadePolicialMilitar;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface UnidadePolicialMilitarService {

    UnidadePolicialMilitar findUPMById(Integer id);
    public List<UnidadePolicialMilitar> listar();
    public UnidadePolicialMilitar entityExists(int id);

}



//
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Optional;
//import java.util.Set;
//import java.util.stream.Collectors;
//
//import br.gov.df.pm.sgf.dto.sgpol.AfastamentoDTO;
//import br.gov.df.pm.sgf.entity.sgpol.*;
//import br.gov.df.pm.sgf.exception.NomeLocalAgregacaoJaCadastradoException;
//import br.gov.df.pm.sgf.repository.sgpol.*;
//import br.gov.df.pm.sgf.repository.sgpol.filter.AfastamentoFilter;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//import org.springframework.transaction.annotation.Transactional;
//
//
//@Service
//public class UnidadePolicialMilitarService {
//
//	@Autowired
//	private UnidadePolicialMilitarRepository unidadePolicialMilitarRepository;
//
//
//	@Autowired
//	private LotacaoRepository lotacaoRepository;
//
//	@Autowired
//	private UpmLotacaoRepository upmLotacaoRepository;
//
//	@Autowired
//	private FuncaoRepository funcaoRepository;
//
//	@Autowired
//	private FuncaoUpmLotacaoRepository funcaoUpmLotacaoRepository;
//
//	@Autowired
//	TipoAfastamentoRepository tipoAfastamentoRepository;
//
//	@Autowired
//	AfastamentoRepository afastamentoRepository;
//
//
//
//
//	@Transactional
//	public void salvar(UnidadePolicialMilitar unidade){
//		Optional<UnidadePolicialMilitar> opmOptional = unidadePolicialMilitarRepository.findByNomeIgnoreCase(unidade.getNome());
//		if(opmOptional.isPresent()) {
//			if(opmOptional.get().getAtivo() == 0 ) {
//				throw new NomeLocalAgregacaoJaCadastradoException("Este local de agregação já existe e está desativado!<a href=\"/localagregacao/ativar/"+opmOptional.get().getId()+"\">Deseja Ativá-lo ?</a>");
//			} else {
//				throw new NomeLocalAgregacaoJaCadastradoException("Unidade já existe!");
//			}
//
//		}
//		unidadePolicialMilitarRepository.save(unidade);
//	}
//
//
//	public List<Policial> listarPoliciais(Integer unidade){
//		List<Policial> policiais  = unidadePolicialMilitarRepository.buscarPoliciaisPorUnidade(unidade);
//
//		return policiais;
//	}
//
//
//
//	public void excluir (Integer codigo){
//		unidadePolicialMilitarRepository.deleteById(codigo);
//	}
//
//	public UnidadePolicialMilitar desativar(int id){
//
//
//		UnidadePolicialMilitar upm = unidadePolicialMilitarRepository.getOne(id);
//
//		upm.setAtivo(0);
//
//		unidadePolicialMilitarRepository.save(upm);
//
//		return upm;
//	}
//
//
//	public void atualizarUpmLotacao(String[] nomes, Integer id) {
//
//		UnidadePolicialMilitar unidadePolicialMilitar = unidadePolicialMilitarRepository.buscarComLotacoes(id);
//
//		Set<UpmLotacao> listUpmLotacaoAntes = unidadePolicialMilitar.getListidUpmLotacao();
//
//		List<Lotacao> listLotacaoDepois = lotacaoRepository.findByNomeIn(nomes);
//
//		List<UpmLotacao> listUpmLotacaoDepois = new ArrayList<>();
//
//		for (Lotacao lotacao : listLotacaoDepois) {
//			UpmLotacao upmLotacao = new UpmLotacao();
//			upmLotacao.setIdUpm(unidadePolicialMilitar);
//			upmLotacao.setIdLotacao(lotacao);
//			listUpmLotacaoDepois.add(upmLotacao);
//		}
//
//		if(listUpmLotacaoAntes.size() > listLotacaoDepois.size()){
//
//			List<UpmLotacao> listaRemover = new ArrayList<UpmLotacao>();
//			for (UpmLotacao upmlotacaoantes :listUpmLotacaoAntes) {
//
//				boolean isexiste = false;
//
//				for (Lotacao upmlotacaodepois : listLotacaoDepois) {
//					if(upmlotacaoantes.getIdLotacao().getId() == upmlotacaodepois.getId()){
//						isexiste = true;
//						break;
//					}
//				}
//
//				if(!isexiste){
//					listaRemover.add(upmlotacaoantes);
//				}
//			}
//
//			for (UpmLotacao upmLotacao : listaRemover) {
//				unidadePolicialMilitar.getListidUpmLotacao().remove(upmLotacao);
//				upmLotacaoRepository.delete(upmLotacao);
//
//			}
//
//			unidadePolicialMilitarRepository.save(unidadePolicialMilitar);
//
//		}else{
//			for (UpmLotacao upmlotacaodepois : listUpmLotacaoDepois) {
//
//				boolean isexiste = false;
//
//				for (UpmLotacao upmlotacaoantes : listUpmLotacaoAntes) {
//					if(upmlotacaodepois.getIdLotacao().getId() == upmlotacaoantes.getIdLotacao().getId()){
//						isexiste = true;
//						break;
//					}
//				}
//
//				if(!isexiste){
//					upmLotacaoRepository.save(upmlotacaodepois);
//				}
//			}
//		}
//	}
//
//	public void atualizarFuncaoUpmLotacao(String[] nomes, Integer id) {
//
//		//funcoes selecionadas pelo usuario
//		List<Funcao> listFuncaoDepois = funcaoRepository.findByNomeIn(nomes);
//		//funções que ja existem no banco
//		List<FuncaoUpmLotacao> listFuncaoUpmLotacaoAntes = funcaoUpmLotacaoRepository.porIdUpmLotacaoConsulta(id);
//		//inserir o objeto funcaoUpmLotacao para manipulação
//		List<FuncaoUpmLotacao> listFuncaoUpmLotacaoDepois = new ArrayList<>();
//
//		for (Funcao funcao : listFuncaoDepois) {
//
//			FuncaoUpmLotacao funcaoUpmLotacao = new FuncaoUpmLotacao();
//
//			funcaoUpmLotacao.setIdUpmLotacao(upmLotacaoRepository.getOne(id));
//			funcaoUpmLotacao.setIdFuncao(funcao);
//
//			listFuncaoUpmLotacaoDepois.add(funcaoUpmLotacao);
//		}
//
//		if(listFuncaoUpmLotacaoAntes.size() > listFuncaoDepois.size()){
//
//			List<FuncaoUpmLotacao> listaRemover = new ArrayList<FuncaoUpmLotacao>();
//			for (FuncaoUpmLotacao funcaoUpmlotacaoantes :listFuncaoUpmLotacaoAntes) {
//
//				boolean isexiste = false;
//
//				for (Funcao funcaoUpmlotacaodepois : listFuncaoDepois) {
//					if(funcaoUpmlotacaoantes.getIdFuncao().getId() == funcaoUpmlotacaodepois.getId()){
//						isexiste = true;
//						break;
//					}
//				}
//
//				if(!isexiste){
//					listaRemover.add(funcaoUpmlotacaoantes);
//				}
//			}
//
//			for (FuncaoUpmLotacao funcaoUpmLotacao : listaRemover) {
//				listFuncaoUpmLotacaoAntes.remove(funcaoUpmLotacao);
//				funcaoUpmLotacaoRepository.delete(funcaoUpmLotacao);
//
//			}
//
//			funcaoUpmLotacaoRepository.saveAll(listFuncaoUpmLotacaoAntes);
//
//		}else{
//			for (FuncaoUpmLotacao funcaoUpmlotacaodepois : listFuncaoUpmLotacaoDepois) {
//
//				boolean isexiste = false;
//
//				for (FuncaoUpmLotacao funcaoUpmlotacaoantes : listFuncaoUpmLotacaoAntes) {
//					if(funcaoUpmlotacaodepois.getIdFuncao().getId() == funcaoUpmlotacaoantes.getIdFuncao().getId()){
//						isexiste = true;
//						break;
//					}
//				}
//
//				if(!isexiste){
//					funcaoUpmLotacaoRepository.save(funcaoUpmlotacaodepois);
//				}
//			}
//		}
//
//
//
//
//	}
//
//
//	/**
//	 * Essa busca retorna todas as unidades que estão abaixo do unidade que passar como parametro no caso de a unidade passada for o DOP viram todas as unidades da Policial miliat
//	 * @param unidadePolicialMilitar
//	 * @return
//	 */
//	public List<UnidadePolicialMilitar> getListaPorHierarquiaRecurssiva(UnidadePolicialMilitar unidadePolicialMilitar){
//		List<UnidadePolicialMilitar> listafilhos = unidadePolicialMilitarRepository.findByIdSubordinacaoIdAndAtivo((unidadePolicialMilitar.getId()==626?8:unidadePolicialMilitar.getId()),1);
//		List<UnidadePolicialMilitar> listaTodasUpms = unidadePolicialMilitarRepository.findAllComSubordinacao();
//		List<UnidadePolicialMilitar> listaRetorno = new ArrayList<UnidadePolicialMilitar>();
//		aplicarRecursividade(listafilhos,listaRetorno,0,listaTodasUpms);
//		return listaRetorno;
//	}
//
//
//	public List<UnidadePolicialMilitar> getListaPorHierarquiaRecurssivaGeral(UnidadePolicialMilitar unidadePolicialMilitar){
//		List<UnidadePolicialMilitar> listafilhos = unidadePolicialMilitarRepository.findByIdSubordinacaoIdAndAtivo(unidadePolicialMilitar.getId(),1);
//		List<UnidadePolicialMilitar> listaTodasUpms = unidadePolicialMilitarRepository.findAllComSubordinacao();
//		List<UnidadePolicialMilitar> listaRetorno = new ArrayList<UnidadePolicialMilitar>();
//		aplicarRecursividade(listafilhos,listaRetorno,0,listaTodasUpms);
//		return listaRetorno;
//	}
//
//
//
//	public UnidadePolicialMilitar buscarUpmGCG() {
//		UnidadePolicialMilitar upmGCG = unidadePolicialMilitarRepository.getOne(8);
//		return upmGCG;
//	}
//
//	public List<UnidadePolicialMilitar> buscarUnidadesSubordinadasUpmGCG() {
//		UnidadePolicialMilitar upmGCG = unidadePolicialMilitarRepository.getOne(8);
//		return getListaPorHierarquiaRecurssivaGeral(upmGCG);
//	}
//
//	public List<TipoAfastamento> listarAfastamento() {
//		List<TipoAfastamento> listarAfastamento = tipoAfastamentoRepository.findByOrderByNomeAsc();
//		return listarAfastamento;
//	}
//
//	public List<AfastamentoDTO> filtrarAfastamento(AfastamentoFilter afastamentoFilter, UnidadePolicialMilitar upm) {
//		List<AfastamentoDTO> paginaWrapper = afastamentoRepository.filtrarAfastamentoInicio(afastamentoFilter, upm);
//		return paginaWrapper;
//	}
//
//
//	/**
//	 * Essa busca retorna todas as unidades que estão abaixo do unidade que passar como parametro
//	 * @param unidadePolicialMilitar
//	 * @return
//	 */
//	public List<UnidadePolicialMilitar> getListaPorHierarquiaRecurssivaSemDop(UnidadePolicialMilitar unidadePolicialMilitar){
//		List<UnidadePolicialMilitar> listafilhos = unidadePolicialMilitarRepository.findByIdSubordinacaoIdAndAtivo(unidadePolicialMilitar.getId(),1);
//		List<UnidadePolicialMilitar> listaTodasUpms = unidadePolicialMilitarRepository.findAllComSubordinacao();
//		List<UnidadePolicialMilitar> listaRetorno = new ArrayList<UnidadePolicialMilitar>();
//		aplicarRecursividade(listafilhos,listaRetorno,0,listaTodasUpms);
//		return listaRetorno;
//	}
//
//
//
//	/**
//	 * Enquanto tiver filhos fica adcionando na lista de filhos até o próximo do mesmo nível
//	 * @param listaFilhos (LISTA DE FILHOS DA UNIDADE ATUALO)
//	 * @param listaRetorno (LISTA QUE VAI SER O RETORNO)
//	 * @param nivel (NIVEL QUE A UNIDADE DEVE SER ADCIONADA)
//	 * @param listaTodasUpms (TODAS AS UNIDADES COM A UNIDADE PAI)
//	 */
//	private void aplicarRecursividade(List<UnidadePolicialMilitar> listaFilhos,List<UnidadePolicialMilitar> listaRetorno,int nivel,List<UnidadePolicialMilitar> listaTodasUpms) {
//		if(!listaFilhos.isEmpty()) {
//			for (UnidadePolicialMilitar upm : listaFilhos) {
//				upm.setNivel(nivel);
//				listaRetorno.add(upm);
//				aplicarRecursividade(getFilhos(upm,listaTodasUpms),listaRetorno,nivel+1,listaTodasUpms);
//			}
//		}
//
//	}
//
//
//	private List<UnidadePolicialMilitar> getFilhos(UnidadePolicialMilitar upmPai,List<UnidadePolicialMilitar> listaTodasUpms){
//		List<UnidadePolicialMilitar> listUpmsFilhas = new ArrayList<UnidadePolicialMilitar>();
//		List<UnidadePolicialMilitar> listtemp = new ArrayList<UnidadePolicialMilitar>();
//
//		for (UnidadePolicialMilitar filho : listaTodasUpms) {
//			if(filho.getIdSubordinacao()!=null && filho.getIdSubordinacao().getId()==
//					upmPai.getId()) {
//				listUpmsFilhas.add(filho);
//			}
//			else {
//				listtemp.add(filho);
//			}
//
//		}
//		return listUpmsFilhas;
//
//	}
//
//
//	public void setComandante(UnidadePolicialMilitar unidade){
//
//		Policial cmt = null;
//
//
//		if(unidade!=null && unidade.getIdFuncaoComando()!=null){
//			cmt = unidadePolicialMilitarRepository.buscarComandanteUnidade(unidade.getIdFuncaoComando().getId(), unidade.getId());
//
//		}
//		unidade.setComandante(cmt);
//	}
//
//	public void setLotacoesComTelefone(UnidadePolicialMilitar unidadePolicialMilitarAtual) {
//
//		List<UpmLotacao> listsecao =  upmLotacaoRepository.porUpmId(unidadePolicialMilitarAtual.getId());
//
//
//		Set<UpmLotacao> setsecao = listsecao.stream().collect(Collectors.toSet());
//
//		unidadePolicialMilitarAtual.setListidUpmLotacao(setsecao);
//
//
//	}
//
//	public UnidadePolicialMilitar buscar(Integer id) {
//		return unidadePolicialMilitarRepository.getOne(id);
//	}
//
//	public List<UnidadePolicialMilitar> buscarAtivas() {
//		List<Integer> tipo = new ArrayList<Integer>();
//		tipo.add(1);
//		tipo.add(2);
//		return unidadePolicialMilitarRepository.findAllByAtivoAndTipoIdInOrderByNomeAsc(1,tipo);
//	}
//
//
//	public List<UnidadePolicialMilitar> buscaUnidadesPorRecurso(Integer id) {
//
//		List<UnidadePolicialMilitar> retorno = unidadePolicialMilitarRepository.findByUpmRecursosRecursoId(id);
//
//		return retorno;
//	}
//
//
//	public UnidadePolicialMilitar ativar(UnidadePolicialMilitar unidadePolicialMilitar) {
//		unidadePolicialMilitar.setAtivo(1);
//
//		unidadePolicialMilitarRepository.saveAndFlush(unidadePolicialMilitar);
//		return null;
//	}
//
//}
