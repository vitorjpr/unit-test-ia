package br.gov.df.pm.sgv.feign.dto;

import lombok.Data;

@Data
public class MessageAuthKeycloak {
    private String access_token;
    private Long refresh_expires_in;
    private String refresh_token;
    private String token_type;
}
