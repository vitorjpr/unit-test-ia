Sure! Here are some unit tests for the `TipoVistoriaEntity` class:

```java
package br.gov.df.pm.sgv.domain;

import org.junit.jupiter.api.Test;
import java.time.LocalDate;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class TipoVistoriaEntityTest {

    @Test
    public void testGettersAndSetters() {
        TipoVistoriaEntity tipoVistoria = new TipoVistoriaEntity();
        tipoVistoria.setId(1L);
        tipoVistoria.setNome("Teste");
        tipoVistoria.setDescricao("Descrição do teste");
        tipoVistoria.setStatusAnterior("Anterior");
        tipoVistoria.setStatusPosterior("Posterior");
        tipoVistoria.setAtivo(true);
        tipoVistoria.setDataInclusao(LocalDate.now());

        assertEquals(1L, tipoVistoria.getId());
        assertEquals("Teste", tipoVistoria.getNome());
        assertEquals("Descrição do teste", tipoVistoria.getDescricao());
        assertEquals("Anterior", tipoVistoria.getStatusAnterior());
        assertEquals("Posterior", tipoVistoria.getStatusPosterior());
        assertEquals(true, tipoVistoria.isAtivo());
        assertEquals(LocalDate.now(), tipoVistoria.getDataInclusao());
    }

    @Test
    public void testEqualsAndHashCode() {
        TipoVistoriaEntity tipoVistoria1 = new TipoVistoriaEntity();
        tipoVistoria1.setId(1L);

        TipoVistoriaEntity tipoVistoria2 = new TipoVistoriaEntity();
        tipoVistoria2.setId(1L);

        assertEquals(tipoVistoria1, tipoVistoria2);
        assertEquals(tipoVistoria1.hashCode(), tipoVistoria2.hashCode());
    }

    // Add more tests for other methods or edge cases if needed

}
```

Make sure to add the necessary imports for the test class. These tests cover the basic functionality of the `TipoVistoriaEntity` class, including getters and setters, equals and hashCode methods. You can add more tests to cover additional methods or edge cases as needed.