package br.gov.df.pm.sgv.dto;

import br.gov.df.pm.sgv.domain.TipoDefeitoVistoriaEntity;
import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class EdicaoSubitemVistoriaDTO {
    private String nome;
    private String descricao;
    private List<TipoDefeitoVistoriaEntity> defeitos;
}
