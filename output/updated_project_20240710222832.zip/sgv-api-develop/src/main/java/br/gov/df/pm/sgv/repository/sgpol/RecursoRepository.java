package br.gov.df.pm.sgv.repository.sgpol;

import br.gov.df.pm.sgv.domain.sgpol.Recurso;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface RecursoRepository extends JpaRepository<Recurso, Long>{

//    @Query("select Distinct recurso From Policial policial Inner join policial.idPessoa pessoa  Inner join pessoa.listPessoaRecurso recurso where policial.matricula = :matricula")
   @Query("select recurso From Policial policial Inner join policial.idPessoa pessoa  Inner join pessoa.listPessoaRecurso recurso where policial.matricula = :matricula")
   List<Recurso> findRecursoPessoaByMatricula(String matricula);

//    @Query("select Distinct recurso From Policial policial Inner join policial.idPessoa pessoa Inner join pessoa.pessoaPerfil perfil Inner join perfil.listPessoaRecurso recurso  where policial.matricula = :matricula")
//    List<Recurso> findRecursoPessoaPerfilByMatricula(String matricula);
}