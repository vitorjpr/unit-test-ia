```java
package br.gov.df.pm.sgv.domain.sgpol;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class RecursoTest {

    @Test
    public void testGetId() {
        Recurso recurso = new Recurso();
        recurso.setId(1);
        assertEquals(1, recurso.getId());
    }

    @Test
    public void testGetAtivo() {
        Recurso recurso = new Recurso();
        recurso.setAtivo(1);
        assertEquals(1, recurso.getAtivo());
    }

    @Test
    public void testGetDescricao() {
        Recurso recurso = new Recurso();
        recurso.setDescricao("Descrição do Recurso");
        assertEquals("Descrição do Recurso", recurso.getDescricao());
    }

    @Test
    public void testGetNome() {
        Recurso recurso = new Recurso();
        recurso.setNome("Nome do Recurso");
        assertEquals("Nome do Recurso", recurso.getNome());
    }

    @Test
    public void testGetTitulo() {
        Recurso recurso = new Recurso();
        recurso.setTitulo("Título do Recurso");
        assertEquals("Título do Recurso", recurso.getTitulo());
    }

    @Test
    public void testHashCode() {
        Recurso recurso1 = new Recurso();
        recurso1.setId(1);
        Recurso recurso2 = new Recurso();
        recurso2.setId(1);
        assertEquals(recurso1.hashCode(), recurso2.hashCode());
    }

    @Test
    public void testEquals() {
        Recurso recurso1 = new Recurso();
        recurso1.setId(1);
        Recurso recurso2 = new Recurso();
        recurso2.setId(1);
        assertTrue(recurso1.equals(recurso2));
    }

    @Test
    public void testToString() {
        Recurso recurso = new Recurso();
        recurso.setId(1);
        recurso.setAtivo(1);
        recurso.setDescricao("Descrição do Recurso");
        recurso.setNome("Nome do Recurso");
        assertEquals("Recurso [id=1, ativo=1, descricao=Descrição do Recurso, nome=Nome do Recurso]", recurso.toString());
    }

    @Test
    public void testNotBlankConstraints() {
        Recurso recurso = new Recurso();
        assertThrows(javax.validation.ConstraintViolationException.class, () -> {
            recurso.setDescricao("");
            recurso.setNome("");
            recurso.setTitulo("");
        });
    }
}
```

Neste exemplo, foram criados testes para os métodos `getId`, `getAtivo`, `getDescricao`, `getNome`, `getTitulo`, `hashCode`, `equals`, `toString` e para as restrições `@NotBlank` nos campos `descricao`, `nome` e `titulo`. Certifique-se de adicionar as dependências necessárias para o Lombok e o JUnit em seu projeto.