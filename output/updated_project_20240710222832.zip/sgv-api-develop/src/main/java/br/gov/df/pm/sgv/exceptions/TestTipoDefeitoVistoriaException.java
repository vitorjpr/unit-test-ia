Sure! Here are the unit tests for the provided Java code:

```java
package br.gov.df.pm.sgv.exceptions;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

public class TipoDefeitoVistoriaExceptionTest {

    @Test
    public void testConstructorWithoutArguments() {
        TipoDefeitoVistoriaException exception = new TipoDefeitoVistoriaException();
        assertNull(exception.getMessage());
        assertNull(exception.getCause());
    }

    @Test
    public void testConstructorWithMessage() {
        String message = "Test message";
        TipoDefeitoVistoriaException exception = new TipoDefeitoVistoriaException(message);
        assertEquals(message, exception.getMessage());
        assertNull(exception.getCause());
    }

    @Test
    public void testConstructorWithMessageAndCause() {
        String message = "Test message";
        Throwable cause = new RuntimeException("Test cause");
        TipoDefeitoVistoriaException exception = new TipoDefeitoVistoriaException(message, cause);
        assertEquals(message, exception.getMessage());
        assertEquals(cause, exception.getCause());
    }
}
```

These unit tests cover all three constructors of the `TipoDefeitoVistoriaException` class, ensuring that they behave as expected.