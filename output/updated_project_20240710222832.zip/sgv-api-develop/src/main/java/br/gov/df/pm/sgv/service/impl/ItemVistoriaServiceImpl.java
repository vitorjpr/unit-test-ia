package br.gov.df.pm.sgv.service.impl;

import br.gov.df.pm.sgv.dto.*;
import br.gov.df.pm.sgv.domain.*;
import br.gov.df.pm.sgv.exceptions.ItemVistoriaException;
import br.gov.df.pm.sgv.exceptions.VistoriaExceptions;
import br.gov.df.pm.sgv.mapper.ItemVistoriaMapper;
import br.gov.df.pm.sgv.repository.*;
import br.gov.df.pm.sgv.service.ItemVistoriaService;
import br.gov.df.pm.sgv.service.TipoVistoriaService;
import br.gov.df.pm.sgv.shared.utils.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.thymeleaf.util.ListUtils;

import javax.persistence.criteria.Predicate;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Service
public class ItemVistoriaServiceImpl implements ItemVistoriaService {

    @Autowired
    private ItemVistoriaRepository repository;
    @Autowired
    private ItensVistoriaRepository itensRepository;
    @Autowired
    private SubitemVistoriaRepository subitemRepository;
    @Autowired
    private SubitensVistoriaRepository subitensRepository;
    @Autowired
    private TipoVistoriaService tipoVistoriaService;
    @Autowired
    private DefeitosVistoriaRepository defeitosVistoriaRepository;

    public ItemVistoriaServiceImpl (ItemVistoriaRepository repository,
                                    SubitemVistoriaRepository subitemRepository,
                                    SubitensVistoriaRepository subitensRepository) {
        this.repository = repository;
        this.subitemRepository = subitemRepository;
        this.subitensRepository = subitensRepository;
    }

    @Override
    public ResponseEntity<ItemVistoriaDTO> buscarId(Long id) {
        return ResponseEntity.ok(new ItemVistoriaMapper().convertDTO(findById(id)));
    }

    @Override
    public Page<ItemVistoriaEntity> buscar(String filter, Pageable pageable) {
        List<SubitensVistoriaEntity> subitemList = new ArrayList<>();
        var subItem = subitemRepository.findByNome(filter);
        if(subItem.isPresent()) {
            subitemList = subitensRepository.findAllByCodSubitem(subItem.get());
        }
        return repository.findAll(filtroToSpecification(filter, subitemList), pageable);
    }

    private Specification<ItemVistoriaEntity> filtroToSpecification(String filtro, List<SubitensVistoriaEntity> subitensList) {
        return (root, query, builder) -> {
            if (!StringUtils.isEmptyOrNull(filtro)) {
                var predications = new ArrayList<Predicate>();
                if(!ListUtils.isEmpty(subitensList)) {
                    for(SubitensVistoriaEntity subitens: subitensList) {
                        predications.add(builder.equal(root.get("id"), subitens.getCodItem()));
                    }
                }
                predications.add(builder.like(root.get("nome"),"%" + filtro + "%"));
                predications.add(builder.like(root.get("descricao"),"%" + filtro + "%"));
                return builder.or(predications.toArray(Predicate[]::new));
            }
            return null;
        };
    }

    @Override
    public ResponseEntity<?> salvar(ItemVistoriaDTO itemVistoria) {
        if(StringUtils.isEmptyOrNull(itemVistoria.getNome()) || repository.findByNome(itemVistoria.getNome()).isPresent()) {
            throw new VistoriaExceptions("Item já cadastrado no sistema.");
        }
        var itemSaved = repository.save(new ItemVistoriaMapper().convertEntity(itemVistoria));
        List<SubitensVistoriaEntity> subitens = new ArrayList<>();
        for(SubitemVistoriaEntity item: itemVistoria.getSubitens()) {
            SubitensVistoriaEntity subitem = new SubitensVistoriaEntity();
            subitem.setCodItem(itemSaved);
            subitem.setCodSubitem(item);
            subitem.setDataInclusao(LocalDate.now());
            subitem.setAtivo(true);
            subitens.add(subitem);
        }
        subitensRepository.saveAll(subitens);
        return ResponseEntity.ok(itemSaved);
    }

    @Override
    public ResponseEntity<?> editar(Long id, EdicaoItemVistoriaDTO edicao) {
        if(repository.findByNome(edicao.getNome()).isPresent()) {
            throw new VistoriaExceptions("Item já cadastrado no sistema.");
        }
        var itemVistoria = findById(id);
        if (!StringUtils.isEmptyOrNull(edicao.getNome())) {
            itemVistoria.setNome(edicao.getNome());
        }
        if (!StringUtils.isEmptyOrNull(edicao.getDescricao())) {
            itemVistoria.setDescricao(edicao.getDescricao());
        }
        if (!ListUtils.isEmpty(edicao.getSubitens())) {
            var defeitosVistoriaList = subitensRepository.findAllByCodItem(itemVistoria);
            if (!defeitosVistoriaList.isEmpty()) {
                for (SubitensVistoriaEntity subitensVistoria : defeitosVistoriaList) {
                    if (edicao.getSubitens().stream().noneMatch(t ->
                            Objects.equals(t.getId(), subitensVistoria.getCodSubitem().getId()))) {
                        subitensRepository.delete(subitensVistoria);
                    }
                }
            }
            for (SubitemVistoriaEntity subitemVistoria : edicao.getSubitens()) {
                if (subitensRepository.findByCodItemAndCodSubitem(itemVistoria, subitemVistoria).isEmpty()) {
                    subitensRepository.save(SubitensVistoriaEntity.builder()
                            .codItem(itemVistoria)
                            .codSubitem(subitemVistoria)
                            .ativo(true)
                            .dataInclusao(LocalDate.now())
                            .build());
                }
            }
        } else {
            var todosSubitens = subitensRepository.findAllByCodItem(itemVistoria);
            if(!ListUtils.isEmpty(todosSubitens)) {
                subitensRepository.deleteAll(todosSubitens);
            }
        }
        return ResponseEntity.ok(repository.save(itemVistoria));
    }

    @Override
    public ResponseEntity<?> desativar(Long id) {
        var itemVistoria = findById(id);
        var subitens = itensRepository.findAllByCodItem(itemVistoria);
        if(!ListUtils.isEmpty(subitens)) {
            throw new VistoriaExceptions("Não é possível remover o Item, há (" + ListUtils.size(subitens) + ") sendo utilizado(s) em Tipo(s).");
        }
        itemVistoria.setAtivo(false);
        repository.save(itemVistoria);
        return ResponseEntity.ok().build();
    }

    @Override
    public ResponseEntity<?> excluir(Long id) {
        var itemVistoria = findById(id);
        var subitens = itensRepository.findAllByCodItem(itemVistoria);
        if(!ListUtils.isEmpty(subitens)) {
            throw new VistoriaExceptions("Não é possível excluir o Item, há (" + ListUtils.size(subitens) + ") sendo utilizado(s) em Tipo(s).");
        }
        repository.delete(itemVistoria);
        return ResponseEntity.ok().build();
    }

    @Override
    public ResponseEntity<?> ativar(Long id) {
        var itemVistoria = findById(id);
        itemVistoria.setAtivo(true);
        repository.save(itemVistoria);
        return ResponseEntity.ok().build();
    }

    @Override
    public ResponseEntity<List<SubitensVistoriaEntity>> findAllSubitensVistoria() {
        return ResponseEntity.ok(subitensRepository.findAll());
    }

    @Override
    public ResponseEntity<List<SubitemVistoriaEntity>> findAllSubitemVistoriaById(String nome) {
        var subitenslist = subitensRepository.findAllByCodItem(repository.findByNome(nome).get());
        List<SubitemVistoriaEntity> response = new ArrayList<>();
        for(SubitensVistoriaEntity subitem: subitenslist) {
            response.add(subitemRepository.findById(subitem.getCodSubitem().getId()).get());
        }
        return ResponseEntity.ok(response);
    }

    @Override
    public ResponseEntity<List<SubitemVistoriaEntity>> findAllSubitemVistoria() {
        var subitem = subitemRepository.findAll(Sort.by(Sort.Direction.ASC, "nome"));
        subitem.removeIf(tipo -> tipo.getAtivo().equals(false));
        return ResponseEntity.ok(subitem);
    }

    @Override
    public OcorrenciasDTO listAllAtivosByTipoVistoria(Long tipoVistoria) {
        OcorrenciasDTO ocorrenciasDTO = new OcorrenciasDTO();
        List<ItemVistoriaOcorrenciaDTO> itemVistoriaOcorrenciaDTOS = new ArrayList<>();

        TipoVistoriaEntity tipoVistoriaEntity = tipoVistoriaService.findByIdTipoVistoria(tipoVistoria);
        List<ItensVistoriaEntity> itensVistoriaEntities = itensRepository.findBycodTipoAndAtivo(tipoVistoriaEntity, true);

        if (itensVistoriaEntities.isEmpty()) {
            throw new ItemVistoriaException("Não existe Item Vistoria cadastrado para esse tipo vistoria de ID: " + tipoVistoria);
        }

        for (ItensVistoriaEntity itemVistoriaEntity : itensVistoriaEntities) {
            List<SubitemVistoriaDTO> subitemVistoriaDTOS = new ArrayList<>();
            List<SubitensVistoriaEntity> subitemVistoriaEntities = subitensRepository.findAllByCodItemAndAtivo(itemVistoriaEntity.getCodItem(), true);

            for (SubitensVistoriaEntity subitensVistoriaEntity: subitemVistoriaEntities){
                List<DefeitosVistoriaEntity> defeitosVistoriaEntities =
                        defeitosVistoriaRepository.findAllByCodSubitemAndAtivo(subitensVistoriaEntity.getCodSubitem(), true);

                List<TipoDefeitoVistoriaEntity> tipoDefeitoVistoriaEntities = defeitosVistoriaEntities.stream()
                        .map(this::getDefeitoVistoriaEntity)
                        .collect(Collectors.toList());

                SubitemVistoriaDTO subitemVistoriaDTO = getSubitemVistoriaDTO(subitensVistoriaEntity, tipoDefeitoVistoriaEntities);
                subitemVistoriaDTOS.add(subitemVistoriaDTO);
            }

            ItemVistoriaOcorrenciaDTO itemVistoriaOcorrenciaDTO = getItemVistoriaOcorrenciaDTO(itemVistoriaEntity, subitemVistoriaDTOS);
            itemVistoriaOcorrenciaDTOS.add(itemVistoriaOcorrenciaDTO);
        }

        ocorrenciasDTO.setItemVistoriaOcorrenciaDTOS(itemVistoriaOcorrenciaDTOS);
        return ocorrenciasDTO;
    }



    private ItemVistoriaOcorrenciaDTO getItemVistoriaOcorrenciaDTO(ItensVistoriaEntity itensVistoriaEntity, List<SubitemVistoriaDTO> subitemVistoriaDTOS) {
        ItemVistoriaOcorrenciaDTO itemVistoriaOcorrenciaDTO = new ItemVistoriaOcorrenciaDTO();
        itemVistoriaOcorrenciaDTO.setId(itensVistoriaEntity.getCodItem().getId());
        itemVistoriaOcorrenciaDTO.setNome(itensVistoriaEntity.getCodItem().getNome());
        itemVistoriaOcorrenciaDTO.setDescricao(itensVistoriaEntity.getCodItem().getDescricao());
        itemVistoriaOcorrenciaDTO.setAtivo(itensVistoriaEntity.getCodItem().getAtivo());
        itemVistoriaOcorrenciaDTO.setDataInclusao(itensVistoriaEntity.getCodItem().getDataInclusao());
        itemVistoriaOcorrenciaDTO.setSubitemVistoriaDTOS(subitemVistoriaDTOS);
        return itemVistoriaOcorrenciaDTO;
    }

    private SubitemVistoriaDTO getSubitemVistoriaDTO(SubitensVistoriaEntity subitensVistoriaEntity, List<TipoDefeitoVistoriaEntity> tipoDefeitoVistoriaEntities) {
        SubitemVistoriaDTO subitemVistoriaDTO = new SubitemVistoriaDTO();
        subitemVistoriaDTO.setId(subitensVistoriaEntity.getCodSubitem().getId());
        subitemVistoriaDTO.setNome(subitensVistoriaEntity.getCodSubitem().getNome());
        subitemVistoriaDTO.setDescricao(subitensVistoriaEntity.getCodSubitem().getDescricao());
        subitemVistoriaDTO.setAtivo(subitensVistoriaEntity.getCodSubitem().getAtivo());
        subitemVistoriaDTO.setDataInclusao(subitensVistoriaEntity.getCodSubitem().getDataInclusao());
        subitemVistoriaDTO.setDefeitos(tipoDefeitoVistoriaEntities);
        return subitemVistoriaDTO;
    }

    private TipoDefeitoVistoriaEntity getDefeitoVistoriaEntity(DefeitosVistoriaEntity defeitosVistoriaEntity) {
        TipoDefeitoVistoriaEntity tipoDefeitoVistoriaEntity = new TipoDefeitoVistoriaEntity();
        tipoDefeitoVistoriaEntity.setId(defeitosVistoriaEntity.getCodTipoDefeito().getId());
        tipoDefeitoVistoriaEntity.setNome(defeitosVistoriaEntity.getCodTipoDefeito().getNome());
        tipoDefeitoVistoriaEntity.setDescricao(defeitosVistoriaEntity.getCodTipoDefeito().getDescricao());
        tipoDefeitoVistoriaEntity.setAtivo(defeitosVistoriaEntity.getCodTipoDefeito().getAtivo());
        tipoDefeitoVistoriaEntity.setDataInclusao(defeitosVistoriaEntity.getCodTipoDefeito().getDataInclusao());
        return tipoDefeitoVistoriaEntity;
    }



    private ItemVistoriaEntity findById(Long id) {
        return repository.findById(id).orElseThrow();
    }
}
