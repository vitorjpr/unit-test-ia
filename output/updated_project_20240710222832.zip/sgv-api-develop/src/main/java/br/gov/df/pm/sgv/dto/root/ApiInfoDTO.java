package br.gov.df.pm.sgv.dto.root;

import br.gov.df.pm.sgv.domain.sgpol.Policial;
import lombok.Value;

import java.util.List;

@Value
public class ApiInfoDTO {

    private String buildVersion;

    private Policial policial;

    private List<PerfilDTO> perfis;

    public ApiInfoDTO(String appVersion, Policial policialAutenticado, List<PerfilDTO> perfilDTOS) {
        this.buildVersion = appVersion;
        this.policial = policialAutenticado;
        this.perfis = perfilDTOS;
    }
}