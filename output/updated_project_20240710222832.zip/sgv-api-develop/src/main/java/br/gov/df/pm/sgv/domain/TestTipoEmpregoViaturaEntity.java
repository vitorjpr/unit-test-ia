Here are some unit tests for the provided Java code:

```java
package br.gov.df.pm.sgv.domain;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TipoEmpregoViaturaEntityTest {

    @Test
    public void testGetId() {
        TipoEmpregoViaturaEntity tipoEmprego = new TipoEmpregoViaturaEntity();
        tipoEmprego.setId(1);
        assertEquals(1, tipoEmprego.getId());
    }

    @Test
    public void testGetNome() {
        TipoEmpregoViaturaEntity tipoEmprego = new TipoEmpregoViaturaEntity();
        tipoEmprego.setNome("Teste");
        assertEquals("Teste", tipoEmprego.getNome());
    }

    @Test
    public void testGetAtivo() {
        TipoEmpregoViaturaEntity tipoEmprego = new TipoEmpregoViaturaEntity();
        tipoEmprego.setAtivo(1);
        assertEquals(1, tipoEmprego.getAtivo());
    }

    @Test
    public void testEqualsAndHashCode() {
        TipoEmpregoViaturaEntity tipoEmprego1 = new TipoEmpregoViaturaEntity();
        tipoEmprego1.setId(1);
        TipoEmpregoViaturaEntity tipoEmprego2 = new TipoEmpregoViaturaEntity();
        tipoEmprego2.setId(1);
        assertEquals(tipoEmprego1, tipoEmprego2);
        assertEquals(tipoEmprego1.hashCode(), tipoEmprego2.hashCode());
    }
}
```

Please make sure to include the necessary imports for the `@Test` annotation and assertions. These tests cover the basic functionality of getting and setting the attributes, as well as testing the `equals` and `hashCode` methods based on the `id` attribute.