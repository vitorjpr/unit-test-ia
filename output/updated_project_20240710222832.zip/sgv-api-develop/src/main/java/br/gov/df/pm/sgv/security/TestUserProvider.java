Here are the unit tests for the `UserProvider` interface:

```java
package br.gov.df.pm.sgv.security;

import br.gov.df.pm.sgv.domain.sgpol.Policial;
import br.gov.df.pm.sgv.domain.sgpol.UnidadePolicialMilitar;
import br.gov.df.pm.sgv.dto.root.PerfilDTO;
import br.gov.df.pm.sgv.dto.root.RecursoDTO;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class UserProviderTest {

    private UserProvider userProvider;

    @BeforeEach
    public void setUp() {
        userProvider = mock(UserProvider.class);
    }

    @Test
    public void testGetPolicialAutenticado() {
        Policial policial = new Policial();
        when(userProvider.getPolicialAutenticado()).thenReturn(policial);

        Policial result = userProvider.getPolicialAutenticado();

        assertNotNull(result);
        assertEquals(policial, result);
    }

    @Test
    public void testGetRecursosPolicialAutenticado() {
        RecursoDTO recursoDTO = new RecursoDTO();
        List<RecursoDTO> recursos = Arrays.asList(recursoDTO);
        when(userProvider.getRecursosPolicialAutenticado()).thenReturn(recursos);

        List<RecursoDTO> result = userProvider.getRecursosPolicialAutenticado();

        assertNotNull(result);
        assertEquals(recursos, result);
    }

    @Test
    public void testGetPerfisPolicialAutenticado() {
        PerfilDTO perfilDTO = new PerfilDTO();
        List<PerfilDTO> perfis = Arrays.asList(perfilDTO);
        when(userProvider.getPerfisPolicialAutenticado()).thenReturn(perfis);

        List<PerfilDTO> result = userProvider.getPerfisPolicialAutenticado();

        assertNotNull(result);
        assertEquals(perfis, result);
    }

    @Test
    public void testPossuiRecursos() {
        when(userProvider.possuiRecursos("recurso1", "recurso2")).thenReturn(true);

        assertTrue(userProvider.possuiRecursos("recurso1", "recurso2"));
    }

    @Test
    public void testGetUnidadePolicialAutenticado() {
        UnidadePolicialMilitar unidadePolicial = new UnidadePolicialMilitar();
        when(userProvider.getUnidadePolicialAutenticado()).thenReturn(unidadePolicial);

        UnidadePolicialMilitar result = userProvider.getUnidadePolicialAutenticado();

        assertNotNull(result);
        assertEquals(unidadePolicial, result);
    }
}
```

These unit tests cover the methods defined in the `UserProvider` interface and ensure that they are working as expected. Make sure to include appropriate dependencies (e.g., JUnit, Mockito) in your project to run these tests successfully.