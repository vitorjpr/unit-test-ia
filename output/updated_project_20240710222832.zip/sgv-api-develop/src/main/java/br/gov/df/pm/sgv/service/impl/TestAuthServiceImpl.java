```java
package br.gov.df.pm.sgv.service.impl;

import br.gov.df.pm.sgv.dto.AuthDTO;
import br.gov.df.pm.sgv.feign.ApiServicosExternos;
import br.gov.df.pm.sgv.feign.dto.AuthKeycloakDTO;
import br.gov.df.pm.sgv.feign.dto.MessageAuthKeycloak;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

public class AuthServiceImplTest {

    @InjectMocks
    private AuthServiceImpl authService;

    @Mock
    private ApiServicosExternos apiServicosExternos;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testAuthentication_Successful() {
        AuthDTO auth = new AuthDTO("username", "password");
        AuthKeycloakDTO authKeycloakDTO = AuthKeycloakDTO.builder()
                .username(auth.getUsername())
                .password(auth.getPassword())
                .clientId("testClientId")
                .credentals("testCredentials")
                .build();

        MessageAuthKeycloak messageAuthKeycloak = new MessageAuthKeycloak("success");

        when(apiServicosExternos.authentication(authKeycloakDTO)).thenReturn(ResponseEntity.ok(messageAuthKeycloak));

        ResponseEntity<MessageAuthKeycloak> response = authService.authentication(auth);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(messageAuthKeycloak, response.getBody());

        verify(apiServicosExternos, times(1)).authentication(authKeycloakDTO);
    }

    @Test
    public void testAuthentication_Failure() {
        AuthDTO auth = new AuthDTO("username", "password");
        AuthKeycloakDTO authKeycloakDTO = AuthKeycloakDTO.builder()
                .username(auth.getUsername())
                .password(auth.getPassword())
                .clientId("testClientId")
                .credentals("testCredentials")
                .build();

        when(apiServicosExternos.authentication(authKeycloakDTO)).thenThrow(new RuntimeException("Error"));

        ResponseEntity<MessageAuthKeycloak> response = authService.authentication(auth);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());

        verify(apiServicosExternos, times(1)).authentication(authKeycloakDTO);
        verify(authService, times(1)).doAuthenticationRequest(authKeycloakDTO);
    }
}
```