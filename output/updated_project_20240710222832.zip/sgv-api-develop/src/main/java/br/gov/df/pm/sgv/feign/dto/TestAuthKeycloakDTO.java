Sure! Here are the unit tests for the provided Java code:

```java
package br.gov.df.pm.sgv.feign.dto;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class AuthKeycloakDTOTest {

    @Test
    public void testGetUsername() {
        AuthKeycloakDTO authKeycloakDTO = AuthKeycloakDTO.builder().username("testUser").build();
        assertEquals("testUser", authKeycloakDTO.getUsername());
    }

    @Test
    public void testGetPassword() {
        AuthKeycloakDTO authKeycloakDTO = AuthKeycloakDTO.builder().password("testPassword").build();
        assertEquals("testPassword", authKeycloakDTO.getPassword());
    }

    @Test
    public void testGetClientId() {
        AuthKeycloakDTO authKeycloakDTO = AuthKeycloakDTO.builder().clientId("testClientId").build();
        assertEquals("testClientId", authKeycloakDTO.getClientId());
    }

    @Test
    public void testGetCredentials() {
        AuthKeycloakDTO authKeycloakDTO = AuthKeycloakDTO.builder().credentials("testCredentials").build();
        assertEquals("testCredentials", authKeycloakDTO.getCredentials());
    }

    @Test
    public void testSetUsername() {
        AuthKeycloakDTO authKeycloakDTO = new AuthKeycloakDTO();
        authKeycloakDTO.setUsername("testUser");
        assertEquals("testUser", authKeycloakDTO.getUsername());
    }

    @Test
    public void testSetPassword() {
        AuthKeycloakDTO authKeycloakDTO = new AuthKeycloakDTO();
        authKeycloakDTO.setPassword("testPassword");
        assertEquals("testPassword", authKeycloakDTO.getPassword());
    }

    @Test
    public void testSetClientId() {
        AuthKeycloakDTO authKeycloakDTO = new AuthKeycloakDTO();
        authKeycloakDTO.setClientId("testClientId");
        assertEquals("testClientId", authKeycloakDTO.getClientId());
    }

    @Test
    public void testSetCredentials() {
        AuthKeycloakDTO authKeycloakDTO = new AuthKeycloakDTO();
        authKeycloakDTO.setCredentials("testCredentials");
        assertEquals("testCredentials", authKeycloakDTO.getCredentials());
    }
}
```

These tests cover getter and setter methods for all fields in the `AuthKeycloakDTO` class.