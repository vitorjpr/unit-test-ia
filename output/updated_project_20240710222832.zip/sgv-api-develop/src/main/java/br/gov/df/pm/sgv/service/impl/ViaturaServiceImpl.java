package br.gov.df.pm.sgv.service.impl;

import br.gov.df.pm.sgv.domain.ViaturaEntity;
import br.gov.df.pm.sgv.domain.ViaturaUpmEntity;
import br.gov.df.pm.sgv.domain.VistoriaViaturaEntity;
import br.gov.df.pm.sgv.domain.sgpol.UnidadePolicialMilitar;
import br.gov.df.pm.sgv.dto.TipoEmpregoViaturaDto;
import br.gov.df.pm.sgv.dto.VistoriaViaturaDTO;
import br.gov.df.pm.sgv.exceptions.ViaturaException;
import br.gov.df.pm.sgv.mapper.TipoEmpregoMapper;
import br.gov.df.pm.sgv.repository.TipoEmpregoViaturaRepository;
import br.gov.df.pm.sgv.repository.app.ViaturaRepository;
import br.gov.df.pm.sgv.repository.app.VistoriaViaturaRepository;
import br.gov.df.pm.sgv.repository.sgpol.UnidadePolicialMilitarRepository;
import br.gov.df.pm.sgv.service.ViaturaService;
import br.gov.df.pm.sgv.shared.utils.StringUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.persistence.criteria.Subquery;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
public class ViaturaServiceImpl implements ViaturaService {

    @Autowired
    private ViaturaRepository viaturaRepository;

    @Autowired
    private VistoriaViaturaRepository vistoriaViaturaRepository;

    @Autowired
    UnidadePolicialMilitarRepository unidadePolicialMilitarRepository;


    @Autowired
    TipoEmpregoViaturaRepository tipoEmpregoViaturaRepository;

    @Override
    public Page<ViaturaEntity> buscar(Integer upmCodigo, String prefixo, String placa, Pageable pageable) {
        return viaturaRepository.findAll(filtroToSpecification(upmCodigo, prefixo, placa), pageable);
    }

    @Override
    public Page<ViaturaEntity> buscarViatura(Integer upmCodigo, String prefixo, String placa, Integer tepCodigo, Pageable pageable) {
       Page<ViaturaEntity> viaturaEntities = viaturaRepository.findAll(filtroToSpecificationV1(upmCodigo, prefixo, placa, tepCodigo), pageable);
//       if(viaturaEntities == null || viaturaEntities.isEmpty()){
//           throw new ViaturaException("Não foi encontrada viatura para esses parâmetros de busca.");
//        }
        if(!viaturaEntities.isEmpty()) {
            List<ViaturaEntity> filteredList = viaturaEntities.stream()
                    .filter(ViaturaEntity::getAtivo)
                    .collect(Collectors.toList());

            return new PageImpl<>(filteredList, pageable, viaturaEntities.getTotalElements());
        } else {
            return new PageImpl<>(List.of(), pageable, viaturaEntities.getTotalElements());
        }
    }

    @Override
    public Page<ViaturaEntity> findPaginado(Pageable pageable) {
        return viaturaRepository.findAll(pageable);
    }

    @Override
    public Double getUltimoOdometroByViatura(Long id) {
        var vistoria = vistoriaViaturaRepository.findAllByViaturaId(id);
        if (vistoria.isEmpty()) {
            return 0.0;
        } else {
            double valor = 0.0;
            for (VistoriaViaturaEntity vistoriaViatura : vistoria) {
                if (vistoriaViatura.getDiferencaOdometro() != null) {
                    var valorDiferenca = vistoriaViatura.getDiferencaOdometro().getDiferencaOdometro();
                    if (valor <= valorDiferenca) {
                        valor = valorDiferenca + valor;
                    }
                }
            }
            return valor;
        }
    }

    @Override
    public List<VistoriaViaturaDTO> getVistoriaViaturaByViatura(Long id) {
        List<VistoriaViaturaDTO> vistoriaViatura = new ArrayList<>();
        var entityList = vistoriaViaturaRepository.findAllByViaturaId(id);
        for (VistoriaViaturaEntity entity : entityList) {
            vistoriaViatura.add(VistoriaViaturaDTO.builder()
                    .tipoVistoria(entity.getTipoVistoria())
                    .vistoriaViaturaHistorico(entity.getVistoriaViaturaHistorico())
                    .status(entity.getStatus())
                    .diferencaOdometro(entity.getDiferencaOdometro())
                    .build());
        }
        return vistoriaViatura;
    }

    @Override
    public ResponseEntity<List<UnidadePolicialMilitar>> listarUpm() {
        return ResponseEntity.ok(unidadePolicialMilitarRepository.findAllByAtivoOrderBySigla(1));
    }

    @Override
    public ResponseEntity<List<TipoEmpregoViaturaDto>> listar() {
        List<TipoEmpregoViaturaDto> tipoEmpregoViaturaDtos = new ArrayList<>();
        tipoEmpregoViaturaRepository.findAll().forEach(tipoEmpregoViatura ->
                tipoEmpregoViaturaDtos.add(new TipoEmpregoMapper().convertDTO(tipoEmpregoViatura)));
        return ResponseEntity.ok(tipoEmpregoViaturaDtos);
    }

    @Override
    public Page<ViaturaEntity> buscarViaturasAtivas(Pageable pageable) {
        Page<ViaturaEntity> viaturaEntities = viaturaRepository.findAll(pageable);
        if(viaturaEntities.isEmpty()){
            throw new ViaturaException("Não há viaturas ativas");
        }
        List<ViaturaEntity> viaturasAtivas = viaturaEntities.stream()
                .filter(ViaturaEntity::getAtivo)
                .collect(Collectors.toList());
        return new PageImpl<>(viaturasAtivas, pageable, viaturaEntities.getTotalElements());
    }

    private Specification<ViaturaEntity> filtroToSpecification(Integer upmCodigo, String prefixo, String placa) {
        return (root, query, builder) -> {
            if (upmCodigo != null || !StringUtils.isEmptyOrNull(prefixo) || !StringUtils.isEmptyOrNull(placa) ) {
                var predications = new ArrayList<Predicate>();
                if (upmCodigo != null) {
                    var viaturaUpmSub = query.subquery(ViaturaEntity.class);
                    var viaturaUpmRoot = viaturaUpmSub.from(ViaturaEntity.class);
                    viaturaUpmSub.select(viaturaUpmRoot.get("id"));
                    predications.add(builder.equal(viaturaUpmRoot.get("upmCodigo"), upmCodigo));
                    viaturaUpmSub.where(builder.or(predications.toArray(Predicate[]::new)));
                }
                if (!StringUtils.isEmptyOrNull(prefixo)) {
                    predications.add(builder.equal(root.get("prefixo"), prefixo));
                }
                if (!StringUtils.isEmptyOrNull(placa)) {
                    predications.add(builder.equal(root.get("placa"), placa));
                }

                return builder.or(predications.toArray(Predicate[]::new));
            }
            return null;
        };
    }

    private Specification<ViaturaEntity> filtroToSpecificationV1(Integer upmCodigo, String prefixo, String placa, Integer tepCodigo) {
        return (root, query, builder) -> {
            if (upmCodigo != null || !StringUtils.isEmptyOrNull(prefixo) || !StringUtils.isEmptyOrNull(placa) || tepCodigo != null) {
                var predications = new ArrayList<Predicate>();
                if (upmCodigo != null) {
                    Subquery<Integer> viaturaUpmSub = query.subquery(Integer.class);
                    Root<ViaturaUpmEntity> viaturaUpmRoot = viaturaUpmSub.from(ViaturaUpmEntity.class);
                    viaturaUpmSub.select(viaturaUpmRoot.get("viatura").get("id"));

                    List<Predicate> subPredicates = new ArrayList<>();
                    subPredicates.add(builder.equal(viaturaUpmRoot.get("upmCodigo"), upmCodigo));
                    subPredicates.add(builder.equal(viaturaUpmRoot.get("ativo"), 1));

                    viaturaUpmSub.where(builder.and(subPredicates.toArray(new Predicate[0])));
                    predications.add(builder.in(root.get("id")).value(viaturaUpmSub));
                }
                if (!StringUtils.isEmptyOrNull(prefixo)) {
                    predications.add(builder.equal(root.get("prefixo"), prefixo));
                }
                if (!StringUtils.isEmptyOrNull(placa)) {
                    predications.add(builder.equal(root.get("placa"), placa));
                }

                if (tepCodigo != null) {
                    predications.add(builder.equal(root.get("tipoEmpregoViatura"), tepCodigo));
                }
                return builder.or(predications.toArray(Predicate[]::new));
            }
            return null;
        };
    }
}
