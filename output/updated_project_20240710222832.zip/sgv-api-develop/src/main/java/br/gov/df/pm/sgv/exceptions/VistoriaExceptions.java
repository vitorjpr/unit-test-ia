package br.gov.df.pm.sgv.exceptions;

public class VistoriaExceptions extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public VistoriaExceptions() {
    }

    public VistoriaExceptions(String message) {
        super(message);
    }

    public VistoriaExceptions(String message, Throwable cause) {
        super(message, cause);
    }
}

