Here are the unit tests for the provided Java code:

```java
package br.gov.df.pm.sgv.dto.root;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class RecursoDTOTest {

    @Test
    public void testConstructor() {
        RecursoDTO recursoDTO = new RecursoDTO("Recurso1");
        assertEquals("Recurso1", recursoDTO.getNome());
    }

    @Test
    public void testSetNome() {
        RecursoDTO recursoDTO = new RecursoDTO("Recurso1");
        recursoDTO.setNome("Recurso2");
        assertEquals("Recurso2", recursoDTO.getNome());
    }

    @Test
    public void testEquals() {
        RecursoDTO recursoDTO1 = new RecursoDTO("Recurso1");
        RecursoDTO recursoDTO2 = new RecursoDTO("Recurso1");
        assertEquals(recursoDTO1, recursoDTO2);
    }

    @Test
    public void testHashCode() {
        RecursoDTO recursoDTO1 = new RecursoDTO("Recurso1");
        RecursoDTO recursoDTO2 = new RecursoDTO("Recurso1");
        assertEquals(recursoDTO1.hashCode(), recursoDTO2.hashCode());
    }
}
```

Make sure to include the necessary imports for the test class:

```java
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;
```

These unit tests cover the constructor, setter method, equals method, and hashCode method of the `RecursoDTO` class. You can run these tests to ensure the correctness of the class implementation.