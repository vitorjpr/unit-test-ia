Sure! Here are some unit tests for the provided `VistoriaDTO` class:

```java
package br.gov.df.pm.sgv.dto;

import br.gov.df.pm.sgv.domain.TipoVistoriaEntity;
import br.gov.df.pm.sgv.domain.ViaturaEntity;
import br.gov.df.pm.sgv.domain.enums.VistoriaViaturaStatusEnum;
import br.gov.df.pm.sgv.domain.VistoriaViaturaHistoricoEntity;
import br.gov.df.pm.sgv.domain.VistoriaArquivo;
import br.gov.df.pm.sgv.domain.DiferencaOdometroEntity;
import br.gov.df.pm.sgv.domain.ChecklistVistoriaEntity;
import org.junit.jupiter.api.Test;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class VistoriaDTOTest {

    @Test
    public void testConstructorAndGetters() {
        Long id = 1L;
        String upm = "UPM Test";
        String motorista = "Motorista Test";
        ViaturaEntity viatura = new ViaturaEntity();
        TipoVistoriaEntity tipoVistoria = new TipoVistoriaEntity();
        List<VistoriaViaturaHistoricoEntity> vistoriaViaturaHistorico = new ArrayList<>();
        List<VistoriaArquivo> vistoriaArquivoList = new ArrayList<>();
        DiferencaOdometroEntity diferencaOdometro = new DiferencaOdometroEntity();
        VistoriaViaturaStatusEnum status = VistoriaViaturaStatusEnum.PENDENTE;
        Float odometroInicial = 100.0f;
        Float odometroFinal = 150.0f;
        Boolean diferencaVistoria = true;
        LocalDateTime dataVistoria = LocalDateTime.now();
        List<ChecklistVistoriaEntity> checkLists = new ArrayList<>();

        VistoriaDTO vistoriaDTO = new VistoriaDTO(id, upm, motorista, viatura, tipoVistoria,
                vistoriaViaturaHistorico, vistoriaArquivoList, diferencaOdometro, status, odometroInicial,
                odometroFinal, diferencaVistoria, dataVistoria, checkLists);

        assertNotNull(vistoriaDTO);
        assertEquals(id, vistoriaDTO.getId());
        assertEquals(upm, vistoriaDTO.getUpm());
        assertEquals(motorista, vistoriaDTO.getMotorista());
        assertEquals(viatura, vistoriaDTO.getViatura());
        assertEquals(tipoVistoria, vistoriaDTO.getTipoVistoria());
        assertEquals(vistoriaViaturaHistorico, vistoriaDTO.getVistoriaViaturaHistorico());
        assertEquals(vistoriaArquivoList, vistoriaDTO.getVistoriaArquivoList());
        assertEquals(diferencaOdometro, vistoriaDTO.getDiferencaOdometro());
        assertEquals(status, vistoriaDTO.getStatus());
        assertEquals(odometroInicial, vistoriaDTO.getOdometroInicial());
        assertEquals(odometroFinal, vistoriaDTO.getOdometroFinal());
        assertEquals(diferencaVistoria, vistoriaDTO.getDiferencaVistoria());
        assertEquals(dataVistoria, vistoriaDTO.getDataVistoria());
        assertEquals(checkLists, vistoriaDTO.getCheckLists());
    }

    // Add more test cases as needed
}
```

These tests cover the constructor and getters of the `VistoriaDTO` class. Feel free to add more test cases to cover other methods or scenarios.