Sure! Here are some unit tests for the `TipoDefeitoVistoriaDTO` class using JUnit and Mockito for mocking:

```java
package br.gov.df.pm.sgv.dto;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.time.LocalDate;

public class TipoDefeitoVistoriaDTOTest {

    @Test
    public void testGetterAndSetterMethods() {
        TipoDefeitoVistoriaDTO tipoDefeito = TipoDefeitoVistoriaDTO.builder()
                .id(1L)
                .nome("Defeito1")
                .descricao("Descrição do defeito")
                .dataInclusao(LocalDate.now())
                .ativo(true)
                .build();

        assertEquals(1L, tipoDefeito.getId());
        assertEquals("Defeito1", tipoDefeito.getNome());
        assertEquals("Descrição do defeito", tipoDefeito.getDescricao());
        assertEquals(LocalDate.now(), tipoDefeito.getDataInclusao());
        assertTrue(tipoDefeito.getAtivo());
    }

    @Test
    public void testEqualsAndHashCodeMethods() {
        TipoDefeitoVistoriaDTO tipoDefeito1 = TipoDefeitoVistoriaDTO.builder().id(1L).build();
        TipoDefeitoVistoriaDTO tipoDefeito2 = TipoDefeitoVistoriaDTO.builder().id(1L).build();
        TipoDefeitoVistoriaDTO tipoDefeito3 = TipoDefeitoVistoriaDTO.builder().id(2L).build();

        assertEquals(tipoDefeito1, tipoDefeito2);
        assertNotEquals(tipoDefeito1, tipoDefeito3);
        assertEquals(tipoDefeito1.hashCode(), tipoDefeito2.hashCode());
    }

    @Test
    public void testToStringMethod() {
        TipoDefeitoVistoriaDTO tipoDefeito = TipoDefeitoVistoriaDTO.builder()
                .id(1L)
                .nome("Defeito1")
                .descricao("Descrição do defeito")
                .dataInclusao(LocalDate.now())
                .ativo(true)
                .build();

        String expectedToString = "TipoDefeitoVistoriaDTO(id=1, nome=Defeito1, descricao=Descrição do defeito, " +
                "dataInclusao=" + LocalDate.now() + ", ativo=true)";
        assertEquals(expectedToString, tipoDefeito.toString());
    }
}
```

Make sure to add the necessary dependencies for Lombok, JUnit, and Mockito in your project's build file. These tests cover the getter/setter methods, `equals` and `hashCode` methods, and the `toString` method of the `TipoDefeitoVistoriaDTO` class.