package br.gov.df.pm.sgv.shared.base;


import br.gov.df.pm.sgv.shared.entity.BaseEntity;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDateTime;

@Setter
@Getter
@MappedSuperclass
@EntityListeners({AuditingEntityListener.class})
public abstract class AuditableEntity<I extends Serializable, U extends Serializable> extends BaseEntity<I> {
    private static final long serialVersionUID = -195693146153984198L;

    @CreatedBy
    @ManyToOne
    @JoinColumn(name = "CRIADO_POR")
    private U criadoPor;

    @CreationTimestamp
    @CreatedDate
    @Column(
            updatable = false,
            name = "DATA_CRIACAO"
    )
    private LocalDateTime dataCriacao;

    @LastModifiedBy
    @ManyToOne
    @JoinColumn(name = "ATUALIZADO_POR")
    private U modificadoPor;

    @LastModifiedDate
    @Column(
            name = "DATA_ATUALIZACAO"
    )
    private LocalDateTime ultimaAtualizacao;


}

