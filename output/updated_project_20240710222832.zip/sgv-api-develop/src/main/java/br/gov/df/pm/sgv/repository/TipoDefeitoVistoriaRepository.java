package br.gov.df.pm.sgv.repository;

import br.gov.df.pm.sgv.domain.TipoDefeitoVistoriaEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface TipoDefeitoVistoriaRepository extends JpaRepository<TipoDefeitoVistoriaEntity, Long>, JpaSpecificationExecutor<TipoDefeitoVistoriaEntity> {
    Optional<TipoDefeitoVistoriaEntity> findByNome(String nome);
}
