package br.gov.df.pm.sgv.domain.sgpol;

import lombok.*;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import java.io.Serializable;

@Entity
@Table(name ="UPM", schema = "dbo", catalog = "sgpol")
@Getter @Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class UnidadePolicialMilitar implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "upm_Codigo", unique = true, nullable = false)
	private int id;

	@NotBlank(message = "Sigla é obrigatória!")
	@Column(name = "upm_Sigla")
	private String sigla;

	@NotBlank(message = "Nome é obrigatório!")
	@Column(name = "upm_Nome")
	private String nome;

	@Column(name = "upm_NomeHistorico")
	private String nomeHistorico;
//
//	@Column(name = "upm_Brasao")
//	private File brasao;
//
	@Column(name = "upm_Ativo", nullable = false,  columnDefinition = "int default 1", insertable = false, updatable = true)
	private int ativo;


	@Column(name = "upm_ComandoRegional")
	private boolean comandoRegional;

//
//	@Column(name = "upm_NomeBrasao")
//	private String nomeBrasao;
//
//	@Column(name = "upm_ContentType")
//	private String contentType;
//
//	@OneToMany(cascade = CascadeType.ALL, mappedBy = "idUpm", fetch = FetchType.LAZY)
//	private Set<UpmLotacao>  listidUpmLotacao;
//
//	@OneToOne(fetch = FetchType.LAZY)
//	@JoinColumn(name = "upm_Subordinacao",referencedColumnName = "upm_Codigo")
//	private UnidadePolicialMilitar idSubordinacao;
//
//	@OneToMany(mappedBy = "upm", fetch = FetchType.LAZY)
//	private List<UpmRecurso>  upmRecursos;
//
//	@OneToMany(cascade = CascadeType.ALL, mappedBy = "idSubordinacao", fetch = FetchType.LAZY)
//	private List<UnidadePolicialMilitar> upmsFilhas;
//
//	@OneToMany(mappedBy = "idUpm", fetch = FetchType.LAZY)
//	private List<UpmPolicial> listUpmPoliciais;
//
//
////	@OneToMany(mappedBy = "upm", fetch = FetchType.LAZY)
////	private List<Viatura> viaturas;
//
//	@JoinColumn(name = "tiu_Codigo", referencedColumnName = "tiu_Codigo")
//	@ManyToOne(fetch = FetchType.LAZY)
//	private TipoUPM tipo;
//
//	@JoinColumn(name = "fun_CodigoComando", referencedColumnName = "fun_Codigo")
//	@ManyToOne(fetch = FetchType.LAZY)
//	private Funcao idFuncaoComando;
//
//
//	@OneToMany(mappedBy = "idUpm", fetch = FetchType.LAZY)
//	private List<Talao> idTalao;
//
//	@OneToMany(mappedBy = "upm")
//	private List<ViaturaUpm> listaViaturaUpm;
//
//	@OneToMany(mappedBy = "upm")
//	private List<UpmPerfil> upmPerfil;
//
//	@Transient
//	private Policial comandante;
//
//	@Transient
//	private int nivel;
//
//
//	@Transient
//	private String novoBrasao;
//
//	@Transient
//	private String urlBrasao;
//
//	@Transient
//	private String secoesIds;
//
//
//	@Transient
//	private int totalEfetivo;
//
//	@Transient
//	private List<QuadroPostoGraduacaoFuncaoUpmLotacao> listaQuadroPostoGraduacaoFuncaoUpmLotacao;
//
//	@Transient
//	private List<VwAtivosPorPostoGraduacaoUpm> quantidadePorPostoGraduacao;
//
//	@Transient
//	private List<VwAtivosPorPostoGraduacaoUpmExterna> quantidadePorPostoGraduacaoUpmExterna;
//
//
//	@Transient
//	private int QuantidadePoliciaisAbono = 0;
//
//	@Transient
//	private int QuantidadePoliciaisFerias = 0;
//
//	@Transient
//	private int QuantidadePoliciaisLe = 0;
//
//	@Transient
//	private int QuantidadePoliciaisDm = 0;
//
//	@Transient
//	private int QuantidadePoliciaisRm = 0;
//
//
//
//	public List<Viatura> getViaturas() {
//		List<Viatura> retorno =  new ArrayList<Viatura>();
//
//		if(this.listaViaturaUpm!=null) {
//			for (ViaturaUpm movimentacao : this.listaViaturaUpm) {
//						if(movimentacao.getAtivo()==1) {
//							retorno.add(movimentacao.getViatura());
//							}
//					}
//
//			}
//
//		return retorno;
//	}
////
////	public void setViaturas(List<Viatura> viaturas) {
////		this.viaturas = viaturas;
////	}
//
//
//
//
//
//
//
//
//
//
//
//	public List<QuadroPostoGraduacaoFuncaoUpmLotacao> getListaQuadroPostoGraduacaoFuncaoUpmLotacao() {
//		return listaQuadroPostoGraduacaoFuncaoUpmLotacao;
//	}
//
//	public void setListaQuadroPostoGraduacaoFuncaoUpmLotacao(
//			List<QuadroPostoGraduacaoFuncaoUpmLotacao> listaQuadroPostoGraduacaoFuncaoUpmLotacao) {
//		this.listaQuadroPostoGraduacaoFuncaoUpmLotacao = listaQuadroPostoGraduacaoFuncaoUpmLotacao;
//	}
//
//	public int getEfetivoPrevistoPracas(){
//
//		int retorno = 0;
//
//		if(listaQuadroPostoGraduacaoFuncaoUpmLotacao!=null){
//		for(QuadroPostoGraduacaoFuncaoUpmLotacao quadroPostoGraduacaoFuncaoUpmLotacao :listaQuadroPostoGraduacaoFuncaoUpmLotacao){
//			if(quadroPostoGraduacaoFuncaoUpmLotacao.getAtivo().equals(1) && quadroPostoGraduacaoFuncaoUpmLotacao.isComputa()){
//				if(quadroPostoGraduacaoFuncaoUpmLotacao.getIdQuadroPostoGraduacao().getIdQuadro().getPracaOficial()==0){
//					retorno =retorno+quadroPostoGraduacaoFuncaoUpmLotacao.getQtdPrevista();
//				}
//			}
//		}
//		}
//
//		return retorno;
//
//	}
//
//	public int getEfetivoPrevistoOficiais(){
//
//		int retorno = 0;
//		if(listaQuadroPostoGraduacaoFuncaoUpmLotacao!=null){
//			for(QuadroPostoGraduacaoFuncaoUpmLotacao quadroPostoGraduacaoFuncaoUpmLotacao :listaQuadroPostoGraduacaoFuncaoUpmLotacao){
//				if(quadroPostoGraduacaoFuncaoUpmLotacao.getIdFuncaoUpmLotacao().getIdUpmLotacao().getAtivo().equals(1)
//						&& quadroPostoGraduacaoFuncaoUpmLotacao.isComputa()
//						&& quadroPostoGraduacaoFuncaoUpmLotacao.getAtivo().equals(1)){
//				if(quadroPostoGraduacaoFuncaoUpmLotacao.getIdQuadroPostoGraduacao().getIdQuadro().getPracaOficial()==1){
//
//
//						retorno =retorno+quadroPostoGraduacaoFuncaoUpmLotacao.getQtdPrevista();
//					}
//				}
//			}
//		}
//		return retorno;
//
//	}
//
//
//	public int getTotalGeralPrevisto() {
//		int retorno = 0;
//
//		retorno = getEfetivoPrevistoOficiais() + getEfetivoPrevistoPracas();
//
//		return retorno;
//	}
//
//	public int getEfetivoPrevisto(){
//
//		int retorno = 0;
//
//		if(listaQuadroPostoGraduacaoFuncaoUpmLotacao!=null){
//			for(QuadroPostoGraduacaoFuncaoUpmLotacao quadroPostoGraduacaoFuncaoUpmLotacao :listaQuadroPostoGraduacaoFuncaoUpmLotacao){
//				if(quadroPostoGraduacaoFuncaoUpmLotacao.getIdFuncaoUpmLotacao().getIdUpmLotacao().getAtivo().equals(1)
//						&& quadroPostoGraduacaoFuncaoUpmLotacao.getAtivo().equals(1) && quadroPostoGraduacaoFuncaoUpmLotacao.isComputa()){
//				if(quadroPostoGraduacaoFuncaoUpmLotacao.getIdQuadroPostoGraduacao().getIdQuadro().getPracaOficial()==0){
//					retorno =retorno+quadroPostoGraduacaoFuncaoUpmLotacao.getQtdPrevista();
//				}
//				}
//			}
//		}
//
//		return retorno;
//	}
//
//
//
//	public int getGratificacoesPrevistas(){
//
//		int retorno = 0;
//
//		if(listaQuadroPostoGraduacaoFuncaoUpmLotacao!=null){
//		for(QuadroPostoGraduacaoFuncaoUpmLotacao quadroPostoGraduacaoFuncaoUpmLotacao :listaQuadroPostoGraduacaoFuncaoUpmLotacao){
//			if(quadroPostoGraduacaoFuncaoUpmLotacao.getIdFuncaoUpmLotacao().getIdUpmLotacao().getAtivo().equals(1) && quadroPostoGraduacaoFuncaoUpmLotacao.getAtivo().equals(1)){
//				if(quadroPostoGraduacaoFuncaoUpmLotacao.getIdFuncaoUpmLotacao().getIdGratificacao()!=null){
//					retorno++;
//				}
//			}
//		}
//		}
//		return retorno;
//	}
//
//
//	public List<UnidadePolicialMilitar> getUpmsFilhas() {
//
//		List<UnidadePolicialMilitar> listaRetorno = new ArrayList<UnidadePolicialMilitar>();
//
//		for (UnidadePolicialMilitar unidadePolicialMilitar : upmsFilhas) {
//			if(unidadePolicialMilitar.getAtivo() == 1){
//				listaRetorno.add(unidadePolicialMilitar);
//			}
//		}
//
//		return listaRetorno;
//	}
//
//	public void setUpmsFilhas(List<UnidadePolicialMilitar> upmsFilhas) {
//		this.upmsFilhas = upmsFilhas;
//	}
//
//	public UnidadePolicialMilitar addUpmFilha(UnidadePolicialMilitar upm) {
//		getUpmsFilhas().add(upm);
//		upm.setIdSubordinacao(this);
//		return upm;
//	}
//
//	public UnidadePolicialMilitar removeUpmFilha(UnidadePolicialMilitar upm) {
//		getUpmsFilhas().remove(upm);
//		upm.setIdSubordinacao(null);
//		return upm;
//	}
//
//
//	public List<VwAtivosPorPostoGraduacaoUpmExterna> getQuantidadePorPostoGraduacaoUpmExterna() {
//		return quantidadePorPostoGraduacaoUpmExterna;
//	}
//
//	public void setQuantidadePorPostoGraduacaoUpmExterna(
//			List<VwAtivosPorPostoGraduacaoUpmExterna> quantidadePorPostoGraduacaoUpmExterna) {
//		this.quantidadePorPostoGraduacaoUpmExterna = quantidadePorPostoGraduacaoUpmExterna;
//	}
//
//	public List<Lotacao> getLotacoes(){
//		List<Lotacao> lotacoes = new ArrayList<Lotacao>();
//		for ( UpmLotacao upmLotacao: getListidUpmLotacao()) {
//			if(upmLotacao.getAtivo().equals(1) ){
//				lotacoes.add(upmLotacao.getIdLotacao());
//			}
//		}
//		return lotacoes;
//	}
//
//
//	public List<Lotacao> getLotacoesInativas(){
//		List<Lotacao> lotacoes = new ArrayList<Lotacao>();
//		for ( UpmLotacao upmLotacao: getListidUpmLotacao()) {
//			if(upmLotacao.getAtivo().equals(0)){
//				lotacoes.add(upmLotacao.getIdLotacao());
//			}
//		}
//		return lotacoes;
//	}
//
//
//	public List<UpmLotacao> getUpmLotacoes(){
//
//		List<UpmLotacao> lotacoes = new ArrayList<UpmLotacao>();
//		for ( UpmLotacao upmLotacao: getListidUpmLotacao()) {
//			if(upmLotacao.getAtivo().equals(1)){
//				lotacoes.add(upmLotacao);
//			}
//		}
//
//		return lotacoes;
//	}
//
//
//
//	/**
//	 * LISTA COM AS SEÇÕES DA UNIDADE, SOMENTE AS SEÇÕES QUE NÃO FOI O ESTADO MAIOR QUE CRIOU
//	 * @return
//	 */
////	public List<UpmLotacao> getUpmLotacoesEM(){
////		List<UpmLotacao> lotacoes = new ArrayList<UpmLotacao>();
////		for ( UpmLotacao upmLotacao: getListidUpmLotacao()) {
////			if(upmLotacao.getAtivo().equals(1) && upmLotacao.getIdLotacao().isEm()){
////				lotacoes.add(upmLotacao);
////			}
////		}
////
////		return lotacoes;
////	}
//
//	/**
//	 * LISTA COM AS SEÇÕES DA UNIDADE, SOMENTE AS SEÇÕES QUE NÃO FOI O ESTADO MAIOR QUE CRIOU
//	 * @return
//	 */
//	public List<UpmLotacao> getUpmLotacoesPmdf(){
//		List<UpmLotacao> lotacoes = new ArrayList<UpmLotacao>();
//		if(getListidUpmLotacao()!=null && !getListidUpmLotacao().isEmpty()) {
//			for ( UpmLotacao upmLotacao: getListidUpmLotacao()) {
//				if(upmLotacao.getAtivo().equals(1) ){
//					lotacoes.add(upmLotacao);
//				}
//			}
//		}
//
//		return lotacoes;
//	}
//
//	public String getEndereco(){
//
//		String retorno = "Sem Endereço Cadastrado";
//
//		for (UpmLotacao secao : getUpmLotacoesPmdf()) {
//
//			if(secao.getEndereco()!=null&&  secao.getEndereco().getIdTipoEndereco().getId()==3 && secao.getEndereco().getAtivo()==1){
//				retorno = secao.getEnderecoFormatado();
//			}
//
//		}
//		return retorno;
//
//	}
//
//
//	public String getTelefone(){
//
//		String retorno = "Sem Endereço Cadastrado";
//
//		for (UpmLotacao secao : getUpmLotacoesPmdf()) {
//
//			if(secao.getTelefone()!=null){
//				retorno = secao.getEnderecoFormatado();
//			}
//
//		}
//		return retorno;
//
//	}
//
//
//
//	public UpmLotacao getUpmLotacaoEndereco(){
//
//
//		UpmLotacao retorno = null;
//
//		for (UpmLotacao secao : getUpmLotacoesPmdf()) {
//
//			if(secao.getEndereco()!=null&&  secao.getEndereco().getIdTipoEndereco().getId()==3 && secao.getEndereco().getAtivo()==1){
//				retorno = secao;
//			}
//
//		}
//
//		return retorno;
//
//	}
//
//
//	public List<UpmLotacao> getUpmLotacoesInativas(){
//
//		List<UpmLotacao> lotacoes = new ArrayList<UpmLotacao>();
//
//		for ( UpmLotacao upmLotacao: getListidUpmLotacao()) {
//
//			if(upmLotacao.getAtivo().equals(0)){
//				lotacoes.add(upmLotacao);
//			}
//		}
//
//		return lotacoes;
//	}
//
//	public UpmLotacao addUpmLotacao(UpmLotacao upmLotacao) {
//		getListidUpmLotacao().add(upmLotacao);
//
//		return upmLotacao;
//	}
//
//	public UpmLotacao removeUpmLotacao(UpmLotacao upmLotacao) {
//		getListidUpmLotacao().remove(upmLotacao);
//
//		return upmLotacao;
//	}
//
//	public String carregarSecoesIds() {
//		secoesIds = "";
//		int cont  = 0;
//		for (UpmLotacao lotacao : getUpmLotacoesPmdf()) {
//			if(cont==0){
//				secoesIds+=lotacao.getIdLotacao().getId();
//			}
//			else{
//				secoesIds+=","+lotacao.getIdLotacao().getId();
//			}
//			cont++;
//		}
//		return secoesIds;
//	}
//
//	public List<Recurso> getRecursos(){
//		List<Recurso> retorno = new ArrayList<>();
//
//		for (UpmRecurso rec : this.upmRecursos) {
//			retorno.add(rec.getRecurso());
//		}
//
//		return retorno;
//	}
//
//	public List<Perfil> getPerfis() {
//		List<Perfil> perfis = new ArrayList<>();
//
//		for (UpmPerfil upmPerfil : upmPerfil) {
//			perfis.add(upmPerfil.getPerfil());
//		}
//		return perfis;
//	}
//
//	@SuppressWarnings("unused")
//	public int getEfetivo() {
//		int retorno = 0;
//		for (UpmPolicial upmPolicial  : listUpmPoliciais) {
//			retorno++;
//		}
//
//		return retorno;
//	}
//
//	@Override
//	public String toString() {
//		return "UnidadePolicialMilitar [id=" + id + ", " + (sigla != null ? "sigla=" + sigla.trim() + ", " : "")
//				+ (nome != null ? "nome=" + nome.trim() + ", " : "")
////				+ (nomeHistorico != null ? "nomeHistorico=" + nomeHistorico + ", " : "")
////				+ (brasao != null ? "brasao=" + brasao + ", " : "") + "ativo=" + ativo + ", comandoRegional="
////				+ comandoRegional + ", " + (nomeBrasao != null ? "nomeBrasao=" + nomeBrasao + ", " : "")
////				+ (contentType != null ? "contentType=" + contentType + ", " : "")
////				+ (listidUpmLotacao != null ? "listidUpmLotacao=" + listidUpmLotacao + ", " : "")
////				+ (idSubordinacao != null ? "idSubordinacao=" + idSubordinacao + ", " : "")
////				+ (upmRecursos != null ? "upmRecursos=" + upmRecursos + ", " : "")
//////				+ (upmsFilhas != null ? "upmsFilhas=" + upmsFilhas + ", " : "")
////				+ (listUpmPoliciais != null ? "listUpmPoliciais=" + listUpmPoliciais + ", " : "")
//////				+ (tipo != null ? "tipo=" + tipo + ", " : "")
////				+ (idFuncaoComando != null ? "idFuncaoComando=" + idFuncaoComando + ", " : "")
////				+ (idTalao != null ? "idTalao=" + idTalao + ", " : "")
////				+ (listaViaturaUpm != null ? "listaViaturaUpm=" + listaViaturaUpm + ", " : "")
////				+ (upmPerfil != null ? "upmPerfil=" + upmPerfil + ", " : "")
////				+ (comandante != null ? "comandante=" + comandante + ", " : "") + "nivel=" + nivel + ", "
////				+ (novoBrasao != null ? "novoBrasao=" + novoBrasao + ", " : "")
////				+ (urlBrasao != null ? "urlBrasao=" + urlBrasao + ", " : "")
////				+ (secoesIds != null ? "secoesIds=" + secoesIds + ", " : "") + "totalEfetivo=" + totalEfetivo + ", "
////				+ (listaQuadroPostoGraduacaoFuncaoUpmLotacao != null
////						? "listaQuadroPostoGraduacaoFuncaoUpmLotacao=" + listaQuadroPostoGraduacaoFuncaoUpmLotacao
////								+ ", "
////						: "")
//				+ (quantidadePorPostoGraduacao != null
//						? "quantidadePorPostoGraduacao=" + quantidadePorPostoGraduacao + ", "
//						: "")
//				+ "QuantidadePoliciaisAbono=" + QuantidadePoliciaisAbono + ", QuantidadePoliciaisFerias="
//				+ QuantidadePoliciaisFerias + ", QuantidadePoliciaisLe=" + QuantidadePoliciaisLe
//				+ ", QuantidadePoliciaisDm=" + QuantidadePoliciaisDm + ", QuantidadePoliciaisRm="
//				+ QuantidadePoliciaisRm + "]";
//	}
//
//
//	@Override
//	public int hashCode() {
//		final int prime = 31;
//		int result = 1;
//		result = prime * result + id;
//		return result;
//	}
//
//	@Override
//	public boolean equals(Object obj) {
//		if (this == obj)
//			return true;
//		if (obj == null)
//			return false;
//		if (getClass() != obj.getClass())
//			return false;
//		UnidadePolicialMilitar other = (UnidadePolicialMilitar) obj;
//		if (id != other.id)
//			return false;
//		return true;
//	}
//
//
}
