Sure! Here are the unit tests for the provided Java code:

```java
package br.gov.df.pm.sgv.service;

import br.gov.df.pm.sgv.domain.VistoriaArquivo;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class VistoriaArquivoServiceTest {

    private VistoriaArquivoService vistoriaArquivoService = new VistoriaArquivoServiceImpl();

    @Test
    public void testDeletarPorId() {
        Long id = 1L;
        ResponseEntity<VistoriaArquivo> responseEntity = vistoriaArquivoService.deletarPorId(id);

        assertNotNull(responseEntity);
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    }

    @Test
    public void testDeletarPorLista() {
        List<Long> ids = new ArrayList<>();
        ids.add(1L);
        ids.add(2L);

        ResponseEntity<List<VistoriaArquivo>> responseEntity = vistoriaArquivoService.deletarPorLista(ids);

        assertNotNull(responseEntity);
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals(2, responseEntity.getBody().size());
    }
}
```

In these unit tests, we are testing the `deletarPorId` and `deletarPorLista` methods of the `VistoriaArquivoService` interface. The tests check if the response entity is not null, if the status code is `HttpStatus.OK`, and if the expected number of elements is returned in the case of `deletarPorLista`.

Make sure to replace `VistoriaArquivoServiceImpl` with the actual implementation class of `VistoriaArquivoService` in your project. Additionally, ensure that you have the necessary dependencies and configurations set up for running these tests.