package br.gov.df.pm.sgv.controller;

import br.gov.df.pm.sgv.assembler.SubitemVistoriaAssembler;
import br.gov.df.pm.sgv.dto.EdicaoSubitemVistoriaDTO;
import br.gov.df.pm.sgv.dto.SubitemVistoriaDTO;
import br.gov.df.pm.sgv.domain.DefeitosVistoriaEntity;
import br.gov.df.pm.sgv.domain.SubitemVistoriaEntity;
import br.gov.df.pm.sgv.domain.TipoDefeitoVistoriaEntity;
import br.gov.df.pm.sgv.service.SubitemVistoriaService;
import io.swagger.v3.oas.annotations.Parameter;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.PagedModel;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/vistoria/subitemvistoria")
public class SubitemVistoriaController {
    private final SubitemVistoriaService service;
    private final SubitemVistoriaAssembler subitemVistoriaAssembler;
    private final PagedResourcesAssembler<SubitemVistoriaEntity> pagedResourcesAssembler;

    public SubitemVistoriaController(SubitemVistoriaService service,
                                     SubitemVistoriaAssembler subitemVistoriaAssembler,
                                     PagedResourcesAssembler<SubitemVistoriaEntity> pagedResourcesAssembler) {
        this.service = service;
        this.subitemVistoriaAssembler = subitemVistoriaAssembler;
        this.pagedResourcesAssembler = pagedResourcesAssembler;
    }

    @GetMapping("/buscar/{id}")
    public ResponseEntity<?> buscarId(@PathVariable("id") Long id) {
        return service.buscarId(id);
    }

    @GetMapping("/buscar")
    public PagedModel<EntityModel<SubitemVistoriaDTO>> buscar(
            @Parameter(hidden = true) @PageableDefault(direction = Sort.Direction.ASC, size = 10) String filter, Pageable pageable) {
        var result = pagedResourcesAssembler.toModel(service.buscar(filter, pageable));
        return PagedModel.of(result.getContent().stream().map(e ->
                subitemVistoriaAssembler.toModel(Objects.requireNonNull(e.getContent()))).collect(Collectors.toList()), result.getMetadata());
    }

    @PostMapping("/salvar")
    public ResponseEntity<?> salvar(@RequestBody SubitemVistoriaDTO subitemVistoria) {
        return service.salvar(subitemVistoria);
    }

    @PutMapping("/editar/{id}")
    public ResponseEntity<?> editar(@PathVariable("id") Long id, @RequestBody EdicaoSubitemVistoriaDTO edicao) {
        return service.editar(id, edicao);
    }

    @DeleteMapping("/excluir/{id}")
    public ResponseEntity<?> excluir(@PathVariable("id") Long id) {
        return service.excluir(id);
    }

    @DeleteMapping("/desativar/{id}")
    public ResponseEntity<?> desativar(@PathVariable("id") Long id) {
        return service.desativar(id);
    }

    @PostMapping("/ativar/{id}")
    public ResponseEntity<?> ativar(@PathVariable("id") Long id) {
        return service.ativar(id);
    }

    @GetMapping("/findAllTipoDefeitoVistoriaById/{nome}")
    public ResponseEntity<List<TipoDefeitoVistoriaEntity>> findAllTipoDefeitoVistoriaById(@PathVariable("nome") String nome) {
        return service.findAllTipoDefeitoVistoriaById(nome);
    }

    @GetMapping("/findAllTipoDefeitoVistoria")
    public ResponseEntity<List<TipoDefeitoVistoriaEntity>> findAllTipoDefeitoVistoria() {
        return service.findAllTipoDefeitoVistoria();
    }

    @GetMapping("/findAllDefeitosVistoria")
    public ResponseEntity<List<DefeitosVistoriaEntity>> findAllDefeitosVistoria() {
        return service.findAllDefeitosVistoria();
    }

    @DeleteMapping("/desvincularTodos/{idSubitem}")
    public ResponseEntity<?> desvincularTodosTipoDefeito(@PathVariable("idSubitem") Long idSubitem) {
        return service.desvincularTodosTipoDefeito(idSubitem);
    }

    @DeleteMapping("/desvincular/{idTipoDefeito}/{idSubitem}")
    public ResponseEntity<?> desvincularTipoDefeito(@PathVariable("idTipoDefeito") Long idTipoDefeito, @PathVariable("idSubitem") Long idSubitem) {
        return service.desvincularTipoDefeito(idTipoDefeito, idSubitem);
    }
}
