package br.gov.df.pm.sgv.domain;

import br.gov.df.pm.sgv.domain.enums.VistoriaViaturaStatusEnum;
import br.gov.df.pm.sgv.domain.sgpol.Policial;
import br.gov.df.pm.sgv.domain.sgpol.UnidadePolicialMilitar;
import com.fasterxml.jackson.annotation.JsonBackReference;
import lombok.*;
import net.minidev.json.annotate.JsonIgnore;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.Date;

@Entity
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(of = "id")
@Table(name = "VISTORIA_VIATURA_HISTORICO", schema = "sgv")
public class VistoriaViaturaHistoricoEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "vvh_Codigo", unique = true, nullable = false)
    private Long id;

    @OneToOne
    @JoinColumn(name = "upm_Codigo")
    private UnidadePolicialMilitar unidadePolicialMilitar;

    @OneToOne
    @JoinColumn(name = "pol_Codigo")
    private Policial policial;

    @DateTimeFormat(pattern="dd/MM/yyyy")
    @Column(name = "vvh_data")
    private Date data;

    @Column(name = "vvh_status")
    private VistoriaViaturaStatusEnum status;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "vv_Codigo")
    @JsonBackReference
    private VistoriaViaturaEntity vistoriaViatura;
}
