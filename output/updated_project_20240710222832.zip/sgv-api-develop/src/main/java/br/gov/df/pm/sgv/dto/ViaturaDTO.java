package br.gov.df.pm.sgv.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;

@Data
@Builder
@AllArgsConstructor
public class ViaturaDTO {
    private Long id;
    private String prefixo;
    private String nrSei;
    private String placa;
    private String status;
    private String tombamento;
    private String renavam;
    private LocalDateTime dataInclusao;
    private LocalDateTime dataAtualizacao;
    private Double ultimoOdometro;
    private List<VistoriaViaturaDTO> vistoriaViatura;
    private Boolean ativo;
}
