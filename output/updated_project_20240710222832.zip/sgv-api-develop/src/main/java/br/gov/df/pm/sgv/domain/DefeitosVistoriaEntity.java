package br.gov.df.pm.sgv.domain;

import lombok.*;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDate;

@Entity
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(of = "id")
@Table(name = "DEFEITOSVISTORIA", schema = "sgv")
public class DefeitosVistoriaEntity implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "dev_Codigo", unique = true, nullable = false)
    private Long id;

    @ManyToOne
    @JoinColumn(name ="dev_CodSubitem")
    private SubitemVistoriaEntity codSubitem;

    @ManyToOne
    @JoinColumn(name = "dev_CodTipoDefeito")
    private TipoDefeitoVistoriaEntity codTipoDefeito;

    @Column(name = "dev_ativo")
    private Boolean ativo;

    @DateTimeFormat(pattern="dd/MM/yyyy")
    @Column(name = "dev_DtInclusao")
    private LocalDate dataInclusao;
}
