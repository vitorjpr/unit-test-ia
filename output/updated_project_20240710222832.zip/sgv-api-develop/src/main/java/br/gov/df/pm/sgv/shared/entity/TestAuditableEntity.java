```java
package br.gov.df.pm.sgv.shared.entity;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class AuditableEntityTest {

    @Test
    public void testGetSetCriadoPor() {
        // Create instance of AuditableEntity
        AuditableEntity<Long, String> auditableEntity = new AuditableEntity<>();

        // Set and Get criadoPor
        auditableEntity.setCriadoPor("Alice");
        assertEquals("Alice", auditableEntity.getCriadoPor());
    }

    @Test
    public void testGetSetDataCriacao() {
        // Create instance of AuditableEntity
        AuditableEntity<Long, String> auditableEntity = new AuditableEntity<>();

        // Set and Get dataCriacao
        auditableEntity.setDataCriacao(LocalDateTime.now());
        assertNotNull(auditableEntity.getDataCriacao());
    }

    @Test
    public void testGetSetModificadoPor() {
        // Create instance of AuditableEntity
        AuditableEntity<Long, String> auditableEntity = new AuditableEntity<>();

        // Set and Get modificadoPor
        auditableEntity.setModificadoPor("Bob");
        assertEquals("Bob", auditableEntity.getModificadoPor());
    }

    @Test
    public void testGetSetUltimaAtualizacao() {
        // Create instance of AuditableEntity
        AuditableEntity<Long, String> auditableEntity = new AuditableEntity<>();

        // Set and Get ultimaAtualizacao
        auditableEntity.setUltimaAtualizacao(LocalDateTime.now());
        assertNotNull(auditableEntity.getUltimaAtualizacao());
    }
}
```