Here are the unit tests for the provided Java code:

```java
package br.gov.df.pm.sgv.dto;

import br.gov.df.pm.sgv.domain.TipoVistoriaEntity;
import org.junit.jupiter.api.Test;
import java.time.LocalDate;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class DiferencaOdometroDTOTest {

    @Test
    public void testGetSetReferenciaInicial() {
        TipoVistoriaEntity referenciaInicial = new TipoVistoriaEntity();
        DiferencaOdometroDTO dto = new DiferencaOdometroDTO();
        dto.setReferenciaInicial(referenciaInicial);
        assertEquals(referenciaInicial, dto.getReferenciaInicial());
    }

    @Test
    public void testGetSetReferenciaFinal() {
        TipoVistoriaEntity referenciaFinal = new TipoVistoriaEntity();
        DiferencaOdometroDTO dto = new DiferencaOdometroDTO();
        dto.setReferenciaFinal(referenciaFinal);
        assertEquals(referenciaFinal, dto.getReferenciaFinal());
    }

    @Test
    public void testGetSetDiferencaOdometro() {
        Double diferencaOdometro = 100.0;
        DiferencaOdometroDTO dto = new DiferencaOdometroDTO();
        dto.setDiferencaOdometro(diferencaOdometro);
        assertEquals(diferencaOdometro, dto.getDiferencaOdometro());
    }

    @Test
    public void testGetSetDataInclusao() {
        LocalDate dataInclusao = LocalDate.now();
        DiferencaOdometroDTO dto = new DiferencaOdometroDTO();
        dto.setDataInclusao(dataInclusao);
        assertEquals(dataInclusao, dto.getDataInclusao());
    }

    @Test
    public void testGetSetDataModificacao() {
        LocalDate dataModificacao = LocalDate.now();
        DiferencaOdometroDTO dto = new DiferencaOdometroDTO();
        dto.setDataModificacao(dataModificacao);
        assertEquals(dataModificacao, dto.getDataModificacao());
    }

    @Test
    public void testGetSetDiferencaPermitido() {
        Boolean diferencaPermitido = true;
        DiferencaOdometroDTO dto = new DiferencaOdometroDTO();
        dto.setDiferencaPermitido(diferencaPermitido);
        assertEquals(diferencaPermitido, dto.getDiferencaPermitido());
    }

}
```

These unit tests cover all the getters and setters of the `DiferencaOdometroDTO` class, ensuring that they work as expected. Make sure to include the necessary imports for the classes used in the tests.