Here are the unit tests for the provided Java code:

```java
package br.gov.df.pm.sgv.service;

import br.gov.df.pm.sgv.domain.ViaturaEntity;
import br.gov.df.pm.sgv.domain.sgpol.UnidadePolicialMilitar;
import br.gov.df.pm.sgv.dto.TipoEmpregoViaturaDto;
import br.gov.df.pm.sgv.dto.VistoriaViaturaDTO;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.mock;

@ExtendWith(MockitoExtension.class)
class ViaturaServiceTest {

    @Mock
    private ViaturaService viaturaService;

    @Test
    void buscarTest() {
        Page<ViaturaEntity> viaturas = viaturaService.buscar(1, "Prefixo", "Placa", Pageable.unpaged());
        assertNotNull(viaturas);
    }

    @Test
    void buscarViaturaTest() {
        Page<ViaturaEntity> viaturas = viaturaService.buscarViatura(1, "Prefixo", "Placa", 1, Pageable.unpaged());
        assertNotNull(viaturas);
    }

    @Test
    void findPaginadoTest() {
        Page<ViaturaEntity> viaturas = viaturaService.findPaginado(Pageable.unpaged());
        assertNotNull(viaturas);
    }

    @Test
    void getUltimoOdometroByViaturaTest() {
        Double ultimoOdometro = viaturaService.getUltimoOdometroByViatura(1L);
        assertNotNull(ultimoOdometro);
    }

    @Test
    void getVistoriaViaturaByViaturaTest() {
        List<VistoriaViaturaDTO> vistorias = viaturaService.getVistoriaViaturaByViatura(1L);
        assertNotNull(vistorias);
    }

    @Test
    void listarUpmTest() {
        ResponseEntity<List<UnidadePolicialMilitar>> responseEntity = viaturaService.listarUpm();
        assertNotNull(responseEntity);
    }

    @Test
    void listarTest() {
        ResponseEntity<List<TipoEmpregoViaturaDto>> responseEntity = viaturaService.listar();
        assertNotNull(responseEntity);
    }

    @Test
    void buscarViaturasAtivasTest() {
        Page<ViaturaEntity> viaturas = viaturaService.buscarViaturasAtivas(Pageable.unpaged());
        assertNotNull(viaturas);
    }
}
```

These unit tests cover each method in the `ViaturaService` interface, ensuring that they are called correctly and return non-null values. The tests use Mockito for mocking the service and Spring's `Pageable` for pagination.