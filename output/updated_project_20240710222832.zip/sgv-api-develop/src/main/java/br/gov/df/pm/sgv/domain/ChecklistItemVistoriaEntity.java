package br.gov.df.pm.sgv.domain;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import lombok.*;
import net.minidev.json.annotate.JsonIgnore;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

@Entity
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(of = "id")
@Table(name = "CHECKLIST_VISTORIAITEM", schema = "sgv")
public class ChecklistItemVistoriaEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "cvi_Id", unique = true, nullable = false)
    private Long id;

    @Column(name = "cvi_DataCriacao")
    private Date datachCriacao;

    @JsonBackReference("checklist-itens")
    @ManyToOne
    @JoinColumn(name = "chv_Id", nullable = false)
    private ChecklistVistoriaEntity checklistVistoria;

    @ManyToOne
    @JoinColumn(name = "suv_Codigo", nullable = false)
    private SubitemVistoriaEntity subitemVistoria;

    @JsonManagedReference("item-subitems")
    @OneToMany(mappedBy = "checklistItemVistoria", cascade = CascadeType.ALL)
    private List<ChecklistVistoriaSubItemEntity> checklistVistoriaSubItem;

}
