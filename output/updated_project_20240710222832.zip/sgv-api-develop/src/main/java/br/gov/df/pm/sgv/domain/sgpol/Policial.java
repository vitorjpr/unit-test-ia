package br.gov.df.pm.sgv.domain.sgpol;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.time.LocalDate;


/**
* @author Maj Clauder - clauder.lima@pm.df.gov.br
* PMDF 31 de jan de 2017
*
*@author CB Wallace - walalce.silva@pm.df.gov.br
* PMDF 21 de fev 2017
* Retirei o idLotacao devido atualização feita no banco de dados
*
*/
/**
* @author Wallace
*
*/
@Entity
@Table(name = "POLICIAL", schema = "dbo", catalog = "sgpol")
@Getter @Setter
public class Policial implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "pol_Codigo", unique = true, nullable = false)
	private Integer id;

	@Size(max = 50)
	@NotBlank(message="Nome de Guerra é Obrigatório")
	@Column(name = "pol_NomeGuerra")
	private String nomeGuerra;

	@Size(max = 12)
	@Column(name = "pol_MatriculaSirgh")
	private String sirgh;

	@Column(name = "pol_Login")
	private String login;

	@Column(name = "pol_Almanaque")
	private Integer almanaque;

	@Size(min = 8, max = 8, message="A matrícula deverá ter 8 dígitos")
	@NotBlank(message="Matrícula é Obrigatória")
	@Column(name = "pol_Matricula")
	private String matricula;

	@Size(max = 7)
	@Column(name = "pol_MatriculaSiape")
	private String siape;

	@Column(name = "pol_DtAdmissao")
	private LocalDate dataAdmissao;

	@Size(min = 9, max = 9, message="A Identificação Única deverá ter 9 dígitos")
	@Column(name = "pol_IdentificacaoUnica")
	private String identificacaoUnica;

	@JoinColumn(name = "pes_Codigo", referencedColumnName = "pes_Codigo")
	@OneToOne
	private Pessoa idPessoa;

// 	@OneToMany( mappedBy = "idPolicial", fetch = FetchType.LAZY)
// 	@JsonIgnore
// 	@OrderBy("dataFinalFuncao ASC")
// 	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
// 	private List<FuncaoUpmLotacaoPolicial> listFuncaoUpmLotacaoPolicial;


// 	@OneToMany( mappedBy = "idPolicial", fetch = FetchType.LAZY)
// 	@JsonIgnore
// 	@OrderBy("dataFinalFuncao ASC")
// 	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
// 	private Set<FuncaoUpmLotacaoPolicial> listaFuncaoUpmLotacaoPolicial;

// 	@OneToMany( mappedBy = "idPolicial", fetch = FetchType.LAZY)
// 	@JsonIgnore
// 	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
// 	private List<CargoPublico> listCargoPublico;

// 	@OneToMany( mappedBy = "idPolicial", fetch = FetchType.LAZY)
// 	@JsonIgnore
// 	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
// 	private List<AtividadeExtra> listAtividadeExtra;

// 	@OneToMany( mappedBy = "policial", fetch = FetchType.LAZY)
// 	@JsonIgnore
// 	private List<UpmLotacaoPolicial> upmLotacaoPolicial;

// 	@OneToMany( mappedBy = "idPolicial", fetch = FetchType.LAZY)
// 	@JsonIgnore
// 	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
// 	private List<FuncaoPolicial> funcaoPolicial;


// 	@OneToMany( mappedBy = "idPolicial", fetch = FetchType.EAGER)
// 	@JsonIgnore
// 	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
// 	private Set<QuadroPolicial> listaQuadroPolicial;

// //	@OneToMany( mappedBy = "idPolicial", fetch = FetchType.LAZY)
// //	@JsonIgnore
// //	private Set<QuadroPolicial> quadrosPolicial;

// 	@OneToMany( mappedBy = "policial", fetch = FetchType.LAZY)
// 	@JsonIgnore
// 	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
// 	private List<PolicialTafAgenda> Tafs;

// 	@OneToMany( mappedBy = "idPolicial", fetch = FetchType.LAZY)
// 	@JsonIgnore
// 	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
// 	private Set<Dependente> listDependentes;


// 	@OneToMany( mappedBy = "idPolicial", fetch = FetchType.LAZY)
// 	@JsonIgnore
// 	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
// 	private List<Dependente> dependentes;

// 	@OneToMany( mappedBy = "idPolicial", fetch = FetchType.LAZY)
// 	@JsonIgnore
// 	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
// 	private Set<PolicialComportamento> listPolicialComportamento;

// 	//	@OneToMany(cascade = CascadeType.ALL, mappedBy = "idPolicial", fetch = FetchType.LAZY)
// 	//	private Set<LotacaoPolicial> listLotacaoPolicial;

// 	@OneToMany(mappedBy = "idPolicial", fetch = FetchType.LAZY)
// 	@JsonIgnore
// 	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
// 	private Set<Pensionista> listPensionista;


// 	@OneToMany( mappedBy = "idPolicial", fetch = FetchType.LAZY)
// 	@JsonIgnore
// 	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
// 	private Set<UnidadePolicialPolicialADisposicao> listUnidadePolicialPolicialADisposicao;

// 	@OneToMany(mappedBy = "idPolicial", fetch = FetchType.LAZY)
// 	@JsonIgnore
// 	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
// 	private List<MedidasCorporais> listMedidaCorporal;

// 	@OneToMany(mappedBy = "idPolicial", fetch = FetchType.LAZY)
// 	@JsonIgnore
// 	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
// 	private List<MedidasCorporaisTaf> listMedidaCorporalTaf;

// //	@JoinColumn(name = "can_Codigo", referencedColumnName = "can_Codigo")
// //	@ManyToOne(fetch = FetchType.LAZY)
// //	@JsonIgnore
// //	private Candidato idCandidato;

// 	@JoinColumn(name = "sif_Codigo", referencedColumnName = "sif_Codigo")
// 	@ManyToOne(fetch = FetchType.LAZY)
// 	@JsonIgnore
// 	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
// 	private SituacaoFuncional idSituacaoFuncional;

	@JoinColumn(name = "upm_CodigoPolicialCedido", referencedColumnName = "upm_Codigo")
	@ManyToOne(fetch = FetchType.LAZY)
	@JsonIgnore
	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
	private UnidadePolicialMilitar upmCodigoPolicialCedido;


	@JoinColumn(name = "upm_CodigoAtual", referencedColumnName = "upm_Codigo")
	@ManyToOne(fetch = FetchType.LAZY)
	@JsonIgnore
	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
	private UnidadePolicialMilitar upm;

// 	@OneToMany( mappedBy = "idPolicial", fetch = FetchType.LAZY)
// 	@JsonIgnore
// 	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
// 	private Set<UpmPolicial> listaUpmPolicial;


// 	@OneToMany( mappedBy = "idPolicial", fetch = FetchType.LAZY)
// 	@JsonIgnore
// 	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
// 	private List<PolicialLocalAgregacao> listPolicialLocalAgregacao;

// 	@OneToMany( mappedBy = "idPolicial", fetch = FetchType.LAZY)
// 	@JsonIgnore
// 	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
// 	private List<HistoricoMotivoDesligamentoPolicial> listHistoricoMotivoDesligamentoPolicial;

// 	@OneToMany( mappedBy = "idPolicial", fetch = FetchType.LAZY)
// 	@JsonIgnore
// 	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
// 	private List<HistoricoSituacaoPolicial> listHistoricoSituacaoPolicial;


// 	@OneToMany( mappedBy = "idPolicial", fetch = FetchType.LAZY)
// 	@JsonIgnore
// 	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
// 	private List<HistoricoSituacaoFuncional> listHistoricoSituacaoFuncional;

// 	@OneToMany( mappedBy = "idPolicial", fetch = FetchType.LAZY)
// 	@JsonIgnore
// 	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
// 	private List<RestricaoPorte> listRestricaoPorte;

// 	@OneToMany( mappedBy = "idPolicial", fetch = FetchType.LAZY)
// 	@JsonIgnore
// 	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
// 	private Set<TempoAverbado> listTempoAverbado;

// 	@OneToMany(mappedBy = "policial", fetch = FetchType.LAZY)
// 	@JsonIgnore
// 	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
// 	private List<Talao> idTalao;

// 	@OneToMany( mappedBy = "idPolicial", fetch = FetchType.LAZY)
// 	@JsonIgnore
// 	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
// 	private List<PolicialAuxilioMoradia> listAuxilioMoradia;

// 	@OneToMany( mappedBy = "idPolicial", fetch = FetchType.LAZY)
// 	@JsonIgnore
// 	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
// 	private List<PolicialFundoSaudeAdicional> listFundoSaudeAdicional;

// 	@OneToMany( mappedBy = "idPolicial", fetch = FetchType.LAZY)
// 	@JsonIgnore
// 	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
// 	private List<PolicialCertificacaoProfissional> listPolicialCertificacaoProfissional;



//    @OneToMany( mappedBy = "policial", fetch = FetchType.LAZY)
//    @JsonIgnore
//    @OrderBy("dataCadastro DESC")
// 	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
//    private List<HistoricoSuspensaoAssistenciaMedicaPolicial> historicoSuspensaoAssistenciaMedicaPolicial;



   @Column(name = "pol_AssistenciaMedica")
   private Boolean assistenciaMedica;

   @Column(name = "pol_DtPrevisaoFimAM")
   private LocalDate dataPrevisaoFimAssistenciaMedica;

   @Column(name = "pol_DtSuspensaoAM")
   private LocalDate dataSuspensaoAssistenciaMedica;


	@Transient
	private String cn;

	@Transient
	private boolean porteSuspenso;

	@Transient
	private boolean ctgrafiSuspenso;

	@Transient
	private String graduacaoAtual;

	// @Transient
	// private QuadroPolicial quadroPolicial;


	// @Transient
	// private UpmPolicial upmPolicial;

	@Transient
	private boolean restrito;




// 	@JsonIgnore
// 	@OneToMany( mappedBy = "idPolicial", fetch = FetchType.LAZY)
// //	@JoinColumn(name="pes_Codigo")
//    private List<MedidasCorporais> medidasEPI;



// 	public boolean isMedidasEPI() {
// 		boolean retorno = true;

// 		for (MedidasCorporais obj : this.getMedidasEPI()) {

// 			if(obj.getRecadastramento() != null) {
// 				if(!obj.getRecadastramento()) {
// 					return false;
// 				}
// 			}

// 		}

// 		return retorno;
// 	}

// 	public List<MedidasCorporais> getMedidasEPI() {
// 		return medidasEPI;
// 	}

// 	public void setMedidasEPI(List<MedidasCorporais> medidasEPI) {
// 		this.medidasEPI = medidasEPI;
// 	}

// 	public List<MedidasCorporaisTaf> getListMedidaCorporalTaf() {
// 		return listMedidaCorporalTaf;
// 	}

// 	public void setListMedidaCorporalTaf(List<MedidasCorporaisTaf> listMedidaCorporalTaf) {
// 		this.listMedidaCorporalTaf = listMedidaCorporalTaf;
// 	}

// 	public List<HistoricoSuspensaoAssistenciaMedicaPolicial> getHistoricoSuspensaoAssistenciaMedicaPolicial() {
// 		return historicoSuspensaoAssistenciaMedicaPolicial;
// 	}

// 	public void setHistoricoSuspensaoAssistenciaMedicaPolicial(
// 			List<HistoricoSuspensaoAssistenciaMedicaPolicial> historicoSuspensaoAssistenciaMedicaPolicial) {
// 		this.historicoSuspensaoAssistenciaMedicaPolicial = historicoSuspensaoAssistenciaMedicaPolicial;
// 	}

// 	public Boolean isAssistenciaMedica() {
// 		return assistenciaMedica;
// 	}

// 	public void setAssistenciaMedica(Boolean assistenciaMedica) {
// 		this.assistenciaMedica = assistenciaMedica;
// 	}

// 	public LocalDate getDataPrevisaoFimAssistenciaMedica() {
// 		return dataPrevisaoFimAssistenciaMedica;
// 	}

// 	public void setDataPrevisaoFimAssistenciaMedica(LocalDate dataPrevisaoFimAssistenciaMedica) {
// 		this.dataPrevisaoFimAssistenciaMedica = dataPrevisaoFimAssistenciaMedica;
// 	}

// 	public LocalDate getDataSuspensaoAssistenciaMedica() {
// 		return dataSuspensaoAssistenciaMedica;
// 	}

// 	public void setDataSuspensaoAssistenciaMedica(LocalDate dataSuspensaoAssistenciaMedica) {
// 		this.dataSuspensaoAssistenciaMedica = dataSuspensaoAssistenciaMedica;
// 	}

// 	public boolean isNovo() {
// 		return id == null;
// 	}

// 	public Integer getId() {
// 		return id;
// 	}

// 	public void setId(Integer id) {
// 		this.id = id;
// 	}


// 	public List<PolicialTafAgenda> getTafs() {
// 		return Tafs;
// 	}

// 	public void setTafs(List<PolicialTafAgenda> tafs) {
// 		Tafs = tafs;
// 	}

// 	public List<Dependente> getDependentes() {
// 		return dependentes;
// 	}

// 	public void setDependentes(List<Dependente> dependentes) {
// 		this.dependentes = dependentes;
// 	}

// 	public String getNomeGuerra() {
// 		return nomeGuerra==null?"--":nomeGuerra;
// 	}

// 	public String getGraduacaoAtual() {
// 		return graduacaoAtual;
// 	}

// 	public void setGraduacaoAtual(String graduacaoAtual) {
// 		this.graduacaoAtual = graduacaoAtual;
// 	}

// 	public void setNomeGuerra(String nomeGuerra) {
// 		this.nomeGuerra = nomeGuerra;
// 	}

// 	public String getMatricula() {
// 		return (this.matricula!=null?this.matricula.toUpperCase():null);
// 	}

// 	public String getMatriculaFormatada() {
// 		return   (this.matricula!=null?this.matricula.replaceAll("(\\d{3})(\\d{3})(\\d{3})", "$1.$2.$3/").trim():null);

// 	}

// 	public void setMatricula(String matricula) {
// 		this.matricula = matricula;
// 	}

// 	public String getSirgh() {
// 		return sirgh;
// 	}

// 	public void setSirgh(String sirgh) {
// 		this.sirgh = sirgh;
// 	}

// 	public String getSiape() {
// 		return siape;
// 	}

// 	public void setSiape(String siape) {
// 		this.siape = siape;
// 	}

// 	public LocalDate getDataAdmissao() {
// 		return dataAdmissao;
// 	}

// 	public void setDataAdmissao(LocalDate dataAdmissao) {
// 		this.dataAdmissao = dataAdmissao;
// 	}

// 	public List<Talao> getIdTalao() {
// 		return idTalao;
// 	}

// 	public void setIdTalao(List<Talao> idTalao) {
// 		this.idTalao = idTalao;
// 	}

// 	public String getIdentificacaoUnica() {
// 		return identificacaoUnica;
// 	}

// 	public void setIdentificacaoUnica(String identificacaoUnica) {
// 		this.identificacaoUnica = identificacaoUnica;
// 	}

// 	public Set<Dependente> getListDependentes() {
// 		return listDependentes;
// 	}

// 	public void setListDependentes(Set<Dependente> listDependentes) {
// 		this.listDependentes = listDependentes;
// 	}

// 	public Set<PolicialComportamento> getListPolicialComportamento() {
// 		return listPolicialComportamento;
// 	}

// 	public void setListPolicialComportamento(Set<PolicialComportamento> listPolicialComportamento) {
// 		this.listPolicialComportamento = listPolicialComportamento;
// 	}

// 	public Set<Pensionista> getListPensionista() {
// 		return listPensionista;
// 	}

// 	public List<CargoPublico> getListCargoPublico() {
// 		return listCargoPublico;
// 	}

// 	public void setListCargoPublico(List<CargoPublico> listCargoPublico) {
// 		this.listCargoPublico = listCargoPublico;
// 	}

// 	public List<AtividadeExtra> getListAtividadeExtra() {
// 		return listAtividadeExtra;
// 	}

// 	public void setListAtividadeExtra(List<AtividadeExtra> listAtividadeExtra) {
// 		this.listAtividadeExtra = listAtividadeExtra;
// 	}

// 	public void setListPensionista(Set<Pensionista> listPensionista) {
// 		this.listPensionista = listPensionista;
// 	}


// 	public Set<UnidadePolicialPolicialADisposicao> getListUnidadePolicialPolicialADisposicao() {
// 		return listUnidadePolicialPolicialADisposicao;
// 	}

// 	public void setListUnidadePolicialPolicialADisposicao(
// 			Set<UnidadePolicialPolicialADisposicao> listUnidadePolicialPolicialADisposicao) {
// 		this.listUnidadePolicialPolicialADisposicao = listUnidadePolicialPolicialADisposicao;
// 	}

// 	public List<MedidasCorporais> getListMedidaCorporal() {
// 		return listMedidaCorporal;
// 	}

// 	public void setListMedidaCorporal(List<MedidasCorporais> listMedidaCorporal) {
// 		this.listMedidaCorporal = listMedidaCorporal;
// 	}

// //	public Candidato getIdCandidato() {
// //		return idCandidato;
// //	}
// //
// //	public void setIdCandidato(Candidato idCandidato) {
// //		this.idCandidato = idCandidato;
// //	}

// 	public Pessoa getIdPessoa() {
// 		return idPessoa;
// 	}

// 	public void setIdPessoa(Pessoa idPessoa) {
// 		this.idPessoa = idPessoa;
// 	}

// 	public SituacaoFuncional getIdSituacaoFuncional() {
// 		return idSituacaoFuncional;
// 	}

// 	public void setIdSituacaoFuncional(SituacaoFuncional idSituacaoFuncional) {
// 		this.idSituacaoFuncional = idSituacaoFuncional;
// 	}

// 	public List<PolicialLocalAgregacao> getListPolicialLocalAgregacao() {
// 		return listPolicialLocalAgregacao;
// 	}

// 	public void setListPolicialLocalAgregacao(List<PolicialLocalAgregacao> listPolicialLocalAgregacao) {
// 		this.listPolicialLocalAgregacao = listPolicialLocalAgregacao;
// 	}

// 	public List<HistoricoMotivoDesligamentoPolicial> getListHistoricoMotivoDesligamentoPolicial() {
// 		return listHistoricoMotivoDesligamentoPolicial;
// 	}

// 	public void setListHistoricoMotivoDesligamentoPolicial(
// 			List<HistoricoMotivoDesligamentoPolicial> listHistoricoMotivoDesligamentoPolicial) {
// 		this.listHistoricoMotivoDesligamentoPolicial = listHistoricoMotivoDesligamentoPolicial;
// 	}

// 	public List<FuncaoUpmLotacaoPolicial> getListFuncaoUpmLotacaoPolicial() {
// 		return listFuncaoUpmLotacaoPolicial;
// 	}

// 	public void setListFuncaoUpmLotacaoPolicial(List<FuncaoUpmLotacaoPolicial> listFuncaoUpmLotacaoPolicial) {
// 		this.listFuncaoUpmLotacaoPolicial = listFuncaoUpmLotacaoPolicial;
// 	}



// 	public Set<QuadroPolicial> getListaQuadroPolicial() {
// 		return listaQuadroPolicial;
// 	}

// 	public void setListaQuadroPolicial(Set<QuadroPolicial> listaQuadroPolicial) {
// 		this.listaQuadroPolicial = listaQuadroPolicial;
// 	}

// 	public Set<TempoAverbado> getListTempoAverbado() {
// 		return listTempoAverbado;
// 	}

// 	public void setListTempoAverbado(Set<TempoAverbado> listTempoAverbado) {
// 		this.listTempoAverbado = listTempoAverbado;
// 	}

// 	public List<HistoricoSituacaoPolicial> getListHistoricoSituacaoPolicial() {
// 		return listHistoricoSituacaoPolicial;
// 	}

// 	public void setListHistoricoSituacaoPolicial(List<HistoricoSituacaoPolicial> listHistoricoSituacaoPolicial) {
// 		this.listHistoricoSituacaoPolicial = listHistoricoSituacaoPolicial;
// 	}

// 	public List<RestricaoPorte> getListRestricaoPorte() {
// 		return listRestricaoPorte;
// 	}

// 	public void setListRestricaoPorte(List<RestricaoPorte> restricaoPorte) {
// 		this.listRestricaoPorte = restricaoPorte;
// 	}

// 	public List<UpmLotacaoPolicial> getUpmLotacaoPolicial() {
// 		return upmLotacaoPolicial;
// 	}

// 	public void setUpmLotacaoPolicial(List<UpmLotacaoPolicial> upmLotacaoPolicial) {
// 		this.upmLotacaoPolicial = upmLotacaoPolicial;
// 	}

// 	public List<FuncaoPolicial> getFuncaoPolicial() {
// 		return funcaoPolicial;
// 	}

// 	public void setFuncaoPolicial(List<FuncaoPolicial> funcaoPolicial) {
// 		this.funcaoPolicial = funcaoPolicial;
// 	}

// 	public List<PolicialAuxilioMoradia> getListAuxilioMoradia() {
// 		return listAuxilioMoradia;
// 	}

// 	public void setListAuxilioMoradia(List<PolicialAuxilioMoradia> listAuxilioMoradia) {
// 		this.listAuxilioMoradia = listAuxilioMoradia;
// 	}

// 	public List<PolicialFundoSaudeAdicional> getListFundoSaudeAdicional() {
// 		return listFundoSaudeAdicional;
// 	}

// 	public void setListFundoSaudeAdicional(List<PolicialFundoSaudeAdicional> listFundoSaudeAdicional) {
// 		this.listFundoSaudeAdicional = listFundoSaudeAdicional;
// 	}

// 	public List<PolicialCertificacaoProfissional> getListPolicialCertificacaoProfissional() {
// 		return listPolicialCertificacaoProfissional;
// 	}

// 	public void setListPolicialCertificacaoProfissional(
// 			List<PolicialCertificacaoProfissional> listPolicialCertificacaoProfissional) {
// 		this.listPolicialCertificacaoProfissional = listPolicialCertificacaoProfissional;
// 	}

// 	public void addDependente(Dependente dep) {
// 		this.dependentes.add(dep);
// 		dep.setIdPolicial(this); // mantém a consistência
// 	}




// 	public List<HistoricoSituacaoFuncional> getListHistoricoSituacaoFuncional() {
// 		return listHistoricoSituacaoFuncional;
// 	}

// 	public void setListHistoricoSituacaoFuncional(List<HistoricoSituacaoFuncional> listHistoricoSituacaoFuncional) {
// 		this.listHistoricoSituacaoFuncional = listHistoricoSituacaoFuncional;
// 	}



// 	public String getLogin() {
// 		return login;
// 	}

// 	public void setLogin(String login) {
// 		this.login = login;
// 	}



// 	public Integer getAlmanaque() {
// 		return almanaque;
// 	}

// 	public void setAlmanaque(Integer almanaque) {
// 		this.almanaque = almanaque;
// 	}



// 	/**
// 	 * VERIFICA SE O ACESSO AOS DADOS DO POLICIAL SÃO OU NÃO SÃO RESTRITOS
// 	 *
// 	 * VERIFICA SE O USUÁRIO É QUE ESTÁ QUERENDO VISUALIZAR A PROPRIA FICHA - NESSE CASO É PERMITIDO
// 	 *
// 	 * VERIFICA SE O USUÁRIO TEM ACESSO AO RECURSO VISUALIZAR_DADOS_RESTRITOS - NESSE CASO É PERMITIDO
// 	 *
// 	 * VERIFICA SE A PESSOA EXERCE ALGUMA FUNÇÃO QUE RESTRINGE ACESSO AOS DADOS - NESSE CASO NÃO É PERMITIDO
// 	 *
// 	 * @author wallace.silva
// 	 *
// 	 * @return
// 	 */
// 	public boolean isRestrito() {

// 		if(this.getIdPessoa().isAcessoRestrito()) {
// 			return true;
// 		}

// 		if(  getClassificacaoAtual()!=null && getClassificacaoAtual().getFuncao()!=null ) {
// 			this.restrito = getClassificacaoAtual().getFuncao().isRestrita();
// 		}


// 		return restrito;
// 	}

// 	public void setRestrito(boolean restrito) {
// 		this.restrito = restrito;
// 	}

// 	/**
// 	 * @author Paulo Goncalves
// 	 * @return RestricaoPorte
// 	 * @since 17 Ago 2017
// 	 *
// 	 * Retorna a Restricao Porte do policial
// 	 *
// 	 */
// 	@JsonIgnore
// 	public RestricaoPorte getRestricaoPorte(){

// 		RestricaoPorte restricao = new RestricaoPorte();


// 		if(this.listRestricaoPorte!=null && !this.listRestricaoPorte.isEmpty()){
// 			for (RestricaoPorte restricao1 : this.listRestricaoPorte) {
// 				if(restricao.getAtivo()==1 && (restricao1.getDtRestricaoFinal()==null || restricao1.getDtRestricaoFinal().isAfter(LocalDate.now()))){
// 					restricao = restricao1;
// 				}
// 			}
// 		}
// 		return restricao;


// //		for (RestricaoPorte restricao : this.listRestricaoPorte) {
// //			if(restricao.getDtRestricaoFinal()==null || restricao.getDtRestricaoFinal().after(hoje.getTime())){
// //				return restricao;
// //			}
// //		}
// //		return null;
// 	}


// 	public boolean isPorteSuspenso() {

// 		porteSuspenso = false;

// 		for (RestricaoPorte restricao : this.listRestricaoPorte) {
// 			if(restricao.getAtivo()==1 && (restricao.getTipoSuspensao().getId()==1 || restricao.getTipoSuspensao().getId()==3)) {
// 				if((restricao.getDtRestricaoInicial().isBefore(LocalDate.now()) || restricao.getDtRestricaoInicial().isEqual(LocalDate.now()))
// 					&& (restricao.getDtRestricaoFinal()==null || restricao.getDtRestricaoFinal().isAfter(LocalDate.now()))
// 					){

// 					porteSuspenso =  true;
// 				}
// 			}

// 		}
// 		return porteSuspenso;
// 	}


// 	public RestricaoPorte getPorteArmaVeterano() {
// 		RestricaoPorte porteSuspenso = new RestricaoPorte();
// 		for (RestricaoPorte restricao : this.listRestricaoPorte) {


// 			if(restricao.getAtivo()==1 && (restricao.getTipoSuspensao().getId()==4)) {
// 				if( restricao.getDtRestricaoFinal()==null){
// 					porteSuspenso =  restricao;
// 				}
// 			}

// 		}
// 		return porteSuspenso;
// 	}



// 	public TipoSuspensao getTipoSuspensao() {
// 		TipoSuspensao tipoSuspensao = new TipoSuspensao();
// 		porteSuspenso = false;

// 		for (RestricaoPorte restricao : this.listRestricaoPorte) {
// 			if(restricao.getAtivo()==1 && (restricao.getTipoSuspensao().getId()==1 || restricao.getTipoSuspensao().getId()==3)) {
// 				if((restricao.getDtRestricaoInicial().isBefore(LocalDate.now()) || restricao.getDtRestricaoInicial().isEqual(LocalDate.now()))
// 					&& (restricao.getDtRestricaoFinal()==null || restricao.getDtRestricaoFinal().isAfter(LocalDate.now()))
// 					){
// 					tipoSuspensao = restricao.getTipoSuspensao();
// 				}
// 			}

// 		}
// 		return tipoSuspensao;
// 	}

// 	public boolean isCtgrafiSuspenso() {
// 		ctgrafiSuspenso = false;

// 		for (RestricaoPorte restricao : this.listRestricaoPorte) {
// 			if(restricao.getAtivo()==1) {
// 				if((restricao.getDtRestricaoInicial().isBefore(LocalDate.now()) || restricao.getDtRestricaoInicial().isEqual(LocalDate.now()))
// 					&& (restricao.getDtRestricaoFinal()==null || restricao.getDtRestricaoFinal().isAfter(LocalDate.now()))
// 					){

// 					ctgrafiSuspenso =  true;
// 				}
// 			}
// 		}
// 		return ctgrafiSuspenso;
// 	}

// 	public void setPorteSuspenso(boolean porteSuspenso) {
// 		this.porteSuspenso = porteSuspenso;
// 	}

// 	public void setCtgrafiSuspenso(boolean ctgrafiSuspenso) {
// 		this.ctgrafiSuspenso = ctgrafiSuspenso;
// 	}

// 	/**
// 	 * @author Wallace
// 	 * @return UnidadePolicialMilitar
// 	 * @since 24 Fev 2017
// 	 *
// 	 * Retorna a unidade que o policial está lotado atualmente
// 	 *
// 	 */
// 	@JsonIgnore
// 	public UnidadePolicialMilitar getUnidadePolicialMilitarAtualNew() {
// 		if(this.upmCodigoPolicialCedido!=null) {
// 			return this.upmCodigoPolicialCedido;
// 		}

// 		return  this.listaUpmPolicial
// 		.stream()
// 		.max(Comparator.comparing(UpmPolicial::getId))
// 		.orElse(new UpmPolicial()).getIdUpm();
// 	}

// 	@JsonIgnore
// 	public UpmPolicial getUpmPolicialAtualNew() {

// 		return this.listaUpmPolicial
// 			.stream()
// 			.max(Comparator.comparing(UpmPolicial::getId))
// 			.orElse(new UpmPolicial());
// 	}

// 	public boolean isEditarUpmNew(){

// 		if(isNovo() || getUpmPolicialAtualNew()==null || getUpmPolicialAtualNew().getDataEntrada()==null || listaUpmPolicial ==null || listaUpmPolicial.isEmpty()){
// 			return true;
// 		}
// 		else{
// 			long diasLong = java.sql.Date.valueOf(LocalDate.now()).getTime() - java.sql.Date.valueOf(getUpmPolicialAtualNew().getDataEntrada()).getTime() ;
// 			long daysBetween = (diasLong / (1000*60*60*24));
// 			if(daysBetween<=2){
// 				return true;
// 			}
// 			else{
// 				return false;
// 			}
// 		}
// 	}


// 	/**
// 	 * @author Wallace
// 	 * @return Lotacao
// 	 * @since 24 Fev 2017
// 	 *
// 	 * Retorna a unidade que o policial está lotado atualmente
// 	 *
// 	 */
// 	@JsonIgnore
// 	public Lotacao getLotacaoAtual() {
// 		for (FuncaoUpmLotacaoPolicial lotacao : getListFuncaoUpmLotacaoPolicial()) {
// 			if(lotacao.getDataFinalFuncao()==null){
// 				return lotacao.getIdFuncaoUpmLotacao().getIdUpmLotacao().getIdLotacao();
// 			}
// 		}
// 		return null;
// 	}



// 	/**
// 	 * @author Wallace
// 	 * @return Lotacao
// 	 * @since 24 Fev 2017
// 	 *
// 	 * Retorna a unidade que o policial está lotado atualmente
// 	 *
// 	 */
// 	@JsonIgnore
// 	public Lotacao getLotacaoAtualNew() {
// 		for (UpmLotacaoPolicial lotacao : getUpmLotacaoPolicial()) {
// 			if(lotacao.getDataFinal()==null){
// 				return lotacao.getUpmLotacao().getIdLotacao();
// 			}
// 		}
// 		return null;
// 	}


// 	@JsonIgnore
// 	public FuncaoUpmLotacaoPolicial getFuncaoUpmLotacaoPolicialAtual() {

// 		FuncaoUpmLotacaoPolicial funcaoUpmLotacaoPolicial = new FuncaoUpmLotacaoPolicial();

// 		for (FuncaoUpmLotacaoPolicial lotacao : getListFuncaoUpmLotacaoPolicial()) {
// 			if(lotacao.getDataFinalFuncao()==null){
// 				funcaoUpmLotacaoPolicial =  lotacao;
// 			}
// 		}
// 		return funcaoUpmLotacaoPolicial;
// 	}



// 	@JsonIgnore
// 	public Funcao getFuncaoAtual() {
// 		Funcao retorno = new Funcao();
// 		if(listFuncaoUpmLotacaoPolicial!=null && !listFuncaoUpmLotacaoPolicial.isEmpty())
// 		for (FuncaoUpmLotacaoPolicial funcao : this.listFuncaoUpmLotacaoPolicial) {
// 			if(funcao.getDataFinalFuncao()==null){
// 				retorno =  funcao.getIdFuncaoUpmLotacao().getIdFuncao();
// 			}
// 		}
// 		return retorno;
// 	}


// 	@JsonIgnore
// 	public Funcao getFuncaoAtualNew() {
// 		for (FuncaoPolicial funcao : getFuncaoPolicial()) {
// 			if(funcao.getDataFinal()==null){
// 				return funcao.getIdFuncao();
// 			}
// 		}

// 		return null;
// 	}

// 	@Transient
// 	private PostoGraduacao postoGraduacaoAtual;




// 	public void setPostoGraduacaoAtual(PostoGraduacao postoGraduacao) {
// 		this.postoGraduacaoAtual = postoGraduacao;
// 	}



// 	@JsonIgnore
// 	public PostoGraduacao getPostoGraduacaoAtual() {
// 		postoGraduacaoAtual = new PostoGraduacao();
// 		int count = 0;
// 		postoGraduacaoAtual.setNome("Não Existe");
// 		postoGraduacaoAtual.setSigla("--");
// 		for (QuadroPolicial qp :  listaQuadroPolicial) {
// 			if(count==0){
// 				if(qp.getIdQuadroPostoGraduacao()!=null){
// 					postoGraduacaoAtual=qp.getIdQuadroPostoGraduacao().getIdPostoGraduacao();
// 				}
// 			}
// 		}
// 		graduacaoAtual = postoGraduacaoAtual.getNome();
// 		return postoGraduacaoAtual;

// 	}

// 	@JsonIgnore
// 	public QuadroPostoGraduacao getQuadroPostoGraduacaoAtual() {
// 		QuadroPostoGraduacao quadroPostoGraduacao = new QuadroPostoGraduacao();
// 		int count = 0;
// 		for (QuadroPolicial qp :  listaQuadroPolicial) {
// 			if(count==0){
// 				if(qp.getIdQuadroPostoGraduacao()!=null){
// 					quadroPostoGraduacao=qp.getIdQuadroPostoGraduacao();
// 				}
// 			}
// 		}
// 		return quadroPostoGraduacao;

// 	}

// 	@JsonIgnore
// 	public SituacaoPolicial getSituacaoPolicial() {

// 		SituacaoPolicial retorno = new SituacaoPolicial();
// 		retorno.setNome("Sem Registros");


// 		if( this.listHistoricoSituacaoPolicial!=null &&  !this.listHistoricoSituacaoPolicial.isEmpty()) {
// 			for (HistoricoSituacaoPolicial hist : this.listHistoricoSituacaoPolicial) {
// 				if(hist.getDataFim()==null) {
// 					retorno = hist.getIdSituacaoPolicial();
// 				}
// 			}
// 		}

// 		return retorno;

// 	}

// 	public boolean getDsa(){
// 		if(this.getIdSituacaoFuncional().getId()==5){
// 			return true;
// 		}
// 		return false;
// 	}



// 	/**
// 	 * @return
// 	 * QUADRO EM QUE O POLICIAL SE ENCONTRA ATUALMENTE REPETINDO A MESMA FUNCÇÃO DO MÉTODO getQuadroAtual()
// 	 * QUE OPORTUNAMENTE IRÁ SUBISTITUI-LO
// 	 */
// 	@JsonIgnore
// 	public Quadro getQuadro() {
// 		Quadro quadro = new Quadro();
// 		quadro.setNome("--");
// 		quadro.setSigla("--");
// 		if(!listaQuadroPolicial.isEmpty() && listaQuadroPolicial!=null) {
// 			for (QuadroPolicial qp :  listaQuadroPolicial) {
// 				if(qp.getIdQuadroPostoGraduacao()!=null){
// 					quadro = qp.getIdQuadroPostoGraduacao().getIdQuadro();
// 				}
// 			}
// 		}
// 		return quadro;
// 	}


// 	/**
// 	 * @return
// 	 * QUADRO EM QUE O POLICIAL SE ENCONTRA ATUALMENTE REPETINDO A MESMA FUNCÇÃO DO MÉTODO getQuadro()
// 	 * QUE OPORTUNAMENTE SERÁ EXCLUIDO
// 	 */
// 	@JsonIgnore
// 	public Quadro getQuadroAtual() {


// 		Quadro quadro = null;
// 		for (QuadroPolicial qp :  listaQuadroPolicial) {
// 			if(qp.getIdQuadroPostoGraduacao()!=null){
// 				quadro = qp.getIdQuadroPostoGraduacao().getIdQuadro();
// 			}
// 		}
// 		return quadro;

// 	}

// 	@JsonIgnore
// 	public QuadroPolicial getQuadroPolicialAtual() {

// 		QuadroPolicial quadroPolicial = new QuadroPolicial();

// 		if(listaQuadroPolicial!=null && !listaQuadroPolicial.isEmpty()){
// 			for (QuadroPolicial qp :  listaQuadroPolicial) {
// 				if(qp.getIdQuadroPostoGraduacao()!=null){
// 					quadroPolicial = qp;
// 				}
// 			}
// 		}
// 		return quadroPolicial;

// 	}


// 	@JsonIgnore
// 	public PolicialAuxilioMoradia getAuxilioMoradiaAtual() {

// 		PolicialAuxilioMoradia retorno = new PolicialAuxilioMoradia();

// 		if(this.listAuxilioMoradia!=null){
// 			for (PolicialAuxilioMoradia pam :  this.listAuxilioMoradia) {
// 				if(retorno.getId() < pam.getId()) {
// 					retorno = pam;
// 				}

// 			}
// 		}
// 		return retorno;

// 	}

// 	@JsonIgnore
// 	public PolicialFundoSaudeAdicional getFundoSaudeAdicionalAtual() {

// 		PolicialFundoSaudeAdicional retorno = new PolicialFundoSaudeAdicional();

// 		if(this.listFundoSaudeAdicional!=null){
// 			for (PolicialFundoSaudeAdicional fun :  this.listFundoSaudeAdicional) {
// 				if(retorno.getId() < fun.getId()) {
// 					retorno = fun;
// 				}

// 			}
// 		}
// 		return retorno;

// 	}

// 	@JsonIgnore
// 	public PolicialCertificacaoProfissional getCertificacaoProfissionalAtual() {

// 		PolicialCertificacaoProfissional retorno = new PolicialCertificacaoProfissional();

// 		if(this.listPolicialCertificacaoProfissional!=null){
// 			for (PolicialCertificacaoProfissional cert :  this.listPolicialCertificacaoProfissional) {
// 				if(retorno.getId() < cert.getId()) {
// 					retorno = cert;
// 				}

// 			}
// 		}
// 		return retorno;

// 	}


// 	@JsonIgnore
// 	public List<Recurso> getRecursos() {
// 		List<Recurso> recursos = new ArrayList<>();

// 		for (Perfil perfil : this.getIdPessoa().getPerfils()) {
// 			for (Recurso recurso : perfil.getRecursos()) {
// 				recursos.add(recurso);
// 			}
// 		}
// 		return recursos;
// 	}
// 	@JsonIgnore
// 	public HistoricoSituacaoPolicial getHistoricoSituacaoPolicialAtual() {

// 		HistoricoSituacaoPolicial historicoSituacaoPolicialRetorno = new HistoricoSituacaoPolicial();

// 		SituacaoPolicial situacaoPolicial = new SituacaoPolicial();
// 		situacaoPolicial.setId(5);
// 		situacaoPolicial.setNome("Sem status");
// 		historicoSituacaoPolicialRetorno.setIdSituacaoPolicial(situacaoPolicial);

// 		if(getListHistoricoSituacaoPolicial()!=null && !getListHistoricoSituacaoPolicial().isEmpty()){
// 			for (HistoricoSituacaoPolicial historicoSituacaoPolicial : getListHistoricoSituacaoPolicial()) {
// 				if(historicoSituacaoPolicial.getDataFim()==null){
// 					historicoSituacaoPolicialRetorno =  historicoSituacaoPolicial;
// 				}
// 			}
// 		}

// 		return historicoSituacaoPolicialRetorno;
// 	}

// 	@JsonIgnore
// 	public MedidasCorporais getMedidaCorporalAtual(){


// 		MedidasCorporais retorno = new MedidasCorporais();

// 		if(listMedidaCorporal == null || listMedidaCorporal.isEmpty()){
// 			return retorno;
// 		}else{


// 			for (MedidasCorporais med : listMedidaCorporal) {

// 				if(retorno !=null && (retorno.getId() < med.getId())){
// 					retorno = med;
// 				}

// 			}
// 			return retorno;

// 		}

// 	}

// 	@JsonIgnore
// 	public MedidasCorporaisTaf getMedidaCorporalAtualTaf(){


// 		MedidasCorporaisTaf retorno = new MedidasCorporaisTaf();

// 		if(listMedidaCorporal == null || listMedidaCorporal.isEmpty()){
// 			return retorno;
// 		}else{


// 			for (MedidasCorporaisTaf med : listMedidaCorporalTaf) {

// 				if(retorno.getId() < med.getId()){
// 					retorno = med;
// 				}

// 			}
// 			return retorno;

// 		}

// 	}

// 	public void setId(int id) {
// 		this.id = id;
// 	}

// 	//CONVERTER DATE EM LOCALDATE E CALCULAR PERÍODO ENTRE DATA ATUAL E
// 	@JsonIgnore
// 	public Period getCalcularDatasAtualEDataMedida(Policial policial) {
// 		Period periodo =null;
// //		if(policial.getMedidaCorporalAtual().getDataMedicao()!=null){
// //		Instant instant = Instant.ofEpochMilli(policial.getMedidaCorporalAtual().getDataMedicao().);
// //        LocalDate dataMedida = LocalDateTime.ofInstant(instant, ZoneId.systemDefault()).toLocalDate();
// //
// //		LocalDate hoje = LocalDate.now();
// //
// //		 periodo = Period.between(dataMedida, hoje);
// //		}
// 		return periodo;
// 	}

// 	@JsonIgnore
// 	public  HistoricoSituacaoFuncional getHistoricoSituacaoFuncionalAtual(){

// 		HistoricoSituacaoFuncional historicoSituacaoFuncional = new HistoricoSituacaoFuncional();

// 		for (HistoricoSituacaoFuncional historico : listHistoricoSituacaoFuncional) {
// 			if (historicoSituacaoFuncional.getDataCadastro() ==null
// 					|| historico.getDataTransicao().isAfter(historicoSituacaoFuncional.getDataTransicao())
// 					|| historico.getDataTransicao().isEqual(historicoSituacaoFuncional.getDataTransicao())
// 					|| historico.getDataCadastro().isAfter(historicoSituacaoFuncional.getDataTransicao())
// 			) {
// 				historicoSituacaoFuncional=historico;
// 			}
// 		}

// 		return historicoSituacaoFuncional;

// 	}
// 	@JsonIgnore
// 	public List<Dependente> getDependentesAtual() {

// 		List<Dependente> retorno =  new ArrayList<>();
// 		for (Dependente dependente : this.listDependentes) {
// 			if((dependente.getDataDesligamento()==null || dependente.getDataDesligamento().isAfter(LocalDate.now())) && this.getId() == dependente.getIdPolicial().getId()){
// 				retorno.add(dependente);
// 			}

// 		}

// 		return retorno;
// 	}



// 	public UnidadePolicialMilitar getUpmCodigoPolicialCedido() {
// 		return upmCodigoPolicialCedido;
// 	}

// 	public void setUpmCodigoPolicialCedido(UnidadePolicialMilitar upmCodigoPolicialCedido) {
// 		this.upmCodigoPolicialCedido = upmCodigoPolicialCedido;
// 	}

// 	public boolean getAtivo(){
// 		return this.idSituacaoFuncional.getId()== SituacaoFuncionalENUM.ATIVO.getId();

// 	}

// 	public String getCn() {
// 		return cn;
// 	}

// 	public void setCn(String cn) {
// 		this.cn = cn;
// 	}

// 	public boolean isEditarQuadro(){

// //		if(!listaQuadroPolicial.isEmpty()){
// //			return false;
// //		}
// //		else if(getQuadroPolicialAtual().getDataInicio()==null){
// //			return true;
// //		}
// //
// //		long diasLong = java.sql.Date.valueOf(LocalDate.now()).getTime() - getQuadroPolicialAtual().getDataInicio().getTime();
// //		long daysBetween = (diasLong / (1000*60*60*24));
// //
// //
// //		if(daysBetween<=2){
// //			return true;
// //		}
// //		else{
// //			return false;
// //		}
// 		return true;
// 	}




// 	@JsonIgnore
// 	public PolicialTafAgenda getTafCorrente() {
// 		PolicialTafAgenda retorno = new PolicialTafAgenda();
// 		retorno.setApto(0);
// 		for (PolicialTafAgenda policialTafAgenda : Tafs) {
// 			if(retorno.getId()==0 ||
// 					retorno.getTafAgenda().getDtTaf().before((policialTafAgenda.getTafAgenda().getDtTaf())))
// 			retorno =  policialTafAgenda;
// 		}
// 		return retorno;

// 	}


// 	@JsonIgnore
// 	public QuadroPolicial getQuadroPolicial() {
// 		return quadroPolicial;
// 	}

// 	@JsonIgnore
// 	public void setQuadroPolicial(QuadroPolicial quadroPolicial) {
// 		this.quadroPolicial = quadroPolicial;
// 	}


// 	@JsonIgnore
// 	public Set<FuncaoUpmLotacaoPolicial> getListaFuncaoUpmLotacaoPolicial() {
// 		return listaFuncaoUpmLotacaoPolicial;
// 	}

// 	@JsonIgnore
// 	public void setListaFuncaoUpmLotacaoPolicial(Set<FuncaoUpmLotacaoPolicial> listaFuncaoUpmLotacaoPolicial) {
// 		this.listaFuncaoUpmLotacaoPolicial = listaFuncaoUpmLotacaoPolicial;
// 	}


// 	@JsonIgnore
// 	public Set<UpmPolicial> getListaUpmPolicial() {
// 		return listaUpmPolicial;
// 	}

// 	@JsonIgnore
// 	public void setListaUpmPolicial(Set<UpmPolicial> listaUpmPolicial) {
// 		this.listaUpmPolicial = listaUpmPolicial;
// 	}

// 	@JsonIgnore
// 	public Classificacao getClassificacaoAtual() {
// 		Classificacao retorno = new Classificacao();
// 		if(getUpmPolicialAtualNew().getClassificacoes()!=null) {
// 		for(Classificacao obj:getUpmPolicialAtualNew().getClassificacoes()) {
// 			if(obj.getDataFim()==null) {
// 				retorno = obj;
// 			}
// 		}
// 		}
// 		return retorno;

// 	}

// 	@JsonIgnore
// 	public UpmPolicial getUpmPolicial() {
// 		return upmPolicial;
// 	}

// 	@JsonIgnore
// 	public void setUpmPolicial(UpmPolicial upmPolicial) {
// 		this.upmPolicial = upmPolicial;
// 	}



// 	public UnidadePolicialMilitar getUpm() {
// 		return upm;
// 	}

// 	public void setUpm(UnidadePolicialMilitar upm) {
// 		this.upm = upm;
// 	}

// 	@Override
// 	public int hashCode() {
// 		final int prime = 31;
// 		int result = 1;
// 		result = prime * result + ((id == null) ? 0 : id.hashCode());
// 		return result;
// 	}

// 	@Override
// 	public boolean equals(Object obj) {
// 		if (this == obj)
// 			return true;
// 		if (obj == null)
// 			return false;
// 		if (getClass() != obj.getClass())
// 			return false;
// 		Policial other = (Policial) obj;
// 		if (id == null) {
// 			if (other.id != null)
// 				return false;
// 		} else if (!id.equals(other.id))
// 			return false;
// 		return true;
// 	}

// 	public String toStringAuditoria() {
// 		return "Policial [" + (id != null ? "id=" + id + ", " : "")
// 				+ (nomeGuerra != null ? "nomeGuerra=" + nomeGuerra + ", " : "")
// 				+ (sirgh != null ? "sirgh=" + sirgh + ", " : "") + (login != null ? "login=" + login + ", " : "")
// 				+ (almanaque != null ? "almanaque=" + almanaque + ", " : "")
// 				+ (matricula != null ? "matricula=" + matricula + ", " : "")
// 				+ (siape != null ? "siape=" + siape + ", " : "")
// 				+ (dataAdmissao != null ? "dataAdmissao=" + dataAdmissao + ", " : "")
// 				+ (identificacaoUnica != null ? "identificacaoUnica=" + identificacaoUnica + ", " : "")
// //				+ (idSituacaoFuncional != null ? "idSituacaoFuncional=" + idSituacaoFuncional.getNome() + ", " : "")
// 				+ (idPessoa != null ? "pessoa=" + idPessoa.toStringAuditoria() + ", " : "")
// 				+ (cn != null ? "cn=" + cn + ", " : "") + "porteSuspenso=" + porteSuspenso + ", ctgrafiSuspenso="
// 				+ ctgrafiSuspenso + ", " + (graduacaoAtual != null ? "graduacaoAtual=" + graduacaoAtual + ", " : "")
// 				+ (quadroPolicial != null ? "quadroPolicial=" + quadroPolicial + ", " : "")
// 				+ (upmPolicial != null ? "upmPolicial=" + upmPolicial.getIdUpm().getSigla() + ", " : "") + "restrito=" + restrito + ", "
// 				+ (upm != null ? "upm=" + upm.getNome() + ", " : "")
// 				+ (postoGraduacaoAtual != null ? "postoGraduacaoAtual=" + postoGraduacaoAtual.getNome() : "") + "]";
// 	}






}
