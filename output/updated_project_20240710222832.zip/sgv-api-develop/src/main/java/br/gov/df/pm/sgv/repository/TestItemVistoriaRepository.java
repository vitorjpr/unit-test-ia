Sure! Here are some unit tests for the `ItemVistoriaRepository` class:

```java
package br.gov.df.pm.sgv.repository;

import br.gov.df.pm.sgv.domain.ItemVistoriaEntity;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@DataJpaTest
public class ItemVistoriaRepositoryTest {

    @Autowired
    private ItemVistoriaRepository itemVistoriaRepository;

    @Autowired
    private TestEntityManager entityManager;

    @Test
    public void testFindByNome() {
        // Given
        ItemVistoriaEntity item = new ItemVistoriaEntity();
        item.setNome("Test Item");
        entityManager.persist(item);
        entityManager.flush();

        // When
        Optional<ItemVistoriaEntity> foundItem = itemVistoriaRepository.findByNome("Test Item");

        // Then
        assertTrue(foundItem.isPresent());
        assertEquals("Test Item", foundItem.get().getNome());
    }

    @Test
    public void testFindByNome_NotFound() {
        // Given
        ItemVistoriaEntity item = new ItemVistoriaEntity();
        item.setNome("Test Item");
        entityManager.persist(item);
        entityManager.flush();

        // When
        Optional<ItemVistoriaEntity> foundItem = itemVistoriaRepository.findByNome("Nonexistent Item");

        // Then
        assertTrue(foundItem.isEmpty());
    }
}
```

These tests cover the `findByNome` method of the `ItemVistoriaRepository` class, both for a case where an item is found and for a case where no item is found. The tests use Mockito for mocking and the `TestEntityManager` provided by Spring Boot for testing with an in-memory database.