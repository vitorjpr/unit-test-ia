```java
package br.gov.df.pm.sgv.domain;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class ViaturaEntityTest {

    @Test
    public void testGetterAndSetter() {
        ViaturaEntity viatura = new ViaturaEntity();

        viatura.setId(1L);
        assertEquals(1L, viatura.getId());

        viatura.setPrefixo("ABC123");
        assertEquals("ABC123", viatura.getPrefixo());

        viatura.setNrSei("123456");
        assertEquals("123456", viatura.getNrSei());

        viatura.setPlaca("XYZ9876");
        assertEquals("XYZ9876", viatura.getPlaca());

        viatura.setStatus("Ativo");
        assertEquals("Ativo", viatura.getStatus());

        viatura.setTombamento("12345678901");
        assertEquals("12345678901", viatura.getTombamento());

        viatura.setRenavam("12345678901");
        assertEquals("12345678901", viatura.getRenavam());

        LocalDate dataInclusao = LocalDate.now();
        viatura.setDataInclusao(dataInclusao);
        assertEquals(dataInclusao, viatura.getDataInclusao());

        LocalDate dataAtualizacao = LocalDate.now();
        viatura.setDataAtualizacao(dataAtualizacao);
        assertEquals(dataAtualizacao, viatura.getDataAtualizacao());

        viatura.setAtivo(true);
        assertTrue(viatura.getAtivo());

        TipoEmpregoViaturaEntity tipoEmpregoViatura = new TipoEmpregoViaturaEntity();
        viatura.setTipoEmpregoViatura(tipoEmpregoViatura);
        assertEquals(tipoEmpregoViatura, viatura.getTipoEmpregoViatura());

        List<ViaturaUpmEntity> listaUpm = new ArrayList<>();
        viatura.setListaUpm(listaUpm);
        assertEquals(listaUpm, viatura.getListaUpm());

        viatura.setMarcaModelo("Marca Modelo");
        assertEquals("Marca Modelo", viatura.getMarcaModelo());
    }

    @Test
    public void testEqualsAndHashCode() {
        ViaturaEntity viatura1 = new ViaturaEntity();
        viatura1.setId(1L);

        ViaturaEntity viatura2 = new ViaturaEntity();
        viatura2.setId(1L);

        assertEquals(viatura1, viatura2);
        assertEquals(viatura1.hashCode(), viatura2.hashCode());

        viatura2.setId(2L);

        assertNotEquals(viatura1, viatura2);
        assertNotEquals(viatura1.hashCode(), viatura2.hashCode());
    }

    // Add more tests for validation constraints if necessary

}
```