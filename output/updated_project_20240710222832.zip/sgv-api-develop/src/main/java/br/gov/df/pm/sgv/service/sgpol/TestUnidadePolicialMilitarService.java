Sure! Here are some unit tests for the provided Java code:

```java
package br.gov.df.pm.sgv.service.sgpol;

import br.gov.df.pm.sgv.domain.sgpol.UnidadePolicialMilitar;
import br.gov.df.pm.sgv.exception.NomeLocalAgregacaoJaCadastradoException;
import br.gov.df.pm.sgv.repository.sgpol.UnidadePolicialMilitarRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class UnidadePolicialMilitarServiceTest {

    @InjectMocks
    private UnidadePolicialMilitarService unidadePolicialMilitarService = new UnidadePolicialMilitarServiceImpl();

    @Mock
    private UnidadePolicialMilitarRepository unidadePolicialMilitarRepository;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testFindUPMById() {
        UnidadePolicialMilitar expectedUPM = new UnidadePolicialMilitar();
        when(unidadePolicialMilitarRepository.findById(1)).thenReturn(Optional.of(expectedUPM));

        UnidadePolicialMilitar result = unidadePolicialMilitarService.findUPMById(1);

        assertEquals(expectedUPM, result);
    }

    @Test
    void testListar() {
        List<UnidadePolicialMilitar> expectedList = new ArrayList<>();
        when(unidadePolicialMilitarRepository.findAll()).thenReturn(expectedList);

        List<UnidadePolicialMilitar> result = unidadePolicialMilitarService.listar();

        assertEquals(expectedList, result);
    }

    @Test
    void testEntityExists() {
        int id = 1;
        UnidadePolicialMilitar expectedUPM = new UnidadePolicialMilitar();
        when(unidadePolicialMilitarRepository.findById(id)).thenReturn(Optional.of(expectedUPM));

        UnidadePolicialMilitar result = unidadePolicialMilitarService.entityExists(id);

        assertEquals(expectedUPM, result);
    }

    @Test
    void testSalvar() {
        UnidadePolicialMilitar unidade = new UnidadePolicialMilitar();
        when(unidadePolicialMilitarRepository.findByNomeIgnoreCase(unidade.getNome())).thenReturn(Optional.empty());

        assertDoesNotThrow(() -> unidadePolicialMilitarService.salvar(unidade));
    }

    @Test
    void testSalvarExistingUPM() {
        UnidadePolicialMilitar unidade = new UnidadePolicialMilitar();
        when(unidadePolicialMilitarRepository.findByNomeIgnoreCase(unidade.getNome())).thenReturn(Optional.of(new UnidadePolicialMilitar()));

        assertThrows(NomeLocalAgregacaoJaCadastradoException.class, () -> unidadePolicialMilitarService.salvar(unidade));
    }
}
```

These tests cover the `findUPMById`, `listar`, `entityExists`, and `salvar` methods of the `UnidadePolicialMilitarService` interface. You can expand the test coverage by adding more test cases for other methods as needed.