package br.gov.df.pm.sgv.dto.root;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class RecursoDTO {
    private String nome;
}
