Sure! Here are some unit tests for the `ResourceNotFoundException` class:

```java
package br.gov.df.pm.sgv.exceptions;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class ResourceNotFoundExceptionTest {

    @Test
    public void testConstructorWithMessage() {
        String message = "Resource not found";
        ResourceNotFoundException exception = new ResourceNotFoundException(message);
        assertEquals(message, exception.getMessage());
    }

    @Test
    public void testConstructorWithNullMessage() {
        ResourceNotFoundException exception = new ResourceNotFoundException(null);
        assertEquals(null, exception.getMessage());
    }

    @Test
    public void testConstructorWithEmptyMessage() {
        ResourceNotFoundException exception = new ResourceNotFoundException("");
        assertEquals("", exception.getMessage());
    }

    @Test
    public void testConstructorWithWhitespaceMessage() {
        ResourceNotFoundException exception = new ResourceNotFoundException("   ");
        assertEquals("   ", exception.getMessage());
    }
}
```

These tests cover different scenarios such as creating the exception with a message, with a null message, with an empty message, and with a whitespace message. You can run these tests to ensure the `ResourceNotFoundException` class behaves as expected in these cases.