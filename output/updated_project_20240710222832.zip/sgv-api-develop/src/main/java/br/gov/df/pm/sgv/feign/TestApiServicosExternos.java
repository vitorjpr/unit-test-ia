```java
package br.gov.df.pm.sgv.feign;

import br.gov.df.pm.sgv.feign.dto.AuthKeycloakDTO;
import br.gov.df.pm.sgv.feign.dto.MessageAuthKeycloak;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class ApiServicosExternosTest {

    @Mock
    private ApiServicosExternos apiServicosExternos;

    @Test
    public void testAuthentication() {
        // Given
        AuthKeycloakDTO keycloakRequest = new AuthKeycloakDTO("username", "password");
        MessageAuthKeycloak expectedResponse = new MessageAuthKeycloak("token123");

        when(apiServicosExternos.authentication(keycloakRequest))
                .thenReturn(ResponseEntity.ok(expectedResponse));

        // When
        ResponseEntity<MessageAuthKeycloak> response = apiServicosExternos.authentication(keycloakRequest);

        // Then
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(expectedResponse, response.getBody());
        verify(apiServicosExternos).authentication(keycloakRequest);
    }
}
```

Neste exemplo, foi criado um teste unitário para o método `authentication` da interface `ApiServicosExternos`. O teste utiliza o framework Mockito para simular o comportamento do feign client e verificar se a resposta é a esperada. Certifique-se de adicionar as dependências necessárias do Mockito ao seu projeto para que o código de teste funcione corretamente.