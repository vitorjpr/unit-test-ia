Here are some unit tests for the provided Java code:

```java
package br.gov.df.pm.sgv.configurations;

import org.hibernate.boot.model.naming.Identifier;
import org.hibernate.engine.jdbc.env.spi.JdbcEnvironment;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

public class MultitenancyDbNamingStrategyTest {

    private MultitenancyDbNamingStrategy namingStrategy;

    @Mock
    private JdbcEnvironment jdbcEnvironment;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        namingStrategy = new MultitenancyDbNamingStrategy();
        ReflectionTestUtils.setField(namingStrategy, "catalog", "custom_catalog");
    }

    @Test
    public void testToPhysicalCatalogNameWithMatchingCatalog() {
        Identifier inputIdentifier = Identifier.toIdentifier("sgpol", false);
        Identifier result = namingStrategy.toPhysicalCatalogName(inputIdentifier, jdbcEnvironment);
        assertEquals("custom_catalog", result.getText());
    }

    @Test
    public void testToPhysicalCatalogNameWithNonMatchingCatalog() {
        Identifier inputIdentifier = Identifier.toIdentifier("some_other_catalog", false);
        Identifier result = namingStrategy.toPhysicalCatalogName(inputIdentifier, jdbcEnvironment);
        assertEquals("some_other_catalog", result.getText());
    }

    @Test
    public void testToPhysicalCatalogNameWithNullInput() {
        Identifier result = namingStrategy.toPhysicalCatalogName(null, jdbcEnvironment);
        assertNull(result);
    }

    @Test
    public void testToPhysicalCatalogNameWithNonMatchingNullCatalog() {
        Identifier inputIdentifier = Identifier.toIdentifier(null, false);
        Identifier result = namingStrategy.toPhysicalCatalogName(inputIdentifier, jdbcEnvironment);
        assertNull(result);
    }
}
```

These tests cover different scenarios such as when the input catalog name matches `SGPOL_CATALOG`, when it doesn't match, when the input is null, and when the input catalog name is null. Make sure to include necessary dependencies like Mockito for mocking objects and Spring Test for injecting values using `ReflectionTestUtils`.