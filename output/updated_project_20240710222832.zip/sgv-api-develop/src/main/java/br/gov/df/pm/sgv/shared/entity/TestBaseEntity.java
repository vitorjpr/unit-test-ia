Sure! Here are some unit tests for the provided Java code using JUnit 5:

```java
package br.gov.df.pm.sgv.shared.entity;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;

public class BaseEntityTest {

    @Test
    public void testEqualsSameObject() {
        BaseEntity<Long> entity = mock(BaseEntity.class);
        assertTrue(entity.equals(entity));
    }

    @Test
    public void testEqualsDifferentClass() {
        BaseEntity<Long> entity = new BaseEntity<Long>() {
            @Override
            public Long getId() {
                return 1L;
            }

            @Override
            public void setId(Long id) {
            }
        };
        assertFalse(entity.equals(new Object()));
    }

    @Test
    public void testEqualsSameId() {
        BaseEntity<Long> entity1 = new BaseEntity<Long>() {
            @Override
            public Long getId() {
                return 1L;
            }

            @Override
            public void setId(Long id) {
            }
        };
        BaseEntity<Long> entity2 = new BaseEntity<Long>() {
            @Override
            public Long getId() {
                return 1L;
            }

            @Override
            public void setId(Long id) {
            }
        };
        assertTrue(entity1.equals(entity2));
    }

    @Test
    public void testHashCodeNotNullId() {
        BaseEntity<Long> entity = new BaseEntity<Long>() {
            @Override
            public Long getId() {
                return 1L;
            }

            @Override
            public void setId(Long id) {
            }
        };
        assertEquals(1, entity.hashCode());
    }

    @Test
    public void testHashCodeNullId() {
        BaseEntity<Long> entity = new BaseEntity<Long>() {
            @Override
            public Long getId() {
                return null;
            }

            @Override
            public void setId(Long id) {
            }
        };
        assertEquals(0, entity.hashCode());
    }

    @Test
    public void testToString() {
        BaseEntity<Long> entity = new BaseEntity<Long>() {
            @Override
            public Long getId() {
                return 1L;
            }

            @Override
            public void setId(Long id) {
            }
        };
        assertEquals("Entidade [ BaseEntity ] {id=1}", entity.toString());
    }
}
```

These tests cover the `equals`, `hashCode`, and `toString` methods of the `BaseEntity` class. Make sure to include JUnit 5 in your project dependencies to run these tests.