```java
package br.gov.df.pm.sgv.dto;

import org.junit.jupiter.api.Test;
import java.time.LocalDateTime;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class FiltroVistoriaTest {

    @Test
    public void testGetSetPrefixo() {
        FiltroVistoria filtro = new FiltroVistoria();
        filtro.setPrefixo("ABC123");
        assertEquals("ABC123", filtro.getPrefixo());
    }

    @Test
    public void testGetSetPlaca() {
        FiltroVistoria filtro = new FiltroVistoria();
        filtro.setPlaca("XYZ987");
        assertEquals("XYZ987", filtro.getPlaca());
    }

    @Test
    public void testGetSetTipoVistoria() {
        FiltroVistoria filtro = new FiltroVistoria();
        filtro.setTipoVistoria(1L);
        assertEquals(1L, filtro.getTipoVistoria());
    }

    @Test
    public void testGetSetDataInicio() {
        FiltroVistoria filtro = new FiltroVistoria();
        LocalDateTime dataInicio = LocalDateTime.now();
        filtro.setDataInicio(dataInicio);
        assertEquals(dataInicio, filtro.getDataInicio());
    }

    @Test
    public void testGetSetDataFim() {
        FiltroVistoria filtro = new FiltroVistoria();
        LocalDateTime dataFim = LocalDateTime.now();
        filtro.setDataFim(dataFim);
        assertEquals(dataFim, filtro.getDataFim());
    }

    @Test
    public void testGetSetUnidade() {
        FiltroVistoria filtro = new FiltroVistoria();
        filtro.setUnidade(123);
        assertEquals(123, filtro.getUnidade());
    }
}
```