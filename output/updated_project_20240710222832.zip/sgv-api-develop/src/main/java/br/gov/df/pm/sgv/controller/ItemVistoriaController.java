package br.gov.df.pm.sgv.controller;

import br.gov.df.pm.sgv.assembler.ItemVistoriaAssembler;
import br.gov.df.pm.sgv.dto.EdicaoItemVistoriaDTO;
import br.gov.df.pm.sgv.dto.ItemVistoriaDTO;
import br.gov.df.pm.sgv.domain.*;
import br.gov.df.pm.sgv.service.ItemVistoriaService;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.PagedModel;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/vistoria/itemvistoria")
public class ItemVistoriaController {
    private ItemVistoriaService service;
    private final ItemVistoriaAssembler itemVistoriaAssembler;
    private final PagedResourcesAssembler<ItemVistoriaEntity> pagedResourcesAssembler;

    public ItemVistoriaController(ItemVistoriaService service,
                                  ItemVistoriaAssembler itemVistoriaAssembler,
                                  PagedResourcesAssembler<ItemVistoriaEntity> pagedResourcesAssembler) {
        this.service = service;
        this.itemVistoriaAssembler = itemVistoriaAssembler;
        this.pagedResourcesAssembler = pagedResourcesAssembler;
    }

    @GetMapping("/buscar/{id}")
    public ResponseEntity<ItemVistoriaDTO> buscarId(@PathVariable("id") Long id) {
        return service.buscarId(id);
    }

    @GetMapping("/buscar")
    public PagedModel<EntityModel<ItemVistoriaDTO>> buscar(String filter, Pageable pageable) {
        var result = pagedResourcesAssembler.toModel(service.buscar(filter, pageable));
        return PagedModel.of(result.getContent().stream().map(e ->
                itemVistoriaAssembler.toModel(Objects.requireNonNull(e.getContent()))).collect(Collectors.toList()), result.getMetadata());
    }

    @PostMapping("/salvar")
    public ResponseEntity<?> salvar(@RequestBody ItemVistoriaDTO itemVistoriaDTO) {
        return service.salvar(itemVistoriaDTO);
    }

    @PutMapping("/editar/{id}")
    public ResponseEntity<?> editar(@PathVariable("id") Long id, @RequestBody EdicaoItemVistoriaDTO edicao) {
        return service.editar(id, edicao);
    }

    @GetMapping("/findAllSubitensVistoria")
    public ResponseEntity<List<SubitensVistoriaEntity>> findAllSubitensVistoria() {
        return service.findAllSubitensVistoria();
    }

    @DeleteMapping("/excluir/{id}")
    public ResponseEntity<?> excluir(@PathVariable("id") Long id) {
        return service.excluir(id);
    }

    @DeleteMapping("/desativar/{id}")
    public ResponseEntity<?> desativar(@PathVariable("id") Long id) {
        return service.desativar(id);
    }

    @PostMapping("/ativar/{id}")
    public ResponseEntity<?> ativar(@PathVariable("id") Long id) {
        return service.ativar(id);
    }

    @GetMapping("/findAllSubitemVistoriaById/{nome}")
    public ResponseEntity<List<SubitemVistoriaEntity>> findAllSubitemVistoriaById(@PathVariable("nome") String nome) {
        return service.findAllSubitemVistoriaById(nome);
    }

    @GetMapping("/findAllSubitemVistoria")
    public ResponseEntity<List<SubitemVistoriaEntity>> findAllSubitemVistoria() {
        return service.findAllSubitemVistoria();
    }
}
