Sure! Here are some unit tests for the `ItemVistoriaDTO` class:

```java
package br.gov.df.pm.sgv.dto;

import br.gov.df.pm.sgv.domain.SubitemVistoriaEntity;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class ItemVistoriaDTOTest {

    @Test
    public void testConstructorAndGetters() {
        Long id = 1L;
        String nome = "Item Test";
        String descricao = "Descrição do item";
        LocalDate dataInclusao = LocalDate.now();
        Boolean ativo = true;
        List<SubitemVistoriaEntity> subitens = new ArrayList<>();

        ItemVistoriaDTO itemVistoriaDTO = new ItemVistoriaDTO(id, nome, descricao, dataInclusao, ativo, subitens);

        assertNotNull(itemVistoriaDTO);
        assertEquals(id, itemVistoriaDTO.getId());
        assertEquals(nome, itemVistoriaDTO.getNome());
        assertEquals(descricao, itemVistoriaDTO.getDescricao());
        assertEquals(dataInclusao, itemVistoriaDTO.getDataInclusao());
        assertEquals(ativo, itemVistoriaDTO.getAtivo());
        assertEquals(subitens, itemVistoriaDTO.getSubitens());
    }

    @Test
    public void testBuilder() {
        Long id = 1L;
        String nome = "Item Test";
        String descricao = "Descrição do item";
        LocalDate dataInclusao = LocalDate.now();
        Boolean ativo = true;
        List<SubitemVistoriaEntity> subitens = new ArrayList<>();

        ItemVistoriaDTO itemVistoriaDTO = ItemVistoriaDTO.builder()
                .id(id)
                .nome(nome)
                .descricao(descricao)
                .dataInclusao(dataInclusao)
                .ativo(ativo)
                .subitens(subitens)
                .build();

        assertNotNull(itemVistoriaDTO);
        assertEquals(id, itemVistoriaDTO.getId());
        assertEquals(nome, itemVistoriaDTO.getNome());
        assertEquals(descricao, itemVistoriaDTO.getDescricao());
        assertEquals(dataInclusao, itemVistoriaDTO.getDataInclusao());
        assertEquals(ativo, itemVistoriaDTO.getAtivo());
        assertEquals(subitens, itemVistoriaDTO.getSubitens());
    }

}
```

These unit tests cover the constructor, getters, and builder methods of the `ItemVistoriaDTO` class. They ensure that the class functions correctly by checking the values set and returned by the methods.