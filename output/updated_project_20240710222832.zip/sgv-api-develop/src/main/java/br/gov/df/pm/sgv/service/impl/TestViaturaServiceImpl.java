```java
package br.gov.df.pm.sgv.service.impl;

import br.gov.df.pm.sgv.domain.ViaturaEntity;
import br.gov.df.pm.sgv.domain.ViaturaUpmEntity;
import br.gov.df.pm.sgv.domain.VistoriaViaturaEntity;
import br.gov.df.pm.sgv.domain.sgpol.UnidadePolicialMilitar;
import br.gov.df.pm.sgv.dto.TipoEmpregoViaturaDto;
import br.gov.df.pm.sgv.dto.VistoriaViaturaDTO;
import br.gov.df.pm.sgv.exceptions.ViaturaException;
import br.gov.df.pm.sgv.mapper.TipoEmpregoMapper;
import br.gov.df.pm.sgv.repository.TipoEmpregoViaturaRepository;
import br.gov.df.pm.sgv.repository.app.ViaturaRepository;
import br.gov.df.pm.sgv.repository.app.VistoriaViaturaRepository;
import br.gov.df.pm.sgv.repository.sgpol.UnidadePolicialMilitarRepository;
import br.gov.df.pm.sgv.service.ViaturaService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class ViaturaServiceImplTest {

    @Mock
    private ViaturaRepository viaturaRepository;

    @Mock
    private VistoriaViaturaRepository vistoriaViaturaRepository;

    @Mock
    private UnidadePolicialMilitarRepository unidadePolicialMilitarRepository;

    @Mock
    private TipoEmpregoViaturaRepository tipoEmpregoViaturaRepository;

    @InjectMocks
    private ViaturaServiceImpl viaturaService;

    @Test
    public void testBuscarViatura() {
        // Implement your test for buscarViatura method
    }

    @Test
    public void testFindPaginado() {
        // Implement your test for findPaginado method
    }

    @Test
    public void testGetUltimoOdometroByViatura() {
        // Implement your test for getUltimoOdometroByViatura method
    }

    @Test
    public void testGetVistoriaViaturaByViatura() {
        // Implement your test for getVistoriaViaturaByViatura method
    }

    @Test
    public void testListarUpm() {
        // Implement your test for listarUpm method
    }

    @Test
    public void testListar() {
        // Implement your test for listar method
    }

    @Test
    public void testBuscarViaturasAtivas() {
        // Implement your test for buscarViaturasAtivas method
    }

    @Test
    public void testFiltroToSpecification() {
        // Implement your test for filtroToSpecification method
    }

    @Test
    public void testFiltroToSpecificationV1() {
        // Implement your test for filtroToSpecificationV1 method
    }
}
```

Esses são os esboços dos testes unitários para a classe `ViaturaServiceImpl`. Você pode implementar cada um desses testes preenchendo-os com as asserções e lógica de teste específicas para cada método da classe. Certifique-se de simular cenários variados para garantir uma cobertura abrangente dos testes.