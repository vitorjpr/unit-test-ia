```java
package br.gov.df.pm.sgv.mapper;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import br.gov.df.pm.sgv.domain.DiferencaOdometroEntity;
import br.gov.df.pm.sgv.dto.DiferencaOdometroDTO;

public class DiferencaOdometroMapperTest {

    @Test
    public void testConvertEntity() {
        DiferencaOdometroDTO dto = DiferencaOdometroDTO.builder()
                .referenciaInicial(100)
                .referenciaFinal(200)
                .diferencaOdometro(100)
                .dataModificacao("2022-08-01")
                .dataInclusao("2022-08-01")
                .build();

        DiferencaOdometroEntity entity = DiferencaOdometroMapper.convertEntity(dto);

        assertNotNull(entity);
        assertEquals(dto.getReferenciaInicial(), entity.getReferenciaInicial());
        assertEquals(dto.getReferenciaFinal(), entity.getReferenciaFinal());
        assertEquals(dto.getDiferencaOdometro(), entity.getDiferencaOdometro());
        assertEquals(dto.getDataModificacao(), entity.getDataModificacao());
        assertEquals(dto.getDataInclusao(), entity.getDataInclusao());
    }

    @Test
    public void testConvertDTO() {
        DiferencaOdometroEntity entity = DiferencaOdometroEntity.builder()
                .referenciaInicial(100)
                .referenciaFinal(200)
                .diferencaOdometro(100)
                .dataModificacao("2022-08-01")
                .dataInclusao("2022-08-01")
                .build();

        DiferencaOdometroDTO dto = DiferencaOdometroMapper.convertDTO(entity);

        assertNotNull(dto);
        assertEquals(entity.getReferenciaInicial(), dto.getReferenciaInicial());
        assertEquals(entity.getReferenciaFinal(), dto.getReferenciaFinal());
        assertEquals(entity.getDiferencaOdometro(), dto.getDiferencaOdometro());
        assertEquals(entity.getDataModificacao(), dto.getDataModificacao());
        assertEquals(entity.getDataInclusao(), dto.getDataInclusao());
    }
}
```