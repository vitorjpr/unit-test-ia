package br.gov.df.pm.sgv.service;

import br.gov.df.pm.sgv.dto.TipoEmpregoViaturaDto;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface TipoEmpregoViaturaService {

    List<TipoEmpregoViaturaDto> listTipoEmpregoViaturaAtivo();
}
