package br.gov.df.pm.sgv.configurations;

import org.hibernate.boot.model.naming.Identifier;
import org.hibernate.boot.model.naming.PhysicalNamingStrategyStandardImpl;
import org.hibernate.engine.jdbc.env.spi.JdbcEnvironment;
import org.springframework.beans.factory.annotation.Value;

public class MultitenancyDbNamingStrategy extends PhysicalNamingStrategyStandardImpl {

    private static final String SGPOL_CATALOG = "sgpol";

    @Value("${SGPOL_CATALOG:sgpol_fabrica}")
    private String catalog;

    @Override
    public Identifier toPhysicalCatalogName(Identifier name, JdbcEnvironment jdbcEnvironment) {
        if (name != null && SGPOL_CATALOG.equals(name.getText())) {
            name = Identifier.toIdentifier(catalog, false);
        }
        return name;
    }
}

