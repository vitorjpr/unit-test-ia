package br.gov.df.pm.sgv.configurations;
import org.hibernate.boot.model.naming.PhysicalNamingStrategy;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class PersistenceSgpolAutoConfiguration {

    @Bean
    public PhysicalNamingStrategy physicalNamingStrategy() {
        return new MultitenancyDbNamingStrategy();
    }
}
