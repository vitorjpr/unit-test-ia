Here are the unit tests for the given Java code:

```java
package br.gov.df.pm.sgv.dto;

import br.gov.df.pm.sgv.domain.ItemVistoriaEntity;
import org.junit.jupiter.api.Test;
import java.util.ArrayList;
import java.util.List;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class EdicaoTipoVistoriaDTOTest {

    @Test
    public void testGetNome() {
        EdicaoTipoVistoriaDTO dto = new EdicaoTipoVistoriaDTO();
        dto.setNome("NomeTeste");
        assertEquals("NomeTeste", dto.getNome());
    }

    @Test
    public void testGetDescricao() {
        EdicaoTipoVistoriaDTO dto = new EdicaoTipoVistoriaDTO();
        dto.setDescricao("DescricaoTeste");
        assertEquals("DescricaoTeste", dto.getDescricao());
    }

    @Test
    public void testGetStatusAnterior() {
        EdicaoTipoVistoriaDTO dto = new EdicaoTipoVistoriaDTO();
        dto.setStatusAnterior("StatusAnteriorTeste");
        assertEquals("StatusAnteriorTeste", dto.getStatusAnterior());
    }

    @Test
    public void testGetStatusPosterior() {
        EdicaoTipoVistoriaDTO dto = new EdicaoTipoVistoriaDTO();
        dto.setStatusPosterior("StatusPosteriorTeste");
        assertEquals("StatusPosteriorTeste", dto.getStatusPosterior());
    }

    @Test
    public void testGetItens() {
        EdicaoTipoVistoriaDTO dto = new EdicaoTipoVistoriaDTO();
        List<ItemVistoriaEntity> itens = new ArrayList<>();
        ItemVistoriaEntity item = new ItemVistoriaEntity();
        item.setNome("ItemTeste");
        itens.add(item);
        dto.setItens(itens);
        assertEquals(itens, dto.getItens());
    }
}
```

These tests cover the getters and setters for all the fields in the `EdicaoTipoVistoriaDTO` class. Make sure to include the necessary imports for the classes used in the tests.