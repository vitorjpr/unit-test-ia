Here are some unit tests for the ChecklistVistoriaRepository class:

```java
package br.gov.df.pm.sgv.repository;

import br.gov.df.pm.sgv.domain.ChecklistVistoriaEntity;
import br.gov.df.pm.sgv.domain.VistoriaViaturaEntity;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@SpringBootTest
public class ChecklistVistoriaRepositoryTest {

    @Autowired
    private ChecklistVistoriaRepository checklistVistoriaRepository;

    @Mock
    private VistoriaViaturaEntity vistoriaViatura;

    @Test
    public void testFindByVistoria() {
        // Given
        ChecklistVistoriaEntity checklist1 = new ChecklistVistoriaEntity();
        checklist1.setId(1L);
        checklist1.setVistoria(vistoriaViatura);

        ChecklistVistoriaEntity checklist2 = new ChecklistVistoriaEntity();
        checklist2.setId(2L);
        checklist2.setVistoria(vistoriaViatura);

        when(checklistVistoriaRepository.findByVistoria(vistoriaViatura)).thenReturn(List.of(checklist1, checklist2));

        // When
        List<ChecklistVistoriaEntity> result = checklistVistoriaRepository.findByVistoria(vistoriaViatura);

        // Then
        assertEquals(2, result.size());
        assertEquals(checklist1, result.get(0));
        assertEquals(checklist2, result.get(1));
    }
}
```

In this test class, we are using Mockito for mocking the dependencies and testing the `findByVistoria` method of the `ChecklistVistoriaRepository`. The test case creates two ChecklistVistoriaEntity objects, mocks the behavior of the repository method, and then asserts the expected results.

Make sure to include the necessary dependencies in your project for running these tests, such as JUnit, Mockito, and Spring Boot testing dependencies.