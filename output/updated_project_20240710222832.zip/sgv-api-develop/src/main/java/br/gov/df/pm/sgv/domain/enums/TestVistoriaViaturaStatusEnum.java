```java
package br.gov.df.pm.sgv.domain.enums;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class VistoriaViaturaStatusEnumTest {

    @Test
    public void testValueOfEnum() {
        assertEquals(VistoriaViaturaStatusEnum.DISPONIVEL, VistoriaViaturaStatusEnum.valueOfEnum("DISPONIVEL"));
        assertEquals(VistoriaViaturaStatusEnum.EM_VISTORIA, VistoriaViaturaStatusEnum.valueOfEnum("EM VISTORIA"));
        assertEquals(VistoriaViaturaStatusEnum.EM_USO, VistoriaViaturaStatusEnum.valueOfEnum("EM USO"));
        assertEquals(VistoriaViaturaStatusEnum.INDISPONIVEL, VistoriaViaturaStatusEnum.valueOfEnum("INDISPONIVEL"));
        assertNull(VistoriaViaturaStatusEnum.valueOfEnum("INVALID"));
    }

}
``` 

Esses testes garantem a cobertura do método `valueOfEnum` da classe `VistoriaViaturaStatusEnum`, verificando se ele retorna corretamente os enums com base na descrição fornecida e se retorna `null` para uma descrição inválida.