Sure! Here are some unit tests for the provided Java code:

```java
package br.gov.df.pm.sgv.dto;

import br.gov.df.pm.sgv.domain.DiferencaOdometroEntity;
import br.gov.df.pm.sgv.domain.TipoVistoriaEntity;
import br.gov.df.pm.sgv.domain.VistoriaViaturaHistoricoEntity;
import br.gov.df.pm.sgv.domain.enums.VistoriaViaturaStatusEnum;
import org.junit.jupiter.api.Test;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class VistoriaViaturaDTOTest {

    @Test
    public void testConstructorAndGetters() {
        TipoVistoriaEntity tipoVistoria = new TipoVistoriaEntity();
        List<VistoriaViaturaHistoricoEntity> vistoriaViaturaHistorico = new ArrayList<>();
        DiferencaOdometroEntity diferencaOdometro = new DiferencaOdometroEntity();
        VistoriaViaturaStatusEnum status = VistoriaViaturaStatusEnum.PENDENTE;
        LocalDateTime dataVistoria = LocalDateTime.now();

        VistoriaViaturaDTO vistoriaViaturaDTO = VistoriaViaturaDTO.builder()
                .tipoVistoria(tipoVistoria)
                .vistoriaViaturaHistorico(vistoriaViaturaHistorico)
                .diferencaOdometro(diferencaOdometro)
                .status(status)
                .dataVistoria(dataVistoria)
                .build();

        assertNotNull(vistoriaViaturaDTO);
        assertEquals(tipoVistoria, vistoriaViaturaDTO.getTipoVistoria());
        assertEquals(vistoriaViaturaHistorico, vistoriaViaturaDTO.getVistoriaViaturaHistorico());
        assertEquals(diferencaOdometro, vistoriaViaturaDTO.getDiferencaOdometro());
        assertEquals(status, vistoriaViaturaDTO.getStatus());
        assertEquals(dataVistoria, vistoriaViaturaDTO.getDataVistoria());
    }

    // Add more test cases as needed
}
```

These tests cover the constructor and getters of the `VistoriaViaturaDTO` class. You can add more test cases to cover other methods or behaviors as needed.