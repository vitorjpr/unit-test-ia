Sure! Here are some unit tests for the `ApiError` class in Java:

```java
package br.gov.df.pm.sgv.exceptions;

import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class ApiErrorTest {

    @Test
    public void testApiErrorConstructorWithList() {
        HttpStatus status = HttpStatus.BAD_REQUEST;
        String message = "Validation error";
        List<String> errors = Arrays.asList("Field is required", "Invalid format");
        
        ApiError apiError = new ApiError(status, message, errors);
        
        assertEquals(status, apiError.getStatus());
        assertEquals(message, apiError.getMessage());
        assertEquals(errors, apiError.getErrors());
    }

    @Test
    public void testApiErrorConstructorWithMessage() {
        String message = "Internal server error";
        
        ApiError apiError = new ApiError(message);
        
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, apiError.getStatus());
        assertEquals(message, apiError.getMessage());
        assertEquals(Arrays.asList(message), apiError.getErrors());
    }

    @Test
    public void testApiErrorConstructorWithSingleError() {
        HttpStatus status = HttpStatus.NOT_FOUND;
        String message = "Resource not found";
        String error = "Resource ID not found";
        
        ApiError apiError = new ApiError(status, message, error);
        
        assertEquals(status, apiError.getStatus());
        assertEquals(message, apiError.getMessage());
        assertEquals(Arrays.asList(error), apiError.getErrors());
    }

    @Test
    public void testApiErrorSetStatus() {
        ApiError apiError = new ApiError(HttpStatus.OK, "Success", "No errors");
        
        apiError.setStatus(HttpStatus.CREATED);
        
        assertEquals(HttpStatus.CREATED, apiError.getStatus());
    }
}
```

These tests cover the different constructors of the `ApiError` class, setting and getting the status, message, and errors. Make sure to run these tests to ensure the correctness of the `ApiError` class implementation.