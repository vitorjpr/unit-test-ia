Here are some unit tests for the provided Java code using JUnit and Mockito:

```java
package br.gov.df.pm.sgv.controller;

import br.gov.df.pm.sgv.service.StorageService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.core.io.Resource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;

import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class StorageControllerTest {

    @Mock
    private StorageService storageService;

    @InjectMocks
    private StorageController storageController;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testGetFile() {
        UUID id = UUID.randomUUID();
        Resource resource = Mockito.mock(Resource.class);
        when(storageService.baixarImagemAI(id)).thenReturn(ResponseEntity.ok(resource));

        ResponseEntity<Resource> response = storageController.getFile(id);

        assertEquals(ResponseEntity.ok(resource), response);
    }

    @Test
    public void testSendFile() {
        MultipartFile file = Mockito.mock(MultipartFile.class);
        UUID fileId = UUID.randomUUID();
        when(storageService.salvarImagem(file)).thenReturn(ResponseEntity.ok(fileId));

        ResponseEntity<UUID> response = storageController.sendFile(file);

        assertEquals(ResponseEntity.ok(fileId), response);
    }

    @Test
    public void testDeleteFile() {
        UUID id = UUID.randomUUID();

        ResponseEntity<String> response = storageController.deleteFile(id);

        verify(storageService).removerImagem(id);
        assertEquals("Arquivo excluído com sucesso", response.getBody());
    }
}
```

Make sure to include the necessary imports for the test class. These tests cover the `getFile`, `sendFile`, and `deleteFile` methods of the `StorageController` class by mocking the `StorageService` dependency and verifying the expected behavior.