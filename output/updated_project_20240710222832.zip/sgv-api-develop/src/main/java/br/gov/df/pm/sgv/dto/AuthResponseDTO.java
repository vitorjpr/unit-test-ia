package br.gov.df.pm.sgv.dto;

import lombok.Data;

@Data
public class AuthResponseDTO {
    private String token;
}
