Here are the unit tests for the `PerfilDTO` class:

```java
package br.gov.df.pm.sgv.dto.root;

import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class PerfilDTOTest {

    @Test
    public void testGetNome() {
        PerfilDTO perfilDTO = new PerfilDTO("Admin");
        assertEquals("Admin", perfilDTO.getNome());
    }

    @Test
    public void testSetNome() {
        PerfilDTO perfilDTO = new PerfilDTO();
        perfilDTO.setNome("User");
        assertEquals("User", perfilDTO.getNome());
    }

    @Test
    public void testBuilder() {
        PerfilDTO perfilDTO = PerfilDTO.builder()
                                        .nome("Manager")
                                        .build();
        assertEquals("Manager", perfilDTO.getNome());
    }

    @Test
    public void testAllArgsConstructor() {
        PerfilDTO perfilDTO = new PerfilDTO("Guest");
        assertEquals("Guest", perfilDTO.getNome());
    }

    @Test
    public void testEquals() {
        PerfilDTO perfilDTO1 = new PerfilDTO("Admin");
        PerfilDTO perfilDTO2 = new PerfilDTO("Admin");
        assertEquals(perfilDTO1, perfilDTO2);
    }

    @Test
    public void testHashCode() {
        PerfilDTO perfilDTO1 = new PerfilDTO("Admin");
        PerfilDTO perfilDTO2 = new PerfilDTO("Admin");
        assertEquals(perfilDTO1.hashCode(), perfilDTO2.hashCode());
    }
}
```

Make sure to include the necessary imports for the test class. These tests cover the constructor, builder, getter, setter, `equals`, and `hashCode` methods of the `PerfilDTO` class.