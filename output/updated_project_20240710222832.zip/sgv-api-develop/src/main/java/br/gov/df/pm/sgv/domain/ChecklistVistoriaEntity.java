package br.gov.df.pm.sgv.domain;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import lombok.*;
import net.minidev.json.annotate.JsonIgnore;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

@Entity
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(of = "id")
@Table(name = "CHECKLIST_VISTORIA", schema = "sgv")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class ChecklistVistoriaEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "chv_Id", unique = true, nullable = false)
    private Long id;

    @Column(name = "chv_Observacao")
    private String observacao;

    @Column(name = "chv_DataCriacao")
    private Date dataCriacao;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "vv_Codigo", nullable = false)
    @JsonBackReference("vistoria-checklists")
    private VistoriaViaturaEntity vistoria;

    @ManyToOne
    @JoinColumn(name = "itv_Codigo", nullable = false)
    private ItemVistoriaEntity itemVistoria;

    @JsonManagedReference("checklist-itens")
    @OneToMany(mappedBy = "checklistVistoria", cascade = CascadeType.ALL)
    private List<ChecklistItemVistoriaEntity> checklistItens;


}
