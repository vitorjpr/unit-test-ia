Sure! Here are some unit tests for the provided Java code:

```java
package br.gov.df.pm.sgv.domain;

import org.junit.jupiter.api.Test;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class SubitensVistoriaEntityTest {

    @Test
    public void testGettersAndSetters() {
        SubitensVistoriaEntity entity = new SubitensVistoriaEntity();
        entity.setId(1L);
        entity.setCodItem(new ItemVistoriaEntity());
        entity.setCodSubitem(new SubitemVistoriaEntity());
        entity.setAtivo(true);
        entity.setDataInclusao(LocalDate.now());

        assertEquals(1L, entity.getId());
        assertNotNull(entity.getCodItem());
        assertNotNull(entity.getCodSubitem());
        assertEquals(true, entity.isAtivo());
        assertNotNull(entity.getDataInclusao());
    }

    @Test
    public void testEqualsAndHashCode() {
        SubitensVistoriaEntity entity1 = new SubitensVistoriaEntity();
        entity1.setId(1L);

        SubitensVistoriaEntity entity2 = new SubitensVistoriaEntity();
        entity2.setId(1L);

        assertEquals(entity1, entity2);
        assertEquals(entity1.hashCode(), entity2.hashCode());
    }

    @Test
    public void testToString() {
        SubitensVistoriaEntity entity = new SubitensVistoriaEntity();
        entity.setId(1L);
        entity.setCodItem(new ItemVistoriaEntity());
        entity.setCodSubitem(new SubitemVistoriaEntity());
        entity.setAtivo(true);
        entity.setDataInclusao(LocalDate.now());

        String expected = "SubitensVistoriaEntity(id=1, codItem=ItemVistoriaEntity(), codSubitem=SubitemVistoriaEntity(), ativo=true, dataInclusao=" + LocalDate.now() + ")";
        assertEquals(expected, entity.toString());
    }
}
```

These tests cover the getter and setter methods, equals and hashCode methods, and the toString method of the `SubitensVistoriaEntity` class. Make sure to adjust the test cases according to your specific requirements and add more tests if needed.