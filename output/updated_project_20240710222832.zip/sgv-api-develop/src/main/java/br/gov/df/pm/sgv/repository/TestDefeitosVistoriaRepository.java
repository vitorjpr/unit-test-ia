Here are some unit tests for the provided Java code:

```java
package br.gov.df.pm.sgv.repository;

import br.gov.df.pm.sgv.domain.DefeitosVistoriaEntity;
import br.gov.df.pm.sgv.domain.SubitemVistoriaEntity;
import br.gov.df.pm.sgv.domain.TipoDefeitoVistoriaEntity;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@DataJpaTest
public class DefeitosVistoriaRepositoryTest {

    @Autowired
    private DefeitosVistoriaRepository defeitosVistoriaRepository;

    @Mock
    private SubitemVistoriaEntity subitem;
    @Mock
    private TipoDefeitoVistoriaEntity tipoDefeito;

    @Test
    public void testFindAllByCodSubitem() {
        List<DefeitosVistoriaEntity> result = defeitosVistoriaRepository.findAllByCodSubitem(subitem);
        assertThat(result).isNotNull();
    }

    @Test
    public void testFindAllByCodTipoDefeito() {
        List<DefeitosVistoriaEntity> result = defeitosVistoriaRepository.findAllByCodTipoDefeito(tipoDefeito);
        assertThat(result).isNotNull();
    }

    @Test
    public void testFindByCodSubitemAndCodTipoDefeito() {
        Optional<DefeitosVistoriaEntity> result = defeitosVistoriaRepository.findByCodSubitemAndCodTipoDefeito(subitem, tipoDefeito);
        assertThat(result).isNotNull();
    }

    @Test
    public void testFindAllByCodSubitemAndAtivo() {
        List<DefeitosVistoriaEntity> result = defeitosVistoriaRepository.findAllByCodSubitemAndAtivo(subitem, true);
        assertThat(result).isNotNull();
    }
}
```

These tests cover the basic functionality of the `DefeitosVistoriaRepository` interface methods. Make sure to configure your testing environment properly to run these tests successfully.