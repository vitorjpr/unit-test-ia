package br.gov.df.pm.sgv.repository;

import br.gov.df.pm.sgv.domain.TipoVistoriaEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface TipoVistoriaRepository extends JpaRepository<TipoVistoriaEntity, Long>, JpaSpecificationExecutor<TipoVistoriaEntity> {
    Optional<TipoVistoriaEntity> findByNome(String nome);
    List<TipoVistoriaEntity> findAllByAtivo(Boolean ativo);
    List<TipoVistoriaEntity> findAllByStatusPosterior(String status);
}
