package br.gov.df.pm.sgv.dto;

import br.gov.df.pm.sgv.domain.TipoDefeitoVistoriaEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SubitemVistoriaDTO {
    private Long id;
    private String nome;
    private String descricao;
    private LocalDate dataInclusao;
    private Boolean ativo;
    private List<TipoDefeitoVistoriaEntity> defeitos;
}
