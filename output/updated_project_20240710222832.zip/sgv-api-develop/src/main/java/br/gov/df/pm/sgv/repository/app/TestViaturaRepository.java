Sure! Here are some unit tests for the `ViaturaRepository` interface:

```java
package br.gov.df.pm.sgv.repository.app;

import br.gov.df.pm.sgv.domain.ViaturaEntity;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
class ViaturaRepositoryTest {

    @Mock
    private JpaRepository<ViaturaEntity, Long> jpaRepository;

    @Mock
    private JpaSpecificationExecutor<ViaturaEntity> jpaSpecificationExecutor;

    @Test
    void testRepositoryNotNull() {
        ViaturaRepository viaturaRepository = new ViaturaRepository() {
            @Override
            public JpaRepository<ViaturaEntity, Long> getJpaRepository() {
                return jpaRepository;
            }

            @Override
            public JpaSpecificationExecutor<ViaturaEntity> getJpaSpecificationExecutor() {
                return jpaSpecificationExecutor;
            }
        };

        assertNotNull(viaturaRepository);
    }

    @Test
    void testJpaRepositoryNotNull() {
        ViaturaRepository viaturaRepository = new ViaturaRepository() {
            @Override
            public JpaRepository<ViaturaEntity, Long> getJpaRepository() {
                return jpaRepository;
            }

            @Override
            public JpaSpecificationExecutor<ViaturaEntity> getJpaSpecificationExecutor() {
                return jpaSpecificationExecutor;
            }
        };

        assertNotNull(viaturaRepository.getJpaRepository());
    }

    @Test
    void testJpaSpecificationExecutorNotNull() {
        ViaturaRepository viaturaRepository = new ViaturaRepository() {
            @Override
            public JpaRepository<ViaturaEntity, Long> getJpaRepository() {
                return jpaRepository;
            }

            @Override
            public JpaSpecificationExecutor<ViaturaEntity> getJpaSpecificationExecutor() {
                return jpaSpecificationExecutor;
            }
        };

        assertNotNull(viaturaRepository.getJpaSpecificationExecutor());
    }
}
```

These tests cover the basic functionality of the `ViaturaRepository` interface by ensuring that it is not null and that both `JpaRepository` and `JpaSpecificationExecutor` are not null as well.