package br.gov.df.pm.sgv.service.impl;

import br.gov.df.pm.sgv.domain.TipoEmpregoViaturaEntity;
import br.gov.df.pm.sgv.dto.TipoEmpregoViaturaDto;
import br.gov.df.pm.sgv.exceptions.TipoEmpregoViaturaException;
import br.gov.df.pm.sgv.mapper.TipoEmpregoMapper;
import br.gov.df.pm.sgv.repository.TipoEmpregoViaturaRepository;
import br.gov.df.pm.sgv.service.TipoEmpregoViaturaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class TipoEmpregoViaturaImpl implements TipoEmpregoViaturaService {

    @Autowired
    TipoEmpregoViaturaRepository tipoEmpregoViaturaRepository;

    @Override
    public List<TipoEmpregoViaturaDto> listTipoEmpregoViaturaAtivo() {

       List<TipoEmpregoViaturaEntity> tipoEmpregoViaturaEntities = tipoEmpregoViaturaRepository.findByAtivo(1);

       if(tipoEmpregoViaturaEntities.isEmpty()){
           throw new TipoEmpregoViaturaException("Não encontrou nenhum: Tipo Emprego Viatura Ativo");
       }
        List<TipoEmpregoViaturaDto> tipoEmpregoViaturaDtos = new ArrayList<>();

        tipoEmpregoViaturaEntities.forEach(tipoEmpregoViaturaEntity -> {
            tipoEmpregoViaturaDtos.add(new TipoEmpregoMapper().convertDTO(tipoEmpregoViaturaEntity));
        });

        return tipoEmpregoViaturaDtos;
    }
}
