Here are unit tests for the provided Java code using JUnit 5:

```java
package br.gov.df.pm.sgv.mapper;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.time.LocalDateTime;

import org.junit.jupiter.api.Test;

import br.gov.df.pm.sgv.dto.SubitemVistoriaDTO;
import br.gov.df.pm.sgv.domain.SubitemVistoriaEntity;

public class SubitemVistoriaMapperTest {

    @Test
    public void testConvertEntity() {
        SubitemVistoriaDTO dto = SubitemVistoriaDTO.builder()
                .nome("Teste")
                .descricao("Descrição de teste")
                .dataInclusao(LocalDateTime.now())
                .ativo(true)
                .build();

        SubitemVistoriaMapper mapper = new SubitemVistoriaMapper();
        SubitemVistoriaEntity entity = mapper.convertEntity(dto);

        assertNotNull(entity);
        assertEquals(dto.getNome(), entity.getNome());
        assertEquals(dto.getDescricao(), entity.getDescricao());
        assertEquals(dto.getDataInclusao(), entity.getDataInclusao());
        assertEquals(dto.getAtivo(), entity.getAtivo());
    }

    @Test
    public void testConvertDTO() {
        SubitemVistoriaEntity entity = SubitemVistoriaEntity.builder()
                .nome("Teste")
                .descricao("Descrição de teste")
                .dataInclusao(LocalDateTime.now())
                .ativo(true)
                .build();

        SubitemVistoriaMapper mapper = new SubitemVistoriaMapper();
        SubitemVistoriaDTO dto = mapper.convertDTO(entity);

        assertNotNull(dto);
        assertEquals(entity.getNome(), dto.getNome());
        assertEquals(entity.getDescricao(), dto.getDescricao());
        assertEquals(entity.getDataInclusao(), dto.getDataInclusao());
    }
}
```

These tests cover the conversion methods `convertEntity` and `convertDTO` in the `SubitemVistoriaMapper` class. The tests create sample DTO and Entity objects, then verify if the conversion is done correctly by comparing the attributes.