package br.gov.df.pm.sgv.repository.sgpol;

import br.gov.df.pm.sgv.domain.sgpol.UnidadePolicialMilitar;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface UnidadePolicialMilitarRepository extends JpaRepository<UnidadePolicialMilitar, Integer> {

	Optional<UnidadePolicialMilitar> findBySigla(String sigla);

	List<UnidadePolicialMilitar> findByAtivo(int ativo);

	Optional<UnidadePolicialMilitar> findByNomeIgnoreCase(String nome);

	List<UnidadePolicialMilitar> findAllByAtivoOrderBySigla(int ativo);

	Optional<UnidadePolicialMilitar> findById(int id);

	@Query("select p.upm from Policial p where p.matricula = ?1")
	UnidadePolicialMilitar findUnidadeByPolicial(String matricula);

//
//	String umpPolicial = "(select top 1 upp_Codigo from UPM_POLICIAL u1 where u1.pol_Codigo=pol.pol_Codigo \n"
//			+ "			 \"												and (upp.upp_DtApresentacao is null or upp.upp_DtApresentacao < getdate()) \n"
//			+ "			 \"													order by upp_DtApresentacao desc) ";
//
//
//
//	UnidadePolicialMilitar getOne(Integer id);
//

//
//	List<UnidadePolicialMilitar> findAllByOrderByIdSubordinacaoAsc();
//

//
//	@Override
//	List<UnidadePolicialMilitar> findAllComSubordinacao();
//
//	List<UnidadePolicialMilitar> findAllByAtivoOrderByNomeAsc(int ativo);
//
//	//String[] buscaHierarquia(String unidade);
//
//	List<UnidadePolicialMilitar> findByIdSubordinacaoIdAndAtivo(Integer id, int Ativo);
//
//	@Query(value = "select * from upm where upm.upm_Codigo = ?1", nativeQuery = true)
//	List<UnidadePolicialMilitar> buscarUnidadePorId(Integer id);
//
//	@Query(value = "select * from UPM u"
//			+ " inner join UPM_LOTACAO up on up.upm_Codigo = u.upm_Codigo"
//			+ " inner join LOTACAO lot on lot.lot_Codigo = up.lot_Codigo "
//			+ " where u.upm_Codigo = ?1"
//			+ " and up.upl_Ativo = 1 "
//			//+ " and lot.lot_PM_EM = 1 "
//			+ " order by up.upl_Codigo desc", nativeQuery = true)
//	UnidadePolicialMilitar buscarComSecoesAtivas(Integer idUPM);
//
//	@Query(value = "  select *from upm where upm_sigla like '%CCF%' "
//			+ " OR upm_sigla like '%CI%'  OR upm_sigla like '%APMB%' "
//			+ "  ORDER BY upm_nome ", nativeQuery = true)
//	List<UnidadePolicialMilitar> buscarComSecoesAtivasOrdenadasPorNome();
//
//
//	@Query(value = "select COUNT(pol.pol_Codigo) as totalPoliciais from UPM u"
//			+ " inner join UPM_POLICIAL up on up.upm_Codigo = u.upm_Codigo"
//			+ " inner join policial pol on pol.pol_Codigo = up.pol_Codigo"
//			+ " where u.upm_Codigo = ?1"
//			+ " and up.upp_Codigo in ("+umpPolicial+")"
//			+ " ", nativeQuery = true)
//	Integer qtdePoliciaisUnidade(Integer idUPM);
//
//
//	@Query(value = "select COUNT(pol.pol_Codigo) as totalPoliciais from UPM u"
//			+ " inner join UPM_POLICIAL up on up.upm_Codigo = u.upm_Codigo"
//			+ " inner join policial pol on pol.pol_Codigo = up.pol_Codigo"
//			+ " inner join restricao_porte res on res.pol_Codigo = pol.pol_Codigo"
//			+ " where u.upm_Codigo = ?1"
//			+ " and up.upp_Codigo in ("+umpPolicial+")"
//			+ " and res.rep_DtRestricaoFinal is null"
//			+ " ", nativeQuery = true)
//	Integer qtdePoliciaisPorteSuspensoUnidade(Integer idUPM);
//
//
//	@Query(value = "select COUNT(pol.pol_Codigo) as totalPoliciais from UPM u"
//			+ " inner join UPM_POLICIAL up on up.upm_Codigo = u.upm_Codigo"
//			+ " inner join policial pol on pol.pol_Codigo = up.pol_Codigo"
//			+ " inner join restricao_porte res on res.pol_Codigo = pol.pol_Codigo"
//			+ " where u.upm_Codigo = ?1"
//			+ " and up.upp_Codigo in ("+umpPolicial+")"
//			+ " and res.rep_DtRestricaoFinal is null"
//			+ " ", nativeQuery = true)
//	Integer qtdePoliciaisPorteSuspensoPmdf();
//
//
//	@Query(value = "select COUNT(pol.pol_Codigo) as totalPoliciais from UPM u"
//			+ " inner join UPM_POLICIAL up on up.upm_Codigo = u.upm_Codigo"
//			+ " inner join policial pol on pol.pol_Codigo = up.pol_Codigo"
//			+ " where u.upm_Codigo <> 28"
//			+ " and up.upp_Codigo in ("+umpPolicial+")"
//			+ " ", nativeQuery = true)
//	Integer qtdePoliciaisAtivos();
//
//	@Query(value = "select COUNT(pol.pol_Codigo) as totalPoliciais from UPM u"
//			+ " 	inner join UPM_POLICIAL up on up.upm_Codigo = u.upm_Codigo"
//			+ " 	inner join policial pol on pol.pol_Codigo = up.pol_Codigo"
//			+ " 	inner join restricao_porte res on res.pol_Codigo = pol.pol_Codigo"
//			+ " where u.upm_Codigo <> 28"
//			+ " and up.upp_Codigo in ("+umpPolicial+")"
//			+ " and rep_DtRestricaoInicial <= getDate() "
//			+ " and res.rep_DtRestricaoFinal is null"
//			+ " ", nativeQuery = true)
//	Integer qtdePoliciaisAtivosPorteSuspenso();
//
//	@Query(value = "select COUNT(pol.pol_Codigo) as totalPoliciais from UPM u"
//			+ " 	inner join UPM_POLICIAL up on up.upm_Codigo = u.upm_Codigo"
//			+ " 	inner join policial pol on pol.pol_Codigo = up.pol_Codigo"
//			+ " 	inner join restricao_porte res on res.pol_Codigo = pol.pol_Codigo"
//			+ " where "
//			+ " up.upp_Codigo in ("+umpPolicial+")"
//			+ " and rep_DtRestricaoInicial >= getDate() "
//			+ " and res.rep_DtRestricaoFinal is null"
//			+ " ", nativeQuery = true)
//	Integer qtdePoliciaisAtivosPorteSuspensoFuturo();
//
//
//	@Query(value = "select COUNT(pol.pol_Codigo) as totalPoliciais from UPM u"
//			+ " 	inner join UPM_POLICIAL up on up.upm_Codigo = u.upm_Codigo"
//			+ " 	inner join policial pol on pol.pol_Codigo = up.pol_Codigo"
//			+ " 	inner join restricao_porte res on res.pol_Codigo = pol.pol_Codigo"
//			+ " where u.upm_Codigo = 28"
//			+ " and up.upp_Codigo in ("+umpPolicial+") "
//			+ " and rep_DtRestricaoInicial <= getDate() "
//			+ " and res.rep_DtRestricaoFinal is null"
//			+ " ", nativeQuery = true)
//	Integer qtdePoliciaisInativosPorteSuspenso();
//
//
//
//

//
//	@Query(value = "select u.* from UPM u inner join TIPOUPM tu on tu.tiu_Codigo = u.tiu_Codigo where tu.tiu_Codigo = ?1", nativeQuery = true)
//	List<UnidadePolicialMilitar> findByTipoUnidade(int id);
//
//	@Query(value = "select * from UPM where upm_Ativo = 1 and upm_Nome like ?1", nativeQuery = true)
//	List<UnidadePolicialMilitar> buscarCPRs(String nome);
//
//
//	@Query(value = "select COUNT(pol.pol_Codigo) as totalPoliciais from UPM u"
//			+ " inner join UPM_POLICIAL up on up.upm_Codigo = u.upm_Codigo"
//			+ " inner join POLICIAL pol on pol.pol_Codigo = up.pol_Codigo"
//			+ " inner join UPM_LOTACAO upl on upl.upm_Codigo = up.upm_Codigo"
//			+ " inner join FUNCAO_UPM_LOTACAO fup on fup.upl_Codigo = upl.upl_Codigo"
//			+ " inner join FUNCAO fun on fun.fun_Codigo = fup.fun_Codigo"
//			+ " inner join ATIVIDADE at on at.atv_Codigo = fun.atv_Codigo"
//			+ " where at.atv_Codigo = ?1"
//			+ " and up.upp_Codigo in ("+umpPolicial+")"
//			+ " ", nativeQuery = true)
//	Integer qtdePoliciaisPorAtividade(int atividade);
//
//
//	@Query(value = "select COUNT(pol.pol_Codigo) as totalPoliciais from FUNCAO_UPM_LOTACAO_POLICIAL u"
//			+ " inner join POLICIAL pol on pol.pol_Codigo = u.pol_Codigo"
//			+ " inner join FUNCAO_UPM_LOTACAO fu on fu.fuu_Codigo = u.fuu_Codigo"
//			+ " inner join QUADRO_POSTOGRADUACAO_FUNCAO_UPM_LOTACAO qpf on qpf.fuu_Codigo = u.fuu_Codigo"
//			+ " inner join FUNCAO fun on fun.fun_Codigo = fu.fun_Codigo"
//			+ " inner join ATIVIDADE at on at.atv_Codigo = fun.atv_Codigo"
////			+ " inner join UPM_LOTACAO upl on upl.upm_Codigo = up.upm_Codigo"
////			+ " inner join FUNCAO_UPM_LOTACAO fup on fup.upl_Codigo = upl.upl_Codigo"
////			+ " inner join FUNCAO fun on fun.fun_Codigo = fup.fun_Codigo"
////			+ " inner join ATIVIDADE at on at.atv_Codigo = fun.atv_Codigo"
//			+ " where at.atv_Codigo = ?1"
//			+ " and u.fpo_DtFinalFuncao is null"
//			+ " ", nativeQuery = true)
//	Integer qtdePoliciaisPorAtividadeFuncao(int atividade);
//
//
//	Integer countByAtivoAndTipoId(int i, int j);
//
//
//
//	@Query(value = "with tabela1 as( select upm.upm_Sigla as upm,lot.lot_Sigla as lotacao, "+
//			"qfu.qfu_QtdPrevista as qtd,pgr.pgr_Sigla as patente "+
//			"from upm upm inner join upm_lotacao upl "+
//				"on upm.upm_Codigo = upl.upm_Codigo "+
//				"inner join FUNCAO_UPM_LOTACAO fuu "+
//				"on upl.upl_Codigo = fuu.upl_Codigo "+
//				"inner join QUADRO_POSTOGRADUACAO_FUNCAO_UPM_LOTACAO qfu "+
//				"on fuu.fuu_Codigo = qfu.fuu_Codigo "+
//				"inner join quadro_postograduacao qpg "+
//				"on qfu.qpg_Codigo = qpg.qpg_Codigo "+
//				"inner join POSTOGRADUACAO pgr "+
//				"on pgr.pgr_codigo = qpg.pgr_Codigo "+
//				"inner join LOTACAO lot "+
//				"on lot.lot_Codigo = upl.lot_Codigo "+
//				"where qpg.qpg_Codigo=?)"+
//			"select sum(qtd) as total,upm,lotacao,patente "+
//			"from tabela1 "+
//			"group by upm,lotacao,patente"+
//			" ",nativeQuery = true)
//	List<UnidadeQtdePrevistaDTO> buscaQtdePrevista(int qpg);
//
//	UnidadePolicialMilitar findByIdAndAtivo(Integer id, int i);
//
//	List<UnidadePolicialMilitar> findByUpmRecursosRecursoId(Integer id);
//
//	List<UnidadePolicialMilitar> findByAtivoAndTipoIdIn(int i, List<Integer> ids);
//
//	List<UnidadePolicialMilitar> findByAtivoOrderBySigla(int i);
//
//	List<UnidadePolicialMilitar> findByTipoAndAtivo(int i, int j);
//
//	List<UnidadePolicialMilitar> findByAtivoAndTipoId(int i, int j);
//
//	List<UnidadePolicialMilitar> findAllByAtivoAndTipoIdInOrderByNomeAsc(int i, List<Integer> tipo);
//
//
}
