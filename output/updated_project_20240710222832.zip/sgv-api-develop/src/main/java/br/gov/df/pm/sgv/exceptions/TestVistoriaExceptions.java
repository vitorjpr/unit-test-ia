```java
import org.junit.Test;
import static org.junit.Assert.*;

public class VistoriaExceptionsTest {

    @Test
    public void testConstructorWithoutArguments() {
        VistoriaExceptions exception = new VistoriaExceptions();
        assertNull(exception.getMessage());
        assertNull(exception.getCause());
    }

    @Test
    public void testConstructorWithMessage() {
        String message = "Test message";
        VistoriaExceptions exception = new VistoriaExceptions(message);
        assertEquals(message, exception.getMessage());
        assertNull(exception.getCause());
    }

    @Test
    public void testConstructorWithMessageAndCause() {
        String message = "Test message";
        Throwable cause = new RuntimeException("Test cause");
        VistoriaExceptions exception = new VistoriaExceptions(message, cause);
        assertEquals(message, exception.getMessage());
        assertEquals(cause, exception.getCause());
    }
}
``` 

Estes são os testes unitários para a classe `VistoriaExceptions`. Eles cobrem os três construtores da classe e garantem que a mensagem e a causa sejam configuradas corretamente.