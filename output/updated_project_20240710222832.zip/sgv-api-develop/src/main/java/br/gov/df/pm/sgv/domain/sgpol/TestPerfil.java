```java
package br.gov.df.pm.sgv.domain.sgpol;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

public class PerfilTest {

    private final ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
    private final Validator validator = factory.getValidator();

    @Test
    public void testIdGetterAndSetter() {
        Perfil perfil = new Perfil();
        perfil.setId(1);
        assertEquals(1, perfil.getId());
    }

    @Test
    public void testAtivoGetterAndSetter() {
        Perfil perfil = new Perfil();
        perfil.setAtivo(1);
        assertEquals(1, perfil.getAtivo());
    }

    @Test
    public void testNomeGetterAndSetter() {
        Perfil perfil = new Perfil();
        perfil.setNome("Teste");
        assertEquals("Teste", perfil.getNome());
    }

    @Test
    public void testDescricaoGetterAndSetter() {
        Perfil perfil = new Perfil();
        perfil.setDescricao("Descrição teste");
        assertEquals("Descrição teste", perfil.getDescricao());
    }

    @Test
    public void testNomeNotBlankValidation() {
        Perfil perfil = new Perfil();
        perfil.setNome("");
        assertFalse(validator.validate(perfil).isEmpty());
    }

    @Test
    public void testHashCode() {
        Perfil perfil1 = new Perfil();
        perfil1.setId(1);

        Perfil perfil2 = new Perfil();
        perfil2.setId(1);

        assertEquals(perfil1.hashCode(), perfil2.hashCode());
    }

    @Test
    public void testEquals() {
        Perfil perfil1 = new Perfil();
        perfil1.setId(1);

        Perfil perfil2 = new Perfil();
        perfil2.setId(1);

        assertTrue(perfil1.equals(perfil2));
    }

    @Test
    public void testToString() {
        Perfil perfil = new Perfil();
        perfil.setId(1);
        perfil.setAtivo(1);
        perfil.setNome("Teste");
        perfil.setDescricao("Descrição teste");

        String expected = "Perfil [id=1, ativo=1, nome=Teste, descricao=Descrição teste, pessoaPerfils=null, listPerfilRecurso=null, totalPessoasPorPerfil=0]";
        assertEquals(expected, perfil.toString());
    }
}
``` 

Esses são alguns testes unitários básicos para a classe `Perfil`. Certifique-se de adicionar mais testes de acordo com a lógica de negócios e validações específicas do seu sistema.