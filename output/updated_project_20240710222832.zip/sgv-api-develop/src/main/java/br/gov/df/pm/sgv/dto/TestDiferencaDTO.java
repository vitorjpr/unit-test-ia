Sure! Here are some unit tests for the given Java code using JUnit 5:

```java
package br.gov.df.pm.sgv.dto;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class DiferencaDTOTest {

    @Test
    public void testGetSetIdViatura() {
        DiferencaDTO dto = new DiferencaDTO();
        Long idViatura = 123L;
        dto.setIdViatura(idViatura);
        assertEquals(idViatura, dto.getIdViatura());
    }

    @Test
    public void testGetSetUltimoOdometro() {
        DiferencaDTO dto = new DiferencaDTO();
        Float ultimoOdometro = 100.5f;
        dto.setUltimoOdometro(ultimoOdometro);
        assertEquals(ultimoOdometro, dto.getUltimoOdometro());
    }

    @Test
    public void testGetSetTipoVistoria() {
        DiferencaDTO dto = new DiferencaDTO();
        TipoVistoriaDTO tipoVistoria = new TipoVistoriaDTO();
        dto.setTipoVistoria(tipoVistoria);
        assertEquals(tipoVistoria, dto.getTipoVistoria());
    }
}
```

Make sure to have the necessary imports for JUnit 5 in your test class. These tests cover the getter and setter methods for the `idViatura`, `ultimoOdometro`, and `tipoVistoria` fields in the `DiferencaDTO` class.