package br.gov.df.pm.sgv.service.impl;

import br.gov.df.pm.sgv.dto.EdicaoTipoDefeitoVistoriaDTO;
import br.gov.df.pm.sgv.dto.TipoDefeitoVistoriaDTO;
import br.gov.df.pm.sgv.domain.TipoDefeitoVistoriaEntity;
import br.gov.df.pm.sgv.exceptions.TipoDefeitoVistoriaException;
import br.gov.df.pm.sgv.exceptions.VistoriaExceptions;
import br.gov.df.pm.sgv.mapper.TipoDefeitoVistoriaMapper;
import br.gov.df.pm.sgv.mapper.TipoVistoriaMapper;
import br.gov.df.pm.sgv.repository.DefeitosVistoriaRepository;
import br.gov.df.pm.sgv.repository.TipoDefeitoVistoriaRepository;
import br.gov.df.pm.sgv.service.TipoDefeitoVistoriaService;
import br.gov.df.pm.sgv.shared.utils.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.thymeleaf.util.ListUtils;

import javax.persistence.criteria.Predicate;
import java.util.ArrayList;
import java.util.List;

@Service
public class TipoDefeitoVistoriaServiceImpl implements TipoDefeitoVistoriaService {

    @Autowired
    TipoDefeitoVistoriaRepository repository;
    @Autowired
    DefeitosVistoriaRepository defeitosRepository;

    @Override
    public ResponseEntity<TipoDefeitoVistoriaDTO> buscarId(Long id) {
        return ResponseEntity.ok(new TipoDefeitoVistoriaMapper().convertDTO(findById(id)));
    }

    @Override
    public Page<TipoDefeitoVistoriaEntity> buscar(String filter, Pageable pageable) {
        return repository.findAll(filtroToSpecification(filter), pageable);
    }

    private Specification<TipoDefeitoVistoriaEntity> filtroToSpecification(String filtro) {
        return (root, query, builder) -> {
            if (!StringUtils.isEmptyOrNull(filtro)) {
            var predications = new ArrayList<Predicate>();
            predications.add(builder.like(root.get("nome"),"%" + filtro + "%"));
            predications.add(builder.like(root.get("descricao"),"%" + filtro + "%"));
            return builder.or(predications.toArray(Predicate[]::new));
        }
        return null;
    };
    }

    @Override
    public ResponseEntity<?> salvar(TipoDefeitoVistoriaDTO tipoDefeito) {
        if(StringUtils.isEmptyOrNull(tipoDefeito.getNome()) || repository.findByNome(tipoDefeito.getNome()).isPresent()) {
            throw new VistoriaExceptions("Tipo Defeito já cadastrado no sistema.");
        }
        return ResponseEntity.ok(repository.save(new TipoDefeitoVistoriaMapper().convertEntity(tipoDefeito)));
    }

    @Override
    public ResponseEntity<?> editar(Long id, EdicaoTipoDefeitoVistoriaDTO edicao) {
        if(repository.findByNome(edicao.getNome()).isPresent()) {
            throw new VistoriaExceptions("Subitem já cadastrado no sistema.");
        }
        var tipoDefeito = findById(id);
        if (!StringUtils.isEmptyOrNull(edicao.getNome())) {
            tipoDefeito.setNome(edicao.getNome());
        }
        if (!StringUtils.isEmptyOrNull(edicao.getDescricao())) {
            tipoDefeito.setDescricao(edicao.getDescricao());
        }
        return ResponseEntity.ok(repository.save(tipoDefeito));
    }

    @Override
    public ResponseEntity<?> desativar(Long id) {
        var tipoDefeito = findById(id);
        var subitens = defeitosRepository.findAllByCodTipoDefeito(tipoDefeito);
        if(!ListUtils.isEmpty(subitens)) {
            throw new VistoriaExceptions("Não é possível remover o Tipo Defeito, há (" + ListUtils.size(subitens) + ") sendo utilizado(s) em Subitem(s).");
        }
        tipoDefeito.setAtivo(false);
        repository.save(tipoDefeito);
        return ResponseEntity.ok().build();
    }

    @Override
    public ResponseEntity<?> excluir(Long id) {
        var tipoDefeito = findById(id);
        var subitens = defeitosRepository.findAllByCodTipoDefeito(tipoDefeito);
        if(!ListUtils.isEmpty(subitens)) {
            throw new VistoriaExceptions("Não é possível excluir o Tipo Defeito, há (" + ListUtils.size(subitens) + ") sendo utilizado(s) em Subitem(s).");
        }
        repository.delete(tipoDefeito);
        return ResponseEntity.ok().build();
    }

    @Override
    public ResponseEntity<?> ativar(Long id) {
        var tipoDefeito = findById(id);
        tipoDefeito.setAtivo(true);
        repository.save(tipoDefeito);
        return ResponseEntity.ok().build();
    }

    @Override
    public List<TipoDefeitoVistoriaDTO> listAllAtivos() {
       List<TipoDefeitoVistoriaEntity> tipoDefeitoVistoriaEntities = repository.findAll();

       if(tipoDefeitoVistoriaEntities.isEmpty()){
           throw new TipoDefeitoVistoriaException("Nenhum tipo de defeito de vistoria encontrado.");
       }
       List<TipoDefeitoVistoriaDTO> tipoDefeitoVistoriaDTOS = new ArrayList<>();
       tipoDefeitoVistoriaEntities.forEach(tipoDefeitoVistoriaEntity -> {
           if(tipoDefeitoVistoriaEntity.getAtivo()){
               tipoDefeitoVistoriaDTOS.add(new TipoDefeitoVistoriaMapper().convertDTO(tipoDefeitoVistoriaEntity));
           }

       });
        return tipoDefeitoVistoriaDTOS;
    }

    private TipoDefeitoVistoriaEntity findById(Long id) {
        return repository.findById(id).orElseThrow();
    }
}
