package br.gov.df.pm.sgv.dto;

import br.gov.df.pm.sgv.domain.TipoVistoriaEntity;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;


@Data
@Builder
public class FiltroVistoria {
    private String prefixo;
    private String placa;
    private Long tipoVistoria;
    private LocalDateTime dataInicio;
    private LocalDateTime dataFim;
    private int unidade;
}
