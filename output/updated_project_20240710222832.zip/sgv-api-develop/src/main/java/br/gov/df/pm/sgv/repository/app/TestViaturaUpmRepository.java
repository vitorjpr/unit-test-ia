Here are some unit tests for the `ViaturaUpmRepository` interface using JUnit and Mockito:

```java
package br.gov.df.pm.sgv.repository.app;

import br.gov.df.pm.sgv.domain.ViaturaUpmEntity;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
public class ViaturaUpmRepositoryTest {

    @Mock
    private JpaRepository<ViaturaUpmEntity, Long> jpaRepositoryMock;

    @Mock
    private JpaSpecificationExecutor<ViaturaUpmEntity> jpaSpecificationExecutorMock;

    private ViaturaUpmRepository viaturaUpmRepository;

    @Test
    public void testRepositoryNotNull() {
        viaturaUpmRepository = new ViaturaUpmRepository(jpaRepositoryMock, jpaSpecificationExecutorMock);
        assertNotNull(viaturaUpmRepository);
    }

    @Test
    public void testJpaRepositoryMethods() {
        viaturaUpmRepository = new ViaturaUpmRepository(jpaRepositoryMock, jpaSpecificationExecutorMock);
        viaturaUpmRepository.findAll();
        verify(jpaRepositoryMock).findAll();
        // Add more test cases for other JpaRepository methods if needed
    }

    @Test
    public void testJpaSpecificationExecutorMethods() {
        viaturaUpmRepository = new ViaturaUpmRepository(jpaRepositoryMock, jpaSpecificationExecutorMock);
        viaturaUpmRepository.findAll((root, query, criteriaBuilder) -> null);
        verify(jpaSpecificationExecutorMock).findAll((root, query, criteriaBuilder) -> null);
        // Add more test cases for other JpaSpecificationExecutor methods if needed
    }
}
```

Make sure to include the necessary dependencies in your project for JUnit and Mockito to run these tests successfully. These tests cover the initialization of the repository, as well as the invocation of methods inherited from `JpaRepository` and `JpaSpecificationExecutor`. Feel free to add more test cases based on specific requirements or additional methods you may want to test.