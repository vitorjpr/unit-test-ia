package br.gov.df.pm.sgv.repository;

import br.gov.df.pm.sgv.domain.SubitemVistoriaEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface SubitemVistoriaRepository extends JpaRepository<SubitemVistoriaEntity, Long>, JpaSpecificationExecutor<SubitemVistoriaEntity> {
    Optional<SubitemVistoriaEntity> findByNome(String nome);
}
