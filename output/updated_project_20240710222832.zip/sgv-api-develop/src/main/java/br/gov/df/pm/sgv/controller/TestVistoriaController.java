```java
package br.gov.df.pm.sgv.controller;

import br.gov.df.pm.sgv.assembler.app.VistoriaAssembler;
import br.gov.df.pm.sgv.domain.VistoriaArquivo;
import br.gov.df.pm.sgv.domain.VistoriaViaturaEntity;
import br.gov.df.pm.sgv.domain.sgpol.Policial;
import br.gov.df.pm.sgv.domain.sgpol.UnidadePolicialMilitar;
import br.gov.df.pm.sgv.dto.FiltroVistoria;
import br.gov.df.pm.sgv.dto.ViaturaDTO;
import br.gov.df.pm.sgv.dto.VistoriaDTO;
import br.gov.df.pm.sgv.service.VistoriaService;
import br.gov.df.pm.sgv.service.sgpol.PolicialService;
import br.gov.df.pm.sgv.service.sgpol.UnidadePolicialMilitarService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import io.swagger.v3.oas.annotations.media.Schema;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.PagedModel;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class VistoriaControllerTest {

    @Mock
    private VistoriaService vistoriaService;
    @Mock
    private VistoriaAssembler vistoriaAssembler;
    @Mock
    private PolicialService policialService;
    @Mock
    private UnidadePolicialMilitarService unidadePolicialMilitarService;
    @Mock
    private PagedResourcesAssembler<VistoriaViaturaEntity> pagedResourcesAssembler;

    private VistoriaController vistoriaController;

    @BeforeEach
    void setUp() {
        vistoriaController = new VistoriaController(vistoriaService, vistoriaAssembler, policialService, unidadePolicialMilitarService, pagedResourcesAssembler);
    }

    @Test
    void buscar_ReturnsPagedModelOfVistoriaDTO() {
        FiltroVistoria filtro = new FiltroVistoria();
        Pageable pageable = PageRequest.of(0, 10, Sort.by(Sort.Direction.DESC, "id"));
        List<VistoriaViaturaEntity> vistorias = new ArrayList<>();
        vistorias.add(new VistoriaViaturaEntity());
        when(vistoriaService.buscar(filtro, pageable)).thenReturn(new PageImpl<>(vistorias));

        PagedModel<EntityModel<VistoriaDTO>> result = vistoriaController.buscar(filtro, pageable);

        assertEquals(1, result.getContent().size());
        verify(pagedResourcesAssembler, times(1)).toModel(any());
    }

    @Test
    void salvar_ReturnsResponseEntityOfVistoriaViaturaEntity() {
        String vistoria = "vistoria";
        List<MultipartFile> arquivos = new ArrayList<>();
        ResponseEntity<VistoriaViaturaEntity> expectedResponse = ResponseEntity.ok(new VistoriaViaturaEntity());
        when(vistoriaService.salvar(vistoria, arquivos)).thenReturn(expectedResponse);

        ResponseEntity<VistoriaViaturaEntity> result = vistoriaController.salvar(vistoria, arquivos);

        assertEquals(expectedResponse, result);
    }

    // Add more test cases for the remaining controller methods as needed

}
```

Este é um exemplo básico de testes unitários para o `VistoriaController`. Você pode adicionar mais casos de teste para cobrir todos os métodos do controlador. Certifique-se de adicionar importações necessárias e implementar os testes de acordo com a lógica de negócios de cada método.