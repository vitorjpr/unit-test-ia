```java
package br.gov.df.pm.sgv.security;

import br.gov.df.pm.sgv.domain.sgpol.Policial;
import br.gov.df.pm.sgv.domain.sgpol.UnidadePolicialMilitar;
import br.gov.df.pm.sgv.dto.root.PerfilDTO;
import br.gov.df.pm.sgv.dto.root.RecursoDTO;
import br.gov.df.pm.sgv.service.sgpol.PolicialService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import java.security.Principal;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class UserProviderImplTest {

    @Mock
    private PolicialService policialService;

    @InjectMocks
    private UserProviderImpl userProvider;

    @BeforeEach
    void setUp() {
        userProvider = new UserProviderImpl(policialService);
    }

    @Test
    void testGetPerfisPolicialAutenticado() {
        // Mocking
        when(policialService.getPerfilDtoPolicialAutenticado(anyString())).thenReturn(Arrays.asList(new PerfilDTO()));

        // Test
        List<PerfilDTO> perfis = userProvider.getPerfisPolicialAutenticado();

        // Assertions
        assertNotNull(perfis);
        assertEquals(1, perfis.size());
    }

    @Test
    void testGetPolicialAutenticado() {
        // Mocking
        when(policialService.findPolicialByPessoaMatricula(anyString())).thenReturn(new Policial());

        // Test
        Policial policial = userProvider.getPolicialAutenticado();

        // Assertions
        assertNotNull(policial);
    }

    @Test
    void testGetRecursosPolicialAutenticado() {
        // Mocking
        when(policialService.getRecursoDtoPolicialAutenticado(anyString())).thenReturn(Arrays.asList(new RecursoDTO()));

        // Test
        List<RecursoDTO> recursos = userProvider.getRecursosPolicialAutenticado();

        // Assertions
        assertNotNull(recursos);
        assertEquals(1, recursos.size());
    }

    @Test
    void testGetUnidadePolicialAutenticado() {
        // Mocking
        when(policialService.getUnidadePolicialAutenticado(anyString())).thenReturn(new UnidadePolicialMilitar());

        // Test
        UnidadePolicialMilitar unidade = userProvider.getUnidadePolicialAutenticado();

        // Assertions
        assertNotNull(unidade);
    }

    @Test
    void testPossuiRecursos() {
        // Mocking
        when(policialService.getRecursoDtoPolicialAutenticado(anyString())).thenReturn(Arrays.asList(new RecursoDTO("recurso1")));

        // Test
        boolean possuiRecurso = userProvider.possuiRecursos("recurso1", "recurso2");

        // Assertions
        assertTrue(possuiRecurso);

        // Test with non-existing resource
        boolean naoPossuiRecurso = userProvider.possuiRecursos("recurso2");

        // Assertions
        assertFalse(naoPossuiRecurso);
    }

    // Additional test cases can be added for edge cases and error scenarios
}
```

Esses testes unitários cobrem os métodos da classe `UserProviderImpl` e utilizam o framework Mockito para mockar o serviço `PolicialService`. Certifique-se de ajustar os imports conforme necessário e adicionar mais casos de teste conforme a complexidade do código.