package br.gov.df.pm.sgv.assembler;

import br.gov.df.pm.sgv.dto.TipoDefeitoVistoriaDTO;
import br.gov.df.pm.sgv.domain.TipoDefeitoVistoriaEntity;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.RepresentationModelAssembler;
import org.springframework.stereotype.Component;

@Component
public class TipoDefeitoVistoriaAssembler implements RepresentationModelAssembler<TipoDefeitoVistoriaEntity, EntityModel<TipoDefeitoVistoriaDTO>> {
    @Override
    public EntityModel<TipoDefeitoVistoriaDTO> toModel(TipoDefeitoVistoriaEntity entity) {
        return EntityModel.of(TipoDefeitoVistoriaDTO.builder()
                .id(entity.getId())
                .nome(entity.getNome())
                .descricao(entity.getDescricao())
                .dataInclusao(entity.getDataInclusao())
                .ativo(entity.getAtivo())
                .build());
    }
}
