package br.gov.df.pm.sgv.security;

import br.gov.df.pm.sgv.domain.sgpol.Policial;
import br.gov.df.pm.sgv.domain.sgpol.UnidadePolicialMilitar;
import br.gov.df.pm.sgv.dto.root.PerfilDTO;
import br.gov.df.pm.sgv.dto.root.RecursoDTO;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public interface UserProvider {

   Policial getPolicialAutenticado();

   List<RecursoDTO> getRecursosPolicialAutenticado();

   List<PerfilDTO> getPerfisPolicialAutenticado();

   Boolean possuiRecursos(String... args);

   UnidadePolicialMilitar getUnidadePolicialAutenticado();
}