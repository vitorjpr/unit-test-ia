Sure! Here are the unit tests for the provided Java code:

```java
package br.gov.df.pm.sgv.configurations;

import org.hibernate.boot.model.naming.PhysicalNamingStrategy;
import org.junit.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import static org.junit.Assert.*;

public class PersistenceSgpolAutoConfigurationTest {

    @Test
    public void testPhysicalNamingStrategyBeanCreation() {
        // Given
        PersistenceSgpolAutoConfiguration configuration = new PersistenceSgpolAutoConfiguration();
        
        // When
        PhysicalNamingStrategy physicalNamingStrategy = configuration.physicalNamingStrategy();
        
        // Then
        assertNotNull(physicalNamingStrategy);
        assertTrue(physicalNamingStrategy instanceof MultitenancyDbNamingStrategy);
    }

    @Test
    public void testPhysicalNamingStrategyBeanRegisteredInContext() {
        // Given
        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
        context.register(PersistenceSgpolAutoConfiguration.class);
        context.refresh();
        
        // When
        PhysicalNamingStrategy physicalNamingStrategy = context.getBean(PhysicalNamingStrategy.class);
        
        // Then
        assertNotNull(physicalNamingStrategy);
        assertTrue(physicalNamingStrategy instanceof MultitenancyDbNamingStrategy);
    }
}
```

These tests cover the creation of the `PhysicalNamingStrategy` bean and its registration in the Spring application context. Make sure to add the necessary imports for the test class. Let me know if you need any further assistance!