Sure! Here are the unit tests for the `AppConfig` class in the provided Java code:

```java
package br.gov.df.pm.sgv.configurations;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.Test;
import org.springframework.web.client.RestTemplate;

public class AppConfigTest {

    @Test
    public void testRestTemplateBeanCreation() {
        AppConfig appConfig = new AppConfig();
        RestTemplate restTemplate = appConfig.restTemplate();
        assertNotNull(restTemplate);
    }

    @Test
    public void testRestTemplateBeanType() {
        AppConfig appConfig = new AppConfig();
        RestTemplate restTemplate = appConfig.restTemplate();
        assertTrue(restTemplate instanceof RestTemplate);
    }
}
```

Make sure to include the necessary imports in your test file:

```java
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.Test;
import org.springframework.web.client.RestTemplate;
```

These tests ensure that the `restTemplate` method in the `AppConfig` class creates a non-null `RestTemplate` instance and that the type of the returned object is indeed `RestTemplate`.