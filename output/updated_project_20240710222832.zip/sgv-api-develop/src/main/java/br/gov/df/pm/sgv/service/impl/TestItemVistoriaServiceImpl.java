```java
package br.gov.df.pm.sgv.service.impl;

import br.gov.df.pm.sgv.dto.EdicaoItemVistoriaDTO;
import br.gov.df.pm.sgv.dto.ItemVistoriaDTO;
import br.gov.df.pm.sgv.dto.ItemVistoriaOcorrenciaDTO;
import br.gov.df.pm.sgv.dto.OcorrenciasDTO;
import br.gov.df.pm.sgv.dto.SubitemVistoriaDTO;
import br.gov.df.pm.sgv.entity.ItemVistoriaEntity;
import br.gov.df.pm.sgv.entity.ItensVistoriaEntity;
import br.gov.df.pm.sgv.entity.SubitemVistoriaEntity;
import br.gov.df.pm.sgv.entity.SubitensVistoriaEntity;
import br.gov.df.pm.sgv.entity.TipoDefeitoVistoriaEntity;
import br.gov.df.pm.sgv.entity.TipoVistoriaEntity;
import br.gov.df.pm.sgv.exceptions.ItemVistoriaException;
import br.gov.df.pm.sgv.exceptions.VistoriaExceptions;
import br.gov.df.pm.sgv.mapper.ItemVistoriaMapper;
import br.gov.df.pm.sgv.repository.DefeitosVistoriaRepository;
import br.gov.df.pm.sgv.repository.ItemVistoriaRepository;
import br.gov.df.pm.sgv.repository.ItensVistoriaRepository;
import br.gov.df.pm.sgv.repository.SubitemVistoriaRepository;
import br.gov.df.pm.sgv.repository.SubitensVistoriaRepository;
import br.gov.df.pm.sgv.service.TipoVistoriaService;
import br.gov.df.pm.sgv.shared.utils.StringUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

public class ItemVistoriaServiceImplTest {

    @InjectMocks
    private ItemVistoriaServiceImpl itemVistoriaService;

    @Mock
    private ItemVistoriaRepository itemVistoriaRepository;

    @Mock
    private SubitemVistoriaRepository subitemVistoriaRepository;

    @Mock
    private SubitensVistoriaRepository subitensVistoriaRepository;

    @Mock
    private TipoVistoriaService tipoVistoriaService;

    @Mock
    private DefeitosVistoriaRepository defeitosVistoriaRepository;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testBuscarId() {
        Long id = 1L;
        ItemVistoriaEntity itemVistoriaEntity = new ItemVistoriaEntity();
        itemVistoriaEntity.setId(id);

        when(itemVistoriaRepository.findById(id)).thenReturn(java.util.Optional.of(itemVistoriaEntity));

        ResponseEntity<ItemVistoriaDTO> response = itemVistoriaService.buscarId(id);

        assertEquals(itemVistoriaEntity.getId(), response.getBody().getId());
    }

    // Add more tests for other methods as needed

    @Test
    public void testSalvar() {
        ItemVistoriaDTO itemVistoriaDTO = new ItemVistoriaDTO();
        itemVistoriaDTO.setNome("Test Item");
        itemVistoriaDTO.setSubitens(new ArrayList<>());

        ItemVistoriaEntity itemVistoriaEntity = new ItemVistoriaEntity();
        itemVistoriaEntity.setId(1L);
        itemVistoriaEntity.setNome("Test Item");

        when(itemVistoriaRepository.findByNome("Test Item")).thenReturn(java.util.Optional.empty());
        when(itemVistoriaRepository.save(Mockito.any(ItemVistoriaEntity.class))).thenReturn(itemVistoriaEntity);

        ResponseEntity<?> response = itemVistoriaService.salvar(itemVistoriaDTO);

        assertEquals(itemVistoriaEntity.getId(), ((ItemVistoriaEntity) response.getBody()).getId());
    }

    @Test
    public void testSalvarDuplicateItem() {
        ItemVistoriaDTO itemVistoriaDTO = new ItemVistoriaDTO();
        itemVistoriaDTO.setNome("Test Item");

        when(itemVistoriaRepository.findByNome("Test Item")).thenReturn(java.util.Optional.of(new ItemVistoriaEntity()));

        assertThrows(VistoriaExceptions.class, () -> itemVistoriaService.salvar(itemVistoriaDTO));
    }

    @Test
    public void testEditar() {
        Long id = 1L;
        EdicaoItemVistoriaDTO edicaoItemVistoriaDTO = new EdicaoItemVistoriaDTO();
        edicaoItemVistoriaDTO.setNome("Updated Item");

        ItemVistoriaEntity itemVistoria