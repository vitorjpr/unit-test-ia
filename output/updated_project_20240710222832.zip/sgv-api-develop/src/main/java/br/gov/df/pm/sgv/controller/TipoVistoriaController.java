package br.gov.df.pm.sgv.controller;

import br.gov.df.pm.sgv.assembler.TipoVistoriaAssembler;
import br.gov.df.pm.sgv.dto.EdicaoTipoVistoriaDTO;
import br.gov.df.pm.sgv.dto.TipoVistoriaDTO;
import br.gov.df.pm.sgv.domain.*;
import br.gov.df.pm.sgv.service.TipoVistoriaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.PagedModel;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/vistoria/tipovistoria")
public class TipoVistoriaController {

    @Autowired
    private final TipoVistoriaService service;
    @Autowired
    private final TipoVistoriaAssembler tipoVistoriaAssembler;
    @Autowired
    private final PagedResourcesAssembler<TipoVistoriaEntity> pagedResourcesAssembler;

    public TipoVistoriaController(TipoVistoriaService service,
                                  TipoVistoriaAssembler tipoVistoriaAssembler,
                                  PagedResourcesAssembler<TipoVistoriaEntity> pagedResourcesAssembler) {
        this.service = service;
        this.tipoVistoriaAssembler = tipoVistoriaAssembler;
        this.pagedResourcesAssembler = pagedResourcesAssembler;
    }

    @GetMapping("/buscar/{id}")
    public ResponseEntity<?> buscarId(@PathVariable("id") Long id) {
        return service.buscarId(id);
    }

    @GetMapping("/findAllItensVistoria")
    public ResponseEntity<List<ItensVistoriaEntity>> findAllItensVistoria() {
        return service.findAllItensVistoria();
    }

    @GetMapping("/buscar")
    public PagedModel<EntityModel<TipoVistoriaDTO>> buscar(String filter, Pageable pageable) {
        var result = pagedResourcesAssembler.toModel(service.buscar(filter, pageable));
        return PagedModel.of(result.getContent().stream().map(e ->
                tipoVistoriaAssembler.toModel(Objects.requireNonNull(e.getContent()))).collect(Collectors.toList()), result.getMetadata());
    }

    @PostMapping("/salvar")
    public ResponseEntity<?> salvar(@RequestBody TipoVistoriaDTO tipoVistoria) {
        return service.salvar(tipoVistoria);
    }

    @PutMapping("/editar/{id}")
    public ResponseEntity<?> editar(@PathVariable("id") Long id, @RequestBody EdicaoTipoVistoriaDTO edicao) {
        return service.editar(id, edicao);
    }

    @DeleteMapping("/excluir/{id}")
    public ResponseEntity<?> excluir(@PathVariable("id") Long id) {
        return service.excluir(id);
    }

    @DeleteMapping("/desativar/{id}")
    public ResponseEntity<?> desativar(@PathVariable("id") Long id) {
        return service.desativar(id);
    }

    @PostMapping("/ativar/{id}")
    public ResponseEntity<?> ativar(@PathVariable("id") Long id) {
        return service.ativar(id);
    }

    @GetMapping("/findAllItemVistoriaById/{nome}")
    public ResponseEntity<List<ItemVistoriaEntity>> findAllItemVistoriaById(@PathVariable("nome") String nome) {
        return service.findAllItemVistoriaById(nome);
    }

    @GetMapping("/findAllItemVistoria")
    public ResponseEntity<List<ItemVistoriaEntity>> findAllItemVistoria() {
        return service.findAllItemVistoria();
    }
}
