```java
package br.gov.df.pm.sgv.repository.sgpol;

import br.gov.df.pm.sgv.domain.sgpol.UnidadePolicialMilitar;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class UnidadePolicialMilitarRepositoryTest {

    @InjectMocks
    private UnidadePolicialMilitarRepository upmRepository;

    @Mock
    private JpaRepository<UnidadePolicialMilitar, Integer> jpaRepository;

    @Test
    public void testFindBySigla() {
        String sigla = "SIGLA";
        UnidadePolicialMilitar upm = new UnidadePolicialMilitar();
        when(upmRepository.findBySigla(sigla)).thenReturn(Optional.of(upm));
        Optional<UnidadePolicialMilitar> result = upmRepository.findBySigla(sigla);
        assertEquals(upm, result.get());
    }

    @Test
    public void testFindByAtivo() {
        int ativo = 1;
        List<UnidadePolicialMilitar> upmList = List.of(new UnidadePolicialMilitar(), new UnidadePolicialMilitar());
        when(upmRepository.findByAtivo(ativo)).thenReturn(upmList);
        List<UnidadePolicialMilitar> result = upmRepository.findByAtivo(ativo);
        assertEquals(2, result.size());
    }

    @Test
    public void testFindByNomeIgnoreCase() {
        String nome = "Nome";
        UnidadePolicialMilitar upm = new UnidadePolicialMilitar();
        when(upmRepository.findByNomeIgnoreCase(nome)).thenReturn(Optional.of(upm));
        Optional<UnidadePolicialMilitar> result = upmRepository.findByNomeIgnoreCase(nome);
        assertEquals(upm, result.get());
    }

    @Test
    public void testFindAllByAtivoOrderBySigla() {
        int ativo = 1;
        List<UnidadePolicialMilitar> upmList = List.of(new UnidadePolicialMilitar(), new UnidadePolicialMilitar());
        when(upmRepository.findAllByAtivoOrderBySigla(ativo)).thenReturn(upmList);
        List<UnidadePolicialMilitar> result = upmRepository.findAllByAtivoOrderBySigla(ativo);
        assertEquals(2, result.size());
    }

    @Test
    public void testFindUnidadeByPolicial() {
        String matricula = "MATRICULA";
        UnidadePolicialMilitar upm = new UnidadePolicialMilitar();
        when(upmRepository.findUnidadeByPolicial(matricula)).thenReturn(upm);
        UnidadePolicialMilitar result = upmRepository.findUnidadeByPolicial(matricula);
        assertEquals(upm, result);
    }

    @Test
    public void testFindById() {
        int id = 1;
        UnidadePolicialMilitar upm = new UnidadePolicialMilitar();
        when(upmRepository.findById(id)).thenReturn(Optional.of(upm));
        Optional<UnidadePolicialMilitar> result = upmRepository.findById(id);
        assertEquals(upm, result.get());
    }

    // Add more test cases for other methods as needed

}
```

Este é um exemplo de testes unitários para os métodos da classe `UnidadePolicialMilitarRepository`. Certifique-se de adicionar mais casos de teste para os outros métodos conforme necessário.