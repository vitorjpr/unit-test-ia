```java
package br.gov.df.pm.sgv.service.impl;

import br.gov.df.pm.sgv.domain.DiferencaOdometroEntity;
import br.gov.df.pm.sgv.dto.DiferencaOdometroDTO;
import br.gov.df.pm.sgv.dto.DiferencaDTO;
import br.gov.df.pm.sgv.exceptions.VistoriaExceptions;
import br.gov.df.pm.sgv.mapper.DiferencaOdometroMapper;
import br.gov.df.pm.sgv.repository.DiferencaOdometroRepository;
import br.gov.df.pm.sgv.repository.TipoVistoriaRepository;
import br.gov.df.pm.sgv.repository.app.ViaturaRepository;
import br.gov.df.pm.sgv.repository.app.VistoriaViaturaRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class DiferencaOdometroServiceImplTest {

    @Mock
    private DiferencaOdometroRepository diferencaOdometroRepository;

    @Mock
    private TipoVistoriaRepository tipoVistoriaRepository;

    @Mock
    private ViaturaRepository viaturaRepository;

    @Mock
    private VistoriaViaturaRepository vistoriaViaturaRepository;

    @InjectMocks
    private DiferencaOdometroServiceImpl diferencaOdometroService;

    private DiferencaOdometroEntity diferencaOdometroEntity;

    @BeforeEach
    public void setup() {
        diferencaOdometroEntity = new DiferencaOdometroEntity();
        diferencaOdometroEntity.setId(1L);
        diferencaOdometroEntity.setReferenciaInicial(100);
        diferencaOdometroEntity.setReferenciaFinal(200);
        diferencaOdometroEntity.setDiferencaOdometro(100);
        diferencaOdometroEntity.setDataModificacao(LocalDate.now());
    }

    @Test
    public void testBuscarId() {
        Long id = 1L;
        when(diferencaOdometroRepository.findById(id)).thenReturn(Optional.of(diferencaOdometroEntity));

        ResponseEntity<DiferencaOdometroDTO> response = diferencaOdometroService.buscarId(id);

        assertEquals(diferencaOdometroEntity.getId(), response.getBody().getId());
        // Add more assertions as needed
    }

    @Test
    public void testSalvar() {
        DiferencaOdometroDTO diferencaOdometroDTO = new DiferencaOdometroDTO();
        diferencaOdometroDTO.setReferenciaInicial(300);
        diferencaOdometroDTO.setReferenciaFinal(400);

        when(diferencaOdometroRepository.findByReferenciaInicialAndReferenciaFinal(300, 400)).thenReturn(Optional.empty());

        ResponseEntity<DiferencaOdometroDTO> response = diferencaOdometroService.salvar(diferencaOdometroDTO);

        assertEquals(diferencaOdometroDTO.getReferenciaInicial(), response.getBody().getReferenciaInicial());
        // Add more assertions as needed
    }

    @Test
    public void testEditar() {
        Long id = 1L;
        DiferencaOdometroDTO edicao = new DiferencaOdometroDTO();
        edicao.setReferenciaInicial(500);

        when(diferencaOdometroRepository.findById(id)).thenReturn(Optional.of(diferencaOdometroEntity));
        when(diferencaOdometroRepository.save(any())).thenReturn(diferencaOdometroEntity);

        ResponseEntity<?> response = diferencaOdometroService.editar(id, edicao);

        assertEquals(edicao.getReferenciaInicial(), diferencaOdometroEntity.getReferenciaInicial());
        // Add more assertions as needed
    }

    @Test
    public void testExcluir() {
        Long id = 1L;
        when(diferencaOdometroRepository.findById(id)).thenReturn(Optional.of(diferencaOdometroEntity));

        ResponseEntity<?> response = diferencaOdometroService.excluir(id);

        Mockito.verify(diferencaOdometroRepository).delete(diferencaOdometroEntity);
    }

    @Test
    public void testBuscar() {
        String filter = "100