package br.gov.df.pm.sgv.exceptions;

public class TipoDefeitoVistoriaException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public TipoDefeitoVistoriaException() {
    }

    public TipoDefeitoVistoriaException(String message) {
        super(message);
    }

    public TipoDefeitoVistoriaException(String message, Throwable cause) {
        super(message, cause);
    }
}
