Here are some unit tests for the provided Java code:

```java
package br.gov.df.pm.sgv.controller;

import br.gov.df.pm.sgv.dto.root.ApiInfoDTO;
import br.gov.df.pm.sgv.dto.root.PerfilDTO;
import br.gov.df.pm.sgv.security.UserProvider;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.server.ResponseStatusException;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

class RootControllerTest {

    @Mock
    private UserProvider userProvider;

    private RootController rootController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
        rootController = new RootController(userProvider);
    }

    @Test
    void testRootWithEmptyPerfisList() {
        when(userProvider.getPerfisPolicialAutenticado()).thenReturn(new ArrayList<>());

        ResponseStatusException exception = assertThrows(ResponseStatusException.class,
                () -> rootController.root("1.0.0"));

        assertEquals(HttpStatus.FORBIDDEN, exception.getStatus());
        assertEquals("Você não tem perfis para utilizar o SGF, acesse o SGPOL para atribuir perfil ao SGF.",
                exception.getReason());
    }

    @Test
    void testRootWithNonEmptyPerfisList() {
        List<PerfilDTO> perfis = new ArrayList<>();
        perfis.add(new PerfilDTO("ADMIN"));
        when(userProvider.getPerfisPolicialAutenticado()).thenReturn(perfis);

        ResponseEntity<ApiInfoDTO> response = rootController.root("1.0.0");

        assertEquals(HttpStatus.OK, response.getStatusCode());
        ApiInfoDTO apiInfoDTO = response.getBody();
        assertEquals("1.0.0", apiInfoDTO.getAppVersion());
        assertEquals("Policial", apiInfoDTO.getPolicial());
        assertEquals(perfis, apiInfoDTO.getPerfis());
    }
}
```

Make sure to include the necessary imports for the test class. These tests cover the scenarios of an empty `perfilDTOS` list and a non-empty list in the `root` method of the `RootController` class.