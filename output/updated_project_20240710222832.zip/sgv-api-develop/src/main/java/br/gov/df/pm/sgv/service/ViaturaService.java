package br.gov.df.pm.sgv.service;

import br.gov.df.pm.sgv.domain.ViaturaEntity;
import br.gov.df.pm.sgv.domain.sgpol.UnidadePolicialMilitar;
import br.gov.df.pm.sgv.dto.TipoEmpregoViaturaDto;
import br.gov.df.pm.sgv.dto.VistoriaViaturaDTO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;

import java.util.List;

public interface ViaturaService {
    Page<ViaturaEntity> buscar(Integer upmCodigo, String Prefixo, String placa,  Pageable pageable);
    Page<ViaturaEntity> buscarViatura(Integer upmCodigo, String Prefixo, String placa, Integer tepCodigo, Pageable pageable);
    Page<ViaturaEntity> findPaginado(Pageable pageable);
    Double getUltimoOdometroByViatura(Long id);
    List<VistoriaViaturaDTO> getVistoriaViaturaByViatura(Long id);
    ResponseEntity<List<UnidadePolicialMilitar>> listarUpm();
    ResponseEntity<List<TipoEmpregoViaturaDto>> listar();
    Page<ViaturaEntity> buscarViaturasAtivas(Pageable pageable);
}
