package br.gov.df.pm.sgv.service;

import br.gov.df.pm.sgv.dto.EdicaoItemVistoriaDTO;
import br.gov.df.pm.sgv.dto.ItemVistoriaDTO;
import br.gov.df.pm.sgv.domain.ItemVistoriaEntity;
import br.gov.df.pm.sgv.domain.SubitemVistoriaEntity;
import br.gov.df.pm.sgv.domain.SubitensVistoriaEntity;
import br.gov.df.pm.sgv.dto.OcorrenciasDTO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface ItemVistoriaService {
    ResponseEntity<ItemVistoriaDTO> buscarId(Long id);
    Page<ItemVistoriaEntity> buscar(String filter, Pageable pageable);
    ResponseEntity<?> salvar(ItemVistoriaDTO itemVistoriaDTO);
    ResponseEntity<?> editar(Long id, EdicaoItemVistoriaDTO edicao);
    ResponseEntity<?> desativar(Long id);
    ResponseEntity<?> excluir(Long id);
    ResponseEntity<?> ativar(Long id);
    ResponseEntity<List<SubitensVistoriaEntity>> findAllSubitensVistoria();
    ResponseEntity<List<SubitemVistoriaEntity>> findAllSubitemVistoriaById(String nome);
    ResponseEntity<List<SubitemVistoriaEntity>> findAllSubitemVistoria();
    OcorrenciasDTO listAllAtivosByTipoVistoria(Long tipoVistoria);
}
