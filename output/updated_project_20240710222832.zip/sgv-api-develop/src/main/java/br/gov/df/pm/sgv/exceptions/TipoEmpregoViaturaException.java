package br.gov.df.pm.sgv.exceptions;

public class TipoEmpregoViaturaException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public TipoEmpregoViaturaException() {
    }

    public TipoEmpregoViaturaException(String message) {
        super(message);
    }

    public TipoEmpregoViaturaException(String message, Throwable cause) {
        super(message, cause);
    }
}
