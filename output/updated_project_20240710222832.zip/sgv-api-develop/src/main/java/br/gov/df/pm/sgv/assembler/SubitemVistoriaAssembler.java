package br.gov.df.pm.sgv.assembler;

import br.gov.df.pm.sgv.dto.SubitemVistoriaDTO;
import br.gov.df.pm.sgv.domain.SubitemVistoriaEntity;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.RepresentationModelAssembler;
import org.springframework.stereotype.Component;

@Component
public class SubitemVistoriaAssembler implements RepresentationModelAssembler<SubitemVistoriaEntity, EntityModel<SubitemVistoriaDTO>> {
    @Override
    public EntityModel<SubitemVistoriaDTO> toModel(SubitemVistoriaEntity entity) {
        return EntityModel.of(SubitemVistoriaDTO.builder()
                .id(entity.getId())
                .nome(entity.getNome())
                .descricao(entity.getDescricao())
                .dataInclusao(entity.getDataInclusao())
                .ativo(entity.getAtivo())
                .build());
    }
}
