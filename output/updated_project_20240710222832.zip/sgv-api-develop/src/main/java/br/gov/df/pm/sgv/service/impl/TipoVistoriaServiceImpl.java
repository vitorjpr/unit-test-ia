package br.gov.df.pm.sgv.service.impl;

import br.gov.df.pm.sgv.dto.EdicaoTipoVistoriaDTO;
import br.gov.df.pm.sgv.dto.TipoVistoriaDTO;
import br.gov.df.pm.sgv.domain.*;
import br.gov.df.pm.sgv.exceptions.TipoVistoriaException;
import br.gov.df.pm.sgv.exceptions.ViaturaException;
import br.gov.df.pm.sgv.exceptions.VistoriaExceptions;
import br.gov.df.pm.sgv.mapper.TipoVistoriaMapper;
import br.gov.df.pm.sgv.repository.ItemVistoriaRepository;
import br.gov.df.pm.sgv.repository.ItensVistoriaRepository;
import br.gov.df.pm.sgv.repository.TipoVistoriaRepository;
import br.gov.df.pm.sgv.repository.app.ViaturaRepository;
import br.gov.df.pm.sgv.service.TipoVistoriaService;
import br.gov.df.pm.sgv.shared.utils.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.thymeleaf.util.ListUtils;

import javax.persistence.criteria.Predicate;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Service
public class TipoVistoriaServiceImpl implements TipoVistoriaService {

    @Autowired
    private TipoVistoriaRepository repository;
    @Autowired
    private ItemVistoriaRepository itemRepository;
    @Autowired
    private ItensVistoriaRepository itensRepository;
    @Autowired
    private ViaturaRepository viaturaRepository;

    @Override
    public ResponseEntity<?> buscarId(Long id) {
        return ResponseEntity.ok(new TipoVistoriaMapper().convertDTO(findById(id)));
    }

    @Override
    public Page<TipoVistoriaEntity> buscar(String filter, Pageable pageable) {
        List<ItensVistoriaEntity> itensList = new ArrayList<>();
        var subItem = itemRepository.findByNome(filter);
        if(subItem.isPresent()) {
            itensList = itensRepository.findAllByCodItem(subItem.get());
        }
        return repository.findAll(filtroToSpecification(filter, itensList), pageable);
    }

    private Specification<TipoVistoriaEntity> filtroToSpecification(String filtro, List<ItensVistoriaEntity> itensList) {
        return (root, query, builder) -> {
            if (!StringUtils.isEmptyOrNull(filtro)) {
                var predications = new ArrayList<Predicate>();
                if(!ListUtils.isEmpty(itensList)) {
                    for(ItensVistoriaEntity subitens: itensList) {
                        predications.add(builder.equal(root.get("id"), subitens.getCodItem()));
                    }
                }
                predications.add(builder.like(root.get("nome"),"%" + filtro + "%"));
                predications.add(builder.like(root.get("descricao"),"%" + filtro + "%"));
                return builder.or(predications.toArray(Predicate[]::new));
            }
            return null;
        };
    }

    @Override
    public ResponseEntity<?> salvar(TipoVistoriaDTO tipoVistoria) {
        if(StringUtils.isEmptyOrNull(tipoVistoria.getNome()) || repository.findByNome(tipoVistoria.getNome()).isPresent()) {
            throw new VistoriaExceptions("Tipo já cadastrado no sistema.");
        }
        var tipoSaved = repository.save(new TipoVistoriaMapper().convertEntity(tipoVistoria));
        List<ItensVistoriaEntity> itens = new ArrayList<>();
        for(ItemVistoriaEntity itemV: tipoVistoria.getItens()){
            ItensVistoriaEntity item = new ItensVistoriaEntity();
            item.setCodTipo(tipoSaved);
            item.setCodItem(itemV);
            item.setDataInclusao(LocalDate.now());
            itens.add(item);
        }
        itensRepository.saveAll(itens);
        return ResponseEntity.ok(tipoSaved);
    }

    @Override
    public ResponseEntity<?> editar(Long id, EdicaoTipoVistoriaDTO edicao) {
        if(repository.findByNome(edicao.getNome()).isPresent()) {
            throw new VistoriaExceptions("Tipo já cadastrado no sistema.");
        }
        var tipoVistoria = findById(id);
        if (!StringUtils.isEmptyOrNull(edicao.getNome())) {
            tipoVistoria.setNome(edicao.getNome());
        }
        if (!StringUtils.isEmptyOrNull(edicao.getDescricao())) {
            tipoVistoria.setDescricao(edicao.getDescricao());
        }
        if (!StringUtils.isEmptyOrNull(edicao.getStatusAnterior())) {
            tipoVistoria.setStatusAnterior(edicao.getStatusAnterior());
        }
        if (!StringUtils.isEmptyOrNull(edicao.getStatusPosterior())) {
            tipoVistoria.setStatusPosterior(edicao.getStatusPosterior());
        }
        if (!ListUtils.isEmpty(edicao.getItens())) {
            var defeitosVistoriaList = itensRepository.findAllByCodTipo(tipoVistoria);
            if (!defeitosVistoriaList.isEmpty()) {
                for (ItensVistoriaEntity itensVistoria : defeitosVistoriaList) {
                    if (edicao.getItens().stream().noneMatch(t ->
                            Objects.equals(t.getId(), itensVistoria.getCodItem().getId()))) {
                        itensRepository.delete(itensVistoria);
                    }
                }
            }
            for (ItemVistoriaEntity itemVistoria : edicao.getItens()) {
                if (itensRepository.findByCodTipoAndCodItem(tipoVistoria, itemVistoria).isEmpty()) {
                    itensRepository.save(ItensVistoriaEntity.builder()
                            .codItem(itemVistoria)
                            .codTipo(tipoVistoria)
                            .ativo(true)
                            .dataInclusao(LocalDate.now())
                            .build());
                }
            }
        } else {
            var todositens = itensRepository.findAllByCodTipo(tipoVistoria);
            if(!ListUtils.isEmpty(todositens)) {
                itensRepository.deleteAll(todositens);
            }
        }
        return ResponseEntity.ok(repository.save(tipoVistoria));
    }

    @Override
    public ResponseEntity<?> desativar(Long id) {
        var tipoVistoria = findById(id);
        tipoVistoria.setAtivo(false);
        repository.save(tipoVistoria);
        return ResponseEntity.ok().build();
    }

    @Override
    public ResponseEntity<?> excluir(Long id) {
        var tipoVistoria = findById(id);
        repository.delete(tipoVistoria);
        return ResponseEntity.ok().build();
    }

    @Override
    public ResponseEntity<?> ativar(Long id) {
        var tipoVistoria = findById(id);
        tipoVistoria.setAtivo(true);
        repository.save(tipoVistoria);
        return ResponseEntity.ok().build();
    }

    @Override
    public ResponseEntity<List<ItensVistoriaEntity>> findAllItensVistoria() {
        return ResponseEntity.ok(itensRepository.findAll());
    }

    @Override
    public ResponseEntity<List<ItemVistoriaEntity>> findAllItemVistoriaById(String nome) {
        var itenslist = itensRepository.findAllByCodTipo(repository.findByNome(nome).get());
        List<ItemVistoriaEntity> response = new ArrayList<>();
        for(ItensVistoriaEntity subitem: itenslist) {
            response.add(itemRepository.findById(subitem.getCodItem().getId()).get());
        }
        return ResponseEntity.ok(response);
    }

    @Override
    public ResponseEntity<List<ItemVistoriaEntity>> findAllItemVistoria() {
        var item = itemRepository.findAll(Sort.by(Sort.Direction.ASC, "nome"));
        item.removeIf(tipo -> tipo.getAtivo().equals(false));
        return ResponseEntity.ok(item);
    }

    @Override
    public List<TipoVistoriaDTO> listAllTipoVistoriaAtivos() {

       List<TipoVistoriaEntity> tipoVistoriaEntities = repository.findAllByAtivo(true);

       if(tipoVistoriaEntities.isEmpty()){
           throw new TipoVistoriaException("Não encontrada nenhum tipo de vistoria ativo.");
       }
       List<TipoVistoriaDTO> tipoVistoriaDTOS = new ArrayList<>();
       tipoVistoriaEntities.forEach(tipoVistoriaEntity -> {
           tipoVistoriaDTOS.add(new TipoVistoriaMapper().convertDTO(tipoVistoriaEntity));
       });
        return tipoVistoriaDTOS;
    }

    @Override
    public TipoVistoriaEntity findByIdTipoVistoria(Long id) {
        Optional<TipoVistoriaEntity> tipoVistoriaEntity = repository.findById(id);
        tipoVistoriaEntity.orElseThrow(() -> {
            throw new TipoVistoriaException("Tipo de Vistoria de ID: " + id +  ", não foi encontrado.");
        });
        return tipoVistoriaEntity.get();
    }

    @Override
    public List<TipoVistoriaEntity> listAllTipoVistoriaByStatusViatura(Long idViatura) {
        ViaturaEntity viatura = viaturaRepository.findById(idViatura).orElseThrow(() -> new ViaturaException("Viatura não encontrada"));
        List<TipoVistoriaEntity> tiposVistoria = repository.findAllByStatusPosterior(viatura.getStatus());
        return tiposVistoria;
    }

    private TipoVistoriaEntity findById(Long id) {
        return repository.findById(id).orElseThrow();
    }
}
