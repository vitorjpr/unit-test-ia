package br.gov.df.pm.sgv.shared.entity;

import java.io.Serializable;

public abstract class BaseEntity<T extends Serializable> implements Serializable {
    private static final long serialVersionUID = 1357668119881911675L;

    public BaseEntity() {
    }

    public abstract T getId();

    public abstract void setId(T id);

    public final boolean equals(Object o) {
        if (this == o) {
            return true;
        } else if (!(o instanceof BaseEntity)) {
            return false;
        } else {
            BaseEntity<?> that = (BaseEntity)o;
            return this.getId() != null ? this.getId().equals(that.getId()) : that.getId() == null;
        }
    }

    public final int hashCode() {
        return this.getId() != null ? this.getId().hashCode() : 0;
    }

    public final String toString() {
        String entidade = this.getClass().getSimpleName();
        return "Entidade [ " + entidade + " ] {id=" + this.getId() + "}";
    }
}