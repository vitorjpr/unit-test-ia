Sure! Here are the unit tests for the `Credentials` class in Java using JUnit:

```java
package br.gov.df.pm.sgv.service.config;

import org.junit.Test;
import org.keycloak.representations.idm.CredentialRepresentation;

import static org.junit.Assert.*;

public class CredentialsTest {

    @Test
    public void testCreatePasswordCredentials() {
        String password = "testPassword";
        CredentialRepresentation passwordCredentials = Credentials.createPasswordCredentials(password);

        assertNotNull(passwordCredentials);
        assertFalse(passwordCredentials.isTemporary());
        assertEquals(CredentialRepresentation.PASSWORD, passwordCredentials.getType());
        assertEquals(password, passwordCredentials.getValue());
    }
}
```

In this test class, we import the necessary classes, create a test method `testCreatePasswordCredentials` to test the `createPasswordCredentials` method from the `Credentials` class. We then check if the returned `CredentialRepresentation` object is not null, if the password is not temporary, if the type is set to `PASSWORD`, and if the value matches the input password.

These tests provide coverage for the `createPasswordCredentials` method in the `Credentials` class.