```java
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.context.request.WebRequest;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class ErroVistoriaExceptionsTest {

    @Test
    public void testHandleControllerException() {
        ErroVistoriaExceptions erroVistoriaExceptions = new ErroVistoriaExceptions();
        Exception exception = new Exception("Test Exception");

        ResponseEntity<ErroVistoriaExceptions.ErrorResponse> responseEntity = erroVistoriaExceptions.handleControllerException(exception);

        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, responseEntity.getStatusCode());
        assertEquals("Falha ao realizar a operação: Test Exception", responseEntity.getBody().getMessage());
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), responseEntity.getBody().getStatus());
    }

    @Test
    public void testHandleMethodArgumentNotValid() {
        ErroVistoriaExceptions erroVistoriaExceptions = new ErroVistoriaExceptions();
        MethodArgumentNotValidException exception = mock(MethodArgumentNotValidException.class);
        WebRequest webRequest = mock(WebRequest.class);
        List<ObjectError> errors = new ArrayList<>();
        ObjectError objectError = new ObjectError("field", "Error message");
        errors.add(objectError);
        when(exception.getBindingResult().getAllErrors()).thenReturn(errors);

        ResponseEntity<Object> responseEntity = erroVistoriaExceptions.handleMethodArgumentNotValid(exception, null, HttpStatus.BAD_REQUEST, webRequest);

        assertEquals(HttpStatus.BAD_REQUEST, responseEntity.getStatusCode());
        assertEquals("[Error message]", responseEntity.getBody().toString());
    }

    @Test
    public void testHandleControllerException_ConstraintViolationException() {
        ErroVistoriaExceptions erroVistoriaExceptions = new ErroVistoriaExceptions();
        ConstraintViolationException exception = new ConstraintViolationException("Test Constraint Violation", null);

        ResponseEntity<String> responseEntity = erroVistoriaExceptions.handleControllerException(exception);

        assertEquals(HttpStatus.CONFLICT, responseEntity.getStatusCode());
        assertEquals("Falha ao realizar a operação: Test Constraint Violation", responseEntity.getBody());
    }

    @Test
    public void testHandleValidationErrors() {
        ErroVistoriaExceptions erroVistoriaExceptions = new ErroVistoriaExceptions();
        ValidationError validationError = new ValidationError("Test Validation Error");
        WebRequest webRequest = mock(WebRequest.class);

        ResponseEntity<ExceptionResponse> responseEntity = erroVistoriaExceptions.handleValidationErrors(validationError, webRequest);

        assertEquals(HttpStatus.BAD_REQUEST, responseEntity.getStatusCode());
        assertEquals("Test Validation Error", responseEntity.getBody().getMessage());
    }
}
```

Este é um exemplo de testes unitários para a classe `ErroVistoriaExceptions`. Certifique-se de que os testes cubram todos os casos de exceção tratados pelos métodos da classe. Certifique-se de que os imports estejam corretos de acordo com o código fornecido.