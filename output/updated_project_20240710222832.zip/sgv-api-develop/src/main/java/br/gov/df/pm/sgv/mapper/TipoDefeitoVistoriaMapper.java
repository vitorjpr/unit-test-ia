package br.gov.df.pm.sgv.mapper;

import br.gov.df.pm.sgv.dto.TipoDefeitoVistoriaDTO;
import br.gov.df.pm.sgv.domain.TipoDefeitoVistoriaEntity;


public class TipoDefeitoVistoriaMapper {
    public TipoDefeitoVistoriaEntity convertEntity(TipoDefeitoVistoriaDTO itemVistoriaDTO) {
        return TipoDefeitoVistoriaEntity.builder()
                .nome(itemVistoriaDTO.getNome())
                .descricao(itemVistoriaDTO.getDescricao())
                .dataInclusao(itemVistoriaDTO.getDataInclusao())
                .ativo(itemVistoriaDTO.getAtivo())
                .build();
    }

    public TipoDefeitoVistoriaDTO convertDTO(TipoDefeitoVistoriaEntity tipoVistoriaEntity) {
        return TipoDefeitoVistoriaDTO.builder()
                .nome(tipoVistoriaEntity.getNome())
                .descricao(tipoVistoriaEntity.getDescricao())
                .dataInclusao(tipoVistoriaEntity.getDataInclusao())
                .ativo(tipoVistoriaEntity.getAtivo())
                .id(tipoVistoriaEntity.getId())
                .build();
    }
}
