Here are the unit tests for the provided Java code:

```java
package br.gov.df.pm.sgv.repository.sgpol;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import br.gov.df.pm.sgv.domain.sgpol.Recurso;
import org.springframework.data.jpa.repository.Query;

@ExtendWith(MockitoExtension.class)
public class RecursoRepositoryTest {

    @Mock
    private RecursoRepository recursoRepository;

    @BeforeEach
    public void setUp() {
        List<Recurso> recursos = new ArrayList<>();
        Recurso recurso1 = new Recurso();
        recurso1.setId(1L);
        recurso1.setNome("Recurso 1");
        recursos.add(recurso1);

        Recurso recurso2 = new Recurso();
        recurso2.setId(2L);
        recurso2.setNome("Recurso 2");
        recursos.add(recurso2);

        when(recursoRepository.findRecursoPessoaByMatricula("12345")).thenReturn(recursos);
    }

    @Test
    public void testFindRecursoPessoaByMatricula() {
        String matricula = "12345";
        List<Recurso> recursos = recursoRepository.findRecursoPessoaByMatricula(matricula);

        assertEquals(2, recursos.size());
        assertEquals("Recurso 1", recursos.get(0).getNome());
        assertEquals("Recurso 2", recursos.get(1).getNome());
    }

    // Add more tests for other methods if needed
}
```

In the provided test class `RecursoRepositoryTest`, I have included a test method for the `findRecursoPessoaByMatricula` method of the `RecursoRepository` interface. The test initializes a mock `RecursoRepository` object and sets up the behavior for the `findRecursoPessoaByMatricula` method to return a list of `Recurso` objects when called with a specific matricula.

You can add more test methods for other methods in the `RecursoRepository` interface if needed. Make sure to include necessary imports and dependencies for running the tests successfully.