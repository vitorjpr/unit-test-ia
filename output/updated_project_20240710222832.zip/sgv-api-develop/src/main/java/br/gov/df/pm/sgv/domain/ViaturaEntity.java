package br.gov.df.pm.sgv.domain;

import lombok.*;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.List;

@Entity
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(of = "id")
@Table(name = "VIATURA", schema = "sgf")
public class ViaturaEntity implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "vtr_Codigo", unique = true, nullable = false)
    private Long id;


    @Column(name = "vtr_Prefixo")
    private String prefixo;

    @Column(name = "vtr_NrSei")
    private String nrSei;

    @Column(name = "vtr_Placa")
    private String placa;

    @Column(name = "vtr_Status")
    private String status;

    @Size(max = 11)
    @Column(name = "vtr_Tombamento")
    private String tombamento;

    @Size(max = 11, message = "O Renavam deve ter no máximo 11 dígitos")
    @Column(name = "vtr_Renavam")
    private String renavam;

    @DateTimeFormat(pattern="dd/MM/yyyy")
    @Column(name = "vtr_DtInclusao")
    private LocalDate dataInclusao;

    @DateTimeFormat(pattern="dd/MM/yyyy")
    @Column(name = "vtr_DtAtualizacao")
    private LocalDate dataAtualizacao;

    @Column(name = "vtr_Ativo")
    private Boolean ativo;


    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "tep_Codigo")
    private TipoEmpregoViaturaEntity tipoEmpregoViatura;

    @OneToMany(mappedBy = "viatura")
    private List<ViaturaUpmEntity> listaUpm;

    @Column(name = "vtr_MarcaModelo")
    private String marcaModelo;
}
