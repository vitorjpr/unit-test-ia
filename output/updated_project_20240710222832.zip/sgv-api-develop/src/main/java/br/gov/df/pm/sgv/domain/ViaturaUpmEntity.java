package br.gov.df.pm.sgv.domain;

import br.gov.df.pm.sgv.domain.sgpol.UnidadePolicialMilitar;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(of = "id")
@Table(name = "VIATURA_UPM", schema = "sgf")
public class ViaturaUpmEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "viu_Codigo", unique = true, nullable = false)
    private Integer id;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "vtr_Codigo")
    private ViaturaEntity viatura;

    @JoinColumn(name = "upm_codigo")
    @ManyToOne(fetch = FetchType.LAZY)
    private UnidadePolicialMilitar upmCodigo;

    @Column(name = "viu_DtEntrada")
    private Date dtEntrada;

    @Column(name = "viu_DtSaida")
    private Date dtSaida;

    @Column(name = "viu_NrSei")
    private String nrSei;

    @Column(name = "pes_CodigoCadastranteEntrada")
    private int codCadastranteEntrada;

    @Column(name = "pes_CodigoCadastranteSaida")
    private int codCadastranteSaida;

    @Column(name = "mtv_Codigo")
    private int motivoTransferenciaCodigo;

    @Column(name = "pes_CodigoMovimentador")
    private int movimentadorCodigo;

    @Column(name = "viu_DtMovimentacao")
    private Date dtMovimentacao;

    @Column(name = "viu_Observacao")
    private String observacao;

    @Column(name = "viu_Ativo")
    private int ativo;
}
