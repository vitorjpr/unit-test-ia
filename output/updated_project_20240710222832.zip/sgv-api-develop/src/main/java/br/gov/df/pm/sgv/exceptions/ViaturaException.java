package br.gov.df.pm.sgv.exceptions;

public class ViaturaException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public ViaturaException() {
    }

    public ViaturaException(String message) {
        super(message);
    }

    public ViaturaException(String message, Throwable cause) {
        super(message, cause);
    }
}
