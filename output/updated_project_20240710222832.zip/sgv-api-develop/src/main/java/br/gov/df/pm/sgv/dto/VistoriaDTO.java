package br.gov.df.pm.sgv.dto;

import br.gov.df.pm.sgv.domain.*;
import br.gov.df.pm.sgv.domain.enums.VistoriaViaturaStatusEnum;
import lombok.*;

import java.time.LocalDateTime;
import java.util.List;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class VistoriaDTO {

    private Long id;
    private String upm;
    private String motorista;
    private ViaturaEntity viatura;
    private TipoVistoriaEntity tipoVistoria;
    private List<VistoriaViaturaHistoricoEntity> vistoriaViaturaHistorico;
    private List<VistoriaArquivo> vistoriaArquivoList;
    private DiferencaOdometroEntity diferencaOdometro;
    private VistoriaViaturaStatusEnum status;
    private Float odometroInicial;
    private Float odometroFinal;
    private Boolean diferencaVistoria;
    private LocalDateTime dataVistoria;
    private List<ChecklistVistoriaEntity> checkLists;

}
