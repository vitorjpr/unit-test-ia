package br.gov.df.pm.sgv.repository;

import br.gov.df.pm.sgv.domain.ChecklistItemVistoriaEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ChecklistVistoriaItemRepository extends JpaRepository<ChecklistItemVistoriaEntity, Long> {
}
