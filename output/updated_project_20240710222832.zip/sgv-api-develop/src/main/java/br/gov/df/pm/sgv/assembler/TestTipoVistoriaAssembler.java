```java
package br.gov.df.pm.sgv.assembler;

import br.gov.df.pm.sgv.dto.TipoVistoriaDTO;
import br.gov.df.pm.sgv.domain.TipoVistoriaEntity;
import org.junit.jupiter.api.Test;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.RepresentationModelAssembler;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringJUnitConfig;

import static org.junit.jupiter.api.Assertions.assertEquals;

@SpringBootTest
@SpringJUnitConfig
public class TipoVistoriaAssemblerTest {

    private final TipoVistoriaAssembler tipoVistoriaAssembler = new TipoVistoriaAssembler();

    @Test
    public void testToModel() {
        TipoVistoriaEntity entity = new TipoVistoriaEntity();
        entity.setId(1L);
        entity.setNome("Teste");
        entity.setDescricao("Descrição teste");
        entity.setStatusAnterior("Anterior");
        entity.setStatusPosterior("Posterior");
        entity.setDataInclusao("01/01/2022");
        entity.setAtivo(true);

        EntityModel<TipoVistoriaDTO> result = tipoVistoriaAssembler.toModel(entity);

        assertEquals(entity.getId(), result.getContent().getId());
        assertEquals(entity.getNome(), result.getContent().getNome());
        assertEquals(entity.getDescricao(), result.getContent().getDescricao());
        assertEquals(entity.getStatusAnterior(), result.getContent().getStatusAnterior());
        assertEquals(entity.getStatusPosterior(), result.getContent().getStatusPosterior());
        assertEquals(entity.getDataInclusao(), result.getContent().getDataInclusao());
        assertEquals(entity.getAtivo(), result.getContent().isAtivo());
    }
}
```

Este é um exemplo de teste unitário para a classe `TipoVistoriaAssembler`. Ele verifica se o método `toModel` está corretamente mapeando os atributos da entidade `TipoVistoriaEntity` para a classe `TipoVistoriaDTO`. Certifique-se de que o ambiente de teste esteja configurado corretamente para execução.