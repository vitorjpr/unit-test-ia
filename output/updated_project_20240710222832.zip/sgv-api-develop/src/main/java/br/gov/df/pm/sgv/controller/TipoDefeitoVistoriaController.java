package br.gov.df.pm.sgv.controller;

import br.gov.df.pm.sgv.assembler.TipoDefeitoVistoriaAssembler;
import br.gov.df.pm.sgv.dto.EdicaoTipoDefeitoVistoriaDTO;
import br.gov.df.pm.sgv.dto.TipoDefeitoVistoriaDTO;
import br.gov.df.pm.sgv.domain.TipoDefeitoVistoriaEntity;
import br.gov.df.pm.sgv.service.TipoDefeitoVistoriaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.PagedModel;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Objects;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/vistoria/tipodefeito")
public class TipoDefeitoVistoriaController {

    @Autowired
    private final TipoDefeitoVistoriaService service;
    @Autowired
    private final TipoDefeitoVistoriaAssembler tipoDefeitoVistoriaAssembler;
    @Autowired
    private final PagedResourcesAssembler<TipoDefeitoVistoriaEntity> pagedResourcesAssembler;

    public TipoDefeitoVistoriaController(TipoDefeitoVistoriaService service,
                                         TipoDefeitoVistoriaAssembler tipoDefeitoVistoriaAssembler,
                                         PagedResourcesAssembler<TipoDefeitoVistoriaEntity> pagedResourcesAssembler) {
        this.service = service;
        this.tipoDefeitoVistoriaAssembler = tipoDefeitoVistoriaAssembler;
        this.pagedResourcesAssembler = pagedResourcesAssembler;
    }

    @GetMapping("/buscar/{id}")
    public ResponseEntity<TipoDefeitoVistoriaDTO> buscarId(@PathVariable("id") Long id) {
        return service.buscarId(id);
    }

    @GetMapping("/buscar")
    public PagedModel<EntityModel<TipoDefeitoVistoriaDTO>> buscar(String filter, Pageable pageable) {
        var result = pagedResourcesAssembler.toModel(service.buscar(filter, pageable));
        return PagedModel.of(result.getContent().stream().map(e ->
                tipoDefeitoVistoriaAssembler.toModel(Objects.requireNonNull(e.getContent()))).collect(Collectors.toList()), result.getMetadata());
    }

    @PostMapping("/salvar")
    public ResponseEntity<?> salvar(@RequestBody TipoDefeitoVistoriaDTO tipoDefeito) {
        return service.salvar(tipoDefeito);
    }

    @PutMapping("/editar/{id}")
    public ResponseEntity<?> editar(@PathVariable("id") Long id, @RequestBody  EdicaoTipoDefeitoVistoriaDTO edicao) {
        return service.editar(id, edicao);
    }

    @DeleteMapping("/excluir/{id}")
    public ResponseEntity<?> excluir(@PathVariable("id") Long id) {
        return service.excluir(id);
    }

    @DeleteMapping("/desativar/{id}")
    public ResponseEntity<?> desativar(@PathVariable("id") Long id) {
        return service.desativar(id);
    }

    @PostMapping("/ativar/{id}")
    public ResponseEntity<?> ativar(@PathVariable("id") Long id) {
        return service.ativar(id);
    }
}
