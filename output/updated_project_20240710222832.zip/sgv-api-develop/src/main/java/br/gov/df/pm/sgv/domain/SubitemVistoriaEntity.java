package br.gov.df.pm.sgv.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDate;

@Entity
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(of = "id")
@Table(name = "SUBITEMVISTORIA", schema = "sgv")
public class SubitemVistoriaEntity implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "suv_Codigo", unique = true, nullable = false)
    private Long id;

    @Column(name = "suv_Nome")
    private String nome;

    @Column(name = "suv_Descricao")
    private String descricao;

    @Column(name = "suv_ativo")
    private Boolean ativo;

    @DateTimeFormat(pattern="dd/MM/yyyy")
    @Column(name = "suv_DtInclusao")
    private LocalDate dataInclusao;

}
