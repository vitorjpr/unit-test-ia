package br.gov.df.pm.sgv.feign;

import feign.Response;
import feign.Util;
import feign.codec.ErrorDecoder;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

import java.io.IOException;

@Configuration
@Slf4j
public class FeignSkipExceptionConfiguration {

    @Bean
    public ErrorDecoder errorDecoder() {
        return (methodKey, response) -> {
            String body = getResponseBodyAsString(response.body());
            Integer status = response.status();

            log.info("Status erro FEIGN: {}", status);

            if (status.equals(HttpStatus.BAD_REQUEST.value()) && body == null) {
                body = "Verifique o corpo da Requisição, dados recebidos inválidos.";
            }

            log.info("Detalhes do erro : {}", body);

            throw new ResponseStatusException(HttpStatus.valueOf(status), body);
        };
    }

    private String getResponseBodyAsString(Response.Body body) {
        try {
            if (body != null) {
                return Util.toString(body.asReader());
            }
        } catch (IOException e) {
            log.error("Erro ao ler o corpo da resposta", e);
        }
        return null;
    }
}