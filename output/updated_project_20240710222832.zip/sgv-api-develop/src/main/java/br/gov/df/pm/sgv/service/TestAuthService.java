Sure! Here are the unit tests for the AuthService interface:

```java
package br.gov.df.pm.sgv.service;

import br.gov.df.pm.sgv.dto.AuthDTO;
import br.gov.df.pm.sgv.feign.dto.MessageAuthKeycloak;
import org.junit.jupiter.api.Test;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class AuthServiceTest {

    AuthService authService = mock(AuthService.class);

    @Test
    void testAuthentication() {
        AuthDTO authDTO = new AuthDTO("username", "password");
        MessageAuthKeycloak message = new MessageAuthKeycloak("token", "bearer");

        when(authService.authentication(authDTO)).thenReturn(ResponseEntity.ok(message));

        ResponseEntity<MessageAuthKeycloak> response = authService.authentication(authDTO);

        assertEquals(message, response.getBody());
    }
}
```

Make sure to add the necessary dependencies for JUnit and Mockito in your project to run these tests. These tests cover the authentication method of the AuthService interface by mocking the AuthService class and verifying the response.