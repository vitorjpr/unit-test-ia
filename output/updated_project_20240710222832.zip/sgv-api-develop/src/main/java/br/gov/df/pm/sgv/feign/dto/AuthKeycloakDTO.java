package br.gov.df.pm.sgv.feign.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class AuthKeycloakDTO {
    private String username;
    private String password;
    private String clientId;
    private String credentals;
}
