package br.gov.df.pm.sgv.service.impl;

import br.gov.df.pm.sgv.domain.SubitensVistoriaEntity;
import br.gov.df.pm.sgv.dto.EdicaoSubitemVistoriaDTO;
import br.gov.df.pm.sgv.dto.SubitemVistoriaDTO;
import br.gov.df.pm.sgv.domain.DefeitosVistoriaEntity;
import br.gov.df.pm.sgv.domain.SubitemVistoriaEntity;
import br.gov.df.pm.sgv.domain.TipoDefeitoVistoriaEntity;
import br.gov.df.pm.sgv.exceptions.VistoriaExceptions;
import br.gov.df.pm.sgv.mapper.SubitemVistoriaMapper;
import br.gov.df.pm.sgv.repository.DefeitosVistoriaRepository;
import br.gov.df.pm.sgv.repository.SubitemVistoriaRepository;
import br.gov.df.pm.sgv.repository.SubitensVistoriaRepository;
import br.gov.df.pm.sgv.repository.TipoDefeitoVistoriaRepository;
import br.gov.df.pm.sgv.service.SubitemVistoriaService;
import br.gov.df.pm.sgv.shared.utils.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.thymeleaf.util.ListUtils;

import javax.persistence.criteria.Predicate;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Service
public class SubitemVistoriaServiceImpl implements SubitemVistoriaService {

    @Autowired
    private SubitemVistoriaRepository repository;
    @Autowired
    private SubitensVistoriaRepository subitensRepository;
    @Autowired
    private TipoDefeitoVistoriaRepository tipoDefeitoRepository;
    @Autowired
    private DefeitosVistoriaRepository defeitosRepository;

    @Override
    public ResponseEntity<SubitemVistoriaDTO> buscarId(Long id) {
        return ResponseEntity.ok(new SubitemVistoriaMapper().convertDTO(findById(id)));
    }

    @Override
    public Page<SubitemVistoriaEntity> buscar(String filter, Pageable pageable) {
        List<DefeitosVistoriaEntity> defeitosList = new ArrayList<>();
        var tipoDefeito = tipoDefeitoRepository.findByNome(filter);
        if (tipoDefeito.isPresent()) {
            defeitosList = defeitosRepository.findAllByCodTipoDefeito(tipoDefeito.get());
        }
        return repository.findAll(filtroToSpecification(filter, defeitosList), pageable);
    }

    private Specification<SubitemVistoriaEntity> filtroToSpecification(String filtro, List<DefeitosVistoriaEntity> defeitosList) {
        return (root, query, builder) -> {
            if (!StringUtils.isEmptyOrNull(filtro)) {
                var predications = new ArrayList<Predicate>();
                if (!ListUtils.isEmpty(defeitosList)) {
                    for (DefeitosVistoriaEntity defeito : defeitosList) {
                        predications.add(builder.equal(root.get("id"), defeito.getCodSubitem()));
                    }
                }
                predications.add(builder.like(root.get("nome"), "%" + filtro + "%"));
                predications.add(builder.like(root.get("descricao"), "%" + filtro + "%"));
                return builder.or(predications.toArray(Predicate[]::new));
            }
            return null;
        };
    }

    @Override
    public ResponseEntity<?> salvar(SubitemVistoriaDTO subitemVistoria) {
        if (StringUtils.isEmptyOrNull(subitemVistoria.getNome()) || repository.findByNome(subitemVistoria.getNome()).isPresent()) {
            new VistoriaExceptions("Subitem já cadastrado no sistema.");
        }
        var subitem = repository.save(new SubitemVistoriaMapper().convertEntity(subitemVistoria));
        List<DefeitosVistoriaEntity> defeitos = new ArrayList<>();
        for (TipoDefeitoVistoriaEntity tipoDefeito : subitemVistoria.getDefeitos()) {
            DefeitosVistoriaEntity defeito = new DefeitosVistoriaEntity();
            defeito.setCodSubitem(subitem);
            defeito.setCodTipoDefeito(tipoDefeito);
            defeito.setDataInclusao(LocalDate.now());
            defeito.setAtivo(true);
            defeitos.add(defeito);
        }
        defeitosRepository.saveAll(defeitos);
        return ResponseEntity.ok(subitem);
    }

    @Override
    public ResponseEntity<?> editar(Long id, EdicaoSubitemVistoriaDTO edicao) {
        if (repository.findByNome(edicao.getNome()).isPresent()) {
            throw new VistoriaExceptions("Subitem já cadastrado no sistema.");
        }
        var subitemVistoria = findById(id);
        if (!StringUtils.isEmptyOrNull(edicao.getNome())) {
            subitemVistoria.setNome(edicao.getNome());
        }
        if (!StringUtils.isEmptyOrNull(edicao.getDescricao())) {
            subitemVistoria.setDescricao(edicao.getDescricao());
        }
        if (!ListUtils.isEmpty(edicao.getDefeitos())) {
            var defeitosVistoriaList = defeitosRepository.findAllByCodSubitem(subitemVistoria);
            if (!defeitosVistoriaList.isEmpty()) {
                for (DefeitosVistoriaEntity defeitosVistoria : defeitosVistoriaList) {
                    if (edicao.getDefeitos().stream().noneMatch(t ->
                            Objects.equals(t.getId(), defeitosVistoria.getCodTipoDefeito().getId()))) {
                        defeitosRepository.delete(defeitosVistoria);
                    }
                }
            }
            for (TipoDefeitoVistoriaEntity tipoDefeitoVistoria : edicao.getDefeitos()) {
                if (defeitosRepository.findByCodSubitemAndCodTipoDefeito(subitemVistoria, tipoDefeitoVistoria).isEmpty()) {
                    defeitosRepository.save(DefeitosVistoriaEntity.builder()
                            .codTipoDefeito(tipoDefeitoVistoria)
                            .codSubitem(subitemVistoria)
                            .ativo(true)
                            .dataInclusao(LocalDate.now())
                            .build());
                }
            }
        } else {
            var todosDefeitos = defeitosRepository.findAllByCodSubitem(subitemVistoria);
            if(!ListUtils.isEmpty(todosDefeitos)) {
                defeitosRepository.deleteAll(todosDefeitos);
            }
        }
        return ResponseEntity.ok(repository.save(subitemVistoria));
    }

    @Override
    public ResponseEntity<?> desativar(Long id) {
        var subitemVistoria = findById(id);
        var subitens = subitensRepository.findAllByCodSubitem(subitemVistoria);
        if (!ListUtils.isEmpty(subitens)) {
            throw new VistoriaExceptions("Não é possível remover o Subitem, há (" + ListUtils.size(subitens) + ") sendo utilizado(s) em Item(s).");
        }
        subitemVistoria.setAtivo(false);
        repository.save(subitemVistoria);
        return ResponseEntity.ok().build();
    }

    @Override
    public ResponseEntity<?> excluir(Long id) {
        var subitemVistoria = findById(id);
        var subitens = subitensRepository.findAllByCodSubitem(subitemVistoria);
        if (!ListUtils.isEmpty(subitens)) {
            throw new VistoriaExceptions("Não é possível remover o Subitem, há (" + ListUtils.size(subitens) + ") sendo utilizado(s) em Item(s).");
        }
        repository.delete(subitemVistoria);
        return ResponseEntity.ok().build();
    }

    @Override
    public ResponseEntity<?> ativar(Long id) {
        var subitemVistoria = findById(id);
        subitemVistoria.setAtivo(true);
        repository.save(subitemVistoria);
        return ResponseEntity.ok().build();
    }

    @Override
    public ResponseEntity<List<TipoDefeitoVistoriaEntity>> findAllTipoDefeitoVistoriaById(String nome) {
        var defeitoslist = defeitosRepository.findAllByCodSubitem(repository.findByNome(nome).get());
        List<TipoDefeitoVistoriaEntity> response = new ArrayList<>();
        for (DefeitosVistoriaEntity defeito : defeitoslist) {
            response.add(tipoDefeitoRepository.findById(defeito.getCodTipoDefeito().getId()).get());
        }
        return ResponseEntity.ok(response);
    }

    @Override
    public ResponseEntity<List<TipoDefeitoVistoriaEntity>> findAllTipoDefeitoVistoria() {
        var tipoDefeitoList = tipoDefeitoRepository.findAll(Sort.by(Sort.Direction.ASC, "nome"));
        tipoDefeitoList.removeIf(tipo -> tipo.getAtivo().equals(false));
        return ResponseEntity.ok(tipoDefeitoList);
    }

    @Override
    public ResponseEntity<List<DefeitosVistoriaEntity>> findAllDefeitosVistoria() {
        return ResponseEntity.ok(defeitosRepository.findAll());
    }

    @Override
    public ResponseEntity<?> desvincularTipoDefeito(Long idTipoDefeito, Long idSubitem) {
//        var tiposDefeitos = defeitosRepository.findByCodSubitemAndCodTipoDefeito(idSubitem, idTipoDefeito).orElseThrow();
//        defeitosRepository.delete(tiposDefeitos);
        return null;
    }

    @Override
    public ResponseEntity<?> desvincularTodosTipoDefeito(Long idSubitem) {
        var tiposDefeitos = defeitosRepository.findAllByCodSubitem(findById(idSubitem));
        defeitosRepository.deleteAll(tiposDefeitos);
        return null;
    }

    private SubitemVistoriaEntity findById(Long id) {
        return repository.findById(id).orElseThrow();
    }
}
