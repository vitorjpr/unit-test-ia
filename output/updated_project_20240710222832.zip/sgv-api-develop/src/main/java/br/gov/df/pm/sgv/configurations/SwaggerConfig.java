package br.gov.df.pm.sgv.configurations;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import org.springdoc.core.GroupedOpenApi;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class SwaggerConfig implements WebMvcConfigurer {

    @Bean
    public GroupedOpenApi greetingApi() {
        String[] paths = {
                "/**",
                "/vistoria/**"
        };
        return GroupedOpenApi.builder()
                .pathsToMatch(paths)
                .group("vistoria-api")
                .build();
    }

    private OpenAPI metaData() {
        return new OpenAPI()
                    .info(new Info()
                    .title("API VISTORIA")
                    .description("API VISTORIA")
                    .version("V1"));
    }
}
