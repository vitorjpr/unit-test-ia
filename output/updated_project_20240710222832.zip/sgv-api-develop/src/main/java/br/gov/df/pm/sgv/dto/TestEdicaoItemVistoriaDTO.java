Here are the unit tests for the provided Java code:

```java
package br.gov.df.pm.sgv.dto;

import br.gov.df.pm.sgv.domain.SubitemVistoriaEntity;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;
import java.util.Arrays;
import java.util.List;

public class EdicaoItemVistoriaDTOTest {

    @Test
    public void testGetNome() {
        EdicaoItemVistoriaDTO dto = EdicaoItemVistoriaDTO.builder().nome("Test Nome").build();
        assertEquals("Test Nome", dto.getNome());
    }

    @Test
    public void testGetDescricao() {
        EdicaoItemVistoriaDTO dto = EdicaoItemVistoriaDTO.builder().descricao("Test Descricao").build();
        assertEquals("Test Descricao", dto.getDescricao());
    }

    @Test
    public void testGetSubitens() {
        SubitemVistoriaEntity subitem1 = new SubitemVistoriaEntity();
        SubitemVistoriaEntity subitem2 = new SubitemVistoriaEntity();
        List<SubitemVistoriaEntity> subitens = Arrays.asList(subitem1, subitem2);
        
        EdicaoItemVistoriaDTO dto = EdicaoItemVistoriaDTO.builder().subitens(subitens).build();
        assertEquals(subitens, dto.getSubitens());
    }
}
```

Make sure to add the necessary imports for the classes used in the tests. These tests cover the getters of the `EdicaoItemVistoriaDTO` class and validate that they return the expected values.