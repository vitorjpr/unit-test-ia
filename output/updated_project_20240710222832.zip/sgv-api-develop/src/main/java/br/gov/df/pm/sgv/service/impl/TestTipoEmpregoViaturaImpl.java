```java
package br.gov.df.pm.sgv.service.impl;

import br.gov.df.pm.sgv.domain.TipoEmpregoViaturaEntity;
import br.gov.df.pm.sgv.dto.TipoEmpregoViaturaDto;
import br.gov.df.pm.sgv.exceptions.TipoEmpregoViaturaException;
import br.gov.df.pm.sgv.mapper.TipoEmpregoMapper;
import br.gov.df.pm.sgv.repository.TipoEmpregoViaturaRepository;
import br.gov.df.pm.sgv.service.TipoEmpregoViaturaService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class TipoEmpregoViaturaImplTest {

    @Mock
    private TipoEmpregoViaturaRepository tipoEmpregoViaturaRepository;

    @InjectMocks
    private TipoEmpregoViaturaImpl tipoEmpregoViaturaService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testListTipoEmpregoViaturaAtivo() {
        // Given
        TipoEmpregoViaturaEntity entity1 = new TipoEmpregoViaturaEntity();
        entity1.setId(1L);
        entity1.setNome("Tipo 1");
        TipoEmpregoViaturaEntity entity2 = new TipoEmpregoViaturaEntity();
        entity2.setId(2L);
        entity2.setNome("Tipo 2");
        List<TipoEmpregoViaturaEntity> entities = new ArrayList<>();
        entities.add(entity1);
        entities.add(entity2);

        when(tipoEmpregoViaturaRepository.findByAtivo(1)).thenReturn(entities);

        // When
        List<TipoEmpregoViaturaDto> dtos = tipoEmpregoViaturaService.listTipoEmpregoViaturaAtivo();

        // Then
        assertNotNull(dtos);
        assertEquals(2, dtos.size());
        assertEquals("Tipo 1", dtos.get(0).getNome());
        assertEquals("Tipo 2", dtos.get(1).getNome());
    }

    @Test
    void testListTipoEmpregoViaturaAtivoEmpty() {
        // Given
        List<TipoEmpregoViaturaEntity> entities = new ArrayList<>();

        when(tipoEmpregoViaturaRepository.findByAtivo(1)).thenReturn(entities);

        // When & Then
        TipoEmpregoViaturaException exception = assertThrows(TipoEmpregoViaturaException.class,
                () -> tipoEmpregoViaturaService.listTipoEmpregoViaturaAtivo());
        assertEquals("Não encontrou nenhum: Tipo Emprego Viatura Ativo", exception.getMessage());
    }
}
```

Neste exemplo, foram criados dois testes para o método `listTipoEmpregoViaturaAtivo` da classe `TipoEmpregoViaturaImpl`. O primeiro teste verifica se a lista de DTOs retornada contém os valores esperados quando há entidades retornadas pelo repositório. O segundo teste verifica se uma exceção é lançada corretamente quando não há entidades retornadas pelo repositório. Os testes utilizam mocks do Mockito para simular o comportamento do repositório.