Here are the unit tests for the provided Java code:

```java
package br.gov.df.pm.sgv.controller;

import br.gov.df.pm.sgv.domain.VistoriaArquivo;
import br.gov.df.pm.sgv.service.VistoriaArquivoService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.when;

public class VistoriaArquivoControllerTest {

    @Mock
    private VistoriaArquivoService vistoriaArquivoService;

    @InjectMocks
    private VistoriaArquivoController vistoriaArquivoController;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testDeleteImageById() {
        Long id = 1L;
        VistoriaArquivo vistoriaArquivo = new VistoriaArquivo();
        when(vistoriaArquivoService.deletarPorId(id)).thenReturn(ResponseEntity.ok(vistoriaArquivo));

        ResponseEntity<VistoriaArquivo> response = vistoriaArquivoController.deleteImageByid(id);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(vistoriaArquivo, response.getBody());
    }

    @Test
    public void testDeleteImageByList() {
        List<Long> ids = Arrays.asList(1L, 2L, 3L);
        List<VistoriaArquivo> vistoriaArquivos = Arrays.asList(new VistoriaArquivo(), new VistoriaArquivo(), new VistoriaArquivo());
        when(vistoriaArquivoService.deletarPorLista(anyList())).thenReturn(ResponseEntity.ok(vistoriaArquivos));

        ResponseEntity<List<VistoriaArquivo>> response = vistoriaArquivoController.deleteImageBylist(ids);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(vistoriaArquivos, response.getBody());
    }
}
```

In these unit tests, we use Mockito to mock the `VistoriaArquivoService` and verify the behavior of the `VistoriaArquivoController` methods. The tests cover the scenarios of deleting an image by ID and deleting a list of images.