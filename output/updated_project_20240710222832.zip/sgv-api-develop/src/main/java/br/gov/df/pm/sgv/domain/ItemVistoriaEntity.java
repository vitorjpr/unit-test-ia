package br.gov.df.pm.sgv.domain;

import lombok.*;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.List;

@Entity
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(of = "id")
@Table(name = "ITEMVISTORIA", schema = "sgv")
public class ItemVistoriaEntity implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "itv_Codigo", unique = true, nullable = false)
    private Long id;

    @Column(name = "itv_Nome")
    private String nome;

    @Column(name = "itv_ativo")
    private Boolean ativo;

    @Column(name = "itv_Descricao")
    private String descricao;

    @DateTimeFormat(pattern="dd/MM/yyyy")
    @Column(name = "itv_DtInclusao")
    private LocalDate dataInclusao;

}
