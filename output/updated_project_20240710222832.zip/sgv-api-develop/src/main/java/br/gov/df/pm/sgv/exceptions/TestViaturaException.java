Sure! Here are some unit tests for the `ViaturaException` class:

```java
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

public class ViaturaExceptionTest {

    @Test
    public void testDefaultConstructor() {
        ViaturaException exception = new ViaturaException();
        assertNull(exception.getMessage());
        assertNull(exception.getCause());
    }

    @Test
    public void testConstructorWithMessage() {
        String message = "Test message";
        ViaturaException exception = new ViaturaException(message);
        assertEquals(message, exception.getMessage());
        assertNull(exception.getCause());
    }

    @Test
    public void testConstructorWithMessageAndCause() {
        String message = "Test message";
        Throwable cause = new IllegalArgumentException("Test cause");
        ViaturaException exception = new ViaturaException(message, cause);
        assertEquals(message, exception.getMessage());
        assertEquals(cause, exception.getCause());
    }
}
```

These tests cover the three constructors of the `ViaturaException` class, ensuring that the message and cause are correctly set when creating an instance of the exception.