```java
package br.gov.df.pm.sgv.dto;

import br.gov.df.pm.sgv.domain.TipoDefeitoVistoriaEntity;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;
import java.util.ArrayList;
import java.util.List;

public class EdicaoSubitemVistoriaDTOTest {

    @Test
    public void testGetNome() {
        EdicaoSubitemVistoriaDTO dto = EdicaoSubitemVistoriaDTO.builder().nome("Teste").build();
        assertEquals("Teste", dto.getNome());
    }

    @Test
    public void testGetDescricao() {
        EdicaoSubitemVistoriaDTO dto = EdicaoSubitemVistoriaDTO.builder().descricao("Descrição teste").build();
        assertEquals("Descrição teste", dto.getDescricao());
    }

    @Test
    public void testGetDefeitos() {
        TipoDefeitoVistoriaEntity defeito1 = new TipoDefeitoVistoriaEntity();
        TipoDefeitoVistoriaEntity defeito2 = new TipoDefeitoVistoriaEntity();
        List<TipoDefeitoVistoriaEntity> defeitos = new ArrayList<>();
        defeitos.add(defeito1);
        defeitos.add(defeito2);

        EdicaoSubitemVistoriaDTO dto = EdicaoSubitemVistoriaDTO.builder().defeitos(defeitos).build();
        assertEquals(defeitos, dto.getDefeitos());
    }

    @Test
    public void testBuilder() {
        EdicaoSubitemVistoriaDTO dto = EdicaoSubitemVistoriaDTO.builder()
                .nome("Teste")
                .descricao("Descrição teste")
                .defeitos(new ArrayList<>())
                .build();

        assertEquals("Teste", dto.getNome());
        assertEquals("Descrição teste", dto.getDescricao());
        assertEquals(new ArrayList<>(), dto.getDefeitos());
    }
}
```