package br.gov.df.pm.sgv.controller;

import br.gov.df.pm.sgv.dto.root.RecursoDTO;
import br.gov.df.pm.sgv.repository.sgpol.RecursoRepository;
import br.gov.df.pm.sgv.security.UserProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping(path = "/recurso", produces = MediaType.APPLICATION_JSON_VALUE)
public class RecursoController {

    @Autowired
    private UserProvider userProvider;

    @Autowired
    private RecursoRepository repository;


    @GetMapping
    public List<String> findRecursosLogado() {
        return userProvider.getRecursosPolicialAutenticado().stream()
                .map(RecursoDTO::getNome)
                .collect(Collectors.toList());
    }

}
