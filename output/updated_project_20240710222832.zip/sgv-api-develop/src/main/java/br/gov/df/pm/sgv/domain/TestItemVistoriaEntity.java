```java
package br.gov.df.pm.sgv.domain;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;

public class ItemVistoriaEntityTest {

    @Test
    public void testGetSetId() {
        ItemVistoriaEntity item = new ItemVistoriaEntity();
        Long id = 1L;
        item.setId(id);
        assertEquals(id, item.getId());
    }

    @Test
    public void testGetSetNome() {
        ItemVistoriaEntity item = new ItemVistoriaEntity();
        String nome = "Teste";
        item.setNome(nome);
        assertEquals(nome, item.getNome());
    }

    @Test
    public void testGetSetAtivo() {
        ItemVistoriaEntity item = new ItemVistoriaEntity();
        Boolean ativo = true;
        item.setAtivo(ativo);
        assertEquals(ativo, item.getAtivo());
    }

    @Test
    public void testGetSetDescricao() {
        ItemVistoriaEntity item = new ItemVistoriaEntity();
        String descricao = "Descrição";
        item.setDescricao(descricao);
        assertEquals(descricao, item.getDescricao());
    }

    @Test
    public void testGetSetDataInclusao() {
        ItemVistoriaEntity item = new ItemVistoriaEntity();
        LocalDate dataInclusao = LocalDate.now();
        item.setDataInclusao(dataInclusao);
        assertEquals(dataInclusao, item.getDataInclusao());
    }
}
```