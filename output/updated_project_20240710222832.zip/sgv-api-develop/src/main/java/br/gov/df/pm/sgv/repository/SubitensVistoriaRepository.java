package br.gov.df.pm.sgv.repository;

import br.gov.df.pm.sgv.domain.ItemVistoriaEntity;
import br.gov.df.pm.sgv.domain.SubitemVistoriaEntity;
import br.gov.df.pm.sgv.domain.SubitensVistoriaEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface SubitensVistoriaRepository extends JpaRepository<SubitensVistoriaEntity, Long> {
    List<SubitensVistoriaEntity> findAllByCodSubitem(SubitemVistoriaEntity id);
    List<SubitensVistoriaEntity> findAllByCodItem(ItemVistoriaEntity id);
    Optional<SubitensVistoriaEntity> findByCodItemAndCodSubitem(ItemVistoriaEntity idItem, SubitemVistoriaEntity idSubitem);
    List<SubitensVistoriaEntity> findAllByCodItemAndAtivo(ItemVistoriaEntity id, Boolean ativo);

}
