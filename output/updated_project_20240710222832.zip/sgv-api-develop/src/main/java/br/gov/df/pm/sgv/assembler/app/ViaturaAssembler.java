package br.gov.df.pm.sgv.assembler.app;

import br.gov.df.pm.sgv.domain.ViaturaEntity;
import br.gov.df.pm.sgv.dto.ViaturaDTO;
import br.gov.df.pm.sgv.service.ViaturaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.RepresentationModelAssembler;
import org.springframework.stereotype.Component;

@Component
public class ViaturaAssembler implements RepresentationModelAssembler<ViaturaEntity, EntityModel<ViaturaDTO>> {

    @Autowired
    ViaturaService viaturaService;

    @Override
    public EntityModel<ViaturaDTO> toModel(ViaturaEntity entity) {
        return EntityModel.of(ViaturaDTO.builder()
                .id(entity.getId())
                .nrSei(entity.getNrSei())
                .placa(entity.getPlaca())
                .ativo(entity.getAtivo())
                .dataAtualizacao(entity.getDataAtualizacao().atStartOfDay())
                .renavam(entity.getRenavam())
                .dataInclusao(entity.getDataInclusao().atStartOfDay())
                .prefixo(entity.getPrefixo())
                .ultimoOdometro(viaturaService.getUltimoOdometroByViatura(entity.getId()))
                .tombamento(entity.getTombamento())
                .vistoriaViatura(viaturaService.getVistoriaViaturaByViatura(entity.getId()))
                .build());
    }
}
