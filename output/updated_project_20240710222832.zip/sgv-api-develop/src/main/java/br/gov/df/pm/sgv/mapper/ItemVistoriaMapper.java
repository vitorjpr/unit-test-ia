package br.gov.df.pm.sgv.mapper;

import br.gov.df.pm.sgv.dto.ItemVistoriaDTO;
import br.gov.df.pm.sgv.domain.ItemVistoriaEntity;

import java.time.LocalDate;

public class ItemVistoriaMapper {
    public ItemVistoriaEntity convertEntity(ItemVistoriaDTO itemVistoriaDTO) {
        return ItemVistoriaEntity.builder()
                .nome(itemVistoriaDTO.getNome())
                .descricao(itemVistoriaDTO.getDescricao())
                .dataInclusao(LocalDate.now())
                .ativo(true)
                .build();
    }

    public ItemVistoriaDTO convertDTO(ItemVistoriaEntity itemVistoriaEntity) {
        return ItemVistoriaDTO.builder()
                .nome(itemVistoriaEntity.getNome())
                .descricao(itemVistoriaEntity.getDescricao())
                .dataInclusao(itemVistoriaEntity.getDataInclusao())
                .ativo(itemVistoriaEntity.getAtivo())
                .id(itemVistoriaEntity.getId())
                .build();
    }
}
