package br.gov.df.pm.sgv.service;

import br.gov.df.pm.sgv.dto.EdicaoTipoVistoriaDTO;
import br.gov.df.pm.sgv.dto.TipoVistoriaDTO;
import br.gov.df.pm.sgv.domain.*;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface TipoVistoriaService {
    ResponseEntity<?> buscarId(Long id);
    Page<TipoVistoriaEntity> buscar(String filter, Pageable pageable);
    ResponseEntity<?> salvar(TipoVistoriaDTO tipoVistoria);
    ResponseEntity<?> editar(Long id, EdicaoTipoVistoriaDTO edicao);
    ResponseEntity<?> desativar(Long id);
    ResponseEntity<?> excluir(Long id);
    ResponseEntity<?> ativar(Long id);
    ResponseEntity<List<ItensVistoriaEntity>> findAllItensVistoria();
    ResponseEntity<List<ItemVistoriaEntity>> findAllItemVistoriaById(String nome);
    ResponseEntity<List<ItemVistoriaEntity>> findAllItemVistoria();
    List<TipoVistoriaDTO> listAllTipoVistoriaAtivos();
    TipoVistoriaEntity findByIdTipoVistoria(Long id);
    List<TipoVistoriaEntity> listAllTipoVistoriaByStatusViatura(Long idViatura);
}
