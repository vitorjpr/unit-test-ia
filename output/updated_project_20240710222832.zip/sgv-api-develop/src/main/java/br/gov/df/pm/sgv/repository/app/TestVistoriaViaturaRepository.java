```java
package br.gov.df.pm.sgv.repository.app;

import br.gov.df.pm.sgv.domain.ViaturaEntity;
import br.gov.df.pm.sgv.domain.VistoriaViaturaEntity;
import br.gov.df.pm.sgv.dto.FiltroVistoria;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@ExtendWith({SpringExtension.class, MockitoExtension.class})
public class VistoriaViaturaRepositoryTest {

    @Mock
    private VistoriaViaturaRepository vistoriaViaturaRepository;

    @Test
    public void testFindByViatura() {
        ViaturaEntity viatura = new ViaturaEntity();
        when(vistoriaViaturaRepository.findByViatura(viatura)).thenReturn(Optional.empty());
        Optional<VistoriaViaturaEntity> result = vistoriaViaturaRepository.findByViatura(viatura);
        assertEquals(Optional.empty(), result);
    }

    @Test
    public void testFindAllByViaturaId() {
        Long id = 1L;
        when(vistoriaViaturaRepository.findAllByViaturaId(id)).thenReturn(new ArrayList<>());
        List<VistoriaViaturaEntity> result = vistoriaViaturaRepository.findAllByViaturaId(id);
        assertEquals(0, result.size());
    }

    @Test
    public void testFindAllByViatura() {
        ViaturaEntity viatura = new ViaturaEntity();
        when(vistoriaViaturaRepository.findAllByViatura(viatura)).thenReturn(new ArrayList<>());
        List<VistoriaViaturaEntity> result = vistoriaViaturaRepository.findAllByViatura(viatura);
        assertEquals(0, result.size());
    }

    @Test
    public void testFindAllByFiltro() {
        FiltroVistoria filter = new FiltroVistoria();
        Pageable pageable = Pageable.unpaged();
        when(vistoriaViaturaRepository.findAllByFiltro(filter, pageable)).thenReturn(Page.empty());
        Page<VistoriaViaturaEntity> result = vistoriaViaturaRepository.findAllByFiltro(filter, pageable);
        assertEquals(0, result.getContent().size());
    }
}
```

Neste exemplo de teste unitário, são cobertas as quatro operações definidas na interface `VistoriaViaturaRepository`. Foram utilizados mocks com o framework Mockito para simular o comportamento dos métodos da interface. Cada teste verifica se a chamada aos métodos retorna o resultado esperado.