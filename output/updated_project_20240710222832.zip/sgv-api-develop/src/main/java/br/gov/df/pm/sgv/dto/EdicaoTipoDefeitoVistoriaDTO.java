package br.gov.df.pm.sgv.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class EdicaoTipoDefeitoVistoriaDTO {
    private String nome;
    private String descricao;
}
