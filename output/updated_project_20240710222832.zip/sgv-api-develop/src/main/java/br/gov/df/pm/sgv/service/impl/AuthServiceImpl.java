package br.gov.df.pm.sgv.service.impl;

import br.gov.df.pm.sgv.dto.AuthDTO;
import br.gov.df.pm.sgv.feign.ApiServicosExternos;
import br.gov.df.pm.sgv.feign.dto.AuthKeycloakDTO;
import br.gov.df.pm.sgv.feign.dto.MessageAuthKeycloak;
import br.gov.df.pm.sgv.service.AuthService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.Objects;

@Slf4j
@Service
public class AuthServiceImpl implements AuthService {

    @Value("${keycloak.resource}")
    private String clientId;
    @Value("${keycloak.credentials.secret}")
    private String credentials;

    @Autowired
    private ApiServicosExternos apiServicosExternos;

    @Override
    public ResponseEntity<MessageAuthKeycloak> authentication(AuthDTO auth) {
        return doAuthenticationRequest(AuthKeycloakDTO.builder()
                .username(auth.getUsername())
                .password(auth.getPassword())
                .clientId(clientId)
                .credentals(credentials)
                .build()
        );
    }

    private ResponseEntity<MessageAuthKeycloak> doAuthenticationRequest(AuthKeycloakDTO auth) {
        try {
            var clientResponse = apiServicosExternos.authentication(auth);
            return ResponseEntity.ok(Objects.requireNonNull(clientResponse.getBody()));
        } catch (Exception e) {
            log.error("Erro ao buscar ao autenticar {}", e.getMessage());
            return ResponseEntity.badRequest().build();
        }
    }
}
