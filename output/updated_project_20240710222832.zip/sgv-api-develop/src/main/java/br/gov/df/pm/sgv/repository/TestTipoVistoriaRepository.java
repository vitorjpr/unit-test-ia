```java
package br.gov.df.pm.sgv.repository;

import br.gov.df.pm.sgv.domain.TipoVistoriaEntity;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@DataJpaTest
public class TipoVistoriaRepositoryTest {

    @Autowired
    private TipoVistoriaRepository tipoVistoriaRepository;

    @Autowired
    private TestEntityManager entityManager;

    @Test
    public void testFindByNome() {
        TipoVistoriaEntity tipoVistoria = new TipoVistoriaEntity();
        tipoVistoria.setNome("Teste");
        entityManager.persist(tipoVistoria);

        Optional<TipoVistoriaEntity> foundTipoVistoria = tipoVistoriaRepository.findByNome("Teste");

        assertTrue(foundTipoVistoria.isPresent());
        assertEquals("Teste", foundTipoVistoria.get().getNome());
    }

    @Test
    public void testFindAllByAtivo() {
        TipoVistoriaEntity tipoVistoria1 = new TipoVistoriaEntity();
        tipoVistoria1.setAtivo(true);
        entityManager.persist(tipoVistoria1);

        TipoVistoriaEntity tipoVistoria2 = new TipoVistoriaEntity();
        tipoVistoria2.setAtivo(false);
        entityManager.persist(tipoVistoria2);

        List<TipoVistoriaEntity> tipoVistoriasAtivos = tipoVistoriaRepository.findAllByAtivo(true);

        assertEquals(1, tipoVistoriasAtivos.size());
        assertTrue(tipoVistoriasAtivos.get(0).isAtivo());
    }

    @Test
    public void testFindAllByStatusPosterior() {
        TipoVistoriaEntity tipoVistoria1 = new TipoVistoriaEntity();
        tipoVistoria1.setStatusPosterior("A");
        entityManager.persist(tipoVistoria1);

        TipoVistoriaEntity tipoVistoria2 = new TipoVistoriaEntity();
        tipoVistoria2.setStatusPosterior("B");
        entityManager.persist(tipoVistoria2);

        List<TipoVistoriaEntity> tipoVistoriasStatusB = tipoVistoriaRepository.findAllByStatusPosterior("B");

        assertEquals(1, tipoVistoriasStatusB.size());
        assertEquals("B", tipoVistoriasStatusB.get(0).getStatusPosterior());
    }
}
```

Esses testes unitários cobrem os métodos `findByNome`, `findAllByAtivo` e `findAllByStatusPosterior` da classe `TipoVistoriaRepository`. Eles utilizam o framework Mockito para simular o comportamento dos métodos do repositório e o TestEntityManager do Spring para gerenciar as entidades durante os testes.