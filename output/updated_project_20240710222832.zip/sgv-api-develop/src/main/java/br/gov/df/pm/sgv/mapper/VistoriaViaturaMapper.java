package br.gov.df.pm.sgv.mapper;

import br.gov.df.pm.sgv.domain.VistoriaViaturaEntity;
import br.gov.df.pm.sgv.domain.VistoriaViaturaHistoricoEntity;
import br.gov.df.pm.sgv.domain.enums.VistoriaViaturaStatusEnum;
import br.gov.df.pm.sgv.domain.sgpol.UnidadePolicialMilitar;
import br.gov.df.pm.sgv.dto.VistoriaDTO;

import java.time.LocalDateTime;

public class VistoriaViaturaMapper {

    public VistoriaViaturaEntity convertEntity(VistoriaDTO vistoriaDTO) {
        return VistoriaViaturaEntity.builder()
                .id(vistoriaDTO.getId())
                .viatura(vistoriaDTO.getViatura())
                .tipoVistoria(vistoriaDTO.getTipoVistoria())
                .vistoriaViaturaHistorico(vistoriaDTO.getVistoriaViaturaHistorico())
                .status(VistoriaViaturaStatusEnum.EM_VISTORIA)
                .dataVistoria(vistoriaDTO.getDataVistoria())
                .diferencaVistoria(vistoriaDTO.getDiferencaVistoria())
                .diferencaOdometro(vistoriaDTO.getDiferencaOdometro())
                .odometroInicial(vistoriaDTO.getOdometroInicial())
                .odometroFinal(vistoriaDTO.getOdometroFinal())
                .vistoriaArquivoList(vistoriaDTO.getVistoriaArquivoList())
                .build();
    }
    public VistoriaDTO convertDTO(VistoriaViaturaEntity vistoria) {
        return VistoriaDTO.builder()
                .id(vistoria.getId())
                .viatura(vistoria.getViatura())
                .tipoVistoria(vistoria.getTipoVistoria())
                .vistoriaViaturaHistorico(vistoria.getVistoriaViaturaHistorico())
                .dataVistoria(vistoria.getDataVistoria())
                .diferencaOdometro(vistoria.getDiferencaOdometro())
                .diferencaVistoria(vistoria.getDiferencaVistoria())
                .odometroFinal(vistoria.getOdometroFinal())
                .odometroInicial(vistoria.getOdometroInicial())
                .vistoriaArquivoList(vistoria.getVistoriaArquivoList())
                .status(vistoria.getStatus())
                .build();
    }
}
