Here are some unit tests for the provided Java code:

```java
package br.gov.df.pm.sgv.repository;

import br.gov.df.pm.sgv.domain.ItemVistoriaEntity;
import br.gov.df.pm.sgv.domain.ItensVistoriaEntity;
import br.gov.df.pm.sgv.domain.TipoVistoriaEntity;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@SpringBootTest
@EnableJpaRepositories
public class ItensVistoriaRepositoryTest {

    @Mock
    private ItensVistoriaRepository itensVistoriaRepository;

    @Test
    public void testFindAllByCodTipo() {
        TipoVistoriaEntity tipoVistoriaEntity = new TipoVistoriaEntity();
        List<ItensVistoriaEntity> expectedList = // create expected list
        when(itensVistoriaRepository.findAllByCodTipo(tipoVistoriaEntity)).thenReturn(expectedList);

        List<ItensVistoriaEntity> resultList = itensVistoriaRepository.findAllByCodTipo(tipoVistoriaEntity);

        assertEquals(expectedList, resultList);
    }

    @Test
    public void testFindAllByCodItem() {
        ItemVistoriaEntity itemVistoriaEntity = new ItemVistoriaEntity();
        List<ItensVistoriaEntity> expectedList = // create expected list
        when(itensVistoriaRepository.findAllByCodItem(itemVistoriaEntity)).thenReturn(expectedList);

        List<ItensVistoriaEntity> resultList = itensVistoriaRepository.findAllByCodItem(itemVistoriaEntity);

        assertEquals(expectedList, resultList);
    }

    @Test
    public void testFindByCodTipoAndCodItem() {
        TipoVistoriaEntity tipoVistoriaEntity = new TipoVistoriaEntity();
        ItemVistoriaEntity itemVistoriaEntity = new ItemVistoriaEntity();
        ItensVistoriaEntity expectedEntity = // create expected entity
        when(itensVistoriaRepository.findByCodTipoAndCodItem(tipoVistoriaEntity, itemVistoriaEntity)).thenReturn(Optional.of(expectedEntity));

        Optional<ItensVistoriaEntity> resultEntity = itensVistoriaRepository.findByCodTipoAndCodItem(tipoVistoriaEntity, itemVistoriaEntity);

        assertEquals(expectedEntity, resultEntity.get());
    }

    @Test
    public void testFindBycodTipoAndAtivo() {
        TipoVistoriaEntity tipoVistoriaEntity = new TipoVistoriaEntity();
        Boolean ativo = true;
        List<ItensVistoriaEntity> expectedList = // create expected list
        when(itensVistoriaRepository.findBycodTipoAndAtivo(tipoVistoriaEntity, ativo)).thenReturn(expectedList);

        List<ItensVistoriaEntity> resultList = itensVistoriaRepository.findBycodTipoAndAtivo(tipoVistoriaEntity, ativo);

        assertEquals(expectedList, resultList);
    }
}
```

These tests cover the methods `findAllByCodTipo`, `findAllByCodItem`, `findByCodTipoAndCodItem`, and `findBycodTipoAndAtivo` from the `ItensVistoriaRepository` interface. You can replace the placeholders with actual expected values for more comprehensive testing.