package br.gov.df.pm.sgv.domain;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import lombok.*;

import javax.persistence.*;
import java.util.Date;
import java.util.List;

@Entity
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(of = "id")
@Table(name = "CHECKLIST_VISTORIASUBITEM", schema = "sgv")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class ChecklistVistoriaSubItemEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "cvs_Id", unique = true, nullable = false)
    private Long id;

    @Column(name = "cvs_Selecionado")
    private Boolean selecionado;

    @Column(name = "cvs_DataCriacao")
    private Date dataCriacao;

    @JsonBackReference("item-subitems")
    @ManyToOne
    @JoinColumn(name = "cvi_Id", nullable = false)
    private ChecklistItemVistoriaEntity checklistItemVistoria;

    @ManyToOne
    @JoinColumn(name = "tidv_Codigo", nullable = false)
    private TipoDefeitoVistoriaEntity tipoDefeitoVistoria;

}
