Sure! Here are the unit tests for the `UserDetailsException` class:

```java
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class UserDetailsExceptionTest {

    @Test
    public void testConstructorWithMessage() {
        String message = "Test message";
        UserDetailsException exception = new UserDetailsException(message);
        assertNotNull(exception);
        assertEquals(message, exception.getMessage());
    }

    @Test
    public void testConstructorWithMessageAndCause() {
        String message = "Test message";
        Throwable cause = new RuntimeException("Test cause");
        UserDetailsException exception = new UserDetailsException(message, cause);
        assertNotNull(exception);
        assertEquals(message, exception.getMessage());
        assertEquals(cause, exception.getCause());
    }
}
```

These unit tests cover both constructors of the `UserDetailsException` class, ensuring that the message and cause are set correctly.