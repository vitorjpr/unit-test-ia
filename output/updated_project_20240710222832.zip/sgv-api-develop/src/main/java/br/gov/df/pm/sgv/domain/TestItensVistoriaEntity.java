```java
package br.gov.df.pm.sgv.domain;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.time.LocalDate;

public class ItensVistoriaEntityTest {

    @Test
    public void testGetSetId() {
        ItensVistoriaEntity entity = new ItensVistoriaEntity();
        Long id = 1L;
        entity.setId(id);
        assertEquals(id, entity.getId());
    }

    @Test
    public void testGetSetCodTipo() {
        ItensVistoriaEntity entity = new ItensVistoriaEntity();
        TipoVistoriaEntity tipoVistoriaEntity = new TipoVistoriaEntity();
        entity.setCodTipo(tipoVistoriaEntity);
        assertEquals(tipoVistoriaEntity, entity.getCodTipo());
    }

    @Test
    public void testGetSetCodItem() {
        ItensVistoriaEntity entity = new ItensVistoriaEntity();
        ItemVistoriaEntity itemVistoriaEntity = new ItemVistoriaEntity();
        entity.setCodItem(itemVistoriaEntity);
        assertEquals(itemVistoriaEntity, entity.getCodItem());
    }

    @Test
    public void testGetSetAtivo() {
        ItensVistoriaEntity entity = new ItensVistoriaEntity();
        Boolean ativo = true;
        entity.setAtivo(ativo);
        assertEquals(ativo, entity.getAtivo());
    }

    @Test
    public void testGetSetDataInclusao() {
        ItensVistoriaEntity entity = new ItensVistoriaEntity();
        LocalDate dataInclusao = LocalDate.now();
        entity.setDataInclusao(dataInclusao);
        assertEquals(dataInclusao, entity.getDataInclusao());
    }
}
```