package br.gov.df.pm.sgv.domain;


import lombok.*;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;

@Entity
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(of = "id")
@Table(name = "TIPOEMPREGOVIATURA", schema = "sgf")
public class TipoEmpregoViaturaEntity implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "tep_Codigo")
    private Integer id;

    @Size(max = 50)
    @Column(name = "tep_Nome")
    private String nome;

    @Column(name = "tep_Ativo")
    private Integer ativo;
}
