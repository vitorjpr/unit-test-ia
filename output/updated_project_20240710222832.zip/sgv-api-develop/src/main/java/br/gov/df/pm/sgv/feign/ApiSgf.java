//package br.gov.df.pm.sgv.feign;
//
//import br.gov.df.pm.sgv.domain.sgpol.UnidadePolicialMilitar;
//import org.springframework.cloud.openfeign.FeignClient;
//import org.springframework.http.MediaType;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.GetMapping;
//
//import java.util.List;
//
//@FeignClient(
//        name = "ApiSGF",
//        url = "${api.host.sgf.url}",
//        configuration = { FeignSkipExceptionConfiguration.class }
//)
//public interface ApiSgf {
//    @GetMapping(value ="upm", consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
//    ResponseEntity<List<UnidadePolicialMilitar>> listarUpm();
//}
