package br.gov.df.pm.sgv.domain.sgpol;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import java.io.Serializable;

@Entity
@Table(name = "RECURSO", schema = "dbo", catalog = "sgpol")
@Getter @Setter
public class Recurso implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="rec_Codigo",unique=true, nullable=false)
	private int id;

	@Column(name = "rec_Ativo", nullable = false,  columnDefinition = "int default 1", insertable = false, updatable = true)
	private int ativo;

	@NotBlank(message="Descrição é obrigatório")
	@Lob
	@Column(name="rec_Descricao",nullable=false)
	private String descricao;

	@NotBlank(message="Nome é obrigatório")
	@Column(name="rec_Nome",nullable=false, length=100)
	private String nome;


	@NotBlank(message="Titulo é obrigatório")
	@Column(name="rec_Titulo",nullable=false, length=100)
	private String titulo;

	// @JoinColumn(name = "sub_Codigo", referencedColumnName = "sub_Codigo")
	// @ManyToOne(fetch = FetchType.LAZY)
	// private SubSistema subSistema;


	// @OneToMany(mappedBy = "idRecurso", fetch = FetchType.LAZY)
	// private List<PerfilRecurso> listPerfilRecurso;

	// @OneToMany(mappedBy = "recurso", fetch = FetchType.LAZY)
	// private List<PessoaRecurso> listPessoaRecurso;

	// @OneToMany(mappedBy = "recurso", fetch = FetchType.LAZY)
	// private List<FuncaoUpmLotacaoRecurso> funcaoUpmLotacaoRecurso;

	// @OneToMany(mappedBy = "recurso", fetch = FetchType.LAZY)
	// private List<UpmRecurso> upmRecurso;

	// @Transient
	// private int quantidadePessoas;

	// @Transient
	// private int quantidadeUnidades;

	// @Transient
	// private int quantidadePerfis;

	// @Transient
	// private boolean associado;

	// public boolean isAssociado() {
	// 	return associado;
	// }

	// public void setAssociado(boolean associado) {
	// 	this.associado = associado;
	// }

	// public boolean isNovo(){

	// 	return this.id==0;
	// }

	// public int getId() {
	// 	return id;
	// }

	// public void setId(int id) {
	// 	this.id = id;
	// }

	// public int getAtivo() {
	// 	return ativo;
	// }

	// public void setAtivo(int ativo) {
	// 	this.ativo = ativo;
	// }

	// public String getDescricao() {
	// 	return descricao;
	// }

	// public void setDescricao(String descricao) {
	// 	this.descricao = descricao;
	// }

	// public String getNome() {
	// 	return nome;
	// }

	// public void setNome(String nome) {
	// 	this.nome = nome;
	// }

	// public List<PessoaRecurso> getListPessoaRecurso() {
	// 	return listPessoaRecurso;
	// }

	// public void setListPessoaRecurso(List<PessoaRecurso> listPessoaRecurso) {
	// 	this.listPessoaRecurso = listPessoaRecurso;
	// }

	// public List<PerfilRecurso> getListPerfilRecurso() {
	// 	return listPerfilRecurso;
	// }

	// public void setListPerfilRecurso(List<PerfilRecurso> listPerfilRecurso) {
	// 	this.listPerfilRecurso = listPerfilRecurso;
	// }

	// public SubSistema getSubSistema() {
	// 	return subSistema;
	// }

	// public void setSubSistema(SubSistema subSistema) {
	// 	this.subSistema = subSistema;
	// }

	// public String getTitulo() {
	// 	return titulo;
	// }

	// public void setTitulo(String titulo) {
	// 	this.titulo = titulo;
	// }

	// public List<FuncaoUpmLotacaoRecurso> getFuncaoUpmLotacaoRecurso() {
	// 	return funcaoUpmLotacaoRecurso;
	// }

	// public void setFuncaoUpmLotacaoRecurso(List<FuncaoUpmLotacaoRecurso> funcaoUpmLotacaoRecurso) {
	// 	this.funcaoUpmLotacaoRecurso = funcaoUpmLotacaoRecurso;
	// }

	// public int getQuantidadePessoas() {
	// 	return quantidadePessoas;
	// }

	// public void setQuantidadePessoas(int quantidadePessoas) {
	// 	this.quantidadePessoas = quantidadePessoas;
	// }

	// public int getQuantidadeUnidades() {
	// 	return quantidadeUnidades;
	// }

	// public void setQuantidadeUnidades(int quantidadeUnidades) {
	// 	this.quantidadeUnidades = quantidadeUnidades;
	// }

	// public int getQuantidadePerfis() {
	// 	return quantidadePerfis;
	// }

	// public void setQuantidadePerfis(int quantidadePerfis) {
	// 	this.quantidadePerfis = quantidadePerfis;
	// }

	// public List<UpmRecurso> getUpmRecurso() {
	// 	return upmRecurso;
	// }

	// public void setUpmRecurso(List<UpmRecurso> upmRecurso) {
	// 	this.upmRecurso = upmRecurso;
	// }

	// public int getUnidade() {
	// 	int retorno = 0;
	// 	for (UpmRecurso upmRecurso  : upmRecurso) {
	// 		if(upmRecurso != null) {

	// 			retorno++;
	// 		}
	// 	}

	// 	return retorno;
	// }

	// public List<Pessoa> getPessoas() {
	// 	List<Pessoa> retorno = new ArrayList<Pessoa>();
	// 	for (PessoaRecurso pessoaRecurso : listPessoaRecurso) {

	// 			retorno.add(pessoaRecurso.getPessoa());
	// 	}

	// 	for (PerfilRecurso perfilRecurso : listPerfilRecurso) {
	// 		retorno.addAll(perfilRecurso.getIdPerfil().getPessoas());
	// 	}

	// 	return retorno;
	// }

	// public List<UnidadePolicialMilitar> getUnidades() {
	// 	List<UnidadePolicialMilitar> retorno = new ArrayList<UnidadePolicialMilitar>();
	// 	for (UpmRecurso upmRecursos : upmRecurso) {
	// 		retorno.add(upmRecursos.getUpm());

	// 	}

	// 	return retorno;
	// }

	// public List<Perfil> getPerfis() {
	// 	List<Perfil> retorno = new ArrayList<Perfil>();
	// 	for (PerfilRecurso perfilRecurso : listPerfilRecurso) {
	// 		retorno.add(perfilRecurso.getIdPerfil());
	// 	}

	// 	return retorno;
	// }

	// @SuppressWarnings("unused")
	// public int getPerfil() {
	// 	int retorno = 0;
	// 	for (PerfilRecurso perfilRecurso : listPerfilRecurso) {
	// 		retorno++;
	// 	}

	// 	return retorno;
	// }
/*
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Recurso other = (Recurso) obj;
		if (id != other.id)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Recurso [id=" + id + ", ativo=" + ativo + ", descricao=" + descricao + ", nome=" + nome + "]";
	}
*/



}