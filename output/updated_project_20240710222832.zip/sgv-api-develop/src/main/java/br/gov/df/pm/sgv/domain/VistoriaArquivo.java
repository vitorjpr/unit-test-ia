package br.gov.df.pm.sgv.domain;

import br.gov.df.pm.sgv.domain.enums.VistoriaViaturaStatusEnum;
import com.fasterxml.jackson.annotation.JsonBackReference;
import lombok.*;
import net.minidev.json.annotate.JsonIgnore;

import javax.persistence.*;
import java.util.Date;
import java.util.UUID;

@Entity
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(of = "id")
@Table(name = "VISTORIAARQUIVO", schema = "sgv")
public class VistoriaArquivo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "vis_Codigo", unique = true, nullable = false)
    private Long id;

    @Column(name = "vis_Identidade", nullable = false, length = 200)
    private String identidade;

    @Column(name = "vis_NomeImagem")
    private String nomeImagem;

    @Column(name = "vis_DataCriacao")
    private Date dataCriacao;

    @JsonBackReference
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "vv_Codigo", nullable = false)
    private VistoriaViaturaEntity vistoriaViatura;
}
