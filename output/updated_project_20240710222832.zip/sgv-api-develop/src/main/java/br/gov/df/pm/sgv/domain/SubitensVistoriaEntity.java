package br.gov.df.pm.sgv.domain;

import lombok.*;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDate;

@Entity
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(of = "id")
@Table(name = "SUBITENSVISTORIA", schema = "sgv")
public class SubitensVistoriaEntity implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "suv_Codigo", unique = true, nullable = false)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "suv_CodItem")
    private ItemVistoriaEntity codItem;

    @ManyToOne
    @JoinColumn(name = "suv_CodSubitem")
    private SubitemVistoriaEntity codSubitem;

    @Column(name = "suv_ativo")
    private Boolean ativo;

    @DateTimeFormat(pattern="dd/MM/yyyy")
    @Column(name = "suv_DtInclusao")
    private LocalDate dataInclusao;
}
