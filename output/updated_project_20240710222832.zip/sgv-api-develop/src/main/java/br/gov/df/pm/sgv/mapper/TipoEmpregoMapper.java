package br.gov.df.pm.sgv.mapper;

import br.gov.df.pm.sgv.domain.TipoEmpregoViaturaEntity;
import br.gov.df.pm.sgv.dto.TipoEmpregoViaturaDto;

public class TipoEmpregoMapper {

        public TipoEmpregoViaturaEntity convertEntity(TipoEmpregoViaturaDto tipoEmpregoViaturaDto) {
            return TipoEmpregoViaturaEntity.builder()
                    .ativo(tipoEmpregoViaturaDto.getAtivo())
                    .id(tipoEmpregoViaturaDto.getId())
                    .nome(tipoEmpregoViaturaDto.getNome())
                    .build();
        }

        public TipoEmpregoViaturaDto convertDTO(TipoEmpregoViaturaEntity tipoEmpregoViatura) {
            return TipoEmpregoViaturaDto.builder()
                    .ativo(tipoEmpregoViatura.getAtivo())
                    .id(tipoEmpregoViatura.getId())
                    .nome(tipoEmpregoViatura.getNome())
                    .build();
        }
}