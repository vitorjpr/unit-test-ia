Sure! Here are some unit tests for the `OperationException` class:

```java
package br.gov.df.pm.sgv.exceptions;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class OperationExceptionTest {

    @Test
    public void testConstructorWithMessage() {
        String message = "Test message";
        OperationException exception = new OperationException(message);

        assertNotNull(exception);
        assertEquals(message, exception.getMessage());
    }

    @Test
    public void testConstructorWithMessageAndCause() {
        String message = "Test message";
        Throwable cause = new RuntimeException("Test cause");
        OperationException exception = new OperationException(message, cause);

        assertNotNull(exception);
        assertEquals(message, exception.getMessage());
        assertEquals(cause, exception.getCause());
    }

    @Test
    public void testConstructorWithNullMessage() {
        OperationException exception = new OperationException(null);

        assertNotNull(exception);
        assertEquals(null, exception.getMessage());
    }

    @Test
    public void testConstructorWithNullMessageAndCause() {
        Throwable cause = new RuntimeException("Test cause");
        OperationException exception = new OperationException(null, cause);

        assertNotNull(exception);
        assertEquals(null, exception.getMessage());
        assertEquals(cause, exception.getCause());
    }
}
```

These tests cover the constructors of the `OperationException` class with different scenarios, including passing a message, passing a message and a cause, passing a null message, and passing a null message and a cause.