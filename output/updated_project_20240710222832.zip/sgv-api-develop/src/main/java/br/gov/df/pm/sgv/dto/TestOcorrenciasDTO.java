Sure! Here are some unit tests for the `OcorrenciasDTO` class:

```java
package br.gov.df.pm.sgv.dto;

import org.junit.jupiter.api.Test;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class OcorrenciasDTOTest {

    @Test
    public void testConstructorAndGetters() {
        List<ItemVistoriaOcorrenciaDTO> itemVistoriaOcorrenciaDTOS = new ArrayList<>();
        itemVistoriaOcorrenciaDTOS.add(new ItemVistoriaOcorrenciaDTO());

        OcorrenciasDTO ocorrenciasDTO = new OcorrenciasDTO(itemVistoriaOcorrenciaDTOS);

        assertNotNull(ocorrenciasDTO);
        assertEquals(itemVistoriaOcorrenciaDTOS, ocorrenciasDTO.getItemVistoriaOcorrenciaDTOS());
    }

    @Test
    public void testSetters() {
        List<ItemVistoriaOcorrenciaDTO> itemVistoriaOcorrenciaDTOS = new ArrayList<>();
        itemVistoriaOcorrenciaDTOS.add(new ItemVistoriaOcorrenciaDTO());

        OcorrenciasDTO ocorrenciasDTO = new OcorrenciasDTO();
        ocorrenciasDTO.setItemVistoriaOcorrenciaDTOS(itemVistoriaOcorrenciaDTOS);

        assertEquals(itemVistoriaOcorrenciaDTOS, ocorrenciasDTO.getItemVistoriaOcorrenciaDTOS());
    }

    // Add more tests here as needed

}
```

Make sure to add more tests to cover other scenarios and edge cases if needed.