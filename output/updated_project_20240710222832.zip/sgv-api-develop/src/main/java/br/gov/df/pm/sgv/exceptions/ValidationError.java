package br.gov.df.pm.sgv.exceptions;

public class ValidationError extends RuntimeException{
    public ValidationError(String message) {
        super(message);
    }
}
