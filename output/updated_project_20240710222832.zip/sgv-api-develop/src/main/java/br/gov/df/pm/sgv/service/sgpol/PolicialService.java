package br.gov.df.pm.sgv.service.sgpol;

import br.gov.df.pm.sgv.domain.sgpol.Policial;
import br.gov.df.pm.sgv.domain.sgpol.UnidadePolicialMilitar;
import br.gov.df.pm.sgv.dto.root.PerfilDTO;
import br.gov.df.pm.sgv.dto.root.RecursoDTO;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;



@Service
public interface PolicialService {
   Policial findPolicialById(Integer id);

   ResponseEntity<Policial> findById(Integer id);

   Policial findPolicialByPessoaMatricula(String matricula);

   List<RecursoDTO> getRecursoDtoPolicialAutenticado(String matricula);

   UnidadePolicialMilitar getUnidadePolicialAutenticado(String matricula);

   List<PerfilDTO> getPerfilDtoPolicialAutenticado(String matricula);
}