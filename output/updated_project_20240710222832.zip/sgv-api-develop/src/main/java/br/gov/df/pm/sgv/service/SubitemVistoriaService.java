package br.gov.df.pm.sgv.service;

import br.gov.df.pm.sgv.dto.EdicaoSubitemVistoriaDTO;
import br.gov.df.pm.sgv.dto.SubitemVistoriaDTO;
import br.gov.df.pm.sgv.domain.DefeitosVistoriaEntity;
import br.gov.df.pm.sgv.domain.SubitemVistoriaEntity;
import br.gov.df.pm.sgv.domain.TipoDefeitoVistoriaEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface SubitemVistoriaService {
    ResponseEntity<SubitemVistoriaDTO> buscarId(Long id);
    Page<SubitemVistoriaEntity> buscar(String filter, Pageable pageable);
    ResponseEntity<?> salvar(SubitemVistoriaDTO subitemVistoria);
    ResponseEntity<?> editar(Long id, EdicaoSubitemVistoriaDTO edicao);
    ResponseEntity<?> desativar(Long id);
    ResponseEntity<?> excluir(Long id);
    ResponseEntity<?> ativar(Long id);
    ResponseEntity<List<TipoDefeitoVistoriaEntity>> findAllTipoDefeitoVistoriaById(String nome);
    ResponseEntity<List<TipoDefeitoVistoriaEntity>> findAllTipoDefeitoVistoria();
    ResponseEntity<List<DefeitosVistoriaEntity>> findAllDefeitosVistoria();
    ResponseEntity<?> desvincularTipoDefeito(Long idTipoDefeito, Long idSubitem);
    ResponseEntity<?> desvincularTodosTipoDefeito(Long idSubitem);
}
