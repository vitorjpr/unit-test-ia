package br.gov.df.pm.sgv.repository.app;

import br.gov.df.pm.sgv.domain.VistoriaViaturaHistoricoEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface VistoriaViaturaHistoricoRepository extends JpaRepository<VistoriaViaturaHistoricoEntity, Long> {
}
