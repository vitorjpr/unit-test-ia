package br.gov.df.pm.sgv.service.sgpol.exception;

public class SisgepatError extends RuntimeException{

	private static final long serialVersionUID = 1L;

	public SisgepatError(String message) {
        super(message);
    }

    public SisgepatError(String message, Throwable cause) {
        super(message, cause);
    }

    public static <T> boolean isInstance(T t) {
        return t instanceof SisgepatError;
    }
}
