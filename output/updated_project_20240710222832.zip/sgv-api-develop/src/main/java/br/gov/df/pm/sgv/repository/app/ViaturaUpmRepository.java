package br.gov.df.pm.sgv.repository.app;

import br.gov.df.pm.sgv.domain.ViaturaUpmEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface ViaturaUpmRepository extends JpaRepository<ViaturaUpmEntity, Long>, JpaSpecificationExecutor<ViaturaUpmEntity> {
}
