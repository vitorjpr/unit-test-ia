package br.gov.df.pm.sgv.domain;

import br.gov.df.pm.sgv.domain.enums.VistoriaViaturaStatusEnum;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import lombok.*;
import net.minidev.json.annotate.JsonIgnore;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "VISTORIA_VIATURA", schema = "sgv")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class VistoriaViaturaEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "vv_Codigo", unique = true, nullable = false)
    private Long id;

    @Column(name="vv_Codigo_Policial")
    private Integer idPolicial;

    @Column(name="vv_Codigo_Upm")
    private Integer idUpm;

    @OneToOne
    @JoinColumn(name = "vtr_Codigo")
    private ViaturaEntity viatura;

    @OneToOne
    @JoinColumn(name = "tiv_Codigo")
    private TipoVistoriaEntity tipoVistoria;

    @OneToMany(mappedBy = "vistoriaViatura", cascade = CascadeType.ALL)
    @JsonManagedReference
    private List<VistoriaViaturaHistoricoEntity> vistoriaViaturaHistorico;

    @OneToMany(mappedBy = "vistoriaViatura", cascade = CascadeType.ALL)
    @JsonManagedReference
    private List<VistoriaArquivo> vistoriaArquivoList;

    @OneToOne
    @JoinColumn(name = "do_Codigo")
    private DiferencaOdometroEntity diferencaOdometro;

    @Column(name = "vv_Status")
    private VistoriaViaturaStatusEnum status;

    @Column(name = "vv_OdometroInicial")
    private Float odometroInicial;

    @Column(name = "vv_OdometroFinal")
    private Float odometroFinal;

    @Column(name = "vv_DiferencaVistoria")
    private Boolean diferencaVistoria;

    @Column(name = "vv_DataVistoria")
    private LocalDateTime dataVistoria;

    @JsonManagedReference("vistoria-checklists")
    @OneToMany(mappedBy = "vistoria", cascade = CascadeType.ALL)
    private List<ChecklistVistoriaEntity> checkLists;

}
