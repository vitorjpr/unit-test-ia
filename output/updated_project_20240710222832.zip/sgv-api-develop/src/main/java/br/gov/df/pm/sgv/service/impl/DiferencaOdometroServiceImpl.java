package br.gov.df.pm.sgv.service.impl;

import br.gov.df.pm.sgv.domain.DiferencaOdometroEntity;
import br.gov.df.pm.sgv.domain.TipoVistoriaEntity;
import br.gov.df.pm.sgv.domain.ViaturaEntity;
import br.gov.df.pm.sgv.domain.VistoriaViaturaEntity;
import br.gov.df.pm.sgv.dto.DiferencaOdometroDTO;
import br.gov.df.pm.sgv.dto.DiferencaDTO;
import br.gov.df.pm.sgv.exceptions.VistoriaExceptions;
import br.gov.df.pm.sgv.mapper.DiferencaOdometroMapper;
import br.gov.df.pm.sgv.repository.DiferencaOdometroRepository;
import br.gov.df.pm.sgv.repository.TipoVistoriaRepository;
import br.gov.df.pm.sgv.repository.app.ViaturaRepository;
import br.gov.df.pm.sgv.repository.app.VistoriaViaturaRepository;
import br.gov.df.pm.sgv.service.DiferencaOdometroService;
import br.gov.df.pm.sgv.shared.utils.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import javax.persistence.criteria.Predicate;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

@Service
public class DiferencaOdometroServiceImpl implements DiferencaOdometroService {

    @Autowired
    DiferencaOdometroRepository diferencaOdometroRepository;

    @Autowired
    TipoVistoriaRepository tipoVistoriaRepository;

    @Autowired
    ViaturaRepository viaturaRepository;

    @Autowired
    VistoriaViaturaRepository vistoriaViaturaRepository;

    @Override
    public ResponseEntity<DiferencaOdometroDTO> buscarId(Long id) {
        return ResponseEntity.ok(new DiferencaOdometroMapper().convertDTO(findById(id)));
    }

    @Override
    public Page<DiferencaOdometroEntity> buscar(String filter, Pageable pageable) {
        return diferencaOdometroRepository.findAll(filtroToSpecification(filter), pageable);
    }

    private Specification<DiferencaOdometroEntity> filtroToSpecification(String filtro) {
        return (root, query, builder) -> {
            if (!StringUtils.isEmptyOrNull(filtro)) {
                var predications = new ArrayList<Predicate>();
                if(isIntegerValue(filtro) != null) {
                    var value = isIntegerValue(filtro);
                    predications.add(builder.equal(root.get("diferencaOdometro"), value));
                }
                return builder.or(predications.toArray(Predicate[]::new));
            }
            return null;
        };
    }

    private Integer isIntegerValue(String value) {
        try{
            var newValue = value.replace(".", "");
            return Integer.parseInt(newValue);
        }
        catch (NumberFormatException ex){
            ex.printStackTrace(); return null;
        }
    }

    @Override
    public ResponseEntity<DiferencaOdometroDTO> salvar(DiferencaOdometroDTO diferencaOdometroDTO) {
        var diferencaOdometro = diferencaOdometroRepository.findByReferenciaInicialAndReferenciaFinal(diferencaOdometroDTO.getReferenciaInicial(), diferencaOdometroDTO.getReferenciaFinal());
        if(diferencaOdometro.isPresent()) {
            throw new VistoriaExceptions("Diferença Odômetro referência Inicial com Final já criado!");
        }
        diferencaOdometroRepository.save(new DiferencaOdometroMapper().convertEntity(diferencaOdometroDTO));
        return ResponseEntity.ok(diferencaOdometroDTO);
    }

    @Override
    public ResponseEntity<?> editar(Long id, DiferencaOdometroDTO edicao) {
        var diferencaOdometro = findById(id);
        if (edicao.getReferenciaInicial() != null) {
            diferencaOdometro.setReferenciaInicial(edicao.getReferenciaInicial());
        }
        if (edicao.getReferenciaFinal() != null) {
            diferencaOdometro.setReferenciaFinal(edicao.getReferenciaFinal());
        }
        if (edicao.getDiferencaOdometro() != null) {
            diferencaOdometro.setDiferencaOdometro(edicao.getDiferencaOdometro());
        }
        diferencaOdometro.setDataModificacao(LocalDate.now());
        return ResponseEntity.ok(diferencaOdometroRepository.save(diferencaOdometro));
    }

    @Override
    public ResponseEntity<?> excluir(Long id) {
        var diferencaOdometro = findById(id);
         diferencaOdometroRepository.delete(diferencaOdometro);
        return null;
    }

    @Override
    public ResponseEntity<?> desativar(Long id) {
        var diferencaOdometro = findById(id);
        return null;
    }

    @Override
    public ResponseEntity<?> ativar(Long id) {
        var diferencaOdometro = findById(id);
        return null;
    }

    @Override
    public ResponseEntity<List<TipoVistoriaEntity>> findAllTipoVistoria() {
        return ResponseEntity.ok(tipoVistoriaRepository.findAllByAtivo(true));
    }

    @Override
    public DiferencaOdometroDTO buscarDiferenca(DiferencaDTO diferencaDTO) {
        boolean diferencaPermitida;
        ViaturaEntity viatura = viaturaRepository.findById(diferencaDTO.getIdViatura()).orElseThrow(() -> new VistoriaExceptions("Viatura não encontrada"));
        TipoVistoriaEntity tipoVistoria = tipoVistoriaRepository.findById(diferencaDTO.getTipoVistoria().getId()).orElseThrow(() -> new VistoriaExceptions("Tipo de vistoria não encontrado"));
        List<VistoriaViaturaEntity> byViatura = vistoriaViaturaRepository.findAllByViatura(viatura);
        Comparator<VistoriaViaturaEntity> comparator = Comparator.comparing(VistoriaViaturaEntity::getDataVistoria);
        VistoriaViaturaEntity vistoriaViaturaEntity = byViatura.stream().filter(f -> f.getDataVistoria() != null).max(comparator).get();

        List<DiferencaOdometroEntity> byReferenciaInicial = diferencaOdometroRepository.findAllByReferenciaInicial(tipoVistoria);
        if(byReferenciaInicial != null && !byReferenciaInicial.isEmpty()) {
            DiferencaOdometroEntity diferencaOdometroEntity = byReferenciaInicial.get(byReferenciaInicial.size() - 1);
            float diferencaOdometro = diferencaDTO.getUltimoOdometro() - vistoriaViaturaEntity.getOdometroFinal();
            if(diferencaOdometroEntity.getDiferencaOdometro() > diferencaOdometro) {
                diferencaPermitida = true;
            } else {
                diferencaPermitida = false;
            }
            return DiferencaOdometroDTO.builder()
                    .diferencaPermitido(diferencaPermitida)
                    .dataInclusao(diferencaOdometroEntity.getDataInclusao())
                    .dataModificacao(diferencaOdometroEntity.getDataModificacao())
                    .referenciaFinal(diferencaOdometroEntity.getReferenciaFinal())
                    .referenciaInicial(diferencaOdometroEntity.getReferenciaInicial())
                    .diferencaOdometro(diferencaOdometroEntity.getDiferencaOdometro())
                    .build();
        }
        return DiferencaOdometroDTO.builder()
                .diferencaPermitido(true)
                .build();
    }

    private DiferencaOdometroEntity findById(Long id) {
        return diferencaOdometroRepository.findById(id).orElseThrow();
    }
}
