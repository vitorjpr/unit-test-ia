Sure! Here are some unit tests for the provided Java code:

```java
import br.gov.df.pm.sgv.domain.sgpol.UnidadePolicialMilitar;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class ApiSgfTest {

    @Mock
    private ApiSgf apiSgf;

    @Test
    public void testListarUpm() {
        // Mocking the response
        List<UnidadePolicialMilitar> upmList = new ArrayList<>();
        upmList.add(new UnidadePolicialMilitar("UPM1"));
        upmList.add(new UnidadePolicialMilitar("UPM2"));
        ResponseEntity<List<UnidadePolicialMilitar>> responseEntity = ResponseEntity.ok(upmList);

        // Mocking the FeignClient call
        when(apiSgf.listarUpm()).thenReturn(responseEntity);

        // Calling the method
        ResponseEntity<List<UnidadePolicialMilitar>> result = apiSgf.listarUpm();

        // Assertions
        assertEquals(upmList.size(), result.getBody().size());
        assertEquals(upmList.get(0).getNome(), result.getBody().get(0).getNome());
        assertEquals(upmList.get(1).getNome(), result.getBody().get(1).getNome());
    }
}
```

In the test above, we are using Mockito to mock the `ApiSgf` interface and simulate the behavior of the `listarUpm` method. We then verify if the method returns the expected list of `UnidadePolicialMilitar` objects.

Please note that you will need to have the necessary dependencies (like Mockito) added to your project to run these tests successfully.