Sure! Here are some unit tests for the provided Java code:

```java
package br.gov.df.pm.sgv.controller;

import br.gov.df.pm.sgv.assembler.TipoDefeitoVistoriaAssembler;
import br.gov.df.pm.sgv.dto.EdicaoTipoDefeitoVistoriaDTO;
import br.gov.df.pm.sgv.dto.TipoDefeitoVistoriaDTO;
import br.gov.df.pm.sgv.domain.TipoDefeitoVistoriaEntity;
import br.gov.df.pm.sgv.service.TipoDefeitoVistoriaService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.PagedModel;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

public class TipoDefeitoVistoriaControllerTest {

    private TipoDefeitoVistoriaService service;
    private TipoDefeitoVistoriaAssembler assembler;
    private PagedResourcesAssembler<TipoDefeitoVistoriaEntity> pagedResourcesAssembler;
    private TipoDefeitoVistoriaController controller;

    @BeforeEach
    public void setUp() {
        service = mock(TipoDefeitoVistoriaService.class);
        assembler = mock(TipoDefeitoVistoriaAssembler.class);
        pagedResourcesAssembler = mock(PagedResourcesAssembler.class);
        controller = new TipoDefeitoVistoriaController(service, assembler, pagedResourcesAssembler);
    }

    @Test
    public void testBuscarId() {
        Long id = 1L;
        TipoDefeitoVistoriaDTO tipoDefeito = new TipoDefeitoVistoriaDTO();
        when(service.buscarId(id)).thenReturn(ResponseEntity.ok(tipoDefeito));

        ResponseEntity<TipoDefeitoVistoriaDTO> response = controller.buscarId(id);

        assertEquals(tipoDefeito, response.getBody());
    }

    @Test
    public void testBuscar() {
        String filter = "filter";
        PageRequest pageable = PageRequest.of(0, 10);
        PageImpl<TipoDefeitoVistoriaEntity> page = new PageImpl<>(null, pageable, 0);
        when(service.buscar(filter, pageable)).thenReturn(page);

        PagedModel<EntityModel<TipoDefeitoVistoriaDTO>> result = controller.buscar(filter, pageable);

        assertEquals(0, result.getContent().size());
    }

    @Test
    public void testSalvar() {
        TipoDefeitoVistoriaDTO tipoDefeito = new TipoDefeitoVistoriaDTO();
        when(service.salvar(tipoDefeito)).thenReturn(ResponseEntity.ok().build());

        ResponseEntity<?> response = controller.salvar(tipoDefeito);

        assertEquals(200, response.getStatusCodeValue());
    }

    @Test
    public void testEditar() {
        Long id = 1L;
        EdicaoTipoDefeitoVistoriaDTO edicao = new EdicaoTipoDefeitoVistoriaDTO();
        when(service.editar(id, edicao)).thenReturn(ResponseEntity.ok().build());

        ResponseEntity<?> response = controller.editar(id, edicao);

        assertEquals(200, response.getStatusCodeValue());
    }

    @Test
    public void testExcluir() {
        Long id = 1L;
        when(service.excluir(id)).thenReturn(ResponseEntity.ok().build());

        ResponseEntity<?> response = controller.excluir(id);

        assertEquals(200, response.getStatusCodeValue());
    }

    @Test
    public void testDesativar() {
        Long id = 1L;
        when(service.desativar(id)).thenReturn(ResponseEntity.ok().build());

        ResponseEntity<?> response = controller.desativar(id);

        assertEquals(200, response.getStatusCodeValue());
    }

    @Test
    public void testAtivar() {
        Long id = 1L;
        when(service.ativar(id)).thenReturn(ResponseEntity.ok().build());

        ResponseEntity<?> response = controller.ativar(id);

        assertEquals(200, response.getStatusCodeValue());
    }
}
```

These unit tests cover the main functionalities of the `TipoDefeitoVistoriaController` class. Make sure to adjust the test assertions according to the actual behavior of the methods in the service layer.