package br.gov.df.pm.sgv.domain;

import lombok.*;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDate;

@Entity
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(of = "id")
@Table(name = "TIPODEFEITOVISTORIA", schema = "sgv")
public class TipoDefeitoVistoriaEntity implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "tidv_Codigo", unique = true, nullable = false)
    private Long id;

    @Column(name = "tidv_Nome")
    private String nome;

    @Column(name = "tidv_Descricao")
    private String descricao;

    @Column(name = "tidv_ativo")
    private Boolean ativo;

    @DateTimeFormat(pattern="dd/MM/yyyy")
    @Column(name = "tidv_DtInclusao")
    private LocalDate dataInclusao;
}
