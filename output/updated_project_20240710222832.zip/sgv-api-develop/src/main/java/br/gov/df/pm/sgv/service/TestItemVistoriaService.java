Sure! Here are some unit tests for the provided ItemVistoriaService interface:

```java
package br.gov.df.pm.sgv.service;

import br.gov.df.pm.sgv.dto.EdicaoItemVistoriaDTO;
import br.gov.df.pm.sgv.dto.ItemVistoriaDTO;
import br.gov.df.pm.sgv.domain.ItemVistoriaEntity;
import br.gov.df.pm.sgv.domain.SubitemVistoriaEntity;
import br.gov.df.pm.sgv.domain.SubitensVistoriaEntity;
import br.gov.df.pm.sgv.dto.OcorrenciasDTO;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class ItemVistoriaServiceTest {

    @Mock
    private ItemVistoriaService itemVistoriaService;

    @Test
    public void testBuscarId() {
        ResponseEntity<ItemVistoriaDTO> response = itemVistoriaService.buscarId(1L);
        assertNotNull(response);
    }

    @Test
    public void testBuscar() {
        Page<ItemVistoriaEntity> page = itemVistoriaService.buscar("filter", Pageable.unpaged());
        assertNotNull(page);
    }

    @Test
    public void testSalvar() {
        ItemVistoriaDTO itemVistoriaDTO = new ItemVistoriaDTO();
        ResponseEntity<?> response = itemVistoriaService.salvar(itemVistoriaDTO);
        assertNotNull(response);
    }

    @Test
    public void testEditar() {
        EdicaoItemVistoriaDTO edicao = new EdicaoItemVistoriaDTO();
        ResponseEntity<?> response = itemVistoriaService.editar(1L, edicao);
        assertNotNull(response);
    }

    @Test
    public void testDesativar() {
        ResponseEntity<?> response = itemVistoriaService.desativar(1L);
        assertNotNull(response);
    }

    @Test
    public void testExcluir() {
        ResponseEntity<?> response = itemVistoriaService.excluir(1L);
        assertNotNull(response);
    }

    @Test
    public void testAtivar() {
        ResponseEntity<?> response = itemVistoriaService.ativar(1L);
        assertNotNull(response);
    }

    @Test
    public void testFindAllSubitensVistoria() {
        ResponseEntity<List<SubitensVistoriaEntity>> response = itemVistoriaService.findAllSubitensVistoria();
        assertNotNull(response);
    }

    @Test
    public void testFindAllSubitemVistoriaById() {
        ResponseEntity<List<SubitemVistoriaEntity>> response = itemVistoriaService.findAllSubitemVistoriaById("nome");
        assertNotNull(response);
    }

    @Test
    public void testFindAllSubitemVistoria() {
        ResponseEntity<List<SubitemVistoriaEntity>> response = itemVistoriaService.findAllSubitemVistoria();
        assertNotNull(response);
    }

    @Test
    public void testListAllAtivosByTipoVistoria() {
        OcorrenciasDTO ocorrenciasDTO = itemVistoriaService.listAllAtivosByTipoVistoria(1L);
        assertNotNull(ocorrenciasDTO);
    }
}
```

These tests cover each method in the ItemVistoriaService interface and ensure that the responses are not null. You can further expand these tests by adding more specific test cases for each method.