package br.gov.df.pm.sgv.domain.sgpol;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Getter;
import lombok.Setter;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

@Getter @Setter
@Entity
@Table(name = "PESSOA", schema = "dbo", catalog = "sgpol")
public class Pessoa implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "pes_Codigo", unique = true, nullable = false)
	private Integer id;

	@NotBlank(message="Nome é obrigatório")
	@Size(max = 150)
	@Column(name = "pes_Nome")
	@OrderBy("nome DESC")
	private String nome;
	
	@Transient
	private String nomecurto;
	
	// @Transient
	// private MensagemUsuario mensagemBloqueio;
	
	
	
	@Transient
	private int certidaocivil;

	@Size(max = 150)
	@Column(name = "pes_NomeAnterior")
	private String nomeAnterior;

	@Size(max = 20)
	@Column(name = "pes_RG")
	private String rg;

	@Size(max = 10)
	@Column(name = "pes_RGOrgaoExpedidor")
	private String rgOrgaoExpedidor;

	@Column(name = "pes_RGDtEmissao")
	@Temporal(TemporalType.DATE)
	@DateTimeFormat(pattern="dd/MM/yyyy")
	private Date rgDataEmissao;
	
	@Column(name = "pes_DtAtualizacao")
	private LocalDateTime dataAtualizacao;
	
	// @CPF
	@Column(name = "pes_CPF")
	private String cpf;

	@Column(name = "pes_DtNascimento")
//	@Temporal(TemporalType.DATE)
	@DateTimeFormat(pattern="dd/MM/yyyy")
	private LocalDate dataNascimento;

	@Size(max = 150)
	@Column(name = "pes_NomePai")
	private String nomePai;

//	@NotBlank(message="Nome da Mãe é obrigatório")
	@Size(max = 150)
	@Column(name = "pes_NomeMae")
	private String nomeMae;

	@Size(max = 12)
	@Column(name = "pes_PISPASEP")
	private String pisPasep;

	@Column(name = "pes_DtPISPASEP")
	@Temporal(TemporalType.DATE)
	@DateTimeFormat(pattern="dd/MM/yyyy") 
	private Date dataPisPasep;

	@Size(max = 12)
	@Column(name = "pes_TituloEleitorNr")
	private String tituloEleitorNumero;

	@Column(name = "pes_TituloEleitorZona")
	private Integer tituloEleitorZona;

	
	@Column(name = "pes_TituloEleitorSecao")
	private Integer tituloEleitorSecao;

	@Size(max = 15)
	@Column(name = "pes_CNHRegistro")
	private String cnhRegistro;

	@Column(name = "pes_CNHDtEmissao")
	private LocalDate cnhDataEmissao;

	@Column(name = "pes_CNHDtPrimeira")
	private LocalDate cnhDataPrimeira;

	@Column(name = "pes_CNHDtValidade")
	private LocalDate cnhDataValidade;

	
	// @JoinColumn(name = "tps_Codigo", referencedColumnName = "tps_Codigo")
	// @ManyToOne(fetch = FetchType.EAGER)
	// @JsonIgnore
	// private TipoPessoa tpsCodigo;

	//   @Column(name = "tps_Codigo")
	//   private Integer tpsCodigo;
	@Column(name = "usu_Codigo")
	private Integer idUsuario;
	
	@Column(name = "pes_AcessoRestrito")
	private boolean acessoRestrito;

	@Column(name = "pes_idTransacaoEgov")
	private String transacaoEgov;

	@JsonIgnore
	@ManyToMany
	@JoinTable(name = "PESSOA_PERFIL", schema = "dbo", catalog = "sgpol", joinColumns = { @JoinColumn(name = "pes_codigo") }, inverseJoinColumns = {
			@JoinColumn(name = "pef_codigo") })
	public List<Perfil> perfis;
	
// 	@OneToMany(mappedBy = "idPessoa", fetch = FetchType.LAZY)
// 	@JsonIgnore
// 	private List<Email> listEmail;
	
	
// 	@OneToMany(mappedBy = "pessoa", fetch = FetchType.LAZY)
// 	@JsonIgnore
// 	private List<AnexoDocumento> anexosDocumento;
	
	
// //	@OneToMany(mappedBy = "idPessoa", fetch = FetchType.LAZY)
// //	@JsonIgnore
	
// 	@JsonIgnore
// 	@OneToMany(mappedBy = "idPessoa", fetch = FetchType.LAZY)
// 	@Fetch(org.hibernate.annotations.FetchMode.SUBSELECT) 
// 	private List<Endereco> listEndereco;

// 	@OneToMany(mappedBy = "idPessoa", fetch = FetchType.LAZY)
// 	@JsonIgnore
// 	private List<Conta> listConta;
	
	
// 	@OneToOne(mappedBy = "idPessoa", fetch = FetchType.LAZY)
// 	@JsonIgnore
// 	private Policial policial;
	
// 	@OneToOne(mappedBy = "idPessoa", fetch = FetchType.LAZY)
// 	@JsonIgnore
// 	private FuncionarioCivil funcionarioCivil;
	
// 	@OneToMany(mappedBy = "idPessoa", fetch = FetchType.LAZY)
// 	@JsonIgnore
// 	//@Fetch(value = FetchMode.SUBSELECT)
// 	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
// 	private Set<Dependente> dependentePessoa;
	
	
// //	@OneToOne(mappedBy = "idPessoa", fetch = FetchType.LAZY)
// //	private CandidatoPttc candidatoPttc;
	
	
// //	@LazyToOne(LazyToOneOption.NO_PROXY)
// 	@OneToMany(mappedBy = "idPessoa", fetch = FetchType.LAZY)
// 	@JsonIgnore
// 	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
// 	private Set<Pensionista> pensionist;
	
	
// 	@OneToMany(mappedBy = "idPessoaAfetado", fetch = FetchType.LAZY)
// 	@JsonIgnore
// 	private List<AuditoriaCensus> listAuditoriaCensusAfetado;

// 	@JsonIgnore
// 	@OneToMany( mappedBy = "idPessoa", fetch = FetchType.LAZY)
// //	@JoinColumn(name="pes_Codigo") 
//     private List<PessoaIdioma> listPessoaIdiomas;
	
	
// 	@OneToMany( mappedBy = "idPessoa", fetch = FetchType.LAZY)
// 	private List<Dependente> listDependente;

// 	@OneToMany( mappedBy = "idPessoa", fetch = FetchType.LAZY)
// 	@JsonIgnore
// 	private List<Biometria> listBiometria;

// 	@OneToMany(mappedBy = "idPessoa", fetch = FetchType.LAZY)
// 	@JsonIgnore
// 	private List<Senhas> listSenhas;

// 	@OneToMany( mappedBy = "idPessoa", fetch = FetchType.LAZY)
// 	@JsonIgnore
// 	private List<Profissao> listProfissao;

// 	@OneToMany( mappedBy = "idPessoa", fetch = FetchType.LAZY)
// 	@JsonIgnore
// 	private List<CadastroAlteracoes> listCadastroAlteracoes;

// 	@OneToMany( mappedBy = "idPessoa", fetch = FetchType.LAZY)
// 	@JsonIgnore
// 	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
// 	private List<Pensionista> listPensionista;

	
// 	@JsonIgnore
// 	@OneToMany(mappedBy = "idPessoa", fetch = FetchType.LAZY)
// 	private List<Certidoes> listCertidoes;
	
	
// 	@OneToMany(mappedBy = "idPessoa", fetch = FetchType.LAZY)
// 	@JsonIgnore
// 	private List<CertificadoMilitar>  certificadoMilitar;

	
// //	cascade = CascadeType.ALL, mappedBy = "idPessoaAutor", fetch = FetchType.LAZY
// 	@JsonIgnore
// 	@ManyToOne
// 	@JoinColumn(name = "def_Codigo", referencedColumnName = "def_Codigo")
// 	private Deficiencia idDeficiencia;

// 	@JoinColumn(name = "cid_CodigoNaturalidade", referencedColumnName = "cid_Codigo")
// 	@ManyToOne(fetch = FetchType.LAZY)
// 	@JsonIgnore
// 	private Cidade cidCodigoNaturalidade; 

// 	@JoinColumn(name = "cid_CodigoTituloEleitorMunicipio", referencedColumnName = "cid_Codigo")
// 	@ManyToOne(fetch = FetchType.LAZY)
// 	@JsonIgnore
// 	private Cidade cidCodigoTituloEleitorMunicipio;

// 	@JoinColumn(name = "cnh_Codigo", referencedColumnName = "cnh_Codigo")
// 	@ManyToOne(fetch = FetchType.LAZY)
// 	@JsonIgnore
// 	private CnhCategoria idCnhCategoria;

// 	@JoinColumn(name = "cut_Codigo", referencedColumnName = "cut_Codigo")
// 	@ManyToOne(fetch = FetchType.LAZY)
// 	@JsonIgnore
// 	private Cutis idCutis;

// 	@JoinColumn(name = "ufe_CodigoRGOrgaoExpedidor", referencedColumnName = "ufe_Codigo")
// 	@ManyToOne(fetch = FetchType.LAZY)
// 	@JsonIgnore
// 	private UnidadeFederativa ufeOrgaoExpedidor;

// 	@JoinColumn(name = "tca_Codigo", referencedColumnName = "tca_Codigo")
// 	@ManyToOne(fetch = FetchType.LAZY)
// 	@JsonIgnore
// 	private TipoCabelo idTipoCabelo;

// 	@JoinColumn(name = "esc_Codigo", referencedColumnName = "esc_Codigo")
// 	@ManyToOne(fetch = FetchType.LAZY)
// 	@JsonIgnore
// 	private EstadoCivil idEstadoCivil;

// 	@JoinColumn(name = "etn_Codigo", referencedColumnName = "etn_Codigo")
// 	@ManyToOne(fetch = FetchType.LAZY)
// 	@JsonIgnore
// 	private Etnia idEtnia;

// 	@JoinColumn(name = "grs_Codigo", referencedColumnName = "grs_Codigo")
// 	@ManyToOne(fetch = FetchType.LAZY)
// 	@JsonIgnore
// 	private GrupoSanguineo idGrupoSanguineo;

// 	@JoinColumn(name = "olh_Codigo", referencedColumnName = "olh_Codigo")
// 	@ManyToOne(fetch = FetchType.LAZY)
// 	@JsonIgnore
// 	private Olhos idOlhos;


// 	@JoinColumn(name = "sex_Codigo", referencedColumnName = "sex_Codigo")
// 	@ManyToOne(fetch = FetchType.LAZY)
// 	@JsonIgnore
// 	private Sexo idSexo;

// 	@JoinColumn(name = "pai_CodigoNacionalidade", referencedColumnName = "pai_Codigo")
// 	@ManyToOne(fetch = FetchType.LAZY)
// 	@JsonIgnore
// 	private Pais idPais;

// 	@JoinColumn(name = "rel_Codigo", referencedColumnName = "rel_Codigo")
// 	@ManyToOne(fetch = FetchType.LAZY)
// 	@JsonIgnore
// 	private Religiao idReligiao;

// 	@JoinColumn(name = "ufe_CodigoCNH", referencedColumnName = "ufe_Codigo")
// 	@ManyToOne(fetch = FetchType.LAZY)
// 	@JsonIgnore
// 	private UnidadeFederativa ufeCNH;

// 	@JsonIgnore
// 	@OneToMany(mappedBy = "idPessoa", fetch = FetchType.LAZY)
// 	@OrderBy("anoRecadastramento DESC")
// 	private Set<HistoricoRecadastramento> listHistoricoRecadastramentos;

// //	@OneToMany(mappedBy = "idPessoa", fetch = FetchType.LAZY)
// //	@JsonIgnore
	
	
	
// 	@JsonIgnore
// 	@OneToMany(mappedBy = "idPessoa", fetch = FetchType.LAZY)
// 	private List<Telefone> listTelefone;

// 	@JsonIgnore
// 	@OneToMany(mappedBy = "idPessoa", fetch = FetchType.LAZY)
// 	private List<Formacao> listFormacao; 

	

// 	@OneToMany(mappedBy = "idPessoa", fetch = FetchType.LAZY)
// 	@JsonIgnore
// 	private List<Afastamento> listAfastamentos;
	
// 	@OneToMany(mappedBy = "idPessoa", fetch = FetchType.LAZY)
// 	@JsonIgnore
// 	private List<Ferias> listFerias;
	
// 	@OneToMany(mappedBy = "idPessoaUsuario", fetch = FetchType.LAZY)
// 	@JsonIgnore
// 	private List<Ferias> listFeriasUsuario;
	
// 	@OneToMany(mappedBy = "idPessoa", fetch = FetchType.LAZY)
// 	@JsonIgnore
// 	private List<FeriasIndicacao> listFeriasIndicacao;
	
// 	@OneToMany(mappedBy = "idPessoa", fetch = FetchType.LAZY)
// 	@JsonIgnore
// 	private List<Abono> listAbonos;
	
// 	@OneToMany(mappedBy = "idPessoaUsuario", fetch = FetchType.LAZY)
// 	@JsonIgnore
// 	private List<Abono> listAbonosUsuario;
	
// 	@OneToMany(mappedBy = "idPessoa", fetch = FetchType.LAZY)
// 	@JsonIgnore
// 	private List<CandidatoDSA> listCandidatosDSA;
	
// 	@OneToMany(mappedBy = "cadastrante", fetch = FetchType.LAZY)
// 	@JsonIgnore
// 	private List<Talao> idTalao;
	
	
// 	@Column(name = "pes_HabilitaRecadastramento")
// 	@JsonIgnore
// 	private Integer habilitaRecadastramento;
	
	
// 	//bi-directional many-to-one association to PessoaAgendaPericial
// 	@OneToMany(mappedBy="IdPessoa")
// 	@JsonIgnore
// 	private List<PessoaAgendaPericial> listPessoaAgendaPericial;

// 	//bi-directional many-to-one association to PessoaInspecaoSaude
// 	@OneToMany(mappedBy="pessoa")
// 	@JsonIgnore
// 	private List<InspecaoSaude> inspecoesSaude;
	
// 	@OneToMany(mappedBy = "remetente", fetch = FetchType.LAZY)
// 	@JsonIgnore
// 	private List<MensagemUsuario> remetente;
	
	
// 	@OneToMany(mappedBy = "destinatario", fetch = FetchType.LAZY)
// 	@JsonIgnore
// 	private List<MensagemUsuario> destinatario;
	
// 	@OneToMany(mappedBy = "idPessoa", fetch = FetchType.LAZY)
// 	@JsonIgnore
// 	private List<HistoricoProvaDeVida> listHistoricoProvaDeVida;
	
	@Transient
	@JsonIgnore
	private boolean bloqueado = false;
	
	@Transient
	@JsonIgnore
	private boolean mensagemTela = false;
	
	@Transient
	@JsonIgnore
	private boolean mensagemAlerta = false;
	
	@Transient
	private boolean provaVidaValida = false;
	
	@Transient
	private Integer statusProvaVida=1;
		

//	@OneToMany(cascade = CascadeType.ALL, mappedBy = "idPessoaAutor", fetch = FetchType.LAZY)
//	@JsonIgnore
//	private List<AuditoriaCensus> listAuditoriaCensusAutor;

	// public Policial getPolicial() {
	// 	return policial;
	// }

	// public boolean isProvaVidaValida() {
	// 	return provaVidaValida;
	// }

	// public void setProvaVidaValida(boolean provaVidaValida) {
	// 	this.provaVidaValida = provaVidaValida;
	// }

	// public void setPolicial(Policial policial) {
	// 	this.policial = policial;
	// }

	// @OneToOne(mappedBy = "idPessoa", fetch = FetchType.LAZY)
	// @JsonIgnore
	// private Candidato candidatos;
	
	@ManyToMany
	@JoinTable(name = "PESSOA_RECURSO", schema = "dbo", catalog = "sgpol",
		joinColumns = @JoinColumn(name = "pes_Codigo"), 
		inverseJoinColumns = @JoinColumn(name = "rec_Codigo"))
	@JsonIgnore
	private List<Recurso> listPessoaRecurso;

	@ManyToMany
	@JoinTable(name = "PESSOA_PERFIL", schema = "dbo", catalog = "sgpol",
		joinColumns = @JoinColumn(name = "pes_Codigo"), 
		inverseJoinColumns = @JoinColumn(name = "pef_Codigo"))
	@JsonIgnore
	private List<Perfil> pessoaPerfil;

	
	// @OneToMany(mappedBy = "idPessoa", fetch = FetchType.LAZY)
	// @JsonIgnore
	// private List<CandidatoPttc> candidatoPttc;

	// @Transient
	// @JsonIgnore
	// private MedidasCorporais medidaCorporal;
	
	// @Transient
	// private String mensagem;
	
	// @Transient
	// @JsonIgnore
	// private int statusRecadastramento = 0;
	
	// @Transient
	// @JsonIgnore
	// private Endereco enderecoAtual;
	
	// @Transient
	// @JsonIgnore
	// private AnexoDocumento foto;
	
	// @Transient
	// private boolean pensionista = false;
	
	// @Transient
	// private boolean ativo = false;
	
	// @Transient
	// private boolean candidato = false;
	
	// @Transient
	// private boolean inativo = false;
	
	// @Transient
	// private boolean civil = false;
	
	// @Transient
	// private boolean militar = false;

	// @Transient
	// private boolean dependente = false;
	
	// @Transient
	// private boolean desligado = false;
	
	// @Transient
	// public boolean empregadoTerceirizado = false;
	
	// @Transient
	// private int pendenciasAnexos;
	
	
	// @Transient
	// private Pais paisResidencia;
	
	
// 	public boolean isCnhVencida() {
		
// 		boolean retorno = false;
		
// 		if(this.cnhDataValidade!=null && this.cnhDataValidade.isBefore(LocalDate.now())  ) {
// 			retorno = true;
// 		}
		
// 		return retorno;
// 	}
	
// 	public LocalDate getCnhDataEmissao() {
// 		return cnhDataEmissao;
// 	}

// 	public void setCnhDataEmissao(LocalDate cnhDataEmissao) {
// 		this.cnhDataEmissao = cnhDataEmissao;
// 	}

// 	public LocalDate getCnhDataPrimeira() {
// 		return cnhDataPrimeira;
// 	}

// 	public void setCnhDataPrimeira(LocalDate cnhDataPrimeira) {
// 		this.cnhDataPrimeira = cnhDataPrimeira;
// 	}

// 	public LocalDate getCnhDataValidade() {
// 		return cnhDataValidade;
// 	}

// 	public void setCnhDataValidade(LocalDate cnhDataValidade) {
// 		this.cnhDataValidade = cnhDataValidade;
// 	}

// 	public boolean isNovo() {
// 		return id == null;
// 	}
	

// 	public String getMensagem() {
// 		return mensagem;
// 	}

// 	public void setMensagem(String mensagem) {
// 		this.mensagem = mensagem;
// 	}

// 	public List<PessoaAgendaPericial> getListPessoaAgendaPericial() {
// 		return listPessoaAgendaPericial;
// 	}

// 	public void setListPessoaAgendaPericial(List<PessoaAgendaPericial> listPessoaAgendaPericial) {
// 		this.listPessoaAgendaPericial = listPessoaAgendaPericial;
// 	}

// 	public List<InspecaoSaude> getInspecoesSaude() {
// 		return inspecoesSaude;
// 	}

// 	public void setInspecoesSaude(List<InspecaoSaude> inspecoesSaude) {
// 		this.inspecoesSaude = inspecoesSaude;
// 	}

// 	public List<PessoaPerfil> getPessoaPerfil() {
// 		return pessoaPerfil;
// 	}

// 	public void setPessoaPerfil(List<PessoaPerfil> pessoaPerfil) {
// 		this.pessoaPerfil = pessoaPerfil;
// 	}

// 	@PrePersist @PreUpdate
// 	private void prePersistPreUpdate() {
// 		this.cpf = (this.cpf!=null?this.cpf.trim().replaceAll("\\.|-|/", ""):null);
// 	}
	
	

// //	1 - concluido, 
// //	2 - homologado, 
// //	3 - iniciado
// //	4 - pendente, 
	
// 	public String getTransacaoEgov() {
// 		return transacaoEgov;
// 	}

// 	public void setTransacaoEgov(String transacaoEgov) {
// 		this.transacaoEgov = transacaoEgov;
// 	}

// 	@PostLoad
// 	private void postLoad() {		
	
		
// 		if(this.tpsCodigo!=null){
// 			if(this.tpsCodigo.getId().intValue()== TipoPessoaEnum.DEPENDENTE.getId()
// 					|| this.tpsCodigo.getId().intValue()==TipoPessoaEnum.DEPENDENTEDUPLADEPENDENCIA.getId()
// 					|| this.tpsCodigo.getId().intValue()==TipoPessoaEnum.DEPENDENTEFUNCIONARIOCIVILCOMISSIONADO.getId()
// 					|| this.tpsCodigo.getId().intValue()==TipoPessoaEnum.DEPENDENTEGUARDACOMPARTILHADA.getId()
// 					|| this.tpsCodigo.getId().intValue()==TipoPessoaEnum.DEPENDENTEJUDICIAL.getId()
// 					|| this.tpsCodigo.getId().intValue()==TipoPessoaEnum.PENSIONISTADEPENDENTE.getId()
// 					|| this.tpsCodigo.getId().intValue()==TipoPessoaEnum.POLICIALATIVODEPENDENTE.getId()
// 					|| this.tpsCodigo.getId().intValue()==TipoPessoaEnum.POLICIALDESLIGADODEPENDENTE.getId()
// 					|| this.tpsCodigo.getId().intValue()==TipoPessoaEnum.DEPENDENTEEMPREGADOTERCEIRIZADO.getId()
// 					|| this.tpsCodigo.getId().intValue()==TipoPessoaEnum.POLICIALINATIVODEPENDENTE.getId() 
// 					){
// 				dependente = true;
// 			}
			
// 			if(this.tpsCodigo.getId().intValue()==TipoPessoaEnum.PENSIONISTA.getId()
// 					|| this.tpsCodigo.getId().intValue()==TipoPessoaEnum.PENSIONISTADEPENDENTE.getId()
// 					|| this.tpsCodigo.getId().intValue()==TipoPessoaEnum.POLICIALATIVOPENSIONISTA.getId()
// 					|| this.tpsCodigo.getId().intValue()==TipoPessoaEnum.POLICIALINATIVOPENSIONISTA.getId()
// 					|| this.tpsCodigo.getId().intValue()==TipoPessoaEnum.PENSIONISTAFUNCIONARIOCIVILCOMISSIONADO.getId()
// 					){
// 				pensionista = true;
// 			}
			
// 			if(this.tpsCodigo.getId().intValue()==TipoPessoaEnum.POLICIALDESLIGADO.getId()
// 					|| this.tpsCodigo.getId().intValue()==TipoPessoaEnum.POLICIALDESLIGADODEPENDENTE.getId()){
// 				desligado = true;
// 				inativo = true;
// 			}
			
// 			if(this.tpsCodigo.getId().intValue()==TipoPessoaEnum.FUNCIONARIOCIVIL.getId()
// 					|| this.tpsCodigo.getId().intValue()==TipoPessoaEnum.FUNCIONARIOCIVILCOMISSIONADO.getId()
// 					|| this.tpsCodigo.getId().intValue()==TipoPessoaEnum.DEPENDENTEFUNCIONARIOCIVILCOMISSIONADO.getId()
// 					|| this.tpsCodigo.getId().intValue()==TipoPessoaEnum.PENSIONISTAFUNCIONARIOCIVILCOMISSIONADO.getId()
// 					|| this.tpsCodigo.getId().intValue()==TipoPessoaEnum.POLICIALINATIVOFUNCIONARIOCIVIL.getId()
// 					){
// 				civil = true;
// 			}
			
			
			
// 			if(this.tpsCodigo.getId().intValue()==TipoPessoaEnum.POLICIALINATIVO.getId()
// 					|| this.tpsCodigo.getId()==TipoPessoaEnum.POLICIALINATIVOPENSIONISTA.getId()
// 					|| this.tpsCodigo.getId()==TipoPessoaEnum.POLICIALINATIVOFUNCIONARIOCIVIL.getId()
// 					|| this.tpsCodigo.getId()==TipoPessoaEnum.POLICIALINATIVODEPENDENTE.getId() 
// 					){
				
// 				inativo = true;
// 			}
			
// 			if(this.tpsCodigo.getId().intValue()==TipoPessoaEnum.POLICIALATIVO.getId()
// 					|| this.tpsCodigo.getId().intValue()==TipoPessoaEnum.POLICIALATIVOPENSIONISTA.getId()
// 					|| this.tpsCodigo.getId().intValue()==TipoPessoaEnum.POLICIALATIVODEPENDENTE.getId()
// 					){
// 				ativo = true;
// 			}
			
// 			if(this.tpsCodigo.getId().intValue()==TipoPessoaEnum.CANDIDATO.getId()
// 					){
// 				candidato = true;
// 			}
// 			if(this.tpsCodigo.getId().intValue()==TipoPessoaEnum.EMPREGADOTERCEIRIZADO.getId()
// 					|| this.tpsCodigo.getId().intValue()==TipoPessoaEnum.DEPENDENTEEMPREGADOTERCEIRIZADO.getId()
// 					){
// 				empregadoTerceirizado = true;
// 			}
// 			if(ativo || inativo) {
// 				militar = true;
// 			}
			
// 		}
		
// 		this.cpf = (this.cpf!=null?this.cpf.replaceAll("(\\d{3})(\\d{3})(\\d{3})", "$1.$2.$3-").trim():null); 
		
// 		if(this.cnhRegistro!=null){
// 			habilitado = 1;
// 		}
			
		
// 	}
	
	
	
	
// //	public int getPaginaCorrete(Pessoa pessoa) {
// //		
// //		if(pessoa.isAtivo()){
// //			return 10;
// //		}else if (pessoa.isInativo()) {
// //			return 8;
// //		}else if (pessoa.isPensionista()) {
// //			return 8;
// //		}else if (pessoa.isCivil()) {
// //			return 8;
// //		}else{
// //			return 8;
// //		}
// //	}


// 	@Transient
// 	private int habilitado;
	
// 	@Transient
// 	private String novaFoto;
	
// 	@Transient
// 	private String urlFoto;
	
// 	@Transient
// 	private int deficiencia;
	
	
// 	@Transient
// 	private List<AnexosDAO> listaAnexos;
	
	
// 	public boolean isMensagemAlerta() {
// 		return mensagemAlerta;
// 	}

// 	public void setMensagemAlerta(boolean mensagemAlerta) {
// 		this.mensagemAlerta = mensagemAlerta;
// 	}

// 	public Integer getHabilitaRecadastramento() {
// 		return habilitaRecadastramento;
// 	}

// 	public void setHabilitaRecadastramento(Integer habilitaRecadastramento) {
// 		this.habilitaRecadastramento = habilitaRecadastramento;
// 	}

// 	public List<AnexosDAO> getListaAnexos() {
// 		return listaAnexos;
// 	}

// 	public void setListaAnexos(List<AnexosDAO> listaAnexos) {
// 		this.listaAnexos = listaAnexos;
// 	}

// 	public int getDeficiencia() {
// 		return deficiencia;
// 	}

// 	public void setDeficiencia(int deficiencia) {
// 		this.deficiencia = deficiencia;
// 	}

// 	public MedidasCorporais getMedidaCorporal() {
// 		return medidaCorporal;
// 	}

// 	public void setMedidaCorporal(MedidasCorporais medidaCorporal) {
// 		this.medidaCorporal = medidaCorporal;
// 	}

// 	public String getNovaFoto() {
// 		return novaFoto;
// 	}

// 	public void setNovaFoto(String novaFoto) {
// 		this.novaFoto = novaFoto;
// 	}

// 	public String getUrlFoto() {
// 		return urlFoto;
// 	}

// 	public void setUrlFoto(String urlFoto) {
// 		this.urlFoto = urlFoto;
// 	}

// 	public Integer getId() {
// 		return id;
// 	}

// 	public void setId(Integer id) {
// 		this.id = id;
// 	}

// 	public String getNome() {
// 		return nome;
// 	}

// 	public void setNome(String nome) {
// 		this.nome = nome;
// 	}

// 	public String getNomeAnterior() {
// 		return nomeAnterior;
// 	}


// 	public void setNomeAnterior(String nomeAnterior) {
// 		this.nomeAnterior = nomeAnterior;
// 	}

	
// 	public String getRg() {
// 		return rg;
// 	}

// 	public void setRg(String rg) {
// 		this.rg = rg;
// 	}

	
// 	public String getRgOrgaoExpedidor() {
// 		return rgOrgaoExpedidor;
// 	}

// 	public void setRgOrgaoExpedidor(String rgOrgaoExpedidor) {
// 		this.rgOrgaoExpedidor = rgOrgaoExpedidor;
// 	}

	
// 	public Date getRgDataEmissao() {
// 		return rgDataEmissao;
// 	}

// 	public void setRgDataEmissao(Date rgDataEmissao) {
// 		this.rgDataEmissao = rgDataEmissao;
// 	}

// 	public int getStatusRecadastramento() {
// 		setarUltimoRecadastramento();
// 		return statusRecadastramento;
// 	}

// 	public void setStatusRecadastramento(int statusRecadastramento) {
// 		this.statusRecadastramento = statusRecadastramento;
// 	}

// 	public String getCpf() {
// 		return cpf;
// 	}

// 	public void setCpf(String cpf) {
// 		this.cpf = cpf;
// 	}

	
// 	public int getHabilitado() {
// 		return habilitado;
// 	}

// 	public void setHabilitado(int habilitado) {
// 		this.habilitado = habilitado;
// 	}

// 	public LocalDate getDataNascimento() {
// 		return dataNascimento;
// 	}

// 	public void setDataNascimento(LocalDate dataNascimento) {
// 		this.dataNascimento = dataNascimento;
// 	}
	
// 	public String getNomePai() {
// 		return nomePai;
// 	}

// 	public void setNomePai(String nomePai) {
// 		this.nomePai = nomePai;
// 	}

	
// 	public String getNomeMae() {
// 		return nomeMae;
// 	}

// 	public void setNomeMae(String nomeMae) {
// 		this.nomeMae = nomeMae;
// 	}

	
// 	public String getPisPasep() {
// 		return pisPasep;
// 	}


// 	public void setPisPasep(String pisPasep) {
// 		this.pisPasep = pisPasep;
// 	}

	
// 	public Date getDataPisPasep() {
// 		return dataPisPasep;
// 	}

// 	public void setDataPisPasep(Date dataPisPasep) {
// 		this.dataPisPasep = dataPisPasep;
// 	}

	
// 	public String getTituloEleitorNumero() {
// 		return tituloEleitorNumero;
// 	}

// 	public void setTituloEleitorNumero(String tituloEleitorNumero) {
// 		this.tituloEleitorNumero = tituloEleitorNumero;
// 	}

	
// 	public Integer getTituloEleitorZona() {
// 		return tituloEleitorZona;
// 	}

// 	public void setTituloEleitorZona(Integer tituloEleitorZona) {
// 		this.tituloEleitorZona = tituloEleitorZona;
// 	}

	
// 	public Integer getTituloEleitorSecao() {
// 		return tituloEleitorSecao;
// 	}

// 	public void setTituloEleitorSecao(Integer tituloEleitorSecao) {
// 		this.tituloEleitorSecao = tituloEleitorSecao;
// 	}

	
// 	public String getCnhRegistro() {
// 		return cnhRegistro;
// 	}

// 	public void setCnhRegistro(String cnhRegistro) {
// 		this.cnhRegistro = cnhRegistro;
// 	}

	
	

	
// 	public Pais getPaisResidencia() {
// 		return paisResidencia;
// 	}

// 	public void setPaisResidencia(Pais paisResidencia) {
// 		this.paisResidencia = paisResidencia;
// 	}


// 	@Column(name = "pes_NomeFoto")
// 	private String nomeFoto;
	
// 	@Column(name = "pes_ContentType")
// 	private String contentType;
	

	
// 	public TipoPessoa getTpsCodigo() {
// 		return tpsCodigo;
// 	}

// 	public void setTpsCodigo(TipoPessoa tpsCodigo) {
// 		this.tpsCodigo = tpsCodigo;
// 	}

// 	public Integer getIdUsuario() {
// 		return idUsuario;
// 	}

// 	public void setIdUsuario(Integer idUsuario) {
// 		this.idUsuario = idUsuario;
// 	}

// 	public List<Email> getListEmail() {
// 		return listEmail;
// 	}

// 	public void setListEmail(List<Email> listEmail) {
// 		this.listEmail = listEmail;
// 	}

// 	public List<Endereco> getListEndereco() {
// 		return listEndereco;
// 	}

// 	public void setListEndereco(List<Endereco> listEndereco) {
// 		this.listEndereco = listEndereco;
// 	}

// 	public List<Conta> getListConta() {
// 		return listConta;
// 	}

// 	public void setListConta(List<Conta> listConta) {
// 		this.listConta = listConta;
// 	}

	
// 	public List<AuditoriaCensus> getListAuditoriaCensusAfetado() {
// 		return listAuditoriaCensusAfetado;
// 	}

// 	public void setListAuditoriaCensusAfetado(List<AuditoriaCensus> listAuditoriaCensusAfetado) {
// 		this.listAuditoriaCensusAfetado = listAuditoriaCensusAfetado;
// 	}

// 	public List<Dependente> getListDependente() {
// 		return listDependente;
// 	}

// 	public void setListDependente(List<Dependente> listDependente) {
// 		this.listDependente = listDependente;
// 	}

// 	public List<Biometria> getListBiometria() {
// 		return listBiometria;
// 	}

// 	public void setListBiometria(List<Biometria> listBiometria) {
// 		this.listBiometria = listBiometria;
// 	}

// 	public List<Senhas> getListSenhas() {
// 		return listSenhas;
// 	}

// 	public void setListSenhas(List<Senhas> listSenhas) {
// 		this.listSenhas = listSenhas;
// 	}

// 	public List<Profissao> getListProfissao() {
// 		return listProfissao;
// 	}

// 	public void setListProfissao(List<Profissao> listProfissao) {
// 		this.listProfissao = listProfissao;
// 	}

// 	public List<CadastroAlteracoes> getListCadastroAlteracoes() {
// 		return listCadastroAlteracoes;
// 	}

// 	public void setListCadastroAlteracoes(List<CadastroAlteracoes> listCadastroAlteracoes) {
// 		this.listCadastroAlteracoes = listCadastroAlteracoes;
// 	}

// 	public List<Pensionista> getListPensionista() {
// 		return listPensionista;
// 	}

// 	public void setListPensionista(List<Pensionista> listPensionista) {
// 		this.listPensionista = listPensionista;
// 	}

// 	public List<Certidoes> getListCertidoes() {
// 		return listCertidoes;
// 	}

// 	public void setListCertidoes(List<Certidoes> listCertidoes) {
// 		this.listCertidoes = listCertidoes;
// 	}

// 	public Deficiencia getIdDeficiencia() {
// 		return idDeficiencia;
// 	}

// 	public void setIdDeficiencia(Deficiencia idDeficiencia) {
// 		this.idDeficiencia = idDeficiencia;
// 	}

// 	public Cidade getCidCodigoNaturalidade() {
// 		return cidCodigoNaturalidade;
// 	}

// 	public void setCidCodigoNaturalidade(Cidade cidCodigoNaturalidade) {
// 		this.cidCodigoNaturalidade = cidCodigoNaturalidade;
// 	}

// 	public Cidade getCidCodigoTituloEleitorMunicipio() {
// 		return cidCodigoTituloEleitorMunicipio;
// 	}

// 	public void setCidCodigoTituloEleitorMunicipio(Cidade cidCodigoTituloEleitorMunicipio) {
// 		this.cidCodigoTituloEleitorMunicipio = cidCodigoTituloEleitorMunicipio;
// 	}

// 	public CnhCategoria getIdCnhCategoria() {
// 		return idCnhCategoria;
// 	}

// 	public void setIdCnhCategoria(CnhCategoria idCnhCategoria) {
// 		this.idCnhCategoria = idCnhCategoria;
// 	}

// 	public Cutis getIdCutis() {
// 		return idCutis;
// 	}

// 	public void setIdCutis(Cutis idCutis) {
// 		this.idCutis = idCutis;
// 	}

// 	public TipoCabelo getIdTipoCabelo() { 
// 		return idTipoCabelo;
// 	}

// 	public void setIdTipoCabelo(TipoCabelo idTipoCabelo) {
// 		this.idTipoCabelo = idTipoCabelo;
// 	}

// 	public EstadoCivil getIdEstadoCivil() {
		
// 		if(idEstadoCivil == null){
			
// 			idEstadoCivil = new EstadoCivil();
			
// 			idEstadoCivil.setId(1);
			
// 		}
		
// 		return idEstadoCivil;
// 	}

// 	public void setIdEstadoCivil(EstadoCivil idEstadoCivil) {
// 		this.idEstadoCivil = idEstadoCivil;
// 	}

// 	public Etnia getIdEtnia() {
// 		return idEtnia;
// 	}

// 	public void setIdEtnia(Etnia idEtnia) {
// 		this.idEtnia = idEtnia;
// 	}

// 	public GrupoSanguineo getIdGrupoSanguineo() {
// 		return idGrupoSanguineo;
// 	} 

// 	public void setIdGrupoSanguineo(GrupoSanguineo idGrupoSanguineo) {
// 		this.idGrupoSanguineo = idGrupoSanguineo;
// 	}

// 	public Olhos getIdOlhos() {
// 		return idOlhos;
// 	}

// 	public void setIdOlhos(Olhos idOlhos) {
// 		this.idOlhos = idOlhos;
// 	}

// 	public Sexo getIdSexo() {
// 		return idSexo;
// 	}

// 	public void setIdSexo(Sexo idSexo) {
// 		this.idSexo = idSexo;
// 	}

// 	public Pais getIdPais() {
// 		return idPais;
// 	}

// 	public void setIdPais(Pais idPais) {
// 		this.idPais = idPais;
// 	}

// 	public Religiao getIdReligiao() {
// 		return idReligiao;
// 	}

// 	public void setIdReligiao(Religiao idReligiao) {
// 		this.idReligiao = idReligiao;
// 	}

// 	public Set<HistoricoRecadastramento> getListHistoricoRecadastramentos() {
// 		return listHistoricoRecadastramentos;
// 	}

// 	public void setListHistoricoRecadastramentos(Set<HistoricoRecadastramento> listHistoricoRecadastramentos) {
// 		this.listHistoricoRecadastramentos = listHistoricoRecadastramentos;
// 	}

// 	public List<Telefone> getListTelefone() {
// 		return listTelefone;
// 	}

// 	public void setListTelefone(List<Telefone> listTelefone) {
// 		this.listTelefone = listTelefone;
// 	}

// 	public List<Formacao> getListFormacao() {
// 		return listFormacao;
// 	}

// 	public void setListFormacao(List<Formacao> listFormacao) {
// 		this.listFormacao = listFormacao;
// 	}

// 	public List<CandidatoDSA> getListCandidatosDSA() {
// 		return listCandidatosDSA;
// 	}

// 	public void setListCandidatosDSA(List<CandidatoDSA> listCandidatosDSA) {
// 		this.listCandidatosDSA = listCandidatosDSA;
// 	}
	
// 	public List<HistoricoProvaDeVida> getListHistoricoProvaDeVida() {
// 		return listHistoricoProvaDeVida;
// 	}

// 	public void setListHistoricoProvaDeVida(List<HistoricoProvaDeVida> listHistoricoProvaDeVida) {
// 		this.listHistoricoProvaDeVida = listHistoricoProvaDeVida;
// 	}

// 	@JsonIgnore
// 	public Certidoes getCertidaoAtual(){
		
// 		Certidoes retorno = new Certidoes();
// 		for (Certidoes certidao : listCertidoes) {
// 			if(certidao.getId()>retorno.getId()){
// 				retorno = certidao;
// 			}
// 		}
		
// 		return retorno;
// 	}
	

// 	@JsonIgnore
// 	public HistoricoRecadastramento getRecadastramentoCorrente(){
// 		HistoricoRecadastramento retorno =  new HistoricoRecadastramento();
// 		if((listHistoricoRecadastramentos != null) && (!listHistoricoRecadastramentos.isEmpty())) {
// 			for (HistoricoRecadastramento historicoRecadastramento : listHistoricoRecadastramentos) {
// 				if(historicoRecadastramento.isAtual()){
// 					retorno = historicoRecadastramento;
// 					break;
// 				}
// 			}
			
// 		}
// 		return retorno;
		
// 	}
	
// 	@JsonIgnore
// 	public CandidatoPttc getCandidatoPttcAtual(){
		
// 		CandidatoPttc retorno = new CandidatoPttc();
// 		if(this.candidatoPttc.isEmpty() || this.candidatoPttc.get(0).getStatus().getId() == 1){
// 			return retorno;
// 		}else{
// 			for (CandidatoPttc con : this.candidatoPttc) {
				
// //				if(retorno.getId() < con.getId()){
// 				if(con.getAtivo() == 1 && con.getAnoConcurso()==2022){
// 					retorno = con;
// 				}
// 			}
// 			return retorno;
// 		}
		
// 	}
	
// 	@JsonIgnore
// 	public CandidatoPttc getCandidatoPttcUltimo(){
		
// 		CandidatoPttc retorno = new CandidatoPttc();
// 		if(this.candidatoPttc.isEmpty()){
// 			return retorno;
// 		}else{
// 			for (CandidatoPttc con : this.candidatoPttc) {
				
// 				if(retorno.getId() < con.getId() && con.getAnoConcurso()==2022){
// //				if(con.getAtivo() == 1 ){
// 					retorno = con;
// 				}
// 			}
// 			return retorno;
// 		}
		
// 	}
	
	
// 	@JsonIgnore
// 	public boolean getPendenciasAnteriores(){
// 		boolean retorno = false;
		
// 		if(this.getRecadastramentoCorrente()!=null){
// 			HistoricoRecadastramento penultimo = new HistoricoRecadastramento();
			
// 			int cont = 0;
// 			for (HistoricoRecadastramento historicoRecadastramento : listHistoricoRecadastramentos) {
				
// 				if(historicoRecadastramento.getAnoRecadastramento()!=null && this.getRecadastramentoCorrente().getAnoRecadastramento()!=null){
// 					if(historicoRecadastramento.getAnoRecadastramento()<this.getRecadastramentoCorrente().getAnoRecadastramento() && cont==0){
// 						penultimo = historicoRecadastramento;
// 						cont++;
// 					}
// 					if(cont!=0 && historicoRecadastramento.getAnoRecadastramento()>penultimo.getAnoRecadastramento() 
// 							&& historicoRecadastramento.getAnoRecadastramento() != this.getRecadastramentoCorrente().getAnoRecadastramento()){
// 						penultimo =historicoRecadastramento;
// 					}
					
// 					}
				
				
// 			}
			
// 			if(penultimo.getPessoaValidadora()==null){
// 				retorno = true; 
// 			}
// 		}
		
		
// 		return retorno;
// 	}
	
	
// 	//Retorna ULTIMO RECADASTRAMENTO
// 	@JsonIgnore
// 		public HistoricoRecadastramento getUltimoRecadastramento() {
			
// 			if(listHistoricoRecadastramentos.isEmpty()){
// 				return null;
// 			}else{
// 				HistoricoRecadastramento  retorno = new HistoricoRecadastramento();
				
// 				for (HistoricoRecadastramento hist : listHistoricoRecadastramentos) {
					
// 					if(hist.isAtual()){
// 						retorno = hist;
// 					}
// 					else if (hist.getId()==0){
// 						retorno = hist;
// 					}
					
// 				}
// 				return retorno;
				
// 			}
// 		}
	
	
// 	//Retorna CANDIDATO
// 	@JsonIgnore
// 	public CandidatoDSA getCandidatoDSA() {
		
		
// 		if(listCandidatosDSA.isEmpty()){
// 			return null;
// 		}else{
// 			CandidatoDSA  retorno = new CandidatoDSA();
			
// 			for (CandidatoDSA cand : listCandidatosDSA) {
				
// 				if(retorno.getId() < cand.getId()){
// 					retorno = cand;
// 				}
				
// //					if(cand.getAtivo()==1){
// //						retorno =  cand;
// //					}
				
// 			}
// 			return retorno;
			
			
// 		}
// 	}
	
// 	//Retorna CANDIDATO INATIVADO
// 	@JsonIgnore
// 	public CandidatoDSA getCandidatoInativoDSA() {
		
// 		if(listCandidatosDSA.isEmpty()){
// 			return null;
// 		}else{
// 			CandidatoDSA  retorno = new CandidatoDSA();
			
// 			for (CandidatoDSA cand : listCandidatosDSA) {
				
// 				if(retorno.getId() < cand.getId()){
// 					retorno = cand;
// 				}
				
// //				if(cand.getAtivo()==0){
// //					retorno =  cand;
// //				}
				
// 			}
			
// 			return retorno;
			
// 		}
// 	}
	

// 	public UnidadeFederativa getUfeOrgaoExpedidor() {
// 		return ufeOrgaoExpedidor==null?new UnidadeFederativa():ufeOrgaoExpedidor;
// 	}

// 	public void setUfeOrgaoExpedidor(UnidadeFederativa ufeOrgaoExpedidor) {
// 		this.ufeOrgaoExpedidor = ufeOrgaoExpedidor;
// 	}


// 	public UnidadeFederativa getUfeCNH() {
// 		return ufeCNH==null?new UnidadeFederativa():ufeCNH;
// 	}

// 	public void setUfeCNH(UnidadeFederativa ufeCNH) {
// 		this.ufeCNH = ufeCNH;
// 	}



	
// 	public List<PessoaIdioma> getListPessoaIdiomas() {
// 		return listPessoaIdiomas;
// 	}

// 	public void setListPessoaIdiomas(List<PessoaIdioma> listPessoaIdiomas) {
// 		this.listPessoaIdiomas = listPessoaIdiomas;
// 	}

// 	@JsonIgnore
// 	public List<Perfil> getPerfils(){
// 		List<Perfil> perfils = new ArrayList<>();
// 		for(PessoaPerfil pessoaperfil: getPessoaPerfil()){
// 			perfils.add(pessoaperfil.getIdPerfil());
// 		}
// 		return perfils;

// 	}

// 	public List<Afastamento> getListAfastamentos() {
// 		return listAfastamentos;
// 	}

// 	public void setListAfastamentos(List<Afastamento> listAfastamentos) {
// 		this.listAfastamentos = listAfastamentos;
// 	}
	
	
// 	public List<Ferias> getListFerias() {
// 		return listFerias;
// 	}
	
// 	//Lista de Férias em ordem decrescente de ano
// 	@SuppressWarnings({ "unchecked", "rawtypes" })
// 	@JsonIgnore
// 	public List<Ferias> getListFeriasOrdenadaPorAno() {
		
// 		Collections.sort (listFerias, new Comparator() {
//             @Override
// 			public int compare(Object o1, Object o2) {
//             	Ferias p1 = (Ferias) o1;
//             	Ferias p2 = (Ferias) o2;
//                 return p1.getAnoReferencia() < p2.getAnoReferencia() ? +1 : (p1.getAnoReferencia() > p2.getAnoReferencia() ? -1 : 0);
//             }
//         });
		
// 		return listFerias;
// 	}
	
// 	//Retorna Ultimo Registro de ferias
// 	@JsonIgnore
// 	public Ferias getFerias() {
		
// 		Ferias retorno = new Ferias();
// 		if(this.listFerias.isEmpty()){
// 			return retorno;
// 		}else{
			
			
// 			for (Ferias fer : this.listFerias) {
				
// 				if(fer.getAtivo()!=null){
// 					if(fer.getAtivo()==1 && (retorno.getId() < fer.getId()) ){
// 						retorno = fer;
// 					}
// 				}
				
				
// 			}
			
			
// 			return retorno;
			
// 		}
		
		
		
// //		if(listFerias.isEmpty()){
// //			return null;
// //		}else{
// //			return listFerias.get(0);
// //		}
// 	}

// 	public void setListFerias(List<Ferias> listFerias) {
// 		this.listFerias = listFerias;
// 	}
	
// 	public List<FeriasIndicacao> getListFeriasIndicacao() {
// 		return listFeriasIndicacao;
// 	}

// 	public void setListFeriasIndicacao(List<FeriasIndicacao> listFeriasIndicacao) {
// 		this.listFeriasIndicacao = listFeriasIndicacao;
// 	}

// 	public List<Abono> getListAbonos() {
// 		return listAbonos;
// 	}

// 	public void setListAbonos(List<Abono> listAbonos) {
// 		this.listAbonos = listAbonos;
// 	}
	
// 	public List<Ferias> getListFeriasUsuario() {
// 		return listFeriasUsuario;
// 	}

// 	public void setListFeriasUsuario(List<Ferias> listFeriasUsuario) {
// 		this.listFeriasUsuario = listFeriasUsuario;
// 	}

// 	public List<Abono> getListAbonosUsuario() {
// 		return listAbonosUsuario;
// 	}

// 	public void setListAbonosUsuario(List<Abono> listAbonosUsuario) {
// 		this.listAbonosUsuario = listAbonosUsuario;
// 	}
	
// 	public String getNomeFoto() {
// 		return nomeFoto;
// 	}

// 	public void setNomeFoto(String nomeFoto) {
// 		this.nomeFoto = nomeFoto;
// 	}

// 	public String getContentType() {
// 		return contentType;
// 	}

// 	public void setContentType(String contentType) {
// 		this.contentType = contentType;
// 	}

// 	public void setId(int id) {
// 		this.id = id;
// 	}
	



// 	public LocalDateTime getDataAtualizacao() {
// 		return dataAtualizacao;
// 	}

// 	public void setDataAtualizacao(LocalDateTime dataAtualizacao) {
// 		this.dataAtualizacao = dataAtualizacao;
// 	}

// 	//Lista de afastamentos em ordem decrescente de inclusao
// 	@SuppressWarnings({ "unchecked", "rawtypes" })
// 	@JsonIgnore
// 	public List<Afastamento> getListAfastamentosOrdenada() {
		
// 		Collections.sort (listAfastamentos, new Comparator() {
//             @Override
// 			public int compare(Object o1, Object o2) {
//             	Afastamento p1 = (Afastamento) o1;
//             	Afastamento p2 = (Afastamento) o2;
//                 return p1.getId() < p2.getId() ? +1 : (p1.getId() > p2.getId() ? -1 : 0);
//             }
//         });
		
// 		return listAfastamentos;
// 	}
	
// 	//Lista de afastamentos ordenada por data de inicio
// 	@JsonIgnore
// 	public List<Afastamento> getListAfastamentosOrdenadaDataInicio() {
		
// 		Collections.sort(listAfastamentos);
// 		return listAfastamentos;
// 	}
	
// 	//Retorna ultimo afastamento por data
// 	@JsonIgnore
// 	public Afastamento getUltimoAfastamento() {
		
// 		Collections.sort(listAfastamentos);
		
// 		if(listAfastamentos.isEmpty()){
// 			return null;
// 		}else{
// 			return listAfastamentos.get(0);
// 		}
// 	}
	
// 	//Retorna o afastamento caso esteja afastado no mes atual
// 	@JsonIgnore
// 	public Afastamento getAfastamentoNoMes() throws ParseException {
		
// 		Afastamento ultimoAfastamento = getUltimoAfastamento();
	
// 		if(ultimoAfastamento == null){
// 			return null;
// 		}else{
			
// 			Calendar c = Calendar.getInstance();
// 	        int mesAtual = c.get(Calendar.MONTH);
// 	        int anoAtual = c.get(Calendar.YEAR);
			
// 			Calendar calendar = Calendar.getInstance();
// 	        LocalDate data = ultimoAfastamento.getDataInicio();
// 	        calendar.setTime(java.sql.Date.valueOf(data));
// 	        int mes = calendar.get(Calendar.MONTH);
// 	        int ano = calendar.get(Calendar.YEAR);
	        
// 			if( (mes == mesAtual) && (ano == anoAtual)  ){
// 				return ultimoAfastamento;
// 			}else {
// 				return null;
// 			}

// 		}
// 	}
	
// 	//Retorna o afastamento caso esteja afastado na data autal
// 	@SuppressWarnings("unlikely-arg-type")
// 	@JsonIgnore
// 	public Afastamento getAfastamentoNaDataDeHoje() throws ParseException {
		
// 		Afastamento ultimoAfastamento = getUltimoAfastamento();
		
// 		Calendar calendar = Calendar.getInstance();
//         SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
//         Date data = calendar.getTime();
       
//         SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy"); //Definindo o formato de declaração de novos objetos de data. Use o mesmo formato ao declarar novas datas
//         Date data1 = sdf.parse(formato.format(data)); 
	
// 		if(ultimoAfastamento == null || ultimoAfastamento.getDataInicio()==null ||  ultimoAfastamento.getDataTermino()==null){
// 			return null;
// 		}else{
// 			if( ( ( java.sql.Date.valueOf(ultimoAfastamento.getDataInicio()).before(data1) ) &&
// 					  ( java.sql.Date.valueOf(ultimoAfastamento.getDataTermino()).after(data1) ) ) 
// 						||
// 					( ( ultimoAfastamento.getDataInicio().equals(data1) ) &&
// 					  ( java.sql.Date.valueOf(ultimoAfastamento.getDataTermino()).after(data1) ) )
// 						||
// 					( ( java.sql.Date.valueOf(ultimoAfastamento.getDataInicio()).before(data1) ) &&
// 					  ( java.sql.Date.valueOf(ultimoAfastamento.getDataTermino()).equals(data1) ) )
// 						||
// 					( ( java.sql.Date.valueOf(ultimoAfastamento.getDataInicio()).equals(data1) ) &&
// 							  ( java.sql.Date.valueOf(ultimoAfastamento.getDataTermino()).equals(data1) ) )
// 				){
// 				return ultimoAfastamento;
// 			}else {
// 				return null;
// 			}

// 		}
// 	}

// 	public void addTelefone(Telefone telefone) {
// 		this.listTelefone.add(telefone);
// 		telefone.setIdPessoa(this); // mantém a consistência
// 	}
	
	
// 	public void addAnexo(AnexoDocumento anexo) {
// 		this.anexosDocumento.add(anexo);
// 		anexo.setPessoa(this); // mantém a consistência
// 	}
	
	
// 	public void addCertidao(Certidoes certidao) {
// 		this.listCertidoes.add(certidao);
// 		certidao.setIdPessoa(this); // mantém a consistência
// 	}
	
// 	public void addFormacao(Formacao formacao) {
// 		this.listFormacao.add(formacao);
// 		formacao.setIdPessoa(this); // mantém a consistência
// 	}

// 	public void removeaddTelefone(Telefone telefone) {
// 		this.listTelefone.remove(telefone);
// 		telefone.setIdPessoa(null); // mantém a consistência
// 	}	

// //	public void addEmail(Email email) {
// //		this.listEmail.add(email);
// //		email.setIdPessoa(this); // mantém a consistência
// //	}
// //
// //	public void removeEmail(Email email) {
// //		this.listEmail.remove(email);
// //		email.setIdPessoa(null); // mantém a consistência
// //	}
	
	
// 	public void addEndereco(Endereco endereco) {
// 		this.listEndereco.add(endereco);
// 		endereco.setIdPessoa(this); // mantém a consistência
// 	}

// //	public void removeaddEmail(Email email) {
// //		this.listEmail.remove(email);
// //		email.setIdPessoa(null); // mantém a consistência
// //	}
	
	
	

// 	public List<CertificadoMilitar> getCertificadoMilitar() {
// 		return certificadoMilitar;
// 	}

	

// 	public void setCertificadoMilitar(List<CertificadoMilitar> certificadoMilitar) {
// 		this.certificadoMilitar = certificadoMilitar;
// 	}

// //	public void addCertidao(Certidoes certidao) {
// //		getListCertidoes().add(certidao);
// //		certidao.setIdPessoa(this);
// //	}
// //
// //	public void removeCertidao(Certidoes certidao) {
// //		getListCertidoes().remove(certidao);
// //	}

	
// 	public String getCpfSemMascara(){
// 		return this.cpf !=null ? this.cpf.trim().replaceAll("\\.|-|/", ""): this.cpf;
// 	}
	
// 	@JsonIgnore
// 	public int getIdade(){
		
// 		Instant instant = Instant.ofEpochMilli(java.sql.Date.valueOf(this.dataNascimento).getTime());
// 		LocalDate datanascimento = LocalDateTime.ofInstant(instant, ZoneId.systemDefault()).toLocalDate();
		
// 		LocalDate agora = LocalDate.now();
		
// 		final Period idade = Period.between(datanascimento, agora);
		
// 		return idade.getYears();
// 	}
	
// 	public String getNomecurto() {
		
// 		return (nome.length()>=10?nome.substring(0, 10):nome);
// 	}

// 	public void setNomecurto(String nomecurto) {
// 		this.nomecurto = nomecurto;
// 	}
	
	
// 	public void setEnderecoAtual(Endereco enderecoAtual) {
// 		this.enderecoAtual = enderecoAtual;
// 	}
	
// 	public Endereco getEnderecoAtual() {
// 		return this.enderecoAtual = getEndereco();
// 	}

// 	public Set<Pensionista> getPensionist() {
// 		return pensionist;
// 	}

// 	public void setPensionist(Set<Pensionista> pensionist) {
// 		this.pensionist = pensionist;
// 	}

// 	public List<AnexoDocumento> getAnexosDocumento() {
// 		return anexosDocumento;
// 	}

// 	public void setAnexosDocumento(List<AnexoDocumento> anexosDocumento) {
// 		this.anexosDocumento = anexosDocumento;
// 	}

// 	@JsonIgnore
// 	public AnexoDocumento getFoto(){
// 		AnexoDocumento retorno = new  AnexoDocumento();
// 		if(anexosDocumento!=null){
// 		for (AnexoDocumento anexo : anexosDocumento) {
// 			if(anexo.getTipoAnexoDocumento().getId()== TipoAnexoEnum.FOTOFUNCIONAL.getId()){
// 				retorno = anexo;
// 			}
// 		}
// 		}
// 		return retorno;
// 	}
	
// 	public Endereco getEndereco() {
// 		Endereco retorno = new Endereco();
// 		if(this.listEndereco.isEmpty()){
// 			return retorno;
// 		}else{
// 			for (Endereco end : this.listEndereco) {
				
// 				if(end.getAtivo()==1 && (retorno.getId() < end.getId()) ){
// 					retorno = end;
// 				}
// 			}
// 			return retorno;
// 		}
// 	}
	
	
// 	public Set<Dependente> getDependentePessoa() {
// 		return dependentePessoa;
// 	}

// 	public void setDependentePessoa(Set<Dependente> dependentePessoa) {
// 		this.dependentePessoa = dependentePessoa;
// 	}

// 	public boolean isMilitar() {
// 		return militar;
// 	}

// 	public void setMilitar(boolean militar) {
// 		this.militar = militar;
// 	}

// 	@JsonIgnore
// 	public Conta getConta() {
// 		Conta retorno = new Conta();
// 		if(this.listConta.isEmpty()){
// 			return retorno;
// 		}else{
// 			for (Conta con : this.listConta) {
				
// 				if(retorno.getId() < con.getId() ){
// 					retorno = con;
// 				}
// 			}
// 			return retorno;
// 		}
// 	}
	
// 	@JsonIgnore
// 	public String getCEPAtual() {
		
// 		String retorno = "Não Informado";
		
// 		if(this.listEndereco.isEmpty()){
// 			return null;
// 		}else{
			
// 			for (Endereco end : this.listEndereco) {
// 				if(end.getAtivo()==1){
					
// 					if(end.getIdLogradouro()==null){
// 						retorno = "Não Informado";					
// 					}else{
// 						retorno = end.getIdLogradouro().getCep();
// 					}
// 				}
// 			}
// 		}
// 		return retorno;
// 	}
	
// 	@JsonIgnore
// 	public String getEnderecoFormatado() {
		
// 		String retorno = "Sem Endereço";
		
// 		if(this.listEndereco.isEmpty()){
// 			return null;
// 		}else{
			
// 			for (Endereco end : this.listEndereco) {
// 				if(end.getAtivo()==1){
					
					
					
// 					if(end.getCidade()==null){
// 					retorno = end.getIdLogradouro().getNome()+" "+ end.getComplemento() +" -  "+end.getIdLogradouro().getIdBairro().getNome()+
// 							" - "+end.getIdLogradouro().getIdBairro().getIdCidade().getNome()
// 							+" - "+end.getIdLogradouro().getIdBairro().getIdCidade().getIdUnidadeFederativa().getNome()+" / "
// 							+end.getIdLogradouro().getIdBairro().getIdCidade().getIdUnidadeFederativa().getSigla();
// 					this.paisResidencia = end.getIdLogradouro().getIdBairro().getIdCidade().getIdUnidadeFederativa().getIdPais();
					
// 					}
// 					else{
// 						retorno = end.getComplemento() +" -  "+
// 								" - "+end.getCidade().getNome()
// 								+" - "+end.getCidade().getIdUnidadeFederativa().getNome()+" / "
// 								+end.getCidade().getIdUnidadeFederativa().getSigla();
						
// 						this.paisResidencia = end.getCidade().getIdUnidadeFederativa().getIdPais();
// 					}
// 				}
				
// 			}
			
			
// 		}
// 		return retorno;
		
// 	}

	
	/**
	 * Retorna a lista de telefones de um pessoa no formato (99) 9999-8888 / (61) 99999-9999
	 * @return
	 */
/*
	public String getTelefonesFormatados(){
		String retono = "";
		int cont = 0;
		for (Telefone tel : this.listTelefone) {
			if(cont==0){
				retono+=" "+tel.getNumeroFormatado()+" ";
			}
			else{
				retono+=" / "+tel.getNumeroFormatado()+" ";
			}
			cont++;
		}
		
		return retono;
	}
	
	@JsonIgnore
	public String getEmailFormatados(){
		String retono = "";
		
		int cont = 0;
		if(this.listEmail!=null && !this.listEmail.isEmpty()) {
			for (Email email : this.listEmail) {
				if(cont==0){
					retono+=" "+email.getNome()+" <br/> ";
				}
				else{
					retono+=" "+email.getNome()+" <br/> ";
				}
				cont++;
			}
		}
		
		return retono;
	}
	@JsonIgnore
	public String getEmailFormatadosLinha(){
		String retono = "";
		
		int cont = 0;
		for (Email email : this.listEmail) {
			if(cont==0){
				retono+=" "+email.getNome()+"";
			}
			else{
				retono+=" / "+email.getNome()+" ";
			}
			cont++;
		}
		
		return retono;
	}
	
	public boolean isPensionista() {
		return pensionista;
	}

	public void setPensionista(boolean pensionista) {
		this.pensionista = pensionista;
	}

	public boolean isAtivo() {
		return ativo;
	}

	public void setAtivo(boolean ativo) {
		this.ativo = ativo;
	}

	public boolean isInativo() {
		return inativo;
	}

	public void setInativo(boolean inativo) {
		this.inativo = inativo;
	}

	public boolean isCivil() {
		return civil;
	}

	public void setCivil(boolean civil) {
		this.civil = civil;
	}
	
	

	public void setFoto(AnexoDocumento foto) {
		this.foto = foto;
	}

	
	
	public int getPendenciasAnexos() {
		return pendenciasAnexos;
	}

	public void setPendenciasAnexos(int pendenciasAnexos) {
		this.pendenciasAnexos = pendenciasAnexos;
	}

	public int getCertidaocivil() {
		
		if(this.idEstadoCivil==null){
			certidaocivil = 1;
			return  certidaocivil;
		}
		
		switch (this.idEstadoCivil.getId()) {
		case 1://solteiro
			certidaocivil = 1;
			break;
			
		case 2://casado
			certidaocivil = 2;
			break;
			
		case 3://desquitado
			certidaocivil = 3;
			break;
			
		case 4://divorciado
			certidaocivil = 3;
			break;
			
		case 5://viuvo
			certidaocivil = 2;
			break;
			
		case 6://compnhairo
			certidaocivil = 4;  
			break;

		default:
			certidaocivil = 1;
		}
		
		return certidaocivil;
	}
	

	public boolean isDependente() {
		return dependente;
	}

	public void setDependente(boolean dependente) {
		this.dependente = dependente;
	}

	public void setCertidaocivil(int certidaocivil) {
		this.certidaocivil = certidaocivil;
	}
	
	
	public List<MensagemUsuario> getRemetente() {
		return remetente;
	}

	public void setRemetente(List<MensagemUsuario> remetente) {
		this.remetente = remetente;
	}

	public List<MensagemUsuario> getDestinatario() {
		return destinatario;
	}

	public void setDestinatario(List<MensagemUsuario> destinatario) {
		this.destinatario = destinatario;
	}
	
	/**
	 * @return true
	 * Verifica se a pessoa é um dependente, caso seja
	 * Verifica se é um caso de dupla dependencia e retorna true
	 */
/*
	@JsonIgnore
	public boolean isDuplaDependencia() {
		boolean retorno = false;
		if(isDependente() ) {
			if(!this.getDependentePessoa().isEmpty() 
					&& this.getDependentePessoa().size()>1) {
					retorno = true;
			}
		}
		return retorno;
	}
	
	
	/**
	 * @return true
	 * Verifica se a pessoa é um dependente, caso seja
	 * Verifica se é um caso de dupla dependencia e retorna true
	 */
	/*
	@JsonIgnore
	public boolean isDuplaDependencia(int instituidor) {
		boolean retorno = false;
		int c = 0;
		if(isDependente() ) {
			if(!this.getDependentePessoa().isEmpty() 
					&& this.getDependentePessoa().size()>1) {
					
					for (Dependente dep : this.getDependentePessoa()) {
						if(!dep.isDesligado()) {
							c++;
						}
						
						
					}
			}
		}
		
		if(c>1) {
			retorno =true;
		}
		
		return retorno;
	}
	
	
	/**
	 * @return
	 * Caso a pessoa seja um dependente com situação de 
	 * dupla dependencia, retorna todos os instituidores
	 */
/*
	@JsonIgnore
	public List<Policial> getInstituidores(){
		List<Policial>  retorno = new ArrayList<>();
		if(isDuplaDependencia()) {
			for (Dependente dep : this.getDependentePessoa()) {
				if(dep.getDataDesligamento() != null) {
					retorno.add(dep.getIdPolicial());
				}
			}
		}
		return retorno;
	}
	
	@JsonIgnore
	public String getRestricoes(){
		StringBuffer retorno = new StringBuffer();
			for (InspecaoSaude insSaude : inspecoesSaude) {
				for (InspecaoSaudeTipoRestricao restricao: insSaude.getRestricoes()) {
					if(insSaude.getDataTermino() == null || insSaude.getDataTermino().after(java.sql.Date.valueOf(LocalDate.now())) || insSaude.getDataTermino().equals(java.sql.Date.valueOf(LocalDate.now()))) {
						retorno.append(restricao.getIdTipoRestricao().getNome() + ",");
					}
				}
			}
		return retorno.toString();
	}
	
	public boolean isBloqueado() {
		
//		for (MensagemUsuario obj : this.destinatario) {
//			if((obj.getTemaMensagemUsuario().getId()==5 ) && 
//					obj.getAtivo() == 1 && 
//					obj.getDataDesbloqueio()==null && 
//					obj.getPessoaDesbloqueio()==null ) {
//				this.bloqueado = true;
//			}
//			
//		}
		
		return this.bloqueado;
	}
	
	public void setBloqueado(boolean bloqueado) {
		 this.bloqueado = bloqueado;
	}
	
	public boolean isMensagemTela() {
//		for (MensagemUsuario obj : this.destinatario) {
//			if((obj.getTemaMensagemUsuario().getId()==7 ) && 
//					obj.getAtivo() == 1 && 
//					obj.getDataDesbloqueio()==null && 
//					obj.getPessoaDesbloqueio()==null ) {
//				this.mensagemTela = true;
//				break;
//			}
//			
//		}
		return mensagemTela;
	}

	public void setMensagemTela(boolean mensagemTela) {
		this.mensagemTela = mensagemTela;
	}
	
	@JsonIgnore
	public void setarUltimoRecadastramento(){

		if(this.isCandidato()){
			this.setStatusRecadastramento(StatusRecadastramentoENUM.PENDENTE.getId()); 
		}

		
		if(this.getRecadastramentoCorrente() != null && this.getRecadastramentoCorrente().getId()!=0){

			if(this.getRecadastramentoCorrente().getStatusPendenciaRecadastramento()!=null 
					&& this.getRecadastramentoCorrente().getStatusPendenciaRecadastramento().getId()==1){
				this.setStatusRecadastramento(StatusRecadastramentoENUM.PENDENCIASANOTADAS.getId()); 
			}
			else{
				
				//LocalDate dataUltimaAtualizacao = LocalDate.parse( new SimpleDateFormat("yyyy-MM-dd").format(this.getRecadastramentoCorrente().getDataAtualizacao()));
				
				if(this.getPendenciasAnteriores() && this.getRecadastramentoCorrente().getPaginaCorrente()==0){
					this.setStatusRecadastramento(StatusRecadastramentoENUM.PENDENTE.getId());
				}
				else{
	
					if(this.getRecadastramentoCorrente().getPessoaValidadora() == null 
							&& this.getRecadastramentoCorrente().getNumeroTermo()!=null){
						this.setStatusRecadastramento(StatusRecadastramentoENUM.HOMOLOGADO.getId()); 
					}
					else if(this.getRecadastramentoCorrente().getPaginaCorrente()==0){
						this.setStatusRecadastramento(StatusRecadastramentoENUM.PENDENTE.getId()); 
					}
	
					else if(this.getRecadastramentoCorrente().getPessoaValidadora() == null
							&& this.getRecadastramentoCorrente().getPaginaCorrente() < getPaginaCorrete(this)
							&& this.getRecadastramentoCorrente().getPaginaCorrente()!=0){
						this.setStatusRecadastramento(StatusRecadastramentoENUM.ATUALIZACAOINICIADA.getId());
					}
	
					else if(this.getRecadastramentoCorrente().getPessoaValidadora() != null){
						this.setStatusRecadastramento(StatusRecadastramentoENUM.HOMOLOGADO.getId());
					}
					
					else if(this.getRecadastramentoCorrente().getPessoaValidadora() != null){
						this.setStatusRecadastramento(StatusRecadastramentoENUM.EMANALISE.getId());
					}
				}
				
			}

		}
		else{
			this.setStatusRecadastramento(StatusRecadastramentoENUM.PENDENTE.getId());
		}
	}

	@JsonIgnore
	public Integer getStatusUltimaProvaVida() {
		
		
		if(this.listHistoricoProvaDeVida.size() > 0) {		
		
			for (HistoricoProvaDeVida historicoProvaVida : this.listHistoricoProvaDeVida) {
				
				if(historicoProvaVida.getStatus() != null) {
				
					if(historicoProvaVida.getStatus() == 1) {
	//					System.err.println(historicoProvaVida.getId() + "____" + historicoProvaVida.getAutorizado());
						statusProvaVida = historicoProvaVida.getAutorizado();
					}			
				}
			}
		}else {
			//sem transacao valida
			statusProvaVida = 4;			
		}
		
		return statusProvaVida;
	}

	
	@JsonIgnore
	public int getPaginaCorrete(Pessoa pessoa) {
		
		if(pessoa.isAtivo()){
			return 10;
		}else if (pessoa.isInativo()) {
			return 8;
		}else if (pessoa.isPensionista()) {
			return 7;
		}else if (pessoa.isCivil()) {
			return 8;
		}else{
			return 8;
		}
	
	}
	
	public boolean isCandidato() {
		return candidato;
	}

	public void setCandidato(boolean candidato) {
		this.candidato = candidato;
	}

	public List<CandidatoPttc> getCandidatoPttc() {
		return candidatoPttc;
	}

	public void setCandidatoPttc(List<CandidatoPttc> candidatoPttc) {
		this.candidatoPttc = candidatoPttc;
	}

	public Candidato getCandidatos() {
		return candidatos;
	}

	public void setCandidatos(Candidato candidatos) {
		this.candidatos = candidatos;
	}

	public FuncionarioCivil getFuncionarioCivil() {
		return funcionarioCivil;
	}

	public void setFuncionarioCivil(FuncionarioCivil funcionarioCivil) {
		this.funcionarioCivil = funcionarioCivil;
	}
	
	public String getDataNascimentoString() {
		LocalDate agora = this.dataNascimento;

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

		String agoraFormatado = agora.format(formatter);

		return agoraFormatado;
	}


	public MensagemUsuario getMensagemBloqueio() {
		return mensagemBloqueio;
	}

	public void setMensagemBloqueio(MensagemUsuario mensagemBloqueio) {
		this.mensagemBloqueio = mensagemBloqueio;
	}


	public List<Talao> getIdTalao() {
		return idTalao;
	}

	public void setIdTalao(List<Talao> idTalao) {
		this.idTalao = idTalao;
	}

	public boolean isEmpregadoTerceirizado() {
		return empregadoTerceirizado;
	}

	public void setEmpregadoTerceirizado(boolean empregadoTerceirizado) {
		this.empregadoTerceirizado = empregadoTerceirizado;
	}


	
	@JsonIgnore
	public List<Recurso> getRecursos() {
		List<Recurso> recursos = new ArrayList<>();

		if(listPessoaRecurso!=null) {
		for (PessoaRecurso pessoaRecurso : this.listPessoaRecurso) {
			recursos.add(pessoaRecurso.getRecurso());
		}
		}
		return recursos;
	}
	
	@JsonIgnore
	public List<Perfil> getPerfis() {
		List<Perfil> perfis = new ArrayList<>();

		for (PessoaPerfil pessoaPerfil : this.pessoaPerfil) {
			perfis.add(pessoaPerfil.getIdPerfil());
		}
		return perfis;
	}

	public List<PessoaRecurso> getListPessoaRecurso() {
		return listPessoaRecurso;
	}

	public void setListPessoaRecurso(List<PessoaRecurso> listPessoaRecurso) {
		this.listPessoaRecurso = listPessoaRecurso;
	}

	
	
	public boolean isAcessoRestrito() {
		return acessoRestrito;
	}

	public void setAcessoRestrito(boolean acessoRestrito) {
		this.acessoRestrito = acessoRestrito;
	}

	/**
	 * @return Pernsionista que retresenta a pessoa
	 *//*
	public Pensionista getPessoaPensionista() {
		Pensionista retorno = new Pensionista();
		for (Pensionista pensionista : pensionist) {
			retorno = pensionista;
		}
		return retorno;
	}
	
	
	public Dependente getPessoaDependente() {
		Dependente retorno = new Dependente();
		for (Dependente obj : dependentePessoa) {
			retorno = obj;
		}
		return retorno;
	}
	
	

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Pessoa other = (Pessoa) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}
	
	
	public String toStringAuditoria() {
		return "Pessoa [" + (id != null ? "id=" + id + ", " : "") + (nome != null ? "nome=" + nome + ", " : "")
				+ (nomecurto != null ? "nomecurto=" + nomecurto + ", " : "")
				+ certidaocivil + ", " + (nomeAnterior != null ? "nomeAnterior=" + nomeAnterior + ", " : "")
				+ (rg != null ? "rg=" + rg + ", " : "")
				+ (rgOrgaoExpedidor != null ? "rgOrgaoExpedidor=" + rgOrgaoExpedidor + ", " : "")
				+ (rgDataEmissao != null ? "rgDataEmissao=" + rgDataEmissao + ", " : "")
				+ (dataAtualizacao != null ? "dataAtualizacao=" + dataAtualizacao + ", " : "")
				+ (cpf != null ? "cpf=" + cpf + ", " : "")
				+ (dataNascimento != null ? "dataNascimento=" + dataNascimento + ", " : "")
				+ (nomePai != null ? "nomePai=" + nomePai + ", " : "")
				+ (nomeMae != null ? "nomeMae=" + nomeMae + ", " : "")
				+ (pisPasep != null ? "pisPasep=" + pisPasep + ", " : "")
				+ (isAcessoRestrito()? "Acesso = restrito, " : "Acesso =  Livre")
				+ (dataPisPasep != null ? "dataPisPasep=" + dataPisPasep + ", " : "")
				+ (tituloEleitorNumero != null ? "tituloEleitorNumero=" + tituloEleitorNumero + ", " : "")
				+ (tituloEleitorZona != null ? "tituloEleitorZona=" + tituloEleitorZona + ", " : "")
				+ (tituloEleitorSecao != null ? "tituloEleitorSecao=" + tituloEleitorSecao + ", " : "")
				+ (cnhRegistro != null ? "cnhRegistro=" + cnhRegistro + ", " : "")
				+ (cnhDataEmissao != null ? "cnhDataEmissao=" + cnhDataEmissao + ", " : "")
				+ (cnhDataPrimeira != null ? "cnhDataPrimeira=" + cnhDataPrimeira + ", " : "")
				+ (cnhDataValidade != null ? "cnhDataValidade=" + cnhDataValidade + ", " : "")
//				+ (tpsCodigo != null ? "tpsCodigo=" + tpsCodigo.getNome() + ", " : "")
//				+ (certificadoMilitar != null ? "certificadoMilitar=" + certificadoMilitar + ", " : "")
				+ (idDeficiencia != null ? "idDeficiencia=" + idDeficiencia.getNome() + ", " : "")
//				+ (cidCodigoNaturalidade != null ? "cidCodigoNaturalidade=" + cidCodigoNaturalidade.getNome() + ", " : "")
//				+ (cidCodigoTituloEleitorMunicipio != null
//						? "cidCodigoTituloEleitorMunicipio=" + cidCodigoTituloEleitorMunicipio.getNome() + ", "
//						: "")
//				+ (idCnhCategoria != null ? "idCnhCategoria=" + idCnhCategoria.getCategoria() + ", " : "")
//				+ (idCutis != null ? "idCutis=" + idCutis.getNome() + ", " : "")
				//+ (ufeOrgaoExpedidor != null ? "ufeOrgaoExpedidor=" + ufeOrgaoExpedidor + ", " : "")
//				+ (idTipoCabelo != null ? "idTipoCabelo=" + idTipoCabelo.getNome() + ", " : "")
//				+ (idEstadoCivil != null ? "idEstadoCivil=" + idEstadoCivil.getNome() + ", " : "")
//				+ (idEtnia != null ? "idEtnia=" + idEtnia.getNome() + ", " : "")
//				+ (idGrupoSanguineo != null ? "idGrupoSanguineo=" + idGrupoSanguineo.getNome() + ", " : "")
//				+ (idOlhos != null ? "idOlhos=" + idOlhos.getNome() + ", " : "")
//				+ (idSexo != null ? "idSexo=" + idSexo.getNome() + ", " : "") + (idPais != null ? "idPais=" + idPais + ", " : "")
//				+ (idReligiao != null ? "idReligiao=" + idReligiao.getNome() + ", " : "")
//				+ (ufeCNH != null ? "ufeCNH=" + ufeCNH.getSigla() + ", " : "")
//				+ (medidaCorporal != null ? "medidaCorporal=" + medidaCorporal + ", " : "") + "statusRecadastramento="
//				+ statusRecadastramento + ", " + (enderecoAtual != null ? "enderecoAtual=" + this.getEnderecoFormatado() + ", " : "")
//				+ (listEmail != null && !listEmail.isEmpty() ? "Email=" + this.getEmailFormatados() + ", " : "")
//				+ (listTelefone != null && !listTelefone.isEmpty() ? " Telefone=" + this.getTelefonesFormatados() + ", " : "")
//				+ "pensionista=" + pensionista + ", ativo=" + ativo
//				+ ", candidato=" + candidato + ", inativo=" + inativo + ", civil=" + civil + ", militar=" + militar
//				+ ", dependente=" + dependente + ", empregadoTerceirizado=" + empregadoTerceirizado
//				+ ", pendenciasAnexos=" + pendenciasAnexos + ", "
//				+ (paisResidencia != null ? "paisResidencia=" + paisResidencia.getNome() + ", " : "") + "habilitado=" + habilitado
				+  "]";
	}

*/

}