package br.gov.df.pm.sgv.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DiferencaDTO {
    private Long idViatura;
    private Float ultimoOdometro;
    private TipoVistoriaDTO tipoVistoria;
}
