package br.gov.df.pm.sgv.controller;

import br.gov.df.pm.sgv.dto.root.ApiInfoDTO;
import br.gov.df.pm.sgv.dto.root.PerfilDTO;
import br.gov.df.pm.sgv.security.UserProvider;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.SecuritySchemeIn;
import io.swagger.v3.oas.annotations.enums.SecuritySchemeType;
import io.swagger.v3.oas.annotations.security.SecurityScheme;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/")
@SecurityScheme(
        name = "Authorization",
        type = SecuritySchemeType.APIKEY,
        in = SecuritySchemeIn.HEADER,
        paramName = "Authorization"
)
public class RootController {

    private final UserProvider userProvider;

    public RootController(UserProvider userProvider) {
        this.userProvider = userProvider;
    }

    @GetMapping
    public ResponseEntity<ApiInfoDTO> root(@Parameter(hidden = true) @Value("${build.version}") String appVersion) {
        List<PerfilDTO> perfilDTOS = userProvider.getPerfisPolicialAutenticado();
//        if(perfilDTOS.isEmpty()){
//            throw new ResponseStatusException(HttpStatus.FORBIDDEN,"Você não tem perfis para utilizar o SGF, acesse o SGPOL para atribuir perfil ao SGF.");
//        }
        return ResponseEntity.ok(new ApiInfoDTO(appVersion, userProvider.getPolicialAutenticado(), perfilDTOS));
    }
}