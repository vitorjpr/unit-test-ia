```java
package br.gov.df.pm.sgv.repository.sgpol;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@SpringBootTest
@ExtendWith(MockitoExtension.class)
public class PolicialRepositoryTest {

    @MockBean
    private PolicialRepository policialRepository;

    @Test
    public void testFindByMatricula() {
        // Given
        String matricula = "123456";

        // When
        Policial policial = new Policial();
        policial.setMatricula(matricula);
        when(policialRepository.findByMatricula(matricula)).thenReturn(policial);

        // Then
        assertEquals(matricula, policialRepository.findByMatricula(matricula).getMatricula());
    }

    @Test
    public void testFindById() {
        // Given
        Integer id = 1;

        // When
        Policial policial = new Policial();
        policial.setId(id);
        when(policialRepository.findById(id)).thenReturn(Optional.of(policial));

        // Then
        assertEquals(id, policialRepository.findById(id).get().getId());
    }
}
```