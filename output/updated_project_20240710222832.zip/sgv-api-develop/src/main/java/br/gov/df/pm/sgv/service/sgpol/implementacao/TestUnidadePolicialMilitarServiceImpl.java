Here are unit tests for the provided Java code:

```java
package br.gov.df.pm.sgv.service.sgpol.implementacao;

import br.gov.df.pm.sgv.domain.sgpol.UnidadePolicialMilitar;
import br.gov.df.pm.sgv.exceptions.ResourceNotFoundException;
import br.gov.df.pm.sgv.repository.sgpol.UnidadePolicialMilitarRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

public class UnidadePolicialMilitarServiceImplTest {

    @Mock
    private UnidadePolicialMilitarRepository unidadePolicialMilitarRepository;

    @InjectMocks
    private UnidadePolicialMilitarServiceImpl unidadePolicialMilitarService;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testFindUPMById() {
        UnidadePolicialMilitar mockUPM = new UnidadePolicialMilitar();
        mockUPM.setId(1);
        when(unidadePolicialMilitarRepository.findById(1)).thenReturn(Optional.of(mockUPM));

        UnidadePolicialMilitar result = unidadePolicialMilitarService.findUPMById(1);

        assertEquals(1, result.getId());
    }

    @Test
    public void testListar() {
        List<UnidadePolicialMilitar> mockList = new ArrayList<>();
        mockList.add(new UnidadePolicialMilitar());
        mockList.add(new UnidadePolicialMilitar());
        when(unidadePolicialMilitarRepository.findAllByAtivoOrderBySigla(1)).thenReturn(mockList);

        List<UnidadePolicialMilitar> result = unidadePolicialMilitarService.listar();

        assertEquals(2, result.size());
    }

    @Test
    public void testEntityExists() {
        UnidadePolicialMilitar mockUPM = new UnidadePolicialMilitar();
        mockUPM.setId(1);
        when(unidadePolicialMilitarRepository.findById(1)).thenReturn(Optional.of(mockUPM));

        UnidadePolicialMilitar result = unidadePolicialMilitarService.entityExists(1);

        assertEquals(1, result.getId());
    }

    @Test
    public void testEntityExistsNotFound() {
        when(unidadePolicialMilitarRepository.findById(1)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> unidadePolicialMilitarService.entityExists(1));
    }
}
```

These unit tests cover the `UnidadePolicialMilitarServiceImpl` class methods `findUPMById`, `listar`, `entityExists`, and the exception case for `entityExists`. The tests use Mockito for mocking the repository and verifying the expected behavior.