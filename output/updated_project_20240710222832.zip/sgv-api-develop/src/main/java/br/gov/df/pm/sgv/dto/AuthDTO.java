package br.gov.df.pm.sgv.dto;


import lombok.Data;

@Data
public class AuthDTO {
    private String username;
    private String password;
}
