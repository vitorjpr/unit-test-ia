package br.gov.df.pm.sgv.configurations;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.hateoas.LinkRelation;
import org.springframework.hateoas.server.LinkRelationProvider;
import org.springframework.hateoas.server.core.DefaultLinkRelationProvider;

@Configuration
public class HateoasConfiguration {
    /**
     * Configura o retorno json do Hateoas, nomeando o atributo que agrupa os valores com o nome 'values', ex:
     * <p>
     * {
     * _embedded: {
     * values: [{id:1}, {id: 2}]
     * }
     * }
     */

    @Bean
    public LinkRelationProvider genericLinkRelationProvider() {
        return new DefaultLinkRelationProvider() {
            @Override
            public LinkRelation getCollectionResourceRelFor(Class<?> type) {
                return LinkRelation.of("values");
            }
        };
    }
}