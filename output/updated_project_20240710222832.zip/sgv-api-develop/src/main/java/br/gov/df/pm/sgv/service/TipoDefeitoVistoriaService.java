package br.gov.df.pm.sgv.service;

import br.gov.df.pm.sgv.dto.EdicaoTipoDefeitoVistoriaDTO;
import br.gov.df.pm.sgv.dto.TipoDefeitoVistoriaDTO;
import br.gov.df.pm.sgv.domain.TipoDefeitoVistoriaEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface TipoDefeitoVistoriaService {
    ResponseEntity<TipoDefeitoVistoriaDTO> buscarId(Long id);
    Page<TipoDefeitoVistoriaEntity> buscar(String filter, Pageable pageable);
    ResponseEntity<?> salvar(TipoDefeitoVistoriaDTO tipoDefeito);
    ResponseEntity<?> editar(Long id, EdicaoTipoDefeitoVistoriaDTO edicao);
    ResponseEntity<?> desativar(Long id);
    ResponseEntity<?> excluir(Long id);
    ResponseEntity<?> ativar(Long id);
    List<TipoDefeitoVistoriaDTO> listAllAtivos();
}
