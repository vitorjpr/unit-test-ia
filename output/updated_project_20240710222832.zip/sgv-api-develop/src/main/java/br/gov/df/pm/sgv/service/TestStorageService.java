Sure! Below are the unit tests for the given Java code:

```java
package br.gov.df.pm.sgv.service;

import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.core.io.Resource;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

class StorageServiceTest {

    private final RestTemplate restTemplate = mock(RestTemplate.class);
    private final StorageService storageService = new StorageServiceImpl(restTemplate);

    @Test
    void testSalvarImagem() {
        MultipartFile mockFile = mock(MultipartFile.class);
        ResponseEntity<UUID> expectedResponse = ResponseEntity.ok(UUID.randomUUID());

        when(restTemplate.exchange(any(RequestEntity.class), eq(UUID.class)).thenReturn(expectedResponse);

        ResponseEntity<UUID> response = storageService.salvarImagem(mockFile);

        assertEquals(expectedResponse, response);
    }

    @Test
    void testBaixarImagemAI() {
        UUID mockId = UUID.randomUUID();
        ResponseEntity<Resource> expectedResponse = ResponseEntity.ok().contentType(MediaType.IMAGE_JPEG).body(mock(Resource.class));

        when(restTemplate.exchange(any(RequestEntity.class), eq(Resource.class)).thenReturn(expectedResponse);

        ResponseEntity<Resource> response = storageService.baixarImagemAI(mockId);

        assertEquals(expectedResponse, response);
    }

    @Test
    void testRemoverImagem() {
        UUID mockId = UUID.randomUUID();

        doNothing().when(restTemplate).delete(anyString(), eq(mockId));

        storageService.removerImagem(mockId);

        verify(restTemplate, times(1)).delete(anyString(), eq(mockId));
    }
}
```

In these tests, we are using Mockito to mock the `RestTemplate` and verify the interactions with it based on the methods being called in the `StorageService` implementation. The tests cover the `salvarImagem`, `baixarImagemAI`, and `removerImagem` methods of the `StorageService`.

Make sure to include the necessary dependencies for Mockito and JUnit in your project to run these tests successfully.