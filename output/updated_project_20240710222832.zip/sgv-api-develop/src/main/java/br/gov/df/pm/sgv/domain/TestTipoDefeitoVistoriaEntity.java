Here are the unit tests for the `TipoDefeitoVistoriaEntity` class:

```java
package br.gov.df.pm.sgv.domain;

import org.junit.jupiter.api.Test;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

public class TipoDefeitoVistoriaEntityTest {

    @Test
    public void testGetSetId() {
        TipoDefeitoVistoriaEntity entity = new TipoDefeitoVistoriaEntity();
        Long id = 1L;
        entity.setId(id);
        assertEquals(id, entity.getId());
    }

    @Test
    public void testGetSetNome() {
        TipoDefeitoVistoriaEntity entity = new TipoDefeitoVistoriaEntity();
        String nome = "Teste";
        entity.setNome(nome);
        assertEquals(nome, entity.getNome());
    }

    @Test
    public void testGetSetDescricao() {
        TipoDefeitoVistoriaEntity entity = new TipoDefeitoVistoriaEntity();
        String descricao = "Descrição do teste";
        entity.setDescricao(descricao);
        assertEquals(descricao, entity.getDescricao());
    }

    @Test
    public void testGetSetAtivo() {
        TipoDefeitoVistoriaEntity entity = new TipoDefeitoVistoriaEntity();
        Boolean ativo = true;
        entity.setAtivo(ativo);
        assertEquals(ativo, entity.getAtivo());
    }

    @Test
    public void testGetSetDataInclusao() {
        TipoDefeitoVistoriaEntity entity = new TipoDefeitoVistoriaEntity();
        LocalDate dataInclusao = LocalDate.of(2022, 12, 31);
        entity.setDataInclusao(dataInclusao);
        assertEquals(dataInclusao, entity.getDataInclusao());
    }

    @Test
    public void testEqualsAndHashCode() {
        TipoDefeitoVistoriaEntity entity1 = new TipoDefeitoVistoriaEntity();
        entity1.setId(1L);

        TipoDefeitoVistoriaEntity entity2 = new TipoDefeitoVistoriaEntity();
        entity2.setId(1L);

        assertEquals(entity1, entity2);
        assertEquals(entity1.hashCode(), entity2.hashCode());
    }
}
```

Make sure to include the necessary imports for the classes used in the tests. These tests cover the getter and setter methods for all fields, as well as the `equals` and `hashCode` methods based on the `id` field.