package br.gov.df.pm.sgv.service;

import br.gov.df.pm.sgv.dto.AuthDTO;
import br.gov.df.pm.sgv.feign.dto.MessageAuthKeycloak;
import org.springframework.http.ResponseEntity;

public interface AuthService {
    ResponseEntity<MessageAuthKeycloak> authentication(AuthDTO auth);
}
