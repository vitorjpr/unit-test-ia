package br.gov.df.pm.sgv.exceptions;

public class SubItemVistoriaException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public SubItemVistoriaException() {
    }

    public SubItemVistoriaException(String message) {
        super(message);
    }

    public SubItemVistoriaException(String message, Throwable cause) {
        super(message, cause);
    }
}
