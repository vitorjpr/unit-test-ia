CREATE TABLE sgv.DIFERENCAODOMETRO (
	do_Codigo int IDENTITY(1,1) NOT NULL,
	do_ReferenciaInicial int NULL,
	do_ReferenciaFinal int NULL,
	do_DiferencaOdometro int NULL,
	do_DataInclusao date NULL,
	do_DataModificaco date NULL,
	CONSTRAINT PK_DIFERENCA_ODOMETRO PRIMARY KEY (do_Codigo)
);