CREATE TABLE sgv.DEFEITOSVISTORIA (
	dev_Codigo int IDENTITY(1,1) NOT NULL,
	dev_CodSubitem int NULL,
	dev_ativo bit NULL,
	dev_DtInclusao date NULL,
	dev_CodTipoDefeito int NULL,
	CONSTRAINT PK_DEFEITOS_VISTORIA PRIMARY KEY (dev_Codigo)
);

CREATE TABLE sgv.ITEMVISTORIA (
	itv_Codigo int IDENTITY(1,1) NOT NULL,
	itv_Nome varchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	itv_Descricao varchar(200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	itv_ativo bit NULL,
	itv_DtInclusao date NULL,
	CONSTRAINT PK_ITEM_VISTORIA PRIMARY KEY (itv_Codigo)
);

CREATE TABLE sgv.ITENSVISTORIA (
	itv_Codigo int IDENTITY(1,1) NOT NULL,
	itv_CodTipo int NULL,
	itv_ativo bit NULL,
	itv_DtInclusao date NULL,
	itv_CodItem int NULL,
	CONSTRAINT PK_ITENS_VISTORIA PRIMARY KEY (itv_Codigo)
);

CREATE TABLE sgv.SUBITEMVISTORIA (
	suv_Codigo int IDENTITY(1,1) NOT NULL,
	suv_Nome varchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	suv_Descricao varchar(200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	suv_ativo bit NULL,
	suv_DtInclusao date NULL,
	CONSTRAINT PK_SUBITEM_VISTORIA PRIMARY KEY (suv_Codigo)
);

CREATE TABLE sgv.SUBITENSVISTORIA (
	suv_Codigo int IDENTITY(1,1) NOT NULL,
	suv_CodItem int NULL,
	suv_ativo bit NULL,
	suv_DtInclusao date NULL,
	suv_CodSubitem int NULL,
	CONSTRAINT PK_SUBITENS_VISTORIA PRIMARY KEY (suv_Codigo)
);

CREATE TABLE sgv.TIPODEFEITOVISTORIA (
	tidv_Codigo int IDENTITY(1,1) NOT NULL,
	tidv_Nome varchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	tidv_Descricao varchar(200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	tidv_ativo bit NULL,
	tidv_DtInclusao date NULL,
	CONSTRAINT TIPO_DEFEITO_VISTORIA PRIMARY KEY (tidv_Codigo)
);

CREATE TABLE sgv.TIPOVISTORIA (
	tiv_Codigo int IDENTITY(1,1) NOT NULL,
	tiv_Nome varchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	tiv_Descricao varchar(200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	tiv_ativo bit NULL,
	tiv_DtInclusao date NULL,
	CONSTRAINT PK_TIPO_VISTORIA PRIMARY KEY (tiv_Codigo)
);

