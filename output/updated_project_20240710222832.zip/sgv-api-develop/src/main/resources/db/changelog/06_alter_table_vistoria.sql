ALTER TABLE sgf_fabrica.sgv.VISTORIA_VIATURA ADD vv_OdometroInicial float NULL;
EXEC sgf_fabrica.sys.sp_addextendedproperty 'MS_Description', N'Odometro Inicial da vistoria', 'schema', N'sgv', 'table', N'VISTORIA_VIATURA', 'column', N'vv_OdometroInicial';
ALTER TABLE sgf_fabrica.sgv.VISTORIA_VIATURA ADD vv_OdometroFinal float NULL;
EXEC sgf_fabrica.sys.sp_addextendedproperty 'MS_Description', N'Odômetro final da vistoria', 'schema', N'sgv', 'table', N'VISTORIA_VIATURA', 'column', N'vv_OdometroFinal';
ALTER TABLE sgf_fabrica.sgv.VISTORIA_VIATURA ADD vv_DiferencaVistoria bit NULL;
EXEC sgf_fabrica.sys.sp_addextendedproperty 'MS_Description', N'Verifica se a diferença é permitida. True a diferença é permitida, false a diferença não é permitida', 'schema', N'sgv', 'table', N'VISTORIA_VIATURA', 'column', N'vv_DiferencaVistoria';
ALTER TABLE sgf_fabrica.sgv.VISTORIA_VIATURA ADD vv_DataVistoria datetime NULL;
EXEC sgf_fabrica.sys.sp_addextendedproperty 'MS_Description', N'Data da vistoria', 'schema', N'sgv', 'table', N'VISTORIA_VIATURA', 'column', N'vv_DataVistoria';
ALTER TABLE sgf_fabrica.sgv.VISTORIA_VIATURA_HISTORICO ALTER COLUMN vvh_data datetime NULL;