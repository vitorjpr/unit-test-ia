INSERT INTO dbo.PERFIL (pef_Nome, pef_Descricao, pef_Ativo) VALUES('ADMINISTRADOR_SGV', 'Administrador do Sistema', 1);
INSERT INTO dbo.PERFIL (pef_Nome, pef_Descricao, pef_Ativo) VALUES('ADJUNTO_SGV', 'Libera Acesso', 1);
INSERT INTO dbo.PERFIL (pef_Nome, pef_Descricao, pef_Ativo) VALUES('POLICIAL_AREA_SGV', 'Policial de Área', 1);
INSERT INTO dbo.PERFIL (pef_Nome, pef_Descricao, pef_Ativo) VALUES('POLICIAL_COMPLEXO_SGV', 'Policial do Complexo Administrativo', 1);