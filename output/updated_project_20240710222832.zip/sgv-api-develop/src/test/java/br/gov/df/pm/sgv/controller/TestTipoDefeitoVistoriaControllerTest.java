```java
package br.gov.df.pm.sgv.controller;

import br.gov.df.pm.sgv.domain.DefeitosVistoriaEntity;
import br.gov.df.pm.sgv.domain.SubitemVistoriaEntity;
import br.gov.df.pm.sgv.dto.EdicaoTipoDefeitoVistoriaDTO;
import br.gov.df.pm.sgv.dto.TipoDefeitoVistoriaDTO;
import br.gov.df.pm.sgv.domain.TipoDefeitoVistoriaEntity;
import br.gov.df.pm.sgv.exceptions.VistoriaExceptions;
import br.gov.df.pm.sgv.repository.DefeitosVistoriaRepository;
import br.gov.df.pm.sgv.repository.TipoDefeitoVistoriaRepository;
import br.gov.df.pm.sgv.util.TestUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.PagedModel;
import org.springframework.http.ResponseEntity;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class TipoDefeitoVistoriaControllerTest {
    @Mock
    private TipoDefeitoVistoriaRepository repository;

    @Mock
    private DefeitosVistoriaRepository defeitosRepository;

    @InjectMocks
    private TipoDefeitoVistoriaController controller;

    private TipoDefeitoVistoriaEntity tipoDefeitoMock;
    private TipoDefeitoVistoriaDTO tipoDefeitoMockDto;
    private EdicaoTipoDefeitoVistoriaDTO edicaoTipoDefeitoVistoriaMockDto;
    private DefeitosVistoriaEntity defeitosVistoriaEntity;

    @BeforeEach
    void setUp() {
        tipoDefeitoMock = TipoDefeitoVistoriaEntity.builder()
                .id(1L)
                .nome("Vidro")
                .descricao("Vidro da Viatura")
                .ativo(true)
                .dataInclusao(LocalDate.now())
                .build();

        tipoDefeitoMockDto = TipoDefeitoVistoriaDTO.builder()
                .nome("Vidro")
                .descricao("Vidro da Viatura")
                .ativo(true)
                .dataInclusao(LocalDate.now())
                .build();

        edicaoTipoDefeitoVistoriaMockDto = EdicaoTipoDefeitoVistoriaDTO.builder()
                .nome("Vidro")
                .descricao("Vidro da Vistoria")
                .build();

        defeitosVistoriaEntity = DefeitosVistoriaEntity.builder()
                .id(1L)
                .codTipoDefeito(new TipoDefeitoVistoriaEntity())
                .codSubitem(new SubitemVistoriaEntity())
                .dataInclusao(LocalDate.now())
                .ativo(true)
                .build();

        Specification<TipoDefeitoVistoriaEntity> spec = ArgumentMatchers.any();
        Pageable pageable = ArgumentMatchers.any();
        when(repository.findAll(spec, pageable)).then(TestUtils.callableAnswer(invocation -> {
            Specification<TipoDefeitoVistoriaDTO> s = invocation.getArgument(0);
            Root<TipoDefeitoVistoriaDTO> root = mock(Root.class);
            CriteriaQuery<TipoDefeitoVistoriaDTO> query = mock(CriteriaQuery.class);
            when(query.getResultType()).thenReturn(TipoDefeitoVistoriaDTO.class);
            CriteriaBuilder builder = mock(CriteriaBuilder.class);
            s.toPredicate(root, query, builder);
            return new PageImpl<>(List.of(tipoDefeitoMock));
        }));
    }

    @Test
    void buscarId() {
        when(repository.findById(1L)).thenReturn(Optional.of(tipoDefeitoMock));
        ResponseEntity<TipoDefeitoVistoriaDTO> response = controller.buscarId(1L);
        assertNotNull(response);
    }

    @Test
    void buscar() {
        var pageable = PageRequest.of(0, 1);
        PagedModel<EntityModel<TipoDefeitoVistoriaDTO>> response = controller.buscar("Vidro", pageable);
        assertNotNull(response);
    }

    @Test
    void salvar() {
        when(repository.findById(1L)).thenReturn(Optional.of(tipoDefeitoMock));
        assertNotNull