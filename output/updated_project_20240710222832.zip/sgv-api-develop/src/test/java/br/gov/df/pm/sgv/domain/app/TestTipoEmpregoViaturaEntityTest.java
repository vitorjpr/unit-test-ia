```java
package br.gov.df.pm.sgv.domain.app;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class TipoEmpregoViaturaEntityTest {
    private TipoEmpregoViaturaEntity tipoEmprego;

    @BeforeEach
    void setUp() {
        tipoEmprego = new TipoEmpregoViaturaEntity(1, "Vidro", 1);
    }

    @Test
    void testEquals() {
        var tipoEmprego1 = new TipoEmpregoViaturaEntity(1, "Vidro", 1);
        assertEquals(tipoEmprego, tipoEmprego1);

        var tipoEmprego2 = new TipoEmpregoViaturaEntity(null, "Janela", null);
        assertNotEquals(tipoEmprego, tipoEmprego2);
    }

    @Test
    void testHashCode() {
        var tipoEmprego1 = new TipoEmpregoViaturaEntity(1, "Vidro", 1);
        assertEquals(tipoEmprego.hashCode(), tipoEmprego1.hashCode());

        var tipoEmprego2 = new TipoEmpregoViaturaEntity(null, "Janela", null);
        assertNotEquals(tipoEmprego.hashCode(), tipoEmprego2.hashCode());
    }

    @Test
    void testToString() {
        assertNotNull(tipoEmprego.toString());
    }
}
``` 

Estes são os testes unitários para a classe `TipoEmpregoViaturaEntity`. Eles cobrem os métodos `equals()`, `hashCode()` e `toString()`, garantindo uma cobertura básica. Certifique-se de que a classe `TipoEmpregoViaturaEntity` tenha um construtor que aceite os parâmetros `id`, `nome` e `ativo` para que os testes sejam executados corretamente.