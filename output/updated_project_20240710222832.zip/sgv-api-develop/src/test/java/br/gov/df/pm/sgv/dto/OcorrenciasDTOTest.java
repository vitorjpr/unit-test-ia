package br.gov.df.pm.sgv.dto;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class OcorrenciasDTOTest {

    @BeforeEach
    void setUp() {
    }

    @Test
    void getItemVistoriaOcorrenciaDTOS() {
    }

    @Test
    void setItemVistoriaOcorrenciaDTOS() {
    }

    @Test
    void testEquals() {
    }

    @Test
    void canEqual() {
    }

    @Test
    void testHashCode() {
    }

    @Test
    void testToString() {
    }

    @Test
    void builder() {
    }
}