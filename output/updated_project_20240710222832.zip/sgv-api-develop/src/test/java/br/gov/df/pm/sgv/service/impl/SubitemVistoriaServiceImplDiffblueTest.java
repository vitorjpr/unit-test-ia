package br.gov.df.pm.sgv.service.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isA;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import br.gov.df.pm.sgv.domain.DefeitosVistoriaEntity;
import br.gov.df.pm.sgv.domain.ItemVistoriaEntity;
import br.gov.df.pm.sgv.domain.SubitemVistoriaEntity;
import br.gov.df.pm.sgv.domain.SubitensVistoriaEntity;
import br.gov.df.pm.sgv.domain.TipoDefeitoVistoriaEntity;
import br.gov.df.pm.sgv.dto.EdicaoSubitemVistoriaDTO;
import br.gov.df.pm.sgv.dto.SubitemVistoriaDTO;
import br.gov.df.pm.sgv.exceptions.VistoriaExceptions;
import br.gov.df.pm.sgv.repository.DefeitosVistoriaRepository;
import br.gov.df.pm.sgv.repository.SubitemVistoriaRepository;
import br.gov.df.pm.sgv.repository.SubitensVistoriaRepository;
import br.gov.df.pm.sgv.repository.TipoDefeitoVistoriaRepository;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ContextConfiguration(classes = {SubitemVistoriaServiceImpl.class})
@ExtendWith(SpringExtension.class)
class SubitemVistoriaServiceImplDiffblueTest {
    @MockBean
    private DefeitosVistoriaRepository defeitosVistoriaRepository;

    @MockBean
    private SubitemVistoriaRepository subitemVistoriaRepository;

    @Autowired
    private SubitemVistoriaServiceImpl subitemVistoriaServiceImpl;

    @MockBean
    private SubitensVistoriaRepository subitensVistoriaRepository;

    @MockBean
    private TipoDefeitoVistoriaRepository tipoDefeitoVistoriaRepository;

    /**
     * Method under test: {@link SubitemVistoriaServiceImpl#buscarId(Long)}
     */
    @Test
    void testBuscarId() {
        // Arrange
        SubitemVistoriaEntity subitemVistoriaEntity = new SubitemVistoriaEntity();
        subitemVistoriaEntity.setAtivo(true);
        subitemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        subitemVistoriaEntity.setDescricao("Descricao");
        subitemVistoriaEntity.setId(1L);
        subitemVistoriaEntity.setNome("Nome");
        Optional<SubitemVistoriaEntity> ofResult = Optional.of(subitemVistoriaEntity);
        when(subitemVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        // Act
        ResponseEntity<SubitemVistoriaDTO> actualBuscarIdResult = subitemVistoriaServiceImpl.buscarId(1L);

        // Assert
        verify(subitemVistoriaRepository).findById(eq(1L));
        SubitemVistoriaDTO body = actualBuscarIdResult.getBody();
        assertEquals("1970-01-01", body.getDataInclusao().toString());
        assertEquals("Descricao", body.getDescricao());
        assertEquals("Nome", body.getNome());
        assertNull(body.getAtivo());
        assertNull(body.getId());
        assertNull(body.getDefeitos());
        assertEquals(HttpStatus.OK, actualBuscarIdResult.getStatusCode());
        assertTrue(actualBuscarIdResult.hasBody());
        assertTrue(actualBuscarIdResult.getHeaders().isEmpty());
    }

    /**
     * Method under test: {@link SubitemVistoriaServiceImpl#buscarId(Long)}
     */
    @Test
    void testBuscarId2() {
        // Arrange
        SubitemVistoriaEntity subitemVistoriaEntity = mock(SubitemVistoriaEntity.class);
        when(subitemVistoriaEntity.getDescricao()).thenReturn("Descricao");
        when(subitemVistoriaEntity.getNome()).thenReturn("Nome");
        when(subitemVistoriaEntity.getDataInclusao()).thenReturn(LocalDate.of(1970, 1, 1));
        doNothing().when(subitemVistoriaEntity).setAtivo(Mockito.<Boolean>any());
        doNothing().when(subitemVistoriaEntity).setDataInclusao(Mockito.<LocalDate>any());
        doNothing().when(subitemVistoriaEntity).setDescricao(Mockito.<String>any());
        doNothing().when(subitemVistoriaEntity).setId(Mockito.<Long>any());
        doNothing().when(subitemVistoriaEntity).setNome(Mockito.<String>any());
        subitemVistoriaEntity.setAtivo(true);
        subitemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        subitemVistoriaEntity.setDescricao("Descricao");
        subitemVistoriaEntity.setId(1L);
        subitemVistoriaEntity.setNome("Nome");
        Optional<SubitemVistoriaEntity> ofResult = Optional.of(subitemVistoriaEntity);
        when(subitemVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        // Act
        ResponseEntity<SubitemVistoriaDTO> actualBuscarIdResult = subitemVistoriaServiceImpl.buscarId(1L);

        // Assert
        verify(subitemVistoriaEntity).getDataInclusao();
        verify(subitemVistoriaEntity).getDescricao();
        verify(subitemVistoriaEntity).getNome();
        verify(subitemVistoriaEntity).setAtivo(eq(true));
        verify(subitemVistoriaEntity).setDataInclusao(isA(LocalDate.class));
        verify(subitemVistoriaEntity).setDescricao(eq("Descricao"));
        verify(subitemVistoriaEntity).setId(eq(1L));
        verify(subitemVistoriaEntity).setNome(eq("Nome"));
        verify(subitemVistoriaRepository).findById(eq(1L));
        SubitemVistoriaDTO body = actualBuscarIdResult.getBody();
        assertEquals("1970-01-01", body.getDataInclusao().toString());
        assertEquals("Descricao", body.getDescricao());
        assertEquals("Nome", body.getNome());
        assertNull(body.getAtivo());
        assertNull(body.getId());
        assertNull(body.getDefeitos());
        assertEquals(HttpStatus.OK, actualBuscarIdResult.getStatusCode());
        assertTrue(actualBuscarIdResult.hasBody());
        assertTrue(actualBuscarIdResult.getHeaders().isEmpty());
    }

    /**
     * Method under test:
     * {@link SubitemVistoriaServiceImpl#buscar(String, Pageable)}
     */
    @Test
    void testBuscar() {
        // Arrange
        when(defeitosVistoriaRepository.findAllByCodTipoDefeito(Mockito.<TipoDefeitoVistoriaEntity>any()))
                .thenReturn(new ArrayList<>());
        PageImpl<SubitemVistoriaEntity> pageImpl = new PageImpl<>(new ArrayList<>());
        when(
                subitemVistoriaRepository.findAll(Mockito.<Specification<SubitemVistoriaEntity>>any(), Mockito.<Pageable>any()))
                .thenReturn(pageImpl);

        TipoDefeitoVistoriaEntity tipoDefeitoVistoriaEntity = new TipoDefeitoVistoriaEntity();
        tipoDefeitoVistoriaEntity.setAtivo(true);
        tipoDefeitoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoDefeitoVistoriaEntity.setDescricao("Descricao");
        tipoDefeitoVistoriaEntity.setId(1L);
        tipoDefeitoVistoriaEntity.setNome("Nome");
        Optional<TipoDefeitoVistoriaEntity> ofResult = Optional.of(tipoDefeitoVistoriaEntity);
        when(tipoDefeitoVistoriaRepository.findByNome(Mockito.<String>any())).thenReturn(ofResult);

        // Act
        Page<SubitemVistoriaEntity> actualBuscarResult = subitemVistoriaServiceImpl.buscar("Filter", null);

        // Assert
        verify(defeitosVistoriaRepository).findAllByCodTipoDefeito(isA(TipoDefeitoVistoriaEntity.class));
        verify(tipoDefeitoVistoriaRepository).findByNome(eq("Filter"));
        verify(subitemVistoriaRepository).findAll(isA(Specification.class), (Pageable) isNull());
        assertTrue(actualBuscarResult.toList().isEmpty());
        assertSame(pageImpl, actualBuscarResult);
    }

    /**
     * Method under test:
     * {@link SubitemVistoriaServiceImpl#buscar(String, Pageable)}
     */
    @Test
    void testBuscar2() {
        // Arrange
        when(defeitosVistoriaRepository.findAllByCodTipoDefeito(Mockito.<TipoDefeitoVistoriaEntity>any()))
                .thenThrow(new VistoriaExceptions("An error occurred"));

        TipoDefeitoVistoriaEntity tipoDefeitoVistoriaEntity = new TipoDefeitoVistoriaEntity();
        tipoDefeitoVistoriaEntity.setAtivo(true);
        tipoDefeitoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoDefeitoVistoriaEntity.setDescricao("Descricao");
        tipoDefeitoVistoriaEntity.setId(1L);
        tipoDefeitoVistoriaEntity.setNome("Nome");
        Optional<TipoDefeitoVistoriaEntity> ofResult = Optional.of(tipoDefeitoVistoriaEntity);
        when(tipoDefeitoVistoriaRepository.findByNome(Mockito.<String>any())).thenReturn(ofResult);

        // Act and Assert
        assertThrows(VistoriaExceptions.class, () -> subitemVistoriaServiceImpl.buscar("Filter", null));
        verify(defeitosVistoriaRepository).findAllByCodTipoDefeito(isA(TipoDefeitoVistoriaEntity.class));
        verify(tipoDefeitoVistoriaRepository).findByNome(eq("Filter"));
    }

    /**
     * Method under test:
     * {@link SubitemVistoriaServiceImpl#buscar(String, Pageable)}
     */
    @Test
    void testBuscar3() {
        // Arrange
        PageImpl<SubitemVistoriaEntity> pageImpl = new PageImpl<>(new ArrayList<>());
        when(
                subitemVistoriaRepository.findAll(Mockito.<Specification<SubitemVistoriaEntity>>any(), Mockito.<Pageable>any()))
                .thenReturn(pageImpl);
        Optional<TipoDefeitoVistoriaEntity> emptyResult = Optional.empty();
        when(tipoDefeitoVistoriaRepository.findByNome(Mockito.<String>any())).thenReturn(emptyResult);

        // Act
        Page<SubitemVistoriaEntity> actualBuscarResult = subitemVistoriaServiceImpl.buscar("Filter", null);

        // Assert
        verify(tipoDefeitoVistoriaRepository).findByNome(eq("Filter"));
        verify(subitemVistoriaRepository).findAll(isA(Specification.class), (Pageable) isNull());
        assertTrue(actualBuscarResult.toList().isEmpty());
        assertSame(pageImpl, actualBuscarResult);
    }

    /**
     * Method under test:
     * {@link SubitemVistoriaServiceImpl#salvar(SubitemVistoriaDTO)}
     */
    @Test
    void testSalvar() {
        // Arrange
        when(defeitosVistoriaRepository.saveAll(Mockito.<Iterable<DefeitosVistoriaEntity>>any()))
                .thenReturn(new ArrayList<>());

        SubitemVistoriaEntity subitemVistoriaEntity = new SubitemVistoriaEntity();
        subitemVistoriaEntity.setAtivo(true);
        subitemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        subitemVistoriaEntity.setDescricao("Descricao");
        subitemVistoriaEntity.setId(1L);
        subitemVistoriaEntity.setNome("Nome");

        SubitemVistoriaEntity subitemVistoriaEntity2 = new SubitemVistoriaEntity();
        subitemVistoriaEntity2.setAtivo(true);
        subitemVistoriaEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        subitemVistoriaEntity2.setDescricao("Descricao");
        subitemVistoriaEntity2.setId(1L);
        subitemVistoriaEntity2.setNome("Nome");
        Optional<SubitemVistoriaEntity> ofResult = Optional.of(subitemVistoriaEntity2);
        when(subitemVistoriaRepository.findByNome(Mockito.<String>any())).thenReturn(ofResult);
        when(subitemVistoriaRepository.save(Mockito.<SubitemVistoriaEntity>any())).thenReturn(subitemVistoriaEntity);

        SubitemVistoriaDTO subitemVistoria = new SubitemVistoriaDTO();
        subitemVistoria.setDefeitos(new ArrayList<>());
        subitemVistoria.setNome("Subitem já cadastrado no sistema.");

        // Act
        ResponseEntity<?> actualSalvarResult = subitemVistoriaServiceImpl.salvar(subitemVistoria);

        // Assert
        verify(subitemVistoriaRepository).findByNome(eq("Subitem já cadastrado no sistema."));
        verify(defeitosVistoriaRepository).saveAll(isA(Iterable.class));
        verify(subitemVistoriaRepository).save(isA(SubitemVistoriaEntity.class));
        assertEquals(HttpStatus.OK, actualSalvarResult.getStatusCode());
        assertTrue(actualSalvarResult.hasBody());
        assertTrue(actualSalvarResult.getHeaders().isEmpty());
    }

    /**
     * Method under test:
     * {@link SubitemVistoriaServiceImpl#salvar(SubitemVistoriaDTO)}
     */
    @Test
    void testSalvar2() {
        // Arrange
        when(defeitosVistoriaRepository.saveAll(Mockito.<Iterable<DefeitosVistoriaEntity>>any()))
                .thenReturn(new ArrayList<>());

        SubitemVistoriaEntity subitemVistoriaEntity = new SubitemVistoriaEntity();
        subitemVistoriaEntity.setAtivo(true);
        subitemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        subitemVistoriaEntity.setDescricao("Descricao");
        subitemVistoriaEntity.setId(1L);
        subitemVistoriaEntity.setNome("Nome");

        SubitemVistoriaEntity subitemVistoriaEntity2 = new SubitemVistoriaEntity();
        subitemVistoriaEntity2.setAtivo(true);
        subitemVistoriaEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        subitemVistoriaEntity2.setDescricao("Descricao");
        subitemVistoriaEntity2.setId(1L);
        subitemVistoriaEntity2.setNome("Nome");
        Optional<SubitemVistoriaEntity> ofResult = Optional.of(subitemVistoriaEntity2);
        when(subitemVistoriaRepository.findByNome(Mockito.<String>any())).thenReturn(ofResult);
        when(subitemVistoriaRepository.save(Mockito.<SubitemVistoriaEntity>any())).thenReturn(subitemVistoriaEntity);
        SubitemVistoriaDTO subitemVistoria = mock(SubitemVistoriaDTO.class);
        when(subitemVistoria.getAtivo()).thenReturn(true);
        when(subitemVistoria.getDescricao()).thenReturn("Descricao");
        when(subitemVistoria.getNome()).thenReturn("Nome");
        when(subitemVistoria.getDataInclusao()).thenReturn(LocalDate.of(1970, 1, 1));
        when(subitemVistoria.getDefeitos()).thenReturn(new ArrayList<>());
        doNothing().when(subitemVistoria).setDefeitos(Mockito.<List<TipoDefeitoVistoriaEntity>>any());
        doNothing().when(subitemVistoria).setNome(Mockito.<String>any());
        subitemVistoria.setDefeitos(new ArrayList<>());
        subitemVistoria.setNome("Subitem já cadastrado no sistema.");

        // Act
        ResponseEntity<?> actualSalvarResult = subitemVistoriaServiceImpl.salvar(subitemVistoria);

        // Assert
        verify(subitemVistoria).getAtivo();
        verify(subitemVistoria).getDataInclusao();
        verify(subitemVistoria).getDefeitos();
        verify(subitemVistoria).getDescricao();
        verify(subitemVistoria, atLeast(1)).getNome();
        verify(subitemVistoria).setDefeitos(isA(List.class));
        verify(subitemVistoria).setNome(eq("Subitem já cadastrado no sistema."));
        verify(subitemVistoriaRepository).findByNome(eq("Nome"));
        verify(defeitosVistoriaRepository).saveAll(isA(Iterable.class));
        verify(subitemVistoriaRepository).save(isA(SubitemVistoriaEntity.class));
        assertEquals(HttpStatus.OK, actualSalvarResult.getStatusCode());
        assertTrue(actualSalvarResult.hasBody());
        assertTrue(actualSalvarResult.getHeaders().isEmpty());
    }

    /**
     * Method under test:
     * {@link SubitemVistoriaServiceImpl#salvar(SubitemVistoriaDTO)}
     */
    @Test
    void testSalvar3() {
        // Arrange
        when(defeitosVistoriaRepository.saveAll(Mockito.<Iterable<DefeitosVistoriaEntity>>any()))
                .thenReturn(new ArrayList<>());

        SubitemVistoriaEntity subitemVistoriaEntity = new SubitemVistoriaEntity();
        subitemVistoriaEntity.setAtivo(true);
        subitemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        subitemVistoriaEntity.setDescricao("Descricao");
        subitemVistoriaEntity.setId(1L);
        subitemVistoriaEntity.setNome("Nome");
        when(subitemVistoriaRepository.save(Mockito.<SubitemVistoriaEntity>any())).thenReturn(subitemVistoriaEntity);
        SubitemVistoriaDTO subitemVistoria = mock(SubitemVistoriaDTO.class);
        when(subitemVistoria.getAtivo()).thenReturn(true);
        when(subitemVistoria.getDescricao()).thenReturn("Descricao");
        when(subitemVistoria.getNome()).thenReturn("");
        when(subitemVistoria.getDataInclusao()).thenReturn(LocalDate.of(1970, 1, 1));
        when(subitemVistoria.getDefeitos()).thenReturn(new ArrayList<>());
        doNothing().when(subitemVistoria).setDefeitos(Mockito.<List<TipoDefeitoVistoriaEntity>>any());
        doNothing().when(subitemVistoria).setNome(Mockito.<String>any());
        subitemVistoria.setDefeitos(new ArrayList<>());
        subitemVistoria.setNome("Subitem já cadastrado no sistema.");

        // Act
        ResponseEntity<?> actualSalvarResult = subitemVistoriaServiceImpl.salvar(subitemVistoria);

        // Assert
        verify(subitemVistoria).getAtivo();
        verify(subitemVistoria).getDataInclusao();
        verify(subitemVistoria).getDefeitos();
        verify(subitemVistoria).getDescricao();
        verify(subitemVistoria, atLeast(1)).getNome();
        verify(subitemVistoria).setDefeitos(isA(List.class));
        verify(subitemVistoria).setNome(eq("Subitem já cadastrado no sistema."));
        verify(defeitosVistoriaRepository).saveAll(isA(Iterable.class));
        verify(subitemVistoriaRepository).save(isA(SubitemVistoriaEntity.class));
        assertEquals(HttpStatus.OK, actualSalvarResult.getStatusCode());
        assertTrue(actualSalvarResult.hasBody());
        assertTrue(actualSalvarResult.getHeaders().isEmpty());
    }

    /**
     * Method under test:
     * {@link SubitemVistoriaServiceImpl#salvar(SubitemVistoriaDTO)}
     */
    @Test
    void testSalvar4() {
        // Arrange
        when(defeitosVistoriaRepository.saveAll(Mockito.<Iterable<DefeitosVistoriaEntity>>any()))
                .thenReturn(new ArrayList<>());

        SubitemVistoriaEntity subitemVistoriaEntity = new SubitemVistoriaEntity();
        subitemVistoriaEntity.setAtivo(true);
        subitemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        subitemVistoriaEntity.setDescricao("Descricao");
        subitemVistoriaEntity.setId(1L);
        subitemVistoriaEntity.setNome("Nome");

        SubitemVistoriaEntity subitemVistoriaEntity2 = new SubitemVistoriaEntity();
        subitemVistoriaEntity2.setAtivo(true);
        subitemVistoriaEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        subitemVistoriaEntity2.setDescricao("Descricao");
        subitemVistoriaEntity2.setId(1L);
        subitemVistoriaEntity2.setNome("Nome");
        Optional<SubitemVistoriaEntity> ofResult = Optional.of(subitemVistoriaEntity2);
        when(subitemVistoriaRepository.findByNome(Mockito.<String>any())).thenReturn(ofResult);
        when(subitemVistoriaRepository.save(Mockito.<SubitemVistoriaEntity>any())).thenReturn(subitemVistoriaEntity);

        TipoDefeitoVistoriaEntity tipoDefeitoVistoriaEntity = new TipoDefeitoVistoriaEntity();
        tipoDefeitoVistoriaEntity.setAtivo(true);
        tipoDefeitoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoDefeitoVistoriaEntity.setDescricao("Subitem já cadastrado no sistema.");
        tipoDefeitoVistoriaEntity.setId(1L);
        tipoDefeitoVistoriaEntity.setNome("Subitem já cadastrado no sistema.");

        ArrayList<TipoDefeitoVistoriaEntity> tipoDefeitoVistoriaEntityList = new ArrayList<>();
        tipoDefeitoVistoriaEntityList.add(tipoDefeitoVistoriaEntity);
        SubitemVistoriaDTO subitemVistoria = mock(SubitemVistoriaDTO.class);
        when(subitemVistoria.getAtivo()).thenReturn(true);
        when(subitemVistoria.getDescricao()).thenReturn("Descricao");
        when(subitemVistoria.getNome()).thenReturn("Nome");
        when(subitemVistoria.getDataInclusao()).thenReturn(LocalDate.of(1970, 1, 1));
        when(subitemVistoria.getDefeitos()).thenReturn(tipoDefeitoVistoriaEntityList);
        doNothing().when(subitemVistoria).setDefeitos(Mockito.<List<TipoDefeitoVistoriaEntity>>any());
        doNothing().when(subitemVistoria).setNome(Mockito.<String>any());
        subitemVistoria.setDefeitos(new ArrayList<>());
        subitemVistoria.setNome("Subitem já cadastrado no sistema.");

        // Act
        ResponseEntity<?> actualSalvarResult = subitemVistoriaServiceImpl.salvar(subitemVistoria);

        // Assert
        verify(subitemVistoria).getAtivo();
        verify(subitemVistoria).getDataInclusao();
        verify(subitemVistoria).getDefeitos();
        verify(subitemVistoria).getDescricao();
        verify(subitemVistoria, atLeast(1)).getNome();
        verify(subitemVistoria).setDefeitos(isA(List.class));
        verify(subitemVistoria).setNome(eq("Subitem já cadastrado no sistema."));
        verify(subitemVistoriaRepository).findByNome(eq("Nome"));
        verify(defeitosVistoriaRepository).saveAll(isA(Iterable.class));
        verify(subitemVistoriaRepository).save(isA(SubitemVistoriaEntity.class));
        assertEquals(HttpStatus.OK, actualSalvarResult.getStatusCode());
        assertTrue(actualSalvarResult.hasBody());
        assertTrue(actualSalvarResult.getHeaders().isEmpty());
    }

    /**
     * Method under test:
     * {@link SubitemVistoriaServiceImpl#editar(Long, EdicaoSubitemVistoriaDTO)}
     */
    @Test
    void testEditar() {
        // Arrange
        SubitemVistoriaEntity subitemVistoriaEntity = new SubitemVistoriaEntity();
        subitemVistoriaEntity.setAtivo(true);
        subitemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        subitemVistoriaEntity.setDescricao("Descricao");
        subitemVistoriaEntity.setId(1L);
        subitemVistoriaEntity.setNome("Nome");
        Optional<SubitemVistoriaEntity> ofResult = Optional.of(subitemVistoriaEntity);
        when(subitemVistoriaRepository.findByNome(Mockito.<String>any())).thenReturn(ofResult);
        EdicaoSubitemVistoriaDTO.EdicaoSubitemVistoriaDTOBuilder builderResult = EdicaoSubitemVistoriaDTO.builder();
        EdicaoSubitemVistoriaDTO edicao = builderResult.defeitos(new ArrayList<>())
                .descricao("Descricao")
                .nome("Nome")
                .build();

        // Act and Assert
        assertThrows(VistoriaExceptions.class, () -> subitemVistoriaServiceImpl.editar(1L, edicao));
        verify(subitemVistoriaRepository).findByNome(eq("Nome"));
    }

    /**
     * Method under test:
     * {@link SubitemVistoriaServiceImpl#editar(Long, EdicaoSubitemVistoriaDTO)}
     */
    @Test
    void testEditar2() {
        // Arrange
        when(defeitosVistoriaRepository.findAllByCodSubitem(Mockito.<SubitemVistoriaEntity>any()))
                .thenReturn(new ArrayList<>());

        SubitemVistoriaEntity subitemVistoriaEntity = new SubitemVistoriaEntity();
        subitemVistoriaEntity.setAtivo(true);
        subitemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        subitemVistoriaEntity.setDescricao("Descricao");
        subitemVistoriaEntity.setId(1L);
        subitemVistoriaEntity.setNome("Nome");
        Optional<SubitemVistoriaEntity> ofResult = Optional.of(subitemVistoriaEntity);

        SubitemVistoriaEntity subitemVistoriaEntity2 = new SubitemVistoriaEntity();
        subitemVistoriaEntity2.setAtivo(true);
        subitemVistoriaEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        subitemVistoriaEntity2.setDescricao("Descricao");
        subitemVistoriaEntity2.setId(1L);
        subitemVistoriaEntity2.setNome("Nome");
        when(subitemVistoriaRepository.save(Mockito.<SubitemVistoriaEntity>any())).thenReturn(subitemVistoriaEntity2);
        Optional<SubitemVistoriaEntity> emptyResult = Optional.empty();
        when(subitemVistoriaRepository.findByNome(Mockito.<String>any())).thenReturn(emptyResult);
        when(subitemVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);
        EdicaoSubitemVistoriaDTO.EdicaoSubitemVistoriaDTOBuilder builderResult = EdicaoSubitemVistoriaDTO.builder();
        EdicaoSubitemVistoriaDTO edicao = builderResult.defeitos(new ArrayList<>())
                .descricao("Descricao")
                .nome("Nome")
                .build();

        // Act
        ResponseEntity<?> actualEditarResult = subitemVistoriaServiceImpl.editar(1L, edicao);

        // Assert
        verify(defeitosVistoriaRepository).findAllByCodSubitem(isA(SubitemVistoriaEntity.class));
        verify(subitemVistoriaRepository).findByNome(eq("Nome"));
        verify(subitemVistoriaRepository).findById(eq(1L));
        verify(subitemVistoriaRepository).save(isA(SubitemVistoriaEntity.class));
        assertEquals(HttpStatus.OK, actualEditarResult.getStatusCode());
        assertTrue(actualEditarResult.hasBody());
        assertTrue(actualEditarResult.getHeaders().isEmpty());
    }

    /**
     * Method under test:
     * {@link SubitemVistoriaServiceImpl#editar(Long, EdicaoSubitemVistoriaDTO)}
     */
    @Test
    void testEditar3() {
        // Arrange
        when(defeitosVistoriaRepository.findAllByCodSubitem(Mockito.<SubitemVistoriaEntity>any()))
                .thenReturn(new ArrayList<>());

        SubitemVistoriaEntity subitemVistoriaEntity = new SubitemVistoriaEntity();
        subitemVistoriaEntity.setAtivo(true);
        subitemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        subitemVistoriaEntity.setDescricao("Descricao");
        subitemVistoriaEntity.setId(1L);
        subitemVistoriaEntity.setNome("Nome");
        Optional<SubitemVistoriaEntity> ofResult = Optional.of(subitemVistoriaEntity);
        when(subitemVistoriaRepository.save(Mockito.<SubitemVistoriaEntity>any()))
                .thenThrow(new VistoriaExceptions("An error occurred"));
        Optional<SubitemVistoriaEntity> emptyResult = Optional.empty();
        when(subitemVistoriaRepository.findByNome(Mockito.<String>any())).thenReturn(emptyResult);
        when(subitemVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);
        EdicaoSubitemVistoriaDTO.EdicaoSubitemVistoriaDTOBuilder builderResult = EdicaoSubitemVistoriaDTO.builder();
        EdicaoSubitemVistoriaDTO edicao = builderResult.defeitos(new ArrayList<>())
                .descricao("Descricao")
                .nome("Nome")
                .build();

        // Act and Assert
        assertThrows(VistoriaExceptions.class, () -> subitemVistoriaServiceImpl.editar(1L, edicao));
        verify(defeitosVistoriaRepository).findAllByCodSubitem(isA(SubitemVistoriaEntity.class));
        verify(subitemVistoriaRepository).findByNome(eq("Nome"));
        verify(subitemVistoriaRepository).findById(eq(1L));
        verify(subitemVistoriaRepository).save(isA(SubitemVistoriaEntity.class));
    }

    /**
     * Method under test:
     * {@link SubitemVistoriaServiceImpl#editar(Long, EdicaoSubitemVistoriaDTO)}
     */
    @Test
    void testEditar4() {
        // Arrange
        SubitemVistoriaEntity codSubitem = new SubitemVistoriaEntity();
        codSubitem.setAtivo(true);
        codSubitem.setDataInclusao(LocalDate.of(1970, 1, 1));
        codSubitem.setDescricao("Descricao");
        codSubitem.setId(1L);
        codSubitem.setNome("Nome");

        TipoDefeitoVistoriaEntity codTipoDefeito = new TipoDefeitoVistoriaEntity();
        codTipoDefeito.setAtivo(true);
        codTipoDefeito.setDataInclusao(LocalDate.of(1970, 1, 1));
        codTipoDefeito.setDescricao("Descricao");
        codTipoDefeito.setId(1L);
        codTipoDefeito.setNome("Nome");

        DefeitosVistoriaEntity defeitosVistoriaEntity = new DefeitosVistoriaEntity();
        defeitosVistoriaEntity.setAtivo(true);
        defeitosVistoriaEntity.setCodSubitem(codSubitem);
        defeitosVistoriaEntity.setCodTipoDefeito(codTipoDefeito);
        defeitosVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        defeitosVistoriaEntity.setId(1L);

        ArrayList<DefeitosVistoriaEntity> defeitosVistoriaEntityList = new ArrayList<>();
        defeitosVistoriaEntityList.add(defeitosVistoriaEntity);
        doNothing().when(defeitosVistoriaRepository).deleteAll(Mockito.<Iterable<DefeitosVistoriaEntity>>any());
        when(defeitosVistoriaRepository.findAllByCodSubitem(Mockito.<SubitemVistoriaEntity>any()))
                .thenReturn(defeitosVistoriaEntityList);

        SubitemVistoriaEntity subitemVistoriaEntity = new SubitemVistoriaEntity();
        subitemVistoriaEntity.setAtivo(true);
        subitemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        subitemVistoriaEntity.setDescricao("Descricao");
        subitemVistoriaEntity.setId(1L);
        subitemVistoriaEntity.setNome("Nome");
        Optional<SubitemVistoriaEntity> ofResult = Optional.of(subitemVistoriaEntity);

        SubitemVistoriaEntity subitemVistoriaEntity2 = new SubitemVistoriaEntity();
        subitemVistoriaEntity2.setAtivo(true);
        subitemVistoriaEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        subitemVistoriaEntity2.setDescricao("Descricao");
        subitemVistoriaEntity2.setId(1L);
        subitemVistoriaEntity2.setNome("Nome");
        when(subitemVistoriaRepository.save(Mockito.<SubitemVistoriaEntity>any())).thenReturn(subitemVistoriaEntity2);
        Optional<SubitemVistoriaEntity> emptyResult = Optional.empty();
        when(subitemVistoriaRepository.findByNome(Mockito.<String>any())).thenReturn(emptyResult);
        when(subitemVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);
        EdicaoSubitemVistoriaDTO.EdicaoSubitemVistoriaDTOBuilder builderResult = EdicaoSubitemVistoriaDTO.builder();
        EdicaoSubitemVistoriaDTO edicao = builderResult.defeitos(new ArrayList<>())
                .descricao("Descricao")
                .nome("Nome")
                .build();

        // Act
        ResponseEntity<?> actualEditarResult = subitemVistoriaServiceImpl.editar(1L, edicao);

        // Assert
        verify(defeitosVistoriaRepository).findAllByCodSubitem(isA(SubitemVistoriaEntity.class));
        verify(subitemVistoriaRepository).findByNome(eq("Nome"));
        verify(defeitosVistoriaRepository).deleteAll(isA(Iterable.class));
        verify(subitemVistoriaRepository).findById(eq(1L));
        verify(subitemVistoriaRepository).save(isA(SubitemVistoriaEntity.class));
        assertEquals(HttpStatus.OK, actualEditarResult.getStatusCode());
        assertTrue(actualEditarResult.hasBody());
        assertTrue(actualEditarResult.getHeaders().isEmpty());
    }

    /**
     * Method under test:
     * {@link SubitemVistoriaServiceImpl#editar(Long, EdicaoSubitemVistoriaDTO)}
     */
    @Test
    void testEditar5() {
        // Arrange
        SubitemVistoriaEntity codSubitem = new SubitemVistoriaEntity();
        codSubitem.setAtivo(true);
        codSubitem.setDataInclusao(LocalDate.of(1970, 1, 1));
        codSubitem.setDescricao("Descricao");
        codSubitem.setId(1L);
        codSubitem.setNome("Nome");

        TipoDefeitoVistoriaEntity codTipoDefeito = new TipoDefeitoVistoriaEntity();
        codTipoDefeito.setAtivo(true);
        codTipoDefeito.setDataInclusao(LocalDate.of(1970, 1, 1));
        codTipoDefeito.setDescricao("Descricao");
        codTipoDefeito.setId(1L);
        codTipoDefeito.setNome("Nome");

        DefeitosVistoriaEntity defeitosVistoriaEntity = new DefeitosVistoriaEntity();
        defeitosVistoriaEntity.setAtivo(true);
        defeitosVistoriaEntity.setCodSubitem(codSubitem);
        defeitosVistoriaEntity.setCodTipoDefeito(codTipoDefeito);
        defeitosVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        defeitosVistoriaEntity.setId(1L);

        ArrayList<DefeitosVistoriaEntity> defeitosVistoriaEntityList = new ArrayList<>();
        defeitosVistoriaEntityList.add(defeitosVistoriaEntity);
        doNothing().when(defeitosVistoriaRepository).deleteAll(Mockito.<Iterable<DefeitosVistoriaEntity>>any());
        when(defeitosVistoriaRepository.findAllByCodSubitem(Mockito.<SubitemVistoriaEntity>any()))
                .thenReturn(defeitosVistoriaEntityList);
        SubitemVistoriaEntity subitemVistoriaEntity = mock(SubitemVistoriaEntity.class);
        doNothing().when(subitemVistoriaEntity).setAtivo(Mockito.<Boolean>any());
        doNothing().when(subitemVistoriaEntity).setDataInclusao(Mockito.<LocalDate>any());
        doNothing().when(subitemVistoriaEntity).setDescricao(Mockito.<String>any());
        doNothing().when(subitemVistoriaEntity).setId(Mockito.<Long>any());
        doNothing().when(subitemVistoriaEntity).setNome(Mockito.<String>any());
        subitemVistoriaEntity.setAtivo(true);
        subitemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        subitemVistoriaEntity.setDescricao("Descricao");
        subitemVistoriaEntity.setId(1L);
        subitemVistoriaEntity.setNome("Nome");
        Optional<SubitemVistoriaEntity> ofResult = Optional.of(subitemVistoriaEntity);

        SubitemVistoriaEntity subitemVistoriaEntity2 = new SubitemVistoriaEntity();
        subitemVistoriaEntity2.setAtivo(true);
        subitemVistoriaEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        subitemVistoriaEntity2.setDescricao("Descricao");
        subitemVistoriaEntity2.setId(1L);
        subitemVistoriaEntity2.setNome("Nome");
        when(subitemVistoriaRepository.save(Mockito.<SubitemVistoriaEntity>any())).thenReturn(subitemVistoriaEntity2);
        Optional<SubitemVistoriaEntity> emptyResult = Optional.empty();
        when(subitemVistoriaRepository.findByNome(Mockito.<String>any())).thenReturn(emptyResult);
        when(subitemVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);
        EdicaoSubitemVistoriaDTO.EdicaoSubitemVistoriaDTOBuilder builderResult = EdicaoSubitemVistoriaDTO.builder();
        EdicaoSubitemVistoriaDTO edicao = builderResult.defeitos(new ArrayList<>())
                .descricao("Descricao")
                .nome("Nome")
                .build();

        // Act
        ResponseEntity<?> actualEditarResult = subitemVistoriaServiceImpl.editar(1L, edicao);

        // Assert
        verify(subitemVistoriaEntity).setAtivo(eq(true));
        verify(subitemVistoriaEntity).setDataInclusao(isA(LocalDate.class));
        verify(subitemVistoriaEntity, atLeast(1)).setDescricao(eq("Descricao"));
        verify(subitemVistoriaEntity).setId(eq(1L));
        verify(subitemVistoriaEntity, atLeast(1)).setNome(eq("Nome"));
        verify(defeitosVistoriaRepository).findAllByCodSubitem(isA(SubitemVistoriaEntity.class));
        verify(subitemVistoriaRepository).findByNome(eq("Nome"));
        verify(defeitosVistoriaRepository).deleteAll(isA(Iterable.class));
        verify(subitemVistoriaRepository).findById(eq(1L));
        verify(subitemVistoriaRepository).save(isA(SubitemVistoriaEntity.class));
        assertEquals(HttpStatus.OK, actualEditarResult.getStatusCode());
        assertTrue(actualEditarResult.hasBody());
        assertTrue(actualEditarResult.getHeaders().isEmpty());
    }

    /**
     * Method under test: {@link SubitemVistoriaServiceImpl#desativar(Long)}
     */
    @Test
    void testDesativar() {
        // Arrange
        SubitemVistoriaEntity subitemVistoriaEntity = new SubitemVistoriaEntity();
        subitemVistoriaEntity.setAtivo(true);
        subitemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        subitemVistoriaEntity.setDescricao("Descricao");
        subitemVistoriaEntity.setId(1L);
        subitemVistoriaEntity.setNome("Nome");
        Optional<SubitemVistoriaEntity> ofResult = Optional.of(subitemVistoriaEntity);

        SubitemVistoriaEntity subitemVistoriaEntity2 = new SubitemVistoriaEntity();
        subitemVistoriaEntity2.setAtivo(true);
        subitemVistoriaEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        subitemVistoriaEntity2.setDescricao("Descricao");
        subitemVistoriaEntity2.setId(1L);
        subitemVistoriaEntity2.setNome("Nome");
        when(subitemVistoriaRepository.save(Mockito.<SubitemVistoriaEntity>any())).thenReturn(subitemVistoriaEntity2);
        when(subitemVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);
        when(subitensVistoriaRepository.findAllByCodSubitem(Mockito.<SubitemVistoriaEntity>any()))
                .thenReturn(new ArrayList<>());

        // Act
        ResponseEntity<?> actualDesativarResult = subitemVistoriaServiceImpl.desativar(1L);

        // Assert
        verify(subitensVistoriaRepository).findAllByCodSubitem(isA(SubitemVistoriaEntity.class));
        verify(subitemVistoriaRepository).findById(eq(1L));
        verify(subitemVistoriaRepository).save(isA(SubitemVistoriaEntity.class));
        assertNull(actualDesativarResult.getBody());
        assertEquals(HttpStatus.OK, actualDesativarResult.getStatusCode());
        assertTrue(actualDesativarResult.getHeaders().isEmpty());
    }

    /**
     * Method under test: {@link SubitemVistoriaServiceImpl#desativar(Long)}
     */
    @Test
    void testDesativar2() {
        // Arrange
        SubitemVistoriaEntity subitemVistoriaEntity = new SubitemVistoriaEntity();
        subitemVistoriaEntity.setAtivo(true);
        subitemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        subitemVistoriaEntity.setDescricao("Descricao");
        subitemVistoriaEntity.setId(1L);
        subitemVistoriaEntity.setNome("Nome");
        Optional<SubitemVistoriaEntity> ofResult = Optional.of(subitemVistoriaEntity);
        when(subitemVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);
        when(subitensVistoriaRepository.findAllByCodSubitem(Mockito.<SubitemVistoriaEntity>any()))
                .thenThrow(new VistoriaExceptions("An error occurred"));

        // Act and Assert
        assertThrows(VistoriaExceptions.class, () -> subitemVistoriaServiceImpl.desativar(1L));
        verify(subitensVistoriaRepository).findAllByCodSubitem(isA(SubitemVistoriaEntity.class));
        verify(subitemVistoriaRepository).findById(eq(1L));
    }

    /**
     * Method under test: {@link SubitemVistoriaServiceImpl#desativar(Long)}
     */
    @Test
    void testDesativar3() {
        // Arrange
        SubitemVistoriaEntity subitemVistoriaEntity = mock(SubitemVistoriaEntity.class);
        doNothing().when(subitemVistoriaEntity).setAtivo(Mockito.<Boolean>any());
        doNothing().when(subitemVistoriaEntity).setDataInclusao(Mockito.<LocalDate>any());
        doNothing().when(subitemVistoriaEntity).setDescricao(Mockito.<String>any());
        doNothing().when(subitemVistoriaEntity).setId(Mockito.<Long>any());
        doNothing().when(subitemVistoriaEntity).setNome(Mockito.<String>any());
        subitemVistoriaEntity.setAtivo(true);
        subitemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        subitemVistoriaEntity.setDescricao("Descricao");
        subitemVistoriaEntity.setId(1L);
        subitemVistoriaEntity.setNome("Nome");
        Optional<SubitemVistoriaEntity> ofResult = Optional.of(subitemVistoriaEntity);

        SubitemVistoriaEntity subitemVistoriaEntity2 = new SubitemVistoriaEntity();
        subitemVistoriaEntity2.setAtivo(true);
        subitemVistoriaEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        subitemVistoriaEntity2.setDescricao("Descricao");
        subitemVistoriaEntity2.setId(1L);
        subitemVistoriaEntity2.setNome("Nome");
        when(subitemVistoriaRepository.save(Mockito.<SubitemVistoriaEntity>any())).thenReturn(subitemVistoriaEntity2);
        when(subitemVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);
        when(subitensVistoriaRepository.findAllByCodSubitem(Mockito.<SubitemVistoriaEntity>any()))
                .thenReturn(new ArrayList<>());

        // Act
        ResponseEntity<?> actualDesativarResult = subitemVistoriaServiceImpl.desativar(1L);

        // Assert
        verify(subitemVistoriaEntity, atLeast(1)).setAtivo(Mockito.<Boolean>any());
        verify(subitemVistoriaEntity).setDataInclusao(isA(LocalDate.class));
        verify(subitemVistoriaEntity).setDescricao(eq("Descricao"));
        verify(subitemVistoriaEntity).setId(eq(1L));
        verify(subitemVistoriaEntity).setNome(eq("Nome"));
        verify(subitensVistoriaRepository).findAllByCodSubitem(isA(SubitemVistoriaEntity.class));
        verify(subitemVistoriaRepository).findById(eq(1L));
        verify(subitemVistoriaRepository).save(isA(SubitemVistoriaEntity.class));
        assertNull(actualDesativarResult.getBody());
        assertEquals(HttpStatus.OK, actualDesativarResult.getStatusCode());
        assertTrue(actualDesativarResult.getHeaders().isEmpty());
    }

    /**
     * Method under test: {@link SubitemVistoriaServiceImpl#desativar(Long)}
     */
    @Test
    void testDesativar4() {
        // Arrange
        SubitemVistoriaEntity subitemVistoriaEntity = mock(SubitemVistoriaEntity.class);
        doNothing().when(subitemVistoriaEntity).setAtivo(Mockito.<Boolean>any());
        doNothing().when(subitemVistoriaEntity).setDataInclusao(Mockito.<LocalDate>any());
        doNothing().when(subitemVistoriaEntity).setDescricao(Mockito.<String>any());
        doNothing().when(subitemVistoriaEntity).setId(Mockito.<Long>any());
        doNothing().when(subitemVistoriaEntity).setNome(Mockito.<String>any());
        subitemVistoriaEntity.setAtivo(true);
        subitemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        subitemVistoriaEntity.setDescricao("Descricao");
        subitemVistoriaEntity.setId(1L);
        subitemVistoriaEntity.setNome("Nome");
        Optional<SubitemVistoriaEntity> ofResult = Optional.of(subitemVistoriaEntity);
        when(subitemVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        ItemVistoriaEntity codItem = new ItemVistoriaEntity();
        codItem.setAtivo(true);
        codItem.setDataInclusao(LocalDate.of(1970, 1, 1));
        codItem.setDescricao("Descricao");
        codItem.setId(1L);
        codItem.setNome("Nome");

        SubitemVistoriaEntity codSubitem = new SubitemVistoriaEntity();
        codSubitem.setAtivo(true);
        codSubitem.setDataInclusao(LocalDate.of(1970, 1, 1));
        codSubitem.setDescricao("Descricao");
        codSubitem.setId(1L);
        codSubitem.setNome("Nome");

        SubitensVistoriaEntity subitensVistoriaEntity = new SubitensVistoriaEntity();
        subitensVistoriaEntity.setAtivo(true);
        subitensVistoriaEntity.setCodItem(codItem);
        subitensVistoriaEntity.setCodSubitem(codSubitem);
        subitensVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        subitensVistoriaEntity.setId(1L);

        ArrayList<SubitensVistoriaEntity> subitensVistoriaEntityList = new ArrayList<>();
        subitensVistoriaEntityList.add(subitensVistoriaEntity);
        when(subitensVistoriaRepository.findAllByCodSubitem(Mockito.<SubitemVistoriaEntity>any()))
                .thenReturn(subitensVistoriaEntityList);

        // Act and Assert
        assertThrows(VistoriaExceptions.class, () -> subitemVistoriaServiceImpl.desativar(1L));
        verify(subitemVistoriaEntity).setAtivo(eq(true));
        verify(subitemVistoriaEntity).setDataInclusao(isA(LocalDate.class));
        verify(subitemVistoriaEntity).setDescricao(eq("Descricao"));
        verify(subitemVistoriaEntity).setId(eq(1L));
        verify(subitemVistoriaEntity).setNome(eq("Nome"));
        verify(subitensVistoriaRepository).findAllByCodSubitem(isA(SubitemVistoriaEntity.class));
        verify(subitemVistoriaRepository).findById(eq(1L));
    }

    /**
     * Method under test: {@link SubitemVistoriaServiceImpl#excluir(Long)}
     */
    @Test
    void testExcluir() {
        // Arrange
        SubitemVistoriaEntity subitemVistoriaEntity = new SubitemVistoriaEntity();
        subitemVistoriaEntity.setAtivo(true);
        subitemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        subitemVistoriaEntity.setDescricao("Descricao");
        subitemVistoriaEntity.setId(1L);
        subitemVistoriaEntity.setNome("Nome");
        Optional<SubitemVistoriaEntity> ofResult = Optional.of(subitemVistoriaEntity);
        doNothing().when(subitemVistoriaRepository).delete(Mockito.<SubitemVistoriaEntity>any());
        when(subitemVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);
        when(subitensVistoriaRepository.findAllByCodSubitem(Mockito.<SubitemVistoriaEntity>any()))
                .thenReturn(new ArrayList<>());

        // Act
        ResponseEntity<?> actualExcluirResult = subitemVistoriaServiceImpl.excluir(1L);

        // Assert
        verify(subitensVistoriaRepository).findAllByCodSubitem(isA(SubitemVistoriaEntity.class));
        verify(subitemVistoriaRepository).delete(isA(SubitemVistoriaEntity.class));
        verify(subitemVistoriaRepository).findById(eq(1L));
        assertNull(actualExcluirResult.getBody());
        assertEquals(HttpStatus.OK, actualExcluirResult.getStatusCode());
        assertTrue(actualExcluirResult.getHeaders().isEmpty());
    }

    /**
     * Method under test: {@link SubitemVistoriaServiceImpl#excluir(Long)}
     */
    @Test
    void testExcluir2() {
        // Arrange
        SubitemVistoriaEntity subitemVistoriaEntity = new SubitemVistoriaEntity();
        subitemVistoriaEntity.setAtivo(true);
        subitemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        subitemVistoriaEntity.setDescricao("Descricao");
        subitemVistoriaEntity.setId(1L);
        subitemVistoriaEntity.setNome("Nome");
        Optional<SubitemVistoriaEntity> ofResult = Optional.of(subitemVistoriaEntity);
        when(subitemVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);
        when(subitensVistoriaRepository.findAllByCodSubitem(Mockito.<SubitemVistoriaEntity>any()))
                .thenThrow(new VistoriaExceptions("An error occurred"));

        // Act and Assert
        assertThrows(VistoriaExceptions.class, () -> subitemVistoriaServiceImpl.excluir(1L));
        verify(subitensVistoriaRepository).findAllByCodSubitem(isA(SubitemVistoriaEntity.class));
        verify(subitemVistoriaRepository).findById(eq(1L));
    }

    /**
     * Method under test: {@link SubitemVistoriaServiceImpl#excluir(Long)}
     */
    @Test
    void testExcluir3() {
        // Arrange
        SubitemVistoriaEntity subitemVistoriaEntity = new SubitemVistoriaEntity();
        subitemVistoriaEntity.setAtivo(true);
        subitemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        subitemVistoriaEntity.setDescricao("Descricao");
        subitemVistoriaEntity.setId(1L);
        subitemVistoriaEntity.setNome("Nome");
        Optional<SubitemVistoriaEntity> ofResult = Optional.of(subitemVistoriaEntity);
        when(subitemVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        ItemVistoriaEntity codItem = new ItemVistoriaEntity();
        codItem.setAtivo(true);
        codItem.setDataInclusao(LocalDate.of(1970, 1, 1));
        codItem.setDescricao("Descricao");
        codItem.setId(1L);
        codItem.setNome("Nome");

        SubitemVistoriaEntity codSubitem = new SubitemVistoriaEntity();
        codSubitem.setAtivo(true);
        codSubitem.setDataInclusao(LocalDate.of(1970, 1, 1));
        codSubitem.setDescricao("Descricao");
        codSubitem.setId(1L);
        codSubitem.setNome("Nome");

        SubitensVistoriaEntity subitensVistoriaEntity = new SubitensVistoriaEntity();
        subitensVistoriaEntity.setAtivo(true);
        subitensVistoriaEntity.setCodItem(codItem);
        subitensVistoriaEntity.setCodSubitem(codSubitem);
        subitensVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        subitensVistoriaEntity.setId(1L);

        ArrayList<SubitensVistoriaEntity> subitensVistoriaEntityList = new ArrayList<>();
        subitensVistoriaEntityList.add(subitensVistoriaEntity);
        when(subitensVistoriaRepository.findAllByCodSubitem(Mockito.<SubitemVistoriaEntity>any()))
                .thenReturn(subitensVistoriaEntityList);

        // Act and Assert
        assertThrows(VistoriaExceptions.class, () -> subitemVistoriaServiceImpl.excluir(1L));
        verify(subitensVistoriaRepository).findAllByCodSubitem(isA(SubitemVistoriaEntity.class));
        verify(subitemVistoriaRepository).findById(eq(1L));
    }

    /**
     * Method under test: {@link SubitemVistoriaServiceImpl#ativar(Long)}
     */
    @Test
    void testAtivar() {
        // Arrange
        SubitemVistoriaEntity subitemVistoriaEntity = new SubitemVistoriaEntity();
        subitemVistoriaEntity.setAtivo(true);
        subitemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        subitemVistoriaEntity.setDescricao("Descricao");
        subitemVistoriaEntity.setId(1L);
        subitemVistoriaEntity.setNome("Nome");
        Optional<SubitemVistoriaEntity> ofResult = Optional.of(subitemVistoriaEntity);

        SubitemVistoriaEntity subitemVistoriaEntity2 = new SubitemVistoriaEntity();
        subitemVistoriaEntity2.setAtivo(true);
        subitemVistoriaEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        subitemVistoriaEntity2.setDescricao("Descricao");
        subitemVistoriaEntity2.setId(1L);
        subitemVistoriaEntity2.setNome("Nome");
        when(subitemVistoriaRepository.save(Mockito.<SubitemVistoriaEntity>any())).thenReturn(subitemVistoriaEntity2);
        when(subitemVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        // Act
        ResponseEntity<?> actualAtivarResult = subitemVistoriaServiceImpl.ativar(1L);

        // Assert
        verify(subitemVistoriaRepository).findById(eq(1L));
        verify(subitemVistoriaRepository).save(isA(SubitemVistoriaEntity.class));
        assertNull(actualAtivarResult.getBody());
        assertEquals(HttpStatus.OK, actualAtivarResult.getStatusCode());
        assertTrue(actualAtivarResult.getHeaders().isEmpty());
    }

    /**
     * Method under test: {@link SubitemVistoriaServiceImpl#ativar(Long)}
     */
    @Test
    void testAtivar2() {
        // Arrange
        SubitemVistoriaEntity subitemVistoriaEntity = new SubitemVistoriaEntity();
        subitemVistoriaEntity.setAtivo(true);
        subitemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        subitemVistoriaEntity.setDescricao("Descricao");
        subitemVistoriaEntity.setId(1L);
        subitemVistoriaEntity.setNome("Nome");
        Optional<SubitemVistoriaEntity> ofResult = Optional.of(subitemVistoriaEntity);
        when(subitemVistoriaRepository.save(Mockito.<SubitemVistoriaEntity>any()))
                .thenThrow(new VistoriaExceptions("An error occurred"));
        when(subitemVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        // Act and Assert
        assertThrows(VistoriaExceptions.class, () -> subitemVistoriaServiceImpl.ativar(1L));
        verify(subitemVistoriaRepository).findById(eq(1L));
        verify(subitemVistoriaRepository).save(isA(SubitemVistoriaEntity.class));
    }

    /**
     * Method under test: {@link SubitemVistoriaServiceImpl#ativar(Long)}
     */
    @Test
    void testAtivar3() {
        // Arrange
        SubitemVistoriaEntity subitemVistoriaEntity = mock(SubitemVistoriaEntity.class);
        doNothing().when(subitemVistoriaEntity).setAtivo(Mockito.<Boolean>any());
        doNothing().when(subitemVistoriaEntity).setDataInclusao(Mockito.<LocalDate>any());
        doNothing().when(subitemVistoriaEntity).setDescricao(Mockito.<String>any());
        doNothing().when(subitemVistoriaEntity).setId(Mockito.<Long>any());
        doNothing().when(subitemVistoriaEntity).setNome(Mockito.<String>any());
        subitemVistoriaEntity.setAtivo(true);
        subitemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        subitemVistoriaEntity.setDescricao("Descricao");
        subitemVistoriaEntity.setId(1L);
        subitemVistoriaEntity.setNome("Nome");
        Optional<SubitemVistoriaEntity> ofResult = Optional.of(subitemVistoriaEntity);

        SubitemVistoriaEntity subitemVistoriaEntity2 = new SubitemVistoriaEntity();
        subitemVistoriaEntity2.setAtivo(true);
        subitemVistoriaEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        subitemVistoriaEntity2.setDescricao("Descricao");
        subitemVistoriaEntity2.setId(1L);
        subitemVistoriaEntity2.setNome("Nome");
        when(subitemVistoriaRepository.save(Mockito.<SubitemVistoriaEntity>any())).thenReturn(subitemVistoriaEntity2);
        when(subitemVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        // Act
        ResponseEntity<?> actualAtivarResult = subitemVistoriaServiceImpl.ativar(1L);

        // Assert
        verify(subitemVistoriaEntity, atLeast(1)).setAtivo(eq(true));
        verify(subitemVistoriaEntity).setDataInclusao(isA(LocalDate.class));
        verify(subitemVistoriaEntity).setDescricao(eq("Descricao"));
        verify(subitemVistoriaEntity).setId(eq(1L));
        verify(subitemVistoriaEntity).setNome(eq("Nome"));
        verify(subitemVistoriaRepository).findById(eq(1L));
        verify(subitemVistoriaRepository).save(isA(SubitemVistoriaEntity.class));
        assertNull(actualAtivarResult.getBody());
        assertEquals(HttpStatus.OK, actualAtivarResult.getStatusCode());
        assertTrue(actualAtivarResult.getHeaders().isEmpty());
    }

    /**
     * Method under test:
     * {@link SubitemVistoriaServiceImpl#findAllTipoDefeitoVistoriaById(String)}
     */
    @Test
    void testFindAllTipoDefeitoVistoriaById() {
        // Arrange
        ArrayList<DefeitosVistoriaEntity> defeitosVistoriaEntityList = new ArrayList<>();
        when(defeitosVistoriaRepository.findAllByCodSubitem(Mockito.<SubitemVistoriaEntity>any()))
                .thenReturn(defeitosVistoriaEntityList);

        SubitemVistoriaEntity subitemVistoriaEntity = new SubitemVistoriaEntity();
        subitemVistoriaEntity.setAtivo(true);
        subitemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        subitemVistoriaEntity.setDescricao("Descricao");
        subitemVistoriaEntity.setId(1L);
        subitemVistoriaEntity.setNome("Nome");
        Optional<SubitemVistoriaEntity> ofResult = Optional.of(subitemVistoriaEntity);
        when(subitemVistoriaRepository.findByNome(Mockito.<String>any())).thenReturn(ofResult);

        // Act
        ResponseEntity<List<TipoDefeitoVistoriaEntity>> actualFindAllTipoDefeitoVistoriaByIdResult = subitemVistoriaServiceImpl
                .findAllTipoDefeitoVistoriaById("Nome");

        // Assert
        verify(defeitosVistoriaRepository).findAllByCodSubitem(isA(SubitemVistoriaEntity.class));
        verify(subitemVistoriaRepository).findByNome(eq("Nome"));
        assertEquals(HttpStatus.OK, actualFindAllTipoDefeitoVistoriaByIdResult.getStatusCode());
        assertTrue(actualFindAllTipoDefeitoVistoriaByIdResult.getHeaders().isEmpty());
        assertEquals(defeitosVistoriaEntityList, actualFindAllTipoDefeitoVistoriaByIdResult.getBody());
    }

    /**
     * Method under test:
     * {@link SubitemVistoriaServiceImpl#findAllTipoDefeitoVistoriaById(String)}
     */
    @Test
    void testFindAllTipoDefeitoVistoriaById2() {
        // Arrange
        when(defeitosVistoriaRepository.findAllByCodSubitem(Mockito.<SubitemVistoriaEntity>any()))
                .thenThrow(new VistoriaExceptions("An error occurred"));

        SubitemVistoriaEntity subitemVistoriaEntity = new SubitemVistoriaEntity();
        subitemVistoriaEntity.setAtivo(true);
        subitemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        subitemVistoriaEntity.setDescricao("Descricao");
        subitemVistoriaEntity.setId(1L);
        subitemVistoriaEntity.setNome("Nome");
        Optional<SubitemVistoriaEntity> ofResult = Optional.of(subitemVistoriaEntity);
        when(subitemVistoriaRepository.findByNome(Mockito.<String>any())).thenReturn(ofResult);

        // Act and Assert
        assertThrows(VistoriaExceptions.class, () -> subitemVistoriaServiceImpl.findAllTipoDefeitoVistoriaById("Nome"));
        verify(defeitosVistoriaRepository).findAllByCodSubitem(isA(SubitemVistoriaEntity.class));
        verify(subitemVistoriaRepository).findByNome(eq("Nome"));
    }

    /**
     * Method under test:
     * {@link SubitemVistoriaServiceImpl#findAllTipoDefeitoVistoriaById(String)}
     */
    @Test
    void testFindAllTipoDefeitoVistoriaById3() {
        // Arrange
        SubitemVistoriaEntity codSubitem = new SubitemVistoriaEntity();
        codSubitem.setAtivo(true);
        codSubitem.setDataInclusao(LocalDate.of(1970, 1, 1));
        codSubitem.setDescricao("Descricao");
        codSubitem.setId(1L);
        codSubitem.setNome("Nome");

        TipoDefeitoVistoriaEntity codTipoDefeito = new TipoDefeitoVistoriaEntity();
        codTipoDefeito.setAtivo(true);
        codTipoDefeito.setDataInclusao(LocalDate.of(1970, 1, 1));
        codTipoDefeito.setDescricao("Descricao");
        codTipoDefeito.setId(1L);
        codTipoDefeito.setNome("Nome");

        DefeitosVistoriaEntity defeitosVistoriaEntity = new DefeitosVistoriaEntity();
        defeitosVistoriaEntity.setAtivo(true);
        defeitosVistoriaEntity.setCodSubitem(codSubitem);
        defeitosVistoriaEntity.setCodTipoDefeito(codTipoDefeito);
        defeitosVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        defeitosVistoriaEntity.setId(1L);

        ArrayList<DefeitosVistoriaEntity> defeitosVistoriaEntityList = new ArrayList<>();
        defeitosVistoriaEntityList.add(defeitosVistoriaEntity);
        when(defeitosVistoriaRepository.findAllByCodSubitem(Mockito.<SubitemVistoriaEntity>any()))
                .thenReturn(defeitosVistoriaEntityList);

        SubitemVistoriaEntity subitemVistoriaEntity = new SubitemVistoriaEntity();
        subitemVistoriaEntity.setAtivo(true);
        subitemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        subitemVistoriaEntity.setDescricao("Descricao");
        subitemVistoriaEntity.setId(1L);
        subitemVistoriaEntity.setNome("Nome");
        Optional<SubitemVistoriaEntity> ofResult = Optional.of(subitemVistoriaEntity);
        when(subitemVistoriaRepository.findByNome(Mockito.<String>any())).thenReturn(ofResult);

        TipoDefeitoVistoriaEntity tipoDefeitoVistoriaEntity = new TipoDefeitoVistoriaEntity();
        tipoDefeitoVistoriaEntity.setAtivo(true);
        tipoDefeitoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoDefeitoVistoriaEntity.setDescricao("Descricao");
        tipoDefeitoVistoriaEntity.setId(1L);
        tipoDefeitoVistoriaEntity.setNome("Nome");
        Optional<TipoDefeitoVistoriaEntity> ofResult2 = Optional.of(tipoDefeitoVistoriaEntity);
        when(tipoDefeitoVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult2);

        // Act
        ResponseEntity<List<TipoDefeitoVistoriaEntity>> actualFindAllTipoDefeitoVistoriaByIdResult = subitemVistoriaServiceImpl
                .findAllTipoDefeitoVistoriaById("Nome");

        // Assert
        verify(defeitosVistoriaRepository).findAllByCodSubitem(isA(SubitemVistoriaEntity.class));
        verify(subitemVistoriaRepository).findByNome(eq("Nome"));
        verify(tipoDefeitoVistoriaRepository).findById(eq(1L));
        assertEquals(1, actualFindAllTipoDefeitoVistoriaByIdResult.getBody().size());
        assertEquals(HttpStatus.OK, actualFindAllTipoDefeitoVistoriaByIdResult.getStatusCode());
        assertTrue(actualFindAllTipoDefeitoVistoriaByIdResult.hasBody());
        assertTrue(actualFindAllTipoDefeitoVistoriaByIdResult.getHeaders().isEmpty());
    }

    /**
     * Method under test:
     * {@link SubitemVistoriaServiceImpl#findAllTipoDefeitoVistoriaById(String)}
     */
    @Test
    void testFindAllTipoDefeitoVistoriaById4() {
        // Arrange
        SubitemVistoriaEntity codSubitem = new SubitemVistoriaEntity();
        codSubitem.setAtivo(true);
        codSubitem.setDataInclusao(LocalDate.of(1970, 1, 1));
        codSubitem.setDescricao("Descricao");
        codSubitem.setId(1L);
        codSubitem.setNome("Nome");

        TipoDefeitoVistoriaEntity codTipoDefeito = new TipoDefeitoVistoriaEntity();
        codTipoDefeito.setAtivo(true);
        codTipoDefeito.setDataInclusao(LocalDate.of(1970, 1, 1));
        codTipoDefeito.setDescricao("Descricao");
        codTipoDefeito.setId(1L);
        codTipoDefeito.setNome("Nome");

        TipoDefeitoVistoriaEntity tipoDefeitoVistoriaEntity = new TipoDefeitoVistoriaEntity();
        tipoDefeitoVistoriaEntity.setAtivo(true);
        tipoDefeitoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoDefeitoVistoriaEntity.setDescricao("Descricao");
        tipoDefeitoVistoriaEntity.setId(1L);
        tipoDefeitoVistoriaEntity.setNome("Nome");
        DefeitosVistoriaEntity defeitosVistoriaEntity = mock(DefeitosVistoriaEntity.class);
        when(defeitosVistoriaEntity.getCodTipoDefeito()).thenReturn(tipoDefeitoVistoriaEntity);
        doNothing().when(defeitosVistoriaEntity).setAtivo(Mockito.<Boolean>any());
        doNothing().when(defeitosVistoriaEntity).setCodSubitem(Mockito.<SubitemVistoriaEntity>any());
        doNothing().when(defeitosVistoriaEntity).setCodTipoDefeito(Mockito.<TipoDefeitoVistoriaEntity>any());
        doNothing().when(defeitosVistoriaEntity).setDataInclusao(Mockito.<LocalDate>any());
        doNothing().when(defeitosVistoriaEntity).setId(Mockito.<Long>any());
        defeitosVistoriaEntity.setAtivo(true);
        defeitosVistoriaEntity.setCodSubitem(codSubitem);
        defeitosVistoriaEntity.setCodTipoDefeito(codTipoDefeito);
        defeitosVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        defeitosVistoriaEntity.setId(1L);

        ArrayList<DefeitosVistoriaEntity> defeitosVistoriaEntityList = new ArrayList<>();
        defeitosVistoriaEntityList.add(defeitosVistoriaEntity);
        when(defeitosVistoriaRepository.findAllByCodSubitem(Mockito.<SubitemVistoriaEntity>any()))
                .thenReturn(defeitosVistoriaEntityList);

        SubitemVistoriaEntity subitemVistoriaEntity = new SubitemVistoriaEntity();
        subitemVistoriaEntity.setAtivo(true);
        subitemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        subitemVistoriaEntity.setDescricao("Descricao");
        subitemVistoriaEntity.setId(1L);
        subitemVistoriaEntity.setNome("Nome");
        Optional<SubitemVistoriaEntity> ofResult = Optional.of(subitemVistoriaEntity);
        when(subitemVistoriaRepository.findByNome(Mockito.<String>any())).thenReturn(ofResult);

        TipoDefeitoVistoriaEntity tipoDefeitoVistoriaEntity2 = new TipoDefeitoVistoriaEntity();
        tipoDefeitoVistoriaEntity2.setAtivo(true);
        tipoDefeitoVistoriaEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoDefeitoVistoriaEntity2.setDescricao("Descricao");
        tipoDefeitoVistoriaEntity2.setId(1L);
        tipoDefeitoVistoriaEntity2.setNome("Nome");
        Optional<TipoDefeitoVistoriaEntity> ofResult2 = Optional.of(tipoDefeitoVistoriaEntity2);
        when(tipoDefeitoVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult2);

        // Act
        ResponseEntity<List<TipoDefeitoVistoriaEntity>> actualFindAllTipoDefeitoVistoriaByIdResult = subitemVistoriaServiceImpl
                .findAllTipoDefeitoVistoriaById("Nome");

        // Assert
        verify(defeitosVistoriaEntity).getCodTipoDefeito();
        verify(defeitosVistoriaEntity).setAtivo(eq(true));
        verify(defeitosVistoriaEntity).setCodSubitem(isA(SubitemVistoriaEntity.class));
        verify(defeitosVistoriaEntity).setCodTipoDefeito(isA(TipoDefeitoVistoriaEntity.class));
        verify(defeitosVistoriaEntity).setDataInclusao(isA(LocalDate.class));
        verify(defeitosVistoriaEntity).setId(eq(1L));
        verify(defeitosVistoriaRepository).findAllByCodSubitem(isA(SubitemVistoriaEntity.class));
        verify(subitemVistoriaRepository).findByNome(eq("Nome"));
        verify(tipoDefeitoVistoriaRepository).findById(eq(1L));
        assertEquals(1, actualFindAllTipoDefeitoVistoriaByIdResult.getBody().size());
        assertEquals(HttpStatus.OK, actualFindAllTipoDefeitoVistoriaByIdResult.getStatusCode());
        assertTrue(actualFindAllTipoDefeitoVistoriaByIdResult.hasBody());
        assertTrue(actualFindAllTipoDefeitoVistoriaByIdResult.getHeaders().isEmpty());
    }

    /**
     * Method under test:
     * {@link SubitemVistoriaServiceImpl#findAllTipoDefeitoVistoria()}
     */
    @Test
    void testFindAllTipoDefeitoVistoria() {
        // Arrange
        when(tipoDefeitoVistoriaRepository.findAll(Mockito.<Sort>any())).thenReturn(new ArrayList<>());

        // Act
        ResponseEntity<List<TipoDefeitoVistoriaEntity>> actualFindAllTipoDefeitoVistoriaResult = subitemVistoriaServiceImpl
                .findAllTipoDefeitoVistoria();

        // Assert
        verify(tipoDefeitoVistoriaRepository).findAll(isA(Sort.class));
        assertEquals(HttpStatus.OK, actualFindAllTipoDefeitoVistoriaResult.getStatusCode());
        assertTrue(actualFindAllTipoDefeitoVistoriaResult.getBody().isEmpty());
        assertTrue(actualFindAllTipoDefeitoVistoriaResult.hasBody());
        assertTrue(actualFindAllTipoDefeitoVistoriaResult.getHeaders().isEmpty());
    }

    /**
     * Method under test:
     * {@link SubitemVistoriaServiceImpl#findAllTipoDefeitoVistoria()}
     */
    @Test
    void testFindAllTipoDefeitoVistoria2() {
        // Arrange
        TipoDefeitoVistoriaEntity tipoDefeitoVistoriaEntity = new TipoDefeitoVistoriaEntity();
        tipoDefeitoVistoriaEntity.setAtivo(true);
        tipoDefeitoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoDefeitoVistoriaEntity.setDescricao("nome");
        tipoDefeitoVistoriaEntity.setId(1L);
        tipoDefeitoVistoriaEntity.setNome("nome");

        ArrayList<TipoDefeitoVistoriaEntity> tipoDefeitoVistoriaEntityList = new ArrayList<>();
        tipoDefeitoVistoriaEntityList.add(tipoDefeitoVistoriaEntity);
        when(tipoDefeitoVistoriaRepository.findAll(Mockito.<Sort>any())).thenReturn(tipoDefeitoVistoriaEntityList);

        // Act
        ResponseEntity<List<TipoDefeitoVistoriaEntity>> actualFindAllTipoDefeitoVistoriaResult = subitemVistoriaServiceImpl
                .findAllTipoDefeitoVistoria();

        // Assert
        verify(tipoDefeitoVistoriaRepository).findAll(isA(Sort.class));
        assertEquals(1, actualFindAllTipoDefeitoVistoriaResult.getBody().size());
        assertEquals(HttpStatus.OK, actualFindAllTipoDefeitoVistoriaResult.getStatusCode());
        assertTrue(actualFindAllTipoDefeitoVistoriaResult.hasBody());
        assertTrue(actualFindAllTipoDefeitoVistoriaResult.getHeaders().isEmpty());
    }

    /**
     * Method under test:
     * {@link SubitemVistoriaServiceImpl#findAllTipoDefeitoVistoria()}
     */
    @Test
    void testFindAllTipoDefeitoVistoria3() {
        // Arrange
        TipoDefeitoVistoriaEntity tipoDefeitoVistoriaEntity = new TipoDefeitoVistoriaEntity();
        tipoDefeitoVistoriaEntity.setAtivo(true);
        tipoDefeitoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoDefeitoVistoriaEntity.setDescricao("nome");
        tipoDefeitoVistoriaEntity.setId(1L);
        tipoDefeitoVistoriaEntity.setNome("nome");

        TipoDefeitoVistoriaEntity tipoDefeitoVistoriaEntity2 = new TipoDefeitoVistoriaEntity();
        tipoDefeitoVistoriaEntity2.setAtivo(false);
        tipoDefeitoVistoriaEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoDefeitoVistoriaEntity2.setDescricao("Descricao");
        tipoDefeitoVistoriaEntity2.setId(2L);
        tipoDefeitoVistoriaEntity2.setNome("Nome");

        ArrayList<TipoDefeitoVistoriaEntity> tipoDefeitoVistoriaEntityList = new ArrayList<>();
        tipoDefeitoVistoriaEntityList.add(tipoDefeitoVistoriaEntity2);
        tipoDefeitoVistoriaEntityList.add(tipoDefeitoVistoriaEntity);
        when(tipoDefeitoVistoriaRepository.findAll(Mockito.<Sort>any())).thenReturn(tipoDefeitoVistoriaEntityList);

        // Act
        ResponseEntity<List<TipoDefeitoVistoriaEntity>> actualFindAllTipoDefeitoVistoriaResult = subitemVistoriaServiceImpl
                .findAllTipoDefeitoVistoria();

        // Assert
        verify(tipoDefeitoVistoriaRepository).findAll(isA(Sort.class));
        assertEquals(1, actualFindAllTipoDefeitoVistoriaResult.getBody().size());
        assertEquals(HttpStatus.OK, actualFindAllTipoDefeitoVistoriaResult.getStatusCode());
        assertTrue(actualFindAllTipoDefeitoVistoriaResult.hasBody());
        assertTrue(actualFindAllTipoDefeitoVistoriaResult.getHeaders().isEmpty());
    }

    /**
     * Method under test:
     * {@link SubitemVistoriaServiceImpl#findAllTipoDefeitoVistoria()}
     */
    @Test
    void testFindAllTipoDefeitoVistoria4() {
        // Arrange
        when(tipoDefeitoVistoriaRepository.findAll(Mockito.<Sort>any()))
                .thenThrow(new VistoriaExceptions("An error occurred"));

        // Act and Assert
        assertThrows(VistoriaExceptions.class, () -> subitemVistoriaServiceImpl.findAllTipoDefeitoVistoria());
        verify(tipoDefeitoVistoriaRepository).findAll(isA(Sort.class));
    }

    /**
     * Method under test:
     * {@link SubitemVistoriaServiceImpl#findAllDefeitosVistoria()}
     */
    @Test
    void testFindAllDefeitosVistoria() {
        // Arrange
        when(defeitosVistoriaRepository.findAll()).thenReturn(new ArrayList<>());

        // Act
        ResponseEntity<List<DefeitosVistoriaEntity>> actualFindAllDefeitosVistoriaResult = subitemVistoriaServiceImpl
                .findAllDefeitosVistoria();

        // Assert
        verify(defeitosVistoriaRepository).findAll();
        assertEquals(HttpStatus.OK, actualFindAllDefeitosVistoriaResult.getStatusCode());
        assertTrue(actualFindAllDefeitosVistoriaResult.hasBody());
        assertTrue(actualFindAllDefeitosVistoriaResult.getHeaders().isEmpty());
    }

    /**
     * Method under test:
     * {@link SubitemVistoriaServiceImpl#findAllDefeitosVistoria()}
     */
    @Test
    void testFindAllDefeitosVistoria2() {
        // Arrange
        when(defeitosVistoriaRepository.findAll()).thenThrow(new VistoriaExceptions("An error occurred"));

        // Act and Assert
        assertThrows(VistoriaExceptions.class, () -> subitemVistoriaServiceImpl.findAllDefeitosVistoria());
        verify(defeitosVistoriaRepository).findAll();
    }

    /**
     * Method under test:
     * {@link SubitemVistoriaServiceImpl#desvincularTipoDefeito(Long, Long)}
     */
    @Test
    void testDesvincularTipoDefeito() {
        // Arrange, Act and Assert
        assertNull(subitemVistoriaServiceImpl.desvincularTipoDefeito(1L, 1L));
    }

    /**
     * Method under test:
     * {@link SubitemVistoriaServiceImpl#desvincularTodosTipoDefeito(Long)}
     */
    @Test
    void testDesvincularTodosTipoDefeito() {
        // Arrange
        when(defeitosVistoriaRepository.findAllByCodSubitem(Mockito.<SubitemVistoriaEntity>any()))
                .thenReturn(new ArrayList<>());
        doNothing().when(defeitosVistoriaRepository).deleteAll(Mockito.<Iterable<DefeitosVistoriaEntity>>any());

        SubitemVistoriaEntity subitemVistoriaEntity = new SubitemVistoriaEntity();
        subitemVistoriaEntity.setAtivo(true);
        subitemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        subitemVistoriaEntity.setDescricao("Descricao");
        subitemVistoriaEntity.setId(1L);
        subitemVistoriaEntity.setNome("Nome");
        Optional<SubitemVistoriaEntity> ofResult = Optional.of(subitemVistoriaEntity);
        when(subitemVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        // Act
        ResponseEntity<?> actualDesvincularTodosTipoDefeitoResult = subitemVistoriaServiceImpl
                .desvincularTodosTipoDefeito(1L);

        // Assert
        verify(defeitosVistoriaRepository).findAllByCodSubitem(isA(SubitemVistoriaEntity.class));
        verify(defeitosVistoriaRepository).deleteAll(isA(Iterable.class));
        verify(subitemVistoriaRepository).findById(eq(1L));
        assertNull(actualDesvincularTodosTipoDefeitoResult);
    }

    /**
     * Method under test:
     * {@link SubitemVistoriaServiceImpl#desvincularTodosTipoDefeito(Long)}
     */
    @Test
    void testDesvincularTodosTipoDefeito2() {
        // Arrange
        when(defeitosVistoriaRepository.findAllByCodSubitem(Mockito.<SubitemVistoriaEntity>any()))
                .thenThrow(new IllegalArgumentException("foo"));

        SubitemVistoriaEntity subitemVistoriaEntity = new SubitemVistoriaEntity();
        subitemVistoriaEntity.setAtivo(true);
        subitemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        subitemVistoriaEntity.setDescricao("Descricao");
        subitemVistoriaEntity.setId(1L);
        subitemVistoriaEntity.setNome("Nome");
        Optional<SubitemVistoriaEntity> ofResult = Optional.of(subitemVistoriaEntity);
        when(subitemVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        // Act and Assert
        assertThrows(IllegalArgumentException.class, () -> subitemVistoriaServiceImpl.desvincularTodosTipoDefeito(1L));
        verify(defeitosVistoriaRepository).findAllByCodSubitem(isA(SubitemVistoriaEntity.class));
        verify(subitemVistoriaRepository).findById(eq(1L));
    }
}
