//package br.gov.df.pm.sgv.controller;
//
//import br.gov.df.pm.sgv.security.UserProvider;
//import com.fasterxml.jackson.databind.JsonNode;
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
//import org.springframework.boot.test.mock.mockito.MockBean;
//import org.springframework.boot.test.mock.mockito.SpyBean;
//import org.springframework.context.annotation.ComponentScan;
//import org.springframework.http.RequestEntity;
//import org.springframework.http.ResponseEntity;
//import org.springframework.mock.web.MockHttpServletRequest;
//import org.springframework.stereotype.Component;
//import org.springframework.stereotype.Service;
//import org.springframework.test.context.junit.jupiter.SpringExtension;
//import org.springframework.web.client.RestTemplate;
//
//import java.util.Optional;
//
//import static br.gov.df.pm.sgv.util.TestUtils.fromJson;
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.junit.jupiter.api.Assertions.assertNotNull;
//import static org.mockito.ArgumentMatchers.any;
//import static org.mockito.Mockito.when;
//
//@ExtendWith(SpringExtension.class)
//@WebMvcTest(controllers = RootController.class, includeFilters = { @ComponentScan.Filter(Component.class), @ComponentScan.Filter(Service.class) })
//class RootControllerTest {
//
//    @SpyBean
//    ResponseEntity responseEntity;
//    @MockBean RestTemplate restTemplate;
//
//    @Autowired
//    RootController controller;
//
//    void contextLoad() {
//        var request = new MockHttpServletRequest();
//        RequestEntity<?> req = any();
//        var response = ResponseEntity.of(Optional.ofNullable(fromJson(JsonNode.class, "{}")));
//        when(restTemplate.exchange(req, JsonNode.class)).thenReturn(response);
//    }
//
//    @Test
//    void root() {
//        var version = "1.0.0";
//        var response = controller.root(version);
//        assertNotNull(response);
//        assertNotNull(response.getBody());
//        assertEquals(response.getBody().getBuildVersion(), version);
//    }
//}