package br.gov.df.pm.sgv.domain;

import br.gov.df.pm.sgv.domain.enums.VistoriaViaturaStatusEnum;

import java.time.LocalDate;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import br.gov.df.pm.sgv.domain.sgpol.Policial;
import br.gov.df.pm.sgv.domain.sgpol.UnidadePolicialMilitar;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ChecklistVistoriaEntityDiffblueTest {
    /**
     * Methods under test:
     * <ul>
     *   <li>{@link ChecklistVistoriaEntity#ChecklistVistoriaEntity()}
     *   <li>{@link ChecklistVistoriaEntity#setChecklistItens(List)}
     *   <li>{@link ChecklistVistoriaEntity#setDataCriacao(Date)}
     *   <li>{@link ChecklistVistoriaEntity#setId(Long)}
     *   <li>{@link ChecklistVistoriaEntity#setItemVistoria(ItemVistoriaEntity)}
     *   <li>{@link ChecklistVistoriaEntity#setObservacao(String)}
     *   <li>{@link ChecklistVistoriaEntity#setVistoria(VistoriaViaturaEntity)}
     *   <li>{@link ChecklistVistoriaEntity#getChecklistItens()}
     *   <li>{@link ChecklistVistoriaEntity#getDataCriacao()}
     *   <li>{@link ChecklistVistoriaEntity#getId()}
     *   <li>{@link ChecklistVistoriaEntity#getItemVistoria()}
     *   <li>{@link ChecklistVistoriaEntity#getObservacao()}
     *   <li>{@link ChecklistVistoriaEntity#getVistoria()}
     * </ul>
     */
    @Test
    void testGettersAndSetters() {
        // Arrange and Act
        ChecklistVistoriaEntity actualChecklistVistoriaEntity = new ChecklistVistoriaEntity();
        ArrayList<ChecklistItemVistoriaEntity> checklistItens = new ArrayList<>();
        actualChecklistVistoriaEntity.setChecklistItens(checklistItens);
        Date dataCriacao = Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant());
        actualChecklistVistoriaEntity.setDataCriacao(dataCriacao);
        actualChecklistVistoriaEntity.setId(1L);
        ItemVistoriaEntity itemVistoria = new ItemVistoriaEntity();
        itemVistoria.setAtivo(true);
        itemVistoria.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoria.setDescricao("Descricao");
        itemVistoria.setId(1L);
        itemVistoria.setNome("Nome");
        actualChecklistVistoriaEntity.setItemVistoria(itemVistoria);
        actualChecklistVistoriaEntity.setObservacao("Observacao");
        TipoVistoriaEntity referenciaFinal = new TipoVistoriaEntity();
        referenciaFinal.setAtivo(true);
        referenciaFinal.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaFinal.setDescricao("Descricao");
        referenciaFinal.setId(1L);
        referenciaFinal.setNome("Nome");
        referenciaFinal.setStatusAnterior("Status Anterior");
        referenciaFinal.setStatusPosterior("Status Posterior");
        TipoVistoriaEntity referenciaInicial = new TipoVistoriaEntity();
        referenciaInicial.setAtivo(true);
        referenciaInicial.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaInicial.setDescricao("Descricao");
        referenciaInicial.setId(1L);
        referenciaInicial.setNome("Nome");
        referenciaInicial.setStatusAnterior("Status Anterior");
        referenciaInicial.setStatusPosterior("Status Posterior");
        DiferencaOdometroEntity diferencaOdometro = new DiferencaOdometroEntity();
        diferencaOdometro.setDataInclusao(LocalDate.of(1970, 1, 1));
        diferencaOdometro.setDataModificacao(LocalDate.of(1970, 1, 1));
        diferencaOdometro.setDiferencaOdometro(10.0d);
        diferencaOdometro.setId(1L);
        diferencaOdometro.setReferenciaFinal(referenciaFinal);
        diferencaOdometro.setReferenciaInicial(referenciaInicial);
        TipoVistoriaEntity tipoVistoria = new TipoVistoriaEntity();
        tipoVistoria.setAtivo(true);
        tipoVistoria.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoria.setDescricao("Descricao");
        tipoVistoria.setId(1L);
        tipoVistoria.setNome("Nome");
        tipoVistoria.setStatusAnterior("Status Anterior");
        tipoVistoria.setStatusPosterior("Status Posterior");
        TipoEmpregoViaturaEntity tipoEmpregoViatura = new TipoEmpregoViaturaEntity();
        tipoEmpregoViatura.setAtivo(1);
        tipoEmpregoViatura.setId(1);
        tipoEmpregoViatura.setNome("Nome");
        ViaturaEntity viatura = new ViaturaEntity();
        viatura.setAtivo(true);
        viatura.setDataAtualizacao(LocalDate.of(1970, 1, 1));
        viatura.setDataInclusao(LocalDate.of(1970, 1, 1));
        viatura.setId(1L);
        viatura.setListaUpm(new ArrayList<>());
        viatura.setMarcaModelo("Marca Modelo");
        viatura.setNrSei("Nr Sei");
        viatura.setPlaca("Placa");
        viatura.setPrefixo("Prefixo");
        viatura.setRenavam("Renavam");
        viatura.setStatus("Status");
        viatura.setTipoEmpregoViatura(tipoEmpregoViatura);
        viatura.setTombamento("alice.liddell@example.org");
        VistoriaViaturaEntity vistoria = new VistoriaViaturaEntity();
        vistoria.setCheckLists(new ArrayList<>());
        vistoria.setDataVistoria(LocalDate.of(1970, 1, 1).atStartOfDay());
        vistoria.setDiferencaOdometro(diferencaOdometro);
        vistoria.setDiferencaVistoria(true);
        vistoria.setId(1L);
        vistoria.setIdPolicial(1);
        vistoria.setIdUpm(1);
        vistoria.setOdometroFinal(10.0f);
        vistoria.setOdometroInicial(10.0f);
        vistoria.setStatus(VistoriaViaturaStatusEnum.DISPONIVEL);
        vistoria.setTipoVistoria(tipoVistoria);
        vistoria.setViatura(viatura);
        vistoria.setVistoriaArquivoList(new ArrayList<>());
        vistoria.setVistoriaViaturaHistorico(new ArrayList<>());
        actualChecklistVistoriaEntity.setVistoria(vistoria);
        List<ChecklistItemVistoriaEntity> actualChecklistItens = actualChecklistVistoriaEntity.getChecklistItens();
        Date actualDataCriacao = actualChecklistVistoriaEntity.getDataCriacao();
        Long actualId = actualChecklistVistoriaEntity.getId();
        ItemVistoriaEntity actualItemVistoria = actualChecklistVistoriaEntity.getItemVistoria();
        String actualObservacao = actualChecklistVistoriaEntity.getObservacao();
        VistoriaViaturaEntity actualVistoria = actualChecklistVistoriaEntity.getVistoria();

        // Assert that nothing has changed
        assertEquals("Observacao", actualObservacao);
        assertEquals(1L, actualId.longValue());
        assertSame(itemVistoria, actualItemVistoria);
        assertSame(vistoria, actualVistoria);
        assertSame(checklistItens, actualChecklistItens);
        assertSame(dataCriacao, actualDataCriacao);
    }

    /**
     * Methods under test:
     * <ul>
     *   <li>
     * {@link ChecklistVistoriaEntity#ChecklistVistoriaEntity(Long, String, Date, VistoriaViaturaEntity, ItemVistoriaEntity, List)}
     *   <li>{@link ChecklistVistoriaEntity#setChecklistItens(List)}
     *   <li>{@link ChecklistVistoriaEntity#setDataCriacao(Date)}
     *   <li>{@link ChecklistVistoriaEntity#setId(Long)}
     *   <li>{@link ChecklistVistoriaEntity#setItemVistoria(ItemVistoriaEntity)}
     *   <li>{@link ChecklistVistoriaEntity#setObservacao(String)}
     *   <li>{@link ChecklistVistoriaEntity#setVistoria(VistoriaViaturaEntity)}
     *   <li>{@link ChecklistVistoriaEntity#getChecklistItens()}
     *   <li>{@link ChecklistVistoriaEntity#getDataCriacao()}
     *   <li>{@link ChecklistVistoriaEntity#getId()}
     *   <li>{@link ChecklistVistoriaEntity#getItemVistoria()}
     *   <li>{@link ChecklistVistoriaEntity#getObservacao()}
     *   <li>{@link ChecklistVistoriaEntity#getVistoria()}
     * </ul>
     */
    @Test
    void testGettersAndSetters2() {
        // Arrange
        Date dataCriacao = Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant());

        TipoVistoriaEntity referenciaFinal = new TipoVistoriaEntity();
        referenciaFinal.setAtivo(true);
        referenciaFinal.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaFinal.setDescricao("Descricao");
        referenciaFinal.setId(1L);
        referenciaFinal.setNome("Nome");
        referenciaFinal.setStatusAnterior("Status Anterior");
        referenciaFinal.setStatusPosterior("Status Posterior");

        TipoVistoriaEntity referenciaInicial = new TipoVistoriaEntity();
        referenciaInicial.setAtivo(true);
        referenciaInicial.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaInicial.setDescricao("Descricao");
        referenciaInicial.setId(1L);
        referenciaInicial.setNome("Nome");
        referenciaInicial.setStatusAnterior("Status Anterior");
        referenciaInicial.setStatusPosterior("Status Posterior");

        DiferencaOdometroEntity diferencaOdometro = new DiferencaOdometroEntity();
        diferencaOdometro.setDataInclusao(LocalDate.of(1970, 1, 1));
        diferencaOdometro.setDataModificacao(LocalDate.of(1970, 1, 1));
        diferencaOdometro.setDiferencaOdometro(10.0d);
        diferencaOdometro.setId(1L);
        diferencaOdometro.setReferenciaFinal(referenciaFinal);
        diferencaOdometro.setReferenciaInicial(referenciaInicial);

        TipoVistoriaEntity tipoVistoria = new TipoVistoriaEntity();
        tipoVistoria.setAtivo(true);
        tipoVistoria.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoria.setDescricao("Descricao");
        tipoVistoria.setId(1L);
        tipoVistoria.setNome("Nome");
        tipoVistoria.setStatusAnterior("Status Anterior");
        tipoVistoria.setStatusPosterior("Status Posterior");

        TipoEmpregoViaturaEntity tipoEmpregoViatura = new TipoEmpregoViaturaEntity();
        tipoEmpregoViatura.setAtivo(1);
        tipoEmpregoViatura.setId(1);
        tipoEmpregoViatura.setNome("Nome");

        ViaturaEntity viatura = new ViaturaEntity();
        viatura.setAtivo(true);
        viatura.setDataAtualizacao(LocalDate.of(1970, 1, 1));
        viatura.setDataInclusao(LocalDate.of(1970, 1, 1));
        viatura.setId(1L);
        viatura.setListaUpm(new ArrayList<>());
        viatura.setMarcaModelo("Marca Modelo");
        viatura.setNrSei("Nr Sei");
        viatura.setPlaca("Placa");
        viatura.setPrefixo("Prefixo");
        viatura.setRenavam("Renavam");
        viatura.setStatus("Status");
        viatura.setTipoEmpregoViatura(tipoEmpregoViatura);
        viatura.setTombamento("alice.liddell@example.org");

        VistoriaViaturaEntity vistoria = new VistoriaViaturaEntity();
        ArrayList<ChecklistVistoriaEntity> checkLists = new ArrayList<>();
        vistoria.setCheckLists(checkLists);
        vistoria.setDataVistoria(LocalDate.of(1970, 1, 1).atStartOfDay());
        vistoria.setDiferencaOdometro(diferencaOdometro);
        vistoria.setDiferencaVistoria(true);
        vistoria.setId(1L);
        vistoria.setIdPolicial(1);
        vistoria.setIdUpm(1);
        vistoria.setOdometroFinal(10.0f);
        vistoria.setOdometroInicial(10.0f);
        vistoria.setStatus(VistoriaViaturaStatusEnum.DISPONIVEL);
        vistoria.setTipoVistoria(tipoVistoria);
        vistoria.setViatura(viatura);
        vistoria.setVistoriaArquivoList(new ArrayList<>());
        vistoria.setVistoriaViaturaHistorico(new ArrayList<>());

        ItemVistoriaEntity itemVistoria = new ItemVistoriaEntity();
        itemVistoria.setAtivo(true);
        itemVistoria.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoria.setDescricao("Descricao");
        itemVistoria.setId(1L);
        itemVistoria.setNome("Nome");

        // Act
        ChecklistVistoriaEntity actualChecklistVistoriaEntity = new ChecklistVistoriaEntity(1L, "Observacao", dataCriacao,
                vistoria, itemVistoria, new ArrayList<>());
        ArrayList<ChecklistItemVistoriaEntity> checklistItens = new ArrayList<>();
        actualChecklistVistoriaEntity.setChecklistItens(checklistItens);
        Date dataCriacao2 = Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant());
        actualChecklistVistoriaEntity.setDataCriacao(dataCriacao2);
        actualChecklistVistoriaEntity.setId(1L);
        ItemVistoriaEntity itemVistoria2 = new ItemVistoriaEntity();
        itemVistoria2.setAtivo(true);
        itemVistoria2.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoria2.setDescricao("Descricao");
        itemVistoria2.setId(1L);
        itemVistoria2.setNome("Nome");
        actualChecklistVistoriaEntity.setItemVistoria(itemVistoria2);
        actualChecklistVistoriaEntity.setObservacao("Observacao");
        TipoVistoriaEntity referenciaFinal2 = new TipoVistoriaEntity();
        referenciaFinal2.setAtivo(true);
        referenciaFinal2.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaFinal2.setDescricao("Descricao");
        referenciaFinal2.setId(1L);
        referenciaFinal2.setNome("Nome");
        referenciaFinal2.setStatusAnterior("Status Anterior");
        referenciaFinal2.setStatusPosterior("Status Posterior");
        TipoVistoriaEntity referenciaInicial2 = new TipoVistoriaEntity();
        referenciaInicial2.setAtivo(true);
        referenciaInicial2.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaInicial2.setDescricao("Descricao");
        referenciaInicial2.setId(1L);
        referenciaInicial2.setNome("Nome");
        referenciaInicial2.setStatusAnterior("Status Anterior");
        referenciaInicial2.setStatusPosterior("Status Posterior");
        DiferencaOdometroEntity diferencaOdometro2 = new DiferencaOdometroEntity();
        diferencaOdometro2.setDataInclusao(LocalDate.of(1970, 1, 1));
        diferencaOdometro2.setDataModificacao(LocalDate.of(1970, 1, 1));
        diferencaOdometro2.setDiferencaOdometro(10.0d);
        diferencaOdometro2.setId(1L);
        diferencaOdometro2.setReferenciaFinal(referenciaFinal2);
        diferencaOdometro2.setReferenciaInicial(referenciaInicial2);
        TipoVistoriaEntity tipoVistoria2 = new TipoVistoriaEntity();
        tipoVistoria2.setAtivo(true);
        tipoVistoria2.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoria2.setDescricao("Descricao");
        tipoVistoria2.setId(1L);
        tipoVistoria2.setNome("Nome");
        tipoVistoria2.setStatusAnterior("Status Anterior");
        tipoVistoria2.setStatusPosterior("Status Posterior");
        TipoEmpregoViaturaEntity tipoEmpregoViatura2 = new TipoEmpregoViaturaEntity();
        tipoEmpregoViatura2.setAtivo(1);
        tipoEmpregoViatura2.setId(1);
        tipoEmpregoViatura2.setNome("Nome");
        ViaturaEntity viatura2 = new ViaturaEntity();
        viatura2.setAtivo(true);
        viatura2.setDataAtualizacao(LocalDate.of(1970, 1, 1));
        viatura2.setDataInclusao(LocalDate.of(1970, 1, 1));
        viatura2.setId(1L);
        viatura2.setListaUpm(new ArrayList<>());
        viatura2.setMarcaModelo("Marca Modelo");
        viatura2.setNrSei("Nr Sei");
        viatura2.setPlaca("Placa");
        viatura2.setPrefixo("Prefixo");
        viatura2.setRenavam("Renavam");
        viatura2.setStatus("Status");
        viatura2.setTipoEmpregoViatura(tipoEmpregoViatura2);
        viatura2.setTombamento("alice.liddell@example.org");
        VistoriaViaturaEntity vistoria2 = new VistoriaViaturaEntity();
        vistoria2.setCheckLists(new ArrayList<>());
        vistoria2.setDataVistoria(LocalDate.of(1970, 1, 1).atStartOfDay());
        vistoria2.setDiferencaOdometro(diferencaOdometro2);
        vistoria2.setDiferencaVistoria(true);
        vistoria2.setId(1L);
        vistoria2.setIdPolicial(1);
        vistoria2.setIdUpm(1);
        vistoria2.setOdometroFinal(10.0f);
        vistoria2.setOdometroInicial(10.0f);
        vistoria2.setStatus(VistoriaViaturaStatusEnum.DISPONIVEL);
        vistoria2.setTipoVistoria(tipoVistoria2);
        vistoria2.setViatura(viatura2);
        vistoria2.setVistoriaArquivoList(new ArrayList<>());
        vistoria2.setVistoriaViaturaHistorico(new ArrayList<>());
        actualChecklistVistoriaEntity.setVistoria(vistoria2);
        List<ChecklistItemVistoriaEntity> actualChecklistItens = actualChecklistVistoriaEntity.getChecklistItens();
        Date actualDataCriacao = actualChecklistVistoriaEntity.getDataCriacao();
        Long actualId = actualChecklistVistoriaEntity.getId();
        ItemVistoriaEntity actualItemVistoria = actualChecklistVistoriaEntity.getItemVistoria();
        String actualObservacao = actualChecklistVistoriaEntity.getObservacao();
        VistoriaViaturaEntity actualVistoria = actualChecklistVistoriaEntity.getVistoria();

        // Assert that nothing has changed
        assertEquals("Observacao", actualObservacao);
        assertEquals(1L, actualId.longValue());
        assertEquals(itemVistoria, actualItemVistoria);
        assertEquals(checkLists, actualChecklistItens);
        assertSame(itemVistoria2, actualItemVistoria);
        assertSame(vistoria2, actualVistoria);
        assertSame(checklistItens, actualChecklistItens);
        assertSame(dataCriacao2, actualDataCriacao);
    }

    @Test
    void builder() {
        ChecklistVistoriaEntity checklistVistoriaEntity = ChecklistVistoriaEntity.builder()
                .id(1L)
                .dataCriacao(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()))
                .observacao("OBS")
                .vistoria(new VistoriaViaturaEntity())
                .checklistItens(List.of(new ChecklistItemVistoriaEntity()))
                .itemVistoria(new ItemVistoriaEntity())
                .build();

        assertNotNull(checklistVistoriaEntity);
    }

}
