package br.gov.df.pm.sgv.dto;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class EdicaoTipoDefeitoVistoriaDTOTest {
    private EdicaoTipoDefeitoVistoriaDTO edicaoTipoDefeitoVistoria = new EdicaoTipoDefeitoVistoriaDTO("", "");

    @BeforeEach
    void setUp() {
        edicaoTipoDefeitoVistoria.setNome("Vidro");
        edicaoTipoDefeitoVistoria.setDescricao("Vidro do Carro");
    }

    @Test
    void testEquals() {
        var edicaoTipoDefeitoVistoria1 = EdicaoTipoDefeitoVistoriaDTO.builder()
                .nome("Vidro")
                .descricao("Vidro do Carro")
                .build();
        assertEquals(edicaoTipoDefeitoVistoria, edicaoTipoDefeitoVistoria1);

        var edicaoTipoDefeitoVistoria2 = EdicaoTipoDefeitoVistoriaDTO.builder().nome("Janela").build();
        assertNotEquals(edicaoTipoDefeitoVistoria, edicaoTipoDefeitoVistoria2);


    }

    @Test
    void testHashCode() {
        var edicaoTipoDefeitoVistoria1 = EdicaoTipoDefeitoVistoriaDTO.builder()
                .nome("Vidro")
                .descricao("Vidro do Carro")
                .build();
        assertEquals(edicaoTipoDefeitoVistoria.hashCode(), edicaoTipoDefeitoVistoria1.hashCode());

        var edicaoTipoDefeitoVistoria2 = EdicaoTipoDefeitoVistoriaDTO.builder().build();
        assertNotEquals(edicaoTipoDefeitoVistoria.hashCode(), edicaoTipoDefeitoVistoria2.hashCode());
    }

    @Test
    void testToString() {
        assertNotNull(edicaoTipoDefeitoVistoria.toString());
    }
}
