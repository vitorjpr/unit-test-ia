```java
package br.gov.df.pm.sgv.dto;

import br.gov.df.pm.sgv.domain.sgpol.Policial;
import br.gov.df.pm.sgv.dto.root.PerfilDTO;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

class ApiInfoDTOTest {

    private ApiInfoDTO apiInfoDTO;

    @BeforeEach
    void setUp() {
        Policial policial = new Policial();
        PerfilDTO dto1 = new PerfilDTO("");
        dto1.setNome("nome");
        apiInfoDTO = new ApiInfoDTO("policial", policial, List.of(dto1));
    }

    @Test
    void testGetPolicial() {
        Policial expectedPolicial = new Policial();
        assertEquals(expectedPolicial, apiInfoDTO.getPolicial());
    }

    @Test
    void testGetPerfis() {
        PerfilDTO expectedPerfilDTO = new PerfilDTO("nome");
        List<PerfilDTO> expectedPerfis = List.of(expectedPerfilDTO);
        assertEquals(expectedPerfis, apiInfoDTO.getPerfis());
    }

    @Test
    void testEquals() {
        // Test equals with same object
        assertEquals(apiInfoDTO, apiInfoDTO);

        // Test equals with different object but same content
        ApiInfoDTO apiInfoDTO2 = new ApiInfoDTO("policial", new Policial(), List.of(new PerfilDTO("nome")));
        assertEquals(apiInfoDTO, apiInfoDTO2);

        // Test equals with different object and different content
        ApiInfoDTO apiInfoDTO3 = new ApiInfoDTO("outroPolicial", new Policial(), List.of(new PerfilDTO("outroNome")));
        assertNotEquals(apiInfoDTO, apiInfoDTO3);
    }

    @Test
    void testToString() {
        String expectedToString = "ApiInfoDTO{nome='policial', policial=br.gov.df.pm.sgv.domain.sgpol.Policial@<hashcode>, perfis=[PerfilDTO{nome='nome'}]}";
        assertEquals(expectedToString, apiInfoDTO.toString());
    }
}
```

Esses são testes abrangentes para a classe `ApiInfoDTO`, cobrindo os métodos `getPolicial`, `getPerfis`, `equals` e `toString`. Certifique-se de substituir `<hashcode>` pelo hash code real do objeto `Policial`.