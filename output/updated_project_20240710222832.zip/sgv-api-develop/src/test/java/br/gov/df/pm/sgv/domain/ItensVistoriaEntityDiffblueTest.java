package br.gov.df.pm.sgv.domain;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;

import java.time.LocalDate;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

class ItensVistoriaEntityDiffblueTest {
    /**
     * Method under test: {@link ItensVistoriaEntity#canEqual(Object)}
     */
    @Test
    void testCanEqual() {
        // Arrange, Act and Assert
        assertFalse((new ItensVistoriaEntity()).canEqual("Other"));
    }

    /**
     * Method under test: {@link ItensVistoriaEntity#canEqual(Object)}
     */
    @Test
    void testCanEqual2() {
        // Arrange
        ItemVistoriaEntity codItem = new ItemVistoriaEntity();
        codItem.setAtivo(true);
        codItem.setDataInclusao(LocalDate.of(1970, 1, 1));
        codItem.setDescricao("Descricao");
        codItem.setId(1L);
        codItem.setNome("Nome");

        TipoVistoriaEntity codTipo = new TipoVistoriaEntity();
        codTipo.setAtivo(true);
        codTipo.setDataInclusao(LocalDate.of(1970, 1, 1));
        codTipo.setDescricao("Descricao");
        codTipo.setId(1L);
        codTipo.setNome("Nome");
        codTipo.setStatusAnterior("Status Anterior");
        codTipo.setStatusPosterior("Status Posterior");

        ItensVistoriaEntity itensVistoriaEntity = new ItensVistoriaEntity();
        itensVistoriaEntity.setAtivo(true);
        itensVistoriaEntity.setCodItem(codItem);
        itensVistoriaEntity.setCodTipo(codTipo);
        itensVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itensVistoriaEntity.setId(1L);

        ItemVistoriaEntity codItem2 = new ItemVistoriaEntity();
        codItem2.setAtivo(true);
        codItem2.setDataInclusao(LocalDate.of(1970, 1, 1));
        codItem2.setDescricao("Descricao");
        codItem2.setId(1L);
        codItem2.setNome("Nome");

        TipoVistoriaEntity codTipo2 = new TipoVistoriaEntity();
        codTipo2.setAtivo(true);
        codTipo2.setDataInclusao(LocalDate.of(1970, 1, 1));
        codTipo2.setDescricao("Descricao");
        codTipo2.setId(1L);
        codTipo2.setNome("Nome");
        codTipo2.setStatusAnterior("Status Anterior");
        codTipo2.setStatusPosterior("Status Posterior");

        ItensVistoriaEntity itensVistoriaEntity2 = new ItensVistoriaEntity();
        itensVistoriaEntity2.setAtivo(true);
        itensVistoriaEntity2.setCodItem(codItem2);
        itensVistoriaEntity2.setCodTipo(codTipo2);
        itensVistoriaEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        itensVistoriaEntity2.setId(1L);

        // Act and Assert
        assertTrue(itensVistoriaEntity.canEqual(itensVistoriaEntity2));
    }

    /**
     * Method under test: {@link ItensVistoriaEntity#equals(Object)}
     */
    @Test
    void testEquals() {
        // Arrange
        ItemVistoriaEntity codItem = new ItemVistoriaEntity();
        codItem.setAtivo(true);
        codItem.setDataInclusao(LocalDate.of(1970, 1, 1));
        codItem.setDescricao("Descricao");
        codItem.setId(1L);
        codItem.setNome("Nome");

        TipoVistoriaEntity codTipo = new TipoVistoriaEntity();
        codTipo.setAtivo(true);
        codTipo.setDataInclusao(LocalDate.of(1970, 1, 1));
        codTipo.setDescricao("Descricao");
        codTipo.setId(1L);
        codTipo.setNome("Nome");
        codTipo.setStatusAnterior("Status Anterior");
        codTipo.setStatusPosterior("Status Posterior");

        ItensVistoriaEntity itensVistoriaEntity = new ItensVistoriaEntity();
        itensVistoriaEntity.setAtivo(true);
        itensVistoriaEntity.setCodItem(codItem);
        itensVistoriaEntity.setCodTipo(codTipo);
        itensVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itensVistoriaEntity.setId(1L);

        // Act and Assert
        assertNotEquals(itensVistoriaEntity, null);
    }

    /**
     * Method under test: {@link ItensVistoriaEntity#equals(Object)}
     */
    @Test
    void testEquals2() {
        // Arrange
        ItemVistoriaEntity codItem = new ItemVistoriaEntity();
        codItem.setAtivo(true);
        codItem.setDataInclusao(LocalDate.of(1970, 1, 1));
        codItem.setDescricao("Descricao");
        codItem.setId(1L);
        codItem.setNome("Nome");

        TipoVistoriaEntity codTipo = new TipoVistoriaEntity();
        codTipo.setAtivo(true);
        codTipo.setDataInclusao(LocalDate.of(1970, 1, 1));
        codTipo.setDescricao("Descricao");
        codTipo.setId(1L);
        codTipo.setNome("Nome");
        codTipo.setStatusAnterior("Status Anterior");
        codTipo.setStatusPosterior("Status Posterior");

        ItensVistoriaEntity itensVistoriaEntity = new ItensVistoriaEntity();
        itensVistoriaEntity.setAtivo(true);
        itensVistoriaEntity.setCodItem(codItem);
        itensVistoriaEntity.setCodTipo(codTipo);
        itensVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itensVistoriaEntity.setId(1L);

        // Act and Assert
        assertNotEquals(itensVistoriaEntity, "Different type to ItensVistoriaEntity");
    }

    /**
     * Method under test: {@link ItensVistoriaEntity#equals(Object)}
     */
    @Test
    void testEquals3() {
        // Arrange
        ItemVistoriaEntity codItem = mock(ItemVistoriaEntity.class);
        doNothing().when(codItem).setAtivo(Mockito.<Boolean>any());
        doNothing().when(codItem).setDataInclusao(Mockito.<LocalDate>any());
        doNothing().when(codItem).setDescricao(Mockito.<String>any());
        doNothing().when(codItem).setId(Mockito.<Long>any());
        doNothing().when(codItem).setNome(Mockito.<String>any());
        codItem.setAtivo(true);
        codItem.setDataInclusao(LocalDate.of(1970, 1, 1));
        codItem.setDescricao("Descricao");
        codItem.setId(1L);
        codItem.setNome("Nome");

        TipoVistoriaEntity codTipo = new TipoVistoriaEntity();
        codTipo.setAtivo(true);
        codTipo.setDataInclusao(LocalDate.of(1970, 1, 1));
        codTipo.setDescricao("Descricao");
        codTipo.setId(1L);
        codTipo.setNome("Nome");
        codTipo.setStatusAnterior("Status Anterior");
        codTipo.setStatusPosterior("Status Posterior");

        ItensVistoriaEntity itensVistoriaEntity = new ItensVistoriaEntity();
        itensVistoriaEntity.setAtivo(true);
        itensVistoriaEntity.setCodItem(codItem);
        itensVistoriaEntity.setCodTipo(codTipo);
        itensVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itensVistoriaEntity.setId(2L);

        ItemVistoriaEntity codItem2 = new ItemVistoriaEntity();
        codItem2.setAtivo(true);
        codItem2.setDataInclusao(LocalDate.of(1970, 1, 1));
        codItem2.setDescricao("Descricao");
        codItem2.setId(1L);
        codItem2.setNome("Nome");

        TipoVistoriaEntity codTipo2 = new TipoVistoriaEntity();
        codTipo2.setAtivo(true);
        codTipo2.setDataInclusao(LocalDate.of(1970, 1, 1));
        codTipo2.setDescricao("Descricao");
        codTipo2.setId(1L);
        codTipo2.setNome("Nome");
        codTipo2.setStatusAnterior("Status Anterior");
        codTipo2.setStatusPosterior("Status Posterior");

        ItensVistoriaEntity itensVistoriaEntity2 = new ItensVistoriaEntity();
        itensVistoriaEntity2.setAtivo(true);
        itensVistoriaEntity2.setCodItem(codItem2);
        itensVistoriaEntity2.setCodTipo(codTipo2);
        itensVistoriaEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        itensVistoriaEntity2.setId(1L);

        // Act and Assert
        assertNotEquals(itensVistoriaEntity, itensVistoriaEntity2);
    }

    /**
     * Method under test: {@link ItensVistoriaEntity#equals(Object)}
     */
    @Test
    void testEquals4() {
        // Arrange
        ItemVistoriaEntity codItem = mock(ItemVistoriaEntity.class);
        doNothing().when(codItem).setAtivo(Mockito.<Boolean>any());
        doNothing().when(codItem).setDataInclusao(Mockito.<LocalDate>any());
        doNothing().when(codItem).setDescricao(Mockito.<String>any());
        doNothing().when(codItem).setId(Mockito.<Long>any());
        doNothing().when(codItem).setNome(Mockito.<String>any());
        codItem.setAtivo(true);
        codItem.setDataInclusao(LocalDate.of(1970, 1, 1));
        codItem.setDescricao("Descricao");
        codItem.setId(1L);
        codItem.setNome("Nome");

        TipoVistoriaEntity codTipo = new TipoVistoriaEntity();
        codTipo.setAtivo(true);
        codTipo.setDataInclusao(LocalDate.of(1970, 1, 1));
        codTipo.setDescricao("Descricao");
        codTipo.setId(1L);
        codTipo.setNome("Nome");
        codTipo.setStatusAnterior("Status Anterior");
        codTipo.setStatusPosterior("Status Posterior");

        ItensVistoriaEntity itensVistoriaEntity = new ItensVistoriaEntity();
        itensVistoriaEntity.setAtivo(true);
        itensVistoriaEntity.setCodItem(codItem);
        itensVistoriaEntity.setCodTipo(codTipo);
        itensVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itensVistoriaEntity.setId(null);

        ItemVistoriaEntity codItem2 = new ItemVistoriaEntity();
        codItem2.setAtivo(true);
        codItem2.setDataInclusao(LocalDate.of(1970, 1, 1));
        codItem2.setDescricao("Descricao");
        codItem2.setId(1L);
        codItem2.setNome("Nome");

        TipoVistoriaEntity codTipo2 = new TipoVistoriaEntity();
        codTipo2.setAtivo(true);
        codTipo2.setDataInclusao(LocalDate.of(1970, 1, 1));
        codTipo2.setDescricao("Descricao");
        codTipo2.setId(1L);
        codTipo2.setNome("Nome");
        codTipo2.setStatusAnterior("Status Anterior");
        codTipo2.setStatusPosterior("Status Posterior");

        ItensVistoriaEntity itensVistoriaEntity2 = new ItensVistoriaEntity();
        itensVistoriaEntity2.setAtivo(true);
        itensVistoriaEntity2.setCodItem(codItem2);
        itensVistoriaEntity2.setCodTipo(codTipo2);
        itensVistoriaEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        itensVistoriaEntity2.setId(1L);

        // Act and Assert
        assertNotEquals(itensVistoriaEntity, itensVistoriaEntity2);
    }

    /**
     * Methods under test:
     * <ul>
     *   <li>{@link ItensVistoriaEntity#equals(Object)}
     *   <li>{@link ItensVistoriaEntity#hashCode()}
     * </ul>
     */
    @Test
    void testEqualsAndHashCode() {
        // Arrange
        ItemVistoriaEntity codItem = new ItemVistoriaEntity();
        codItem.setAtivo(true);
        codItem.setDataInclusao(LocalDate.of(1970, 1, 1));
        codItem.setDescricao("Descricao");
        codItem.setId(1L);
        codItem.setNome("Nome");

        TipoVistoriaEntity codTipo = new TipoVistoriaEntity();
        codTipo.setAtivo(true);
        codTipo.setDataInclusao(LocalDate.of(1970, 1, 1));
        codTipo.setDescricao("Descricao");
        codTipo.setId(1L);
        codTipo.setNome("Nome");
        codTipo.setStatusAnterior("Status Anterior");
        codTipo.setStatusPosterior("Status Posterior");

        ItensVistoriaEntity itensVistoriaEntity = new ItensVistoriaEntity();
        itensVistoriaEntity.setAtivo(true);
        itensVistoriaEntity.setCodItem(codItem);
        itensVistoriaEntity.setCodTipo(codTipo);
        itensVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itensVistoriaEntity.setId(1L);

        // Act and Assert
        assertEquals(itensVistoriaEntity, itensVistoriaEntity);
        int expectedHashCodeResult = itensVistoriaEntity.hashCode();
        assertEquals(expectedHashCodeResult, itensVistoriaEntity.hashCode());
    }

    /**
     * Methods under test:
     * <ul>
     *   <li>{@link ItensVistoriaEntity#equals(Object)}
     *   <li>{@link ItensVistoriaEntity#hashCode()}
     * </ul>
     */
    @Test
    void testEqualsAndHashCode2() {
        // Arrange
        ItemVistoriaEntity codItem = new ItemVistoriaEntity();
        codItem.setAtivo(true);
        codItem.setDataInclusao(LocalDate.of(1970, 1, 1));
        codItem.setDescricao("Descricao");
        codItem.setId(1L);
        codItem.setNome("Nome");

        TipoVistoriaEntity codTipo = new TipoVistoriaEntity();
        codTipo.setAtivo(true);
        codTipo.setDataInclusao(LocalDate.of(1970, 1, 1));
        codTipo.setDescricao("Descricao");
        codTipo.setId(1L);
        codTipo.setNome("Nome");
        codTipo.setStatusAnterior("Status Anterior");
        codTipo.setStatusPosterior("Status Posterior");

        ItensVistoriaEntity itensVistoriaEntity = new ItensVistoriaEntity();
        itensVistoriaEntity.setAtivo(true);
        itensVistoriaEntity.setCodItem(codItem);
        itensVistoriaEntity.setCodTipo(codTipo);
        itensVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itensVistoriaEntity.setId(1L);

        ItemVistoriaEntity codItem2 = new ItemVistoriaEntity();
        codItem2.setAtivo(true);
        codItem2.setDataInclusao(LocalDate.of(1970, 1, 1));
        codItem2.setDescricao("Descricao");
        codItem2.setId(1L);
        codItem2.setNome("Nome");

        TipoVistoriaEntity codTipo2 = new TipoVistoriaEntity();
        codTipo2.setAtivo(true);
        codTipo2.setDataInclusao(LocalDate.of(1970, 1, 1));
        codTipo2.setDescricao("Descricao");
        codTipo2.setId(1L);
        codTipo2.setNome("Nome");
        codTipo2.setStatusAnterior("Status Anterior");
        codTipo2.setStatusPosterior("Status Posterior");

        ItensVistoriaEntity itensVistoriaEntity2 = new ItensVistoriaEntity();
        itensVistoriaEntity2.setAtivo(true);
        itensVistoriaEntity2.setCodItem(codItem2);
        itensVistoriaEntity2.setCodTipo(codTipo2);
        itensVistoriaEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        itensVistoriaEntity2.setId(1L);

        // Act and Assert
        assertEquals(itensVistoriaEntity, itensVistoriaEntity2);
        int expectedHashCodeResult = itensVistoriaEntity.hashCode();
        assertEquals(expectedHashCodeResult, itensVistoriaEntity2.hashCode());
    }

    /**
     * Methods under test:
     * <ul>
     *   <li>{@link ItensVistoriaEntity#equals(Object)}
     *   <li>{@link ItensVistoriaEntity#hashCode()}
     * </ul>
     */
    @Test
    void testEqualsAndHashCode3() {
        // Arrange
        ItemVistoriaEntity codItem = mock(ItemVistoriaEntity.class);
        doNothing().when(codItem).setAtivo(Mockito.<Boolean>any());
        doNothing().when(codItem).setDataInclusao(Mockito.<LocalDate>any());
        doNothing().when(codItem).setDescricao(Mockito.<String>any());
        doNothing().when(codItem).setId(Mockito.<Long>any());
        doNothing().when(codItem).setNome(Mockito.<String>any());
        codItem.setAtivo(true);
        codItem.setDataInclusao(LocalDate.of(1970, 1, 1));
        codItem.setDescricao("Descricao");
        codItem.setId(1L);
        codItem.setNome("Nome");

        TipoVistoriaEntity codTipo = new TipoVistoriaEntity();
        codTipo.setAtivo(true);
        codTipo.setDataInclusao(LocalDate.of(1970, 1, 1));
        codTipo.setDescricao("Descricao");
        codTipo.setId(1L);
        codTipo.setNome("Nome");
        codTipo.setStatusAnterior("Status Anterior");
        codTipo.setStatusPosterior("Status Posterior");

        ItensVistoriaEntity itensVistoriaEntity = new ItensVistoriaEntity();
        itensVistoriaEntity.setAtivo(true);
        itensVistoriaEntity.setCodItem(codItem);
        itensVistoriaEntity.setCodTipo(codTipo);
        itensVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itensVistoriaEntity.setId(1L);

        ItemVistoriaEntity codItem2 = new ItemVistoriaEntity();
        codItem2.setAtivo(true);
        codItem2.setDataInclusao(LocalDate.of(1970, 1, 1));
        codItem2.setDescricao("Descricao");
        codItem2.setId(1L);
        codItem2.setNome("Nome");

        TipoVistoriaEntity codTipo2 = new TipoVistoriaEntity();
        codTipo2.setAtivo(true);
        codTipo2.setDataInclusao(LocalDate.of(1970, 1, 1));
        codTipo2.setDescricao("Descricao");
        codTipo2.setId(1L);
        codTipo2.setNome("Nome");
        codTipo2.setStatusAnterior("Status Anterior");
        codTipo2.setStatusPosterior("Status Posterior");

        ItensVistoriaEntity itensVistoriaEntity2 = new ItensVistoriaEntity();
        itensVistoriaEntity2.setAtivo(true);
        itensVistoriaEntity2.setCodItem(codItem2);
        itensVistoriaEntity2.setCodTipo(codTipo2);
        itensVistoriaEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        itensVistoriaEntity2.setId(1L);

        // Act and Assert
        assertEquals(itensVistoriaEntity, itensVistoriaEntity2);
        int expectedHashCodeResult = itensVistoriaEntity.hashCode();
        assertEquals(expectedHashCodeResult, itensVistoriaEntity2.hashCode());
    }

    /**
     * Methods under test:
     * <ul>
     *   <li>{@link ItensVistoriaEntity#ItensVistoriaEntity()}
     *   <li>{@link ItensVistoriaEntity#setAtivo(Boolean)}
     *   <li>{@link ItensVistoriaEntity#setCodItem(ItemVistoriaEntity)}
     *   <li>{@link ItensVistoriaEntity#setCodTipo(TipoVistoriaEntity)}
     *   <li>{@link ItensVistoriaEntity#setDataInclusao(LocalDate)}
     *   <li>{@link ItensVistoriaEntity#setId(Long)}
     *   <li>{@link ItensVistoriaEntity#getAtivo()}
     *   <li>{@link ItensVistoriaEntity#getCodItem()}
     *   <li>{@link ItensVistoriaEntity#getCodTipo()}
     *   <li>{@link ItensVistoriaEntity#getDataInclusao()}
     *   <li>{@link ItensVistoriaEntity#getId()}
     * </ul>
     */
    @Test
    void testGettersAndSetters() {
        // Arrange and Act
        ItensVistoriaEntity actualItensVistoriaEntity = new ItensVistoriaEntity();
        actualItensVistoriaEntity.setAtivo(true);
        ItemVistoriaEntity codItem = new ItemVistoriaEntity();
        codItem.setAtivo(true);
        codItem.setDataInclusao(LocalDate.of(1970, 1, 1));
        codItem.setDescricao("Descricao");
        codItem.setId(1L);
        codItem.setNome("Nome");
        actualItensVistoriaEntity.setCodItem(codItem);
        TipoVistoriaEntity codTipo = new TipoVistoriaEntity();
        codTipo.setAtivo(true);
        codTipo.setDataInclusao(LocalDate.of(1970, 1, 1));
        codTipo.setDescricao("Descricao");
        codTipo.setId(1L);
        codTipo.setNome("Nome");
        codTipo.setStatusAnterior("Status Anterior");
        codTipo.setStatusPosterior("Status Posterior");
        actualItensVistoriaEntity.setCodTipo(codTipo);
        LocalDate dataInclusao = LocalDate.of(1970, 1, 1);
        actualItensVistoriaEntity.setDataInclusao(dataInclusao);
        actualItensVistoriaEntity.setId(1L);
        Boolean actualAtivo = actualItensVistoriaEntity.getAtivo();
        ItemVistoriaEntity actualCodItem = actualItensVistoriaEntity.getCodItem();
        TipoVistoriaEntity actualCodTipo = actualItensVistoriaEntity.getCodTipo();
        LocalDate actualDataInclusao = actualItensVistoriaEntity.getDataInclusao();

        // Assert that nothing has changed
        assertEquals(1L, actualItensVistoriaEntity.getId().longValue());
        assertTrue(actualAtivo);
        assertSame(codItem, actualCodItem);
        assertSame(codTipo, actualCodTipo);
        assertSame(dataInclusao, actualDataInclusao);
    }

    /**
     * Methods under test:
     * <ul>
     *   <li>
     * {@link ItensVistoriaEntity#ItensVistoriaEntity(Long, TipoVistoriaEntity, ItemVistoriaEntity, Boolean, LocalDate)}
     *   <li>{@link ItensVistoriaEntity#setAtivo(Boolean)}
     *   <li>{@link ItensVistoriaEntity#setCodItem(ItemVistoriaEntity)}
     *   <li>{@link ItensVistoriaEntity#setCodTipo(TipoVistoriaEntity)}
     *   <li>{@link ItensVistoriaEntity#setDataInclusao(LocalDate)}
     *   <li>{@link ItensVistoriaEntity#setId(Long)}
     *   <li>{@link ItensVistoriaEntity#getAtivo()}
     *   <li>{@link ItensVistoriaEntity#getCodItem()}
     *   <li>{@link ItensVistoriaEntity#getCodTipo()}
     *   <li>{@link ItensVistoriaEntity#getDataInclusao()}
     *   <li>{@link ItensVistoriaEntity#getId()}
     * </ul>
     */
    @Test
    void testGettersAndSetters2() {
        // Arrange
        TipoVistoriaEntity codTipo = new TipoVistoriaEntity();
        codTipo.setAtivo(true);
        codTipo.setDataInclusao(LocalDate.of(1970, 1, 1));
        codTipo.setDescricao("Descricao");
        codTipo.setId(1L);
        codTipo.setNome("Nome");
        codTipo.setStatusAnterior("Status Anterior");
        codTipo.setStatusPosterior("Status Posterior");

        ItemVistoriaEntity codItem = new ItemVistoriaEntity();
        codItem.setAtivo(true);
        codItem.setDataInclusao(LocalDate.of(1970, 1, 1));
        codItem.setDescricao("Descricao");
        codItem.setId(1L);
        codItem.setNome("Nome");

        // Act
        ItensVistoriaEntity actualItensVistoriaEntity = new ItensVistoriaEntity(1L, codTipo, codItem, true,
                LocalDate.of(1970, 1, 1));
        actualItensVistoriaEntity.setAtivo(true);
        ItemVistoriaEntity codItem2 = new ItemVistoriaEntity();
        codItem2.setAtivo(true);
        codItem2.setDataInclusao(LocalDate.of(1970, 1, 1));
        codItem2.setDescricao("Descricao");
        codItem2.setId(1L);
        codItem2.setNome("Nome");
        actualItensVistoriaEntity.setCodItem(codItem2);
        TipoVistoriaEntity codTipo2 = new TipoVistoriaEntity();
        codTipo2.setAtivo(true);
        codTipo2.setDataInclusao(LocalDate.of(1970, 1, 1));
        codTipo2.setDescricao("Descricao");
        codTipo2.setId(1L);
        codTipo2.setNome("Nome");
        codTipo2.setStatusAnterior("Status Anterior");
        codTipo2.setStatusPosterior("Status Posterior");
        actualItensVistoriaEntity.setCodTipo(codTipo2);
        LocalDate dataInclusao = LocalDate.of(1970, 1, 1);
        actualItensVistoriaEntity.setDataInclusao(dataInclusao);
        actualItensVistoriaEntity.setId(1L);
        Boolean actualAtivo = actualItensVistoriaEntity.getAtivo();
        ItemVistoriaEntity actualCodItem = actualItensVistoriaEntity.getCodItem();
        TipoVistoriaEntity actualCodTipo = actualItensVistoriaEntity.getCodTipo();
        LocalDate actualDataInclusao = actualItensVistoriaEntity.getDataInclusao();

        // Assert that nothing has changed
        assertEquals(1L, actualItensVistoriaEntity.getId().longValue());
        assertTrue(actualAtivo);
        assertEquals(codItem, actualCodItem);
        assertEquals(codTipo, actualCodTipo);
        assertSame(codItem2, actualCodItem);
        assertSame(codTipo2, actualCodTipo);
        assertSame(dataInclusao, actualDataInclusao);
    }
}
