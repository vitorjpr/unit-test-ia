package br.gov.df.pm.sgv.dto;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class TipoEmpregoViaturaDtoTest {

    private TipoEmpregoViaturaDto tipoEmpregoViaturaDto;

    @BeforeEach
    void setUp() {
        tipoEmpregoViaturaDto = new TipoEmpregoViaturaDto(1, "nome",1);
        tipoEmpregoViaturaDto.setId(1);
        tipoEmpregoViaturaDto.setNome("nome");
        tipoEmpregoViaturaDto.setAtivo(1);
    }

    @Test
    void getId() {
        assertNotNull(tipoEmpregoViaturaDto.getId());

    }

    @Test
    void getNome() {
        assertNotNull(tipoEmpregoViaturaDto.getNome());
    }

    @Test
    void getAtivo() {
        assertNotNull(tipoEmpregoViaturaDto.getAtivo());
    }

    @Test
    void testEquals() {
       TipoEmpregoViaturaDto tipoEmpregoViaturaDto1 = new TipoEmpregoViaturaDto(1, "nome",1);
        tipoEmpregoViaturaDto1.setId(1);
        tipoEmpregoViaturaDto1.setNome("nome");
        tipoEmpregoViaturaDto1.setAtivo(1);

        assertEquals(tipoEmpregoViaturaDto, tipoEmpregoViaturaDto1);
    }

    @Test
    void testHashCode() {
       TipoEmpregoViaturaDto tipoEmpregoViaturaDto1 = new TipoEmpregoViaturaDto(1, "nome",1);
        tipoEmpregoViaturaDto1.setId(1);
        tipoEmpregoViaturaDto1.setNome("nome");
        tipoEmpregoViaturaDto1.setAtivo(1);

        assertEquals(tipoEmpregoViaturaDto.hashCode(), tipoEmpregoViaturaDto1.hashCode());
    }

    @Test
    void testToString() {
       assertNotNull(tipoEmpregoViaturaDto.toString());
    }

    @Test
    void builder() {
        TipoEmpregoViaturaDto tipoEmpregoViaturaDtoBuilder = TipoEmpregoViaturaDto.builder()
                .id(1)
                .nome("NOME")
                .ativo(1)
                .build();

        assertNotNull(tipoEmpregoViaturaDtoBuilder);
    }
}