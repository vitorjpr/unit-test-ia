package br.gov.df.pm.sgv.dto.app;

import br.gov.df.pm.sgv.dto.ViaturaDTO;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;

public class ViaturaDTOTest {

    LocalDateTime diaAtual = LocalDateTime.now();
    private ViaturaDTO viatura = new ViaturaDTO(null, null, null, null, "",null, null, null, null, null, null, null);

    @BeforeEach
    void setUp() {
        viatura.setId(1L);
        viatura.setPrefixo("XXX");
        viatura.setPlaca("XXXXX");
        viatura.setAtivo(true);
        viatura.setStatus("");
        viatura.setNrSei("XXX");
        viatura.setDataAtualizacao(diaAtual);
    }

    @Test
    void testEquals() {
        var viatura1 = ViaturaDTO.builder()
                .id(1L)
                .prefixo("XXX")
                .placa("XXXXX")
                .ativo(true)
                .nrSei("XXX")
                .status("")
                .dataAtualizacao(diaAtual)
                .build();
        assertEquals(viatura, viatura1);

        var viatura2 = ViaturaDTO.builder().id(1L).build();
        assertNotEquals(viatura, viatura2);
    }

    @Test
    void testHashCode() {
        var viatura1 = ViaturaDTO.builder()
                .id(1L)
                .prefixo("XXX")
                .placa("XXXXX")
                .ativo(true)
                .status("")
                .nrSei("XXX")
                .dataAtualizacao(diaAtual)
                .build();
        assertEquals(viatura.hashCode(), viatura1.hashCode());

        var viatura2 = ViaturaDTO.builder().id(1L).build();
        assertNotEquals(viatura.hashCode(), viatura2.hashCode());
    }

    @Test
    void testToString() { assertNotNull(viatura.toString());}

}
