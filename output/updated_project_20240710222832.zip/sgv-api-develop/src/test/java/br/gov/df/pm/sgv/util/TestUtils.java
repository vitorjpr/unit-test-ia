package br.gov.df.pm.sgv.util;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;

import java.util.function.Function;

@Slf4j
public class TestUtils {

    private TestUtils() {
    }

    private final static ObjectMapper mapper = new ObjectMapper();

    static {
        mapper.configure(JsonParser.Feature.ALLOW_UNQUOTED_FIELD_NAMES, true);
        mapper.configure(JsonParser.Feature.ALLOW_SINGLE_QUOTES, true);
    }

    public static <T> T fromJson(Class<T> clazz, String json) {
        try {
             return mapper.readerFor(clazz).readValue(json);
        } catch (JsonProcessingException e) {
            log.error("Erro ao converter JSON em Objeto", e);
        }
        return null;
    }

    public static <T> Answer<T> callableAnswer(Function<InvocationOnMock, T> callback) {
        return new Answer<T>() {
            @Override
            public T answer(InvocationOnMock invocation) throws Throwable {
                return callback.apply(invocation);
            }
        };
    }
}