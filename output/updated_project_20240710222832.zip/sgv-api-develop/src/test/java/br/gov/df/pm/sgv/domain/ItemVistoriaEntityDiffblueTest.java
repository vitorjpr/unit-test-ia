package br.gov.df.pm.sgv.domain;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.time.LocalDate;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

class ItemVistoriaEntityDiffblueTest {
    /**
     * Method under test: {@link ItemVistoriaEntity#canEqual(Object)}
     */
    @Test
    void testCanEqual() {
        // Arrange, Act and Assert
        assertFalse((new ItemVistoriaEntity()).canEqual("Other"));
    }

    /**
     * Method under test: {@link ItemVistoriaEntity#canEqual(Object)}
     */
    @Test
    void testCanEqual2() {
        // Arrange
        ItemVistoriaEntity itemVistoriaEntity = new ItemVistoriaEntity();
        itemVistoriaEntity.setAtivo(true);
        itemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity.setDescricao("Descricao");
        itemVistoriaEntity.setId(1L);
        itemVistoriaEntity.setNome("Nome");

        ItemVistoriaEntity itemVistoriaEntity2 = new ItemVistoriaEntity();
        itemVistoriaEntity2.setAtivo(true);
        itemVistoriaEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity2.setDescricao("Descricao");
        itemVistoriaEntity2.setId(1L);
        itemVistoriaEntity2.setNome("Nome");

        // Act and Assert
        assertTrue(itemVistoriaEntity.canEqual(itemVistoriaEntity2));
    }

    /**
     * Method under test: {@link ItemVistoriaEntity#equals(Object)}
     */
    @Test
    void testEquals() {
        // Arrange
        ItemVistoriaEntity itemVistoriaEntity = new ItemVistoriaEntity();
        itemVistoriaEntity.setAtivo(true);
        itemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity.setDescricao("Descricao");
        itemVistoriaEntity.setId(1L);
        itemVistoriaEntity.setNome("Nome");

        // Act and Assert
        assertNotEquals(itemVistoriaEntity, null);
    }

    /**
     * Method under test: {@link ItemVistoriaEntity#equals(Object)}
     */
    @Test
    void testEquals2() {
        // Arrange
        ItemVistoriaEntity itemVistoriaEntity = new ItemVistoriaEntity();
        itemVistoriaEntity.setAtivo(true);
        itemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity.setDescricao("Descricao");
        itemVistoriaEntity.setId(1L);
        itemVistoriaEntity.setNome("Nome");

        // Act and Assert
        assertNotEquals(itemVistoriaEntity, "Different type to ItemVistoriaEntity");
    }

    /**
     * Method under test: {@link ItemVistoriaEntity#equals(Object)}
     */
    @Test
    void testEquals3() {
        // Arrange
        ItemVistoriaEntity itemVistoriaEntity = new ItemVistoriaEntity();
        itemVistoriaEntity.setAtivo(true);
        itemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity.setDescricao("Descricao");
        itemVistoriaEntity.setId(2L);
        itemVistoriaEntity.setNome("Nome");

        ItemVistoriaEntity itemVistoriaEntity2 = new ItemVistoriaEntity();
        itemVistoriaEntity2.setAtivo(true);
        itemVistoriaEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity2.setDescricao("Descricao");
        itemVistoriaEntity2.setId(1L);
        itemVistoriaEntity2.setNome("Nome");

        // Act and Assert
        assertNotEquals(itemVistoriaEntity, itemVistoriaEntity2);
    }

    /**
     * Method under test: {@link ItemVistoriaEntity#equals(Object)}
     */
    @Test
    void testEquals4() {
        // Arrange
        ItemVistoriaEntity itemVistoriaEntity = new ItemVistoriaEntity();
        itemVistoriaEntity.setAtivo(true);
        itemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity.setDescricao("Descricao");
        itemVistoriaEntity.setId(null);
        itemVistoriaEntity.setNome("Nome");

        ItemVistoriaEntity itemVistoriaEntity2 = new ItemVistoriaEntity();
        itemVistoriaEntity2.setAtivo(true);
        itemVistoriaEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity2.setDescricao("Descricao");
        itemVistoriaEntity2.setId(1L);
        itemVistoriaEntity2.setNome("Nome");

        // Act and Assert
        assertNotEquals(itemVistoriaEntity, itemVistoriaEntity2);
    }

    /**
     * Methods under test:
     * <ul>
     *   <li>{@link ItemVistoriaEntity#equals(Object)}
     *   <li>{@link ItemVistoriaEntity#hashCode()}
     * </ul>
     */
    @Test
    void testEqualsAndHashCode() {
        // Arrange
        ItemVistoriaEntity itemVistoriaEntity = new ItemVistoriaEntity();
        itemVistoriaEntity.setAtivo(true);
        itemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity.setDescricao("Descricao");
        itemVistoriaEntity.setId(1L);
        itemVistoriaEntity.setNome("Nome");

        // Act and Assert
        assertEquals(itemVistoriaEntity, itemVistoriaEntity);
        int expectedHashCodeResult = itemVistoriaEntity.hashCode();
        assertEquals(expectedHashCodeResult, itemVistoriaEntity.hashCode());
    }

    /**
     * Methods under test:
     * <ul>
     *   <li>{@link ItemVistoriaEntity#equals(Object)}
     *   <li>{@link ItemVistoriaEntity#hashCode()}
     * </ul>
     */
    @Test
    void testEqualsAndHashCode2() {
        // Arrange
        ItemVistoriaEntity itemVistoriaEntity = new ItemVistoriaEntity();
        itemVistoriaEntity.setAtivo(true);
        itemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity.setDescricao("Descricao");
        itemVistoriaEntity.setId(1L);
        itemVistoriaEntity.setNome("Nome");

        ItemVistoriaEntity itemVistoriaEntity2 = new ItemVistoriaEntity();
        itemVistoriaEntity2.setAtivo(true);
        itemVistoriaEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity2.setDescricao("Descricao");
        itemVistoriaEntity2.setId(1L);
        itemVistoriaEntity2.setNome("Nome");

        // Act and Assert
        assertEquals(itemVistoriaEntity, itemVistoriaEntity2);
        int expectedHashCodeResult = itemVistoriaEntity.hashCode();
        assertEquals(expectedHashCodeResult, itemVistoriaEntity2.hashCode());
    }

    /**
     * Methods under test:
     * <ul>
     *   <li>{@link ItemVistoriaEntity#equals(Object)}
     *   <li>{@link ItemVistoriaEntity#hashCode()}
     * </ul>
     */
    @Test
    void testEqualsAndHashCode3() {
        // Arrange
        ItemVistoriaEntity itemVistoriaEntity = new ItemVistoriaEntity();
        itemVistoriaEntity.setAtivo(true);
        itemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity.setDescricao("Descricao");
        itemVistoriaEntity.setId(null);
        itemVistoriaEntity.setNome("Nome");

        ItemVistoriaEntity itemVistoriaEntity2 = new ItemVistoriaEntity();
        itemVistoriaEntity2.setAtivo(true);
        itemVistoriaEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity2.setDescricao("Descricao");
        itemVistoriaEntity2.setId(null);
        itemVistoriaEntity2.setNome("Nome");

        // Act and Assert
        assertEquals(itemVistoriaEntity, itemVistoriaEntity2);
        int expectedHashCodeResult = itemVistoriaEntity.hashCode();
        assertEquals(expectedHashCodeResult, itemVistoriaEntity2.hashCode());
    }

    /**
     * Methods under test:
     * <ul>
     *   <li>{@link ItemVistoriaEntity#equals(Object)}
     *   <li>{@link ItemVistoriaEntity#hashCode()}
     * </ul>
     */
    @Test
    void testEqualsAndHashCode4() {
        // Arrange
        ItemVistoriaEntity.ItemVistoriaEntityBuilder itemVistoriaEntityBuilder = mock(
                ItemVistoriaEntity.ItemVistoriaEntityBuilder.class);
        when(itemVistoriaEntityBuilder.ativo(Mockito.<Boolean>any())).thenReturn(ItemVistoriaEntity.builder());
        ItemVistoriaEntity.ItemVistoriaEntityBuilder ativoResult = itemVistoriaEntityBuilder.ativo(true);
        ItemVistoriaEntity buildResult = ativoResult.dataInclusao(LocalDate.of(1970, 1, 1))
                .descricao("Descricao")
                .id(1L)
                .nome("Nome")
                .build();
        buildResult.setAtivo(true);
        buildResult.setDataInclusao(LocalDate.of(1970, 1, 1));
        buildResult.setDescricao("Descricao");
        buildResult.setId(1L);
        buildResult.setNome("Nome");

        ItemVistoriaEntity itemVistoriaEntity = new ItemVistoriaEntity();
        itemVistoriaEntity.setAtivo(true);
        itemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity.setDescricao("Descricao");
        itemVistoriaEntity.setId(1L);
        itemVistoriaEntity.setNome("Nome");

        // Act and Assert
        assertEquals(buildResult, itemVistoriaEntity);
        int expectedHashCodeResult = buildResult.hashCode();
        assertEquals(expectedHashCodeResult, itemVistoriaEntity.hashCode());
    }

    /**
     * Methods under test:
     * <ul>
     *   <li>{@link ItemVistoriaEntity#ItemVistoriaEntity()}
     *   <li>{@link ItemVistoriaEntity#setAtivo(Boolean)}
     *   <li>{@link ItemVistoriaEntity#setDataInclusao(LocalDate)}
     *   <li>{@link ItemVistoriaEntity#setDescricao(String)}
     *   <li>{@link ItemVistoriaEntity#setId(Long)}
     *   <li>{@link ItemVistoriaEntity#setNome(String)}
     *   <li>{@link ItemVistoriaEntity#getAtivo()}
     *   <li>{@link ItemVistoriaEntity#getDataInclusao()}
     *   <li>{@link ItemVistoriaEntity#getDescricao()}
     *   <li>{@link ItemVistoriaEntity#getId()}
     *   <li>{@link ItemVistoriaEntity#getNome()}
     * </ul>
     */
    @Test
    void testGettersAndSetters() {
        // Arrange and Act
        ItemVistoriaEntity actualItemVistoriaEntity = new ItemVistoriaEntity();
        actualItemVistoriaEntity.setAtivo(true);
        LocalDate dataInclusao = LocalDate.of(1970, 1, 1);
        actualItemVistoriaEntity.setDataInclusao(dataInclusao);
        actualItemVistoriaEntity.setDescricao("Descricao");
        actualItemVistoriaEntity.setId(1L);
        actualItemVistoriaEntity.setNome("Nome");
        Boolean actualAtivo = actualItemVistoriaEntity.getAtivo();
        LocalDate actualDataInclusao = actualItemVistoriaEntity.getDataInclusao();
        String actualDescricao = actualItemVistoriaEntity.getDescricao();
        Long actualId = actualItemVistoriaEntity.getId();

        // Assert that nothing has changed
        assertEquals("Descricao", actualDescricao);
        assertEquals("Nome", actualItemVistoriaEntity.getNome());
        assertEquals(1L, actualId.longValue());
        assertTrue(actualAtivo);
        assertSame(dataInclusao, actualDataInclusao);
    }

    /**
     * Methods under test:
     * <ul>
     *   <li>
     * {@link ItemVistoriaEntity#ItemVistoriaEntity(Long, String, Boolean, String, LocalDate)}
     *   <li>{@link ItemVistoriaEntity#setAtivo(Boolean)}
     *   <li>{@link ItemVistoriaEntity#setDataInclusao(LocalDate)}
     *   <li>{@link ItemVistoriaEntity#setDescricao(String)}
     *   <li>{@link ItemVistoriaEntity#setId(Long)}
     *   <li>{@link ItemVistoriaEntity#setNome(String)}
     *   <li>{@link ItemVistoriaEntity#getAtivo()}
     *   <li>{@link ItemVistoriaEntity#getDataInclusao()}
     *   <li>{@link ItemVistoriaEntity#getDescricao()}
     *   <li>{@link ItemVistoriaEntity#getId()}
     *   <li>{@link ItemVistoriaEntity#getNome()}
     * </ul>
     */
    @Test
    void testGettersAndSetters2() {
        // Arrange and Act
        ItemVistoriaEntity actualItemVistoriaEntity = new ItemVistoriaEntity(1L, "Nome", true, "Descricao",
                LocalDate.of(1970, 1, 1));
        actualItemVistoriaEntity.setAtivo(true);
        LocalDate dataInclusao = LocalDate.of(1970, 1, 1);
        actualItemVistoriaEntity.setDataInclusao(dataInclusao);
        actualItemVistoriaEntity.setDescricao("Descricao");
        actualItemVistoriaEntity.setId(1L);
        actualItemVistoriaEntity.setNome("Nome");
        Boolean actualAtivo = actualItemVistoriaEntity.getAtivo();
        LocalDate actualDataInclusao = actualItemVistoriaEntity.getDataInclusao();
        String actualDescricao = actualItemVistoriaEntity.getDescricao();
        Long actualId = actualItemVistoriaEntity.getId();

        // Assert that nothing has changed
        assertEquals("Descricao", actualDescricao);
        assertEquals("Nome", actualItemVistoriaEntity.getNome());
        assertEquals(1L, actualId.longValue());
        assertTrue(actualAtivo);
        assertSame(dataInclusao, actualDataInclusao);
    }
}
