package br.gov.df.pm.sgv.service.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isA;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import br.gov.df.pm.sgv.domain.DefeitosVistoriaEntity;
import br.gov.df.pm.sgv.domain.SubitemVistoriaEntity;
import br.gov.df.pm.sgv.domain.TipoDefeitoVistoriaEntity;
import br.gov.df.pm.sgv.dto.EdicaoTipoDefeitoVistoriaDTO;
import br.gov.df.pm.sgv.dto.TipoDefeitoVistoriaDTO;
import br.gov.df.pm.sgv.exceptions.TipoDefeitoVistoriaException;
import br.gov.df.pm.sgv.exceptions.VistoriaExceptions;
import br.gov.df.pm.sgv.repository.DefeitosVistoriaRepository;
import br.gov.df.pm.sgv.repository.TipoDefeitoVistoriaRepository;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ContextConfiguration(classes = {TipoDefeitoVistoriaServiceImpl.class})
@ExtendWith(SpringExtension.class)
class TipoDefeitoVistoriaServiceImplDiffblueTest {
    @MockBean
    private DefeitosVistoriaRepository defeitosVistoriaRepository;

    @MockBean
    private TipoDefeitoVistoriaRepository tipoDefeitoVistoriaRepository;

    @Autowired
    private TipoDefeitoVistoriaServiceImpl tipoDefeitoVistoriaServiceImpl;

    /**
     * Method under test: {@link TipoDefeitoVistoriaServiceImpl#buscarId(Long)}
     */
    @Test
    void testBuscarId() {
        // Arrange
        TipoDefeitoVistoriaEntity tipoDefeitoVistoriaEntity = new TipoDefeitoVistoriaEntity();
        tipoDefeitoVistoriaEntity.setAtivo(true);
        tipoDefeitoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoDefeitoVistoriaEntity.setDescricao("Descricao");
        tipoDefeitoVistoriaEntity.setId(1L);
        tipoDefeitoVistoriaEntity.setNome("Nome");
        Optional<TipoDefeitoVistoriaEntity> ofResult = Optional.of(tipoDefeitoVistoriaEntity);
        when(tipoDefeitoVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        // Act
        ResponseEntity<TipoDefeitoVistoriaDTO> actualBuscarIdResult = tipoDefeitoVistoriaServiceImpl.buscarId(1L);

        // Assert
        verify(tipoDefeitoVistoriaRepository).findById(eq(1L));
        TipoDefeitoVistoriaDTO body = actualBuscarIdResult.getBody();
        assertEquals("1970-01-01", body.getDataInclusao().toString());
        assertEquals("Descricao", body.getDescricao());
        assertEquals("Nome", body.getNome());
        assertEquals(1L, body.getId().longValue());
        assertEquals(HttpStatus.OK, actualBuscarIdResult.getStatusCode());
        assertTrue(body.getAtivo());
        assertTrue(actualBuscarIdResult.hasBody());
        assertTrue(actualBuscarIdResult.getHeaders().isEmpty());
    }

    /**
     * Method under test: {@link TipoDefeitoVistoriaServiceImpl#buscarId(Long)}
     */
    @Test
    void testBuscarId2() {
        // Arrange
        TipoDefeitoVistoriaEntity tipoDefeitoVistoriaEntity = mock(TipoDefeitoVistoriaEntity.class);
        when(tipoDefeitoVistoriaEntity.getAtivo()).thenReturn(true);
        when(tipoDefeitoVistoriaEntity.getId()).thenReturn(1L);
        when(tipoDefeitoVistoriaEntity.getDescricao()).thenReturn("Descricao");
        when(tipoDefeitoVistoriaEntity.getNome()).thenReturn("Nome");
        when(tipoDefeitoVistoriaEntity.getDataInclusao()).thenReturn(LocalDate.of(1970, 1, 1));
        doNothing().when(tipoDefeitoVistoriaEntity).setAtivo(Mockito.<Boolean>any());
        doNothing().when(tipoDefeitoVistoriaEntity).setDataInclusao(Mockito.<LocalDate>any());
        doNothing().when(tipoDefeitoVistoriaEntity).setDescricao(Mockito.<String>any());
        doNothing().when(tipoDefeitoVistoriaEntity).setId(Mockito.<Long>any());
        doNothing().when(tipoDefeitoVistoriaEntity).setNome(Mockito.<String>any());
        tipoDefeitoVistoriaEntity.setAtivo(true);
        tipoDefeitoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoDefeitoVistoriaEntity.setDescricao("Descricao");
        tipoDefeitoVistoriaEntity.setId(1L);
        tipoDefeitoVistoriaEntity.setNome("Nome");
        Optional<TipoDefeitoVistoriaEntity> ofResult = Optional.of(tipoDefeitoVistoriaEntity);
        when(tipoDefeitoVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        // Act
        ResponseEntity<TipoDefeitoVistoriaDTO> actualBuscarIdResult = tipoDefeitoVistoriaServiceImpl.buscarId(1L);

        // Assert
        verify(tipoDefeitoVistoriaEntity).getAtivo();
        verify(tipoDefeitoVistoriaEntity).getDataInclusao();
        verify(tipoDefeitoVistoriaEntity).getDescricao();
        verify(tipoDefeitoVistoriaEntity).getId();
        verify(tipoDefeitoVistoriaEntity).getNome();
        verify(tipoDefeitoVistoriaEntity).setAtivo(eq(true));
        verify(tipoDefeitoVistoriaEntity).setDataInclusao(isA(LocalDate.class));
        verify(tipoDefeitoVistoriaEntity).setDescricao(eq("Descricao"));
        verify(tipoDefeitoVistoriaEntity).setId(eq(1L));
        verify(tipoDefeitoVistoriaEntity).setNome(eq("Nome"));
        verify(tipoDefeitoVistoriaRepository).findById(eq(1L));
        TipoDefeitoVistoriaDTO body = actualBuscarIdResult.getBody();
        assertEquals("1970-01-01", body.getDataInclusao().toString());
        assertEquals("Descricao", body.getDescricao());
        assertEquals("Nome", body.getNome());
        assertEquals(1L, body.getId().longValue());
        assertEquals(HttpStatus.OK, actualBuscarIdResult.getStatusCode());
        assertTrue(body.getAtivo());
        assertTrue(actualBuscarIdResult.hasBody());
        assertTrue(actualBuscarIdResult.getHeaders().isEmpty());
    }

    /**
     * Method under test:
     * {@link TipoDefeitoVistoriaServiceImpl#buscar(String, Pageable)}
     */
    @Test
    void testBuscar() {
        // Arrange
        PageImpl<TipoDefeitoVistoriaEntity> pageImpl = new PageImpl<>(new ArrayList<>());
        when(tipoDefeitoVistoriaRepository.findAll(Mockito.<Specification<TipoDefeitoVistoriaEntity>>any(),
                Mockito.<Pageable>any())).thenReturn(pageImpl);

        // Act
        Page<TipoDefeitoVistoriaEntity> actualBuscarResult = tipoDefeitoVistoriaServiceImpl.buscar("Filter", null);

        // Assert
        verify(tipoDefeitoVistoriaRepository).findAll(isA(Specification.class), (Pageable) isNull());
        assertTrue(actualBuscarResult.toList().isEmpty());
        assertSame(pageImpl, actualBuscarResult);
    }

    /**
     * Method under test:
     * {@link TipoDefeitoVistoriaServiceImpl#buscar(String, Pageable)}
     */
    @Test
    void testBuscar2() {
        // Arrange
        when(tipoDefeitoVistoriaRepository.findAll(Mockito.<Specification<TipoDefeitoVistoriaEntity>>any(),
                Mockito.<Pageable>any())).thenThrow(new VistoriaExceptions("An error occurred"));

        // Act and Assert
        assertThrows(VistoriaExceptions.class, () -> tipoDefeitoVistoriaServiceImpl.buscar("Filter", null));
        verify(tipoDefeitoVistoriaRepository).findAll(isA(Specification.class), (Pageable) isNull());
    }

    /**
     * Method under test:
     * {@link TipoDefeitoVistoriaServiceImpl#salvar(TipoDefeitoVistoriaDTO)}
     */
    @Test
    void testSalvar() {
        // Arrange
        TipoDefeitoVistoriaEntity tipoDefeitoVistoriaEntity = new TipoDefeitoVistoriaEntity();
        tipoDefeitoVistoriaEntity.setAtivo(true);
        tipoDefeitoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoDefeitoVistoriaEntity.setDescricao("Descricao");
        tipoDefeitoVistoriaEntity.setId(1L);
        tipoDefeitoVistoriaEntity.setNome("Nome");
        Optional<TipoDefeitoVistoriaEntity> ofResult = Optional.of(tipoDefeitoVistoriaEntity);
        when(tipoDefeitoVistoriaRepository.findByNome(Mockito.<String>any())).thenReturn(ofResult);
        TipoDefeitoVistoriaDTO.TipoDefeitoVistoriaDTOBuilder ativoResult = TipoDefeitoVistoriaDTO.builder().ativo(true);
        TipoDefeitoVistoriaDTO tipoDefeito = ativoResult.dataInclusao(LocalDate.of(1970, 1, 1))
                .descricao("Descricao")
                .id(1L)
                .nome("Nome")
                .build();

        // Act and Assert
        assertThrows(VistoriaExceptions.class, () -> tipoDefeitoVistoriaServiceImpl.salvar(tipoDefeito));
        verify(tipoDefeitoVistoriaRepository).findByNome(eq("Nome"));
    }

    /**
     * Method under test:
     * {@link TipoDefeitoVistoriaServiceImpl#salvar(TipoDefeitoVistoriaDTO)}
     */
    @Test
    void testSalvar2() {
        // Arrange
        TipoDefeitoVistoriaEntity tipoDefeitoVistoriaEntity = new TipoDefeitoVistoriaEntity();
        tipoDefeitoVistoriaEntity.setAtivo(true);
        tipoDefeitoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoDefeitoVistoriaEntity.setDescricao("Descricao");
        tipoDefeitoVistoriaEntity.setId(1L);
        tipoDefeitoVistoriaEntity.setNome("Nome");
        when(tipoDefeitoVistoriaRepository.save(Mockito.<TipoDefeitoVistoriaEntity>any()))
                .thenReturn(tipoDefeitoVistoriaEntity);
        Optional<TipoDefeitoVistoriaEntity> emptyResult = Optional.empty();
        when(tipoDefeitoVistoriaRepository.findByNome(Mockito.<String>any())).thenReturn(emptyResult);
        TipoDefeitoVistoriaDTO.TipoDefeitoVistoriaDTOBuilder ativoResult = TipoDefeitoVistoriaDTO.builder().ativo(true);
        TipoDefeitoVistoriaDTO tipoDefeito = ativoResult.dataInclusao(LocalDate.of(1970, 1, 1))
                .descricao("Descricao")
                .id(1L)
                .nome("Nome")
                .build();

        // Act
        ResponseEntity<?> actualSalvarResult = tipoDefeitoVistoriaServiceImpl.salvar(tipoDefeito);

        // Assert
        verify(tipoDefeitoVistoriaRepository).findByNome(eq("Nome"));
        verify(tipoDefeitoVistoriaRepository).save(isA(TipoDefeitoVistoriaEntity.class));
        assertEquals(HttpStatus.OK, actualSalvarResult.getStatusCode());
        assertTrue(actualSalvarResult.hasBody());
        assertTrue(actualSalvarResult.getHeaders().isEmpty());
    }

    /**
     * Method under test:
     * {@link TipoDefeitoVistoriaServiceImpl#salvar(TipoDefeitoVistoriaDTO)}
     */
    @Test
    void testSalvar3() {
        // Arrange
        TipoDefeitoVistoriaDTO.TipoDefeitoVistoriaDTOBuilder ativoResult = TipoDefeitoVistoriaDTO.builder().ativo(true);
        TipoDefeitoVistoriaDTO tipoDefeito = ativoResult.dataInclusao(LocalDate.of(1970, 1, 1))
                .descricao("Descricao")
                .id(1L)
                .nome("")
                .build();

        // Act and Assert
        assertThrows(VistoriaExceptions.class, () -> tipoDefeitoVistoriaServiceImpl.salvar(tipoDefeito));
    }

    /**
     * Method under test:
     * {@link TipoDefeitoVistoriaServiceImpl#salvar(TipoDefeitoVistoriaDTO)}
     */
    @Test
    void testSalvar4() {
        // Arrange
        when(tipoDefeitoVistoriaRepository.findByNome(Mockito.<String>any()))
                .thenThrow(new IllegalArgumentException("foo"));
        TipoDefeitoVistoriaDTO.TipoDefeitoVistoriaDTOBuilder ativoResult = TipoDefeitoVistoriaDTO.builder().ativo(true);
        TipoDefeitoVistoriaDTO tipoDefeito = ativoResult.dataInclusao(LocalDate.of(1970, 1, 1))
                .descricao("Descricao")
                .id(1L)
                .nome("Nome")
                .build();

        // Act and Assert
        assertThrows(IllegalArgumentException.class, () -> tipoDefeitoVistoriaServiceImpl.salvar(tipoDefeito));
        verify(tipoDefeitoVistoriaRepository).findByNome(eq("Nome"));
    }

    /**
     * Method under test:
     * {@link TipoDefeitoVistoriaServiceImpl#editar(Long, EdicaoTipoDefeitoVistoriaDTO)}
     */
    @Test
    void testEditar() {
        // Arrange
        TipoDefeitoVistoriaEntity tipoDefeitoVistoriaEntity = new TipoDefeitoVistoriaEntity();
        tipoDefeitoVistoriaEntity.setAtivo(true);
        tipoDefeitoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoDefeitoVistoriaEntity.setDescricao("Descricao");
        tipoDefeitoVistoriaEntity.setId(1L);
        tipoDefeitoVistoriaEntity.setNome("Nome");
        Optional<TipoDefeitoVistoriaEntity> ofResult = Optional.of(tipoDefeitoVistoriaEntity);
        when(tipoDefeitoVistoriaRepository.findByNome(Mockito.<String>any())).thenReturn(ofResult);
        EdicaoTipoDefeitoVistoriaDTO edicao = EdicaoTipoDefeitoVistoriaDTO.builder()
                .descricao("Descricao")
                .nome("Nome")
                .build();

        // Act and Assert
        assertThrows(VistoriaExceptions.class, () -> tipoDefeitoVistoriaServiceImpl.editar(1L, edicao));
        verify(tipoDefeitoVistoriaRepository).findByNome(eq("Nome"));
    }

    /**
     * Method under test:
     * {@link TipoDefeitoVistoriaServiceImpl#editar(Long, EdicaoTipoDefeitoVistoriaDTO)}
     */
    @Test
    void testEditar2() {
        // Arrange
        TipoDefeitoVistoriaEntity tipoDefeitoVistoriaEntity = new TipoDefeitoVistoriaEntity();
        tipoDefeitoVistoriaEntity.setAtivo(true);
        tipoDefeitoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoDefeitoVistoriaEntity.setDescricao("Descricao");
        tipoDefeitoVistoriaEntity.setId(1L);
        tipoDefeitoVistoriaEntity.setNome("Nome");
        Optional<TipoDefeitoVistoriaEntity> ofResult = Optional.of(tipoDefeitoVistoriaEntity);

        TipoDefeitoVistoriaEntity tipoDefeitoVistoriaEntity2 = new TipoDefeitoVistoriaEntity();
        tipoDefeitoVistoriaEntity2.setAtivo(true);
        tipoDefeitoVistoriaEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoDefeitoVistoriaEntity2.setDescricao("Descricao");
        tipoDefeitoVistoriaEntity2.setId(1L);
        tipoDefeitoVistoriaEntity2.setNome("Nome");
        when(tipoDefeitoVistoriaRepository.save(Mockito.<TipoDefeitoVistoriaEntity>any()))
                .thenReturn(tipoDefeitoVistoriaEntity2);
        Optional<TipoDefeitoVistoriaEntity> emptyResult = Optional.empty();
        when(tipoDefeitoVistoriaRepository.findByNome(Mockito.<String>any())).thenReturn(emptyResult);
        when(tipoDefeitoVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);
        EdicaoTipoDefeitoVistoriaDTO edicao = EdicaoTipoDefeitoVistoriaDTO.builder()
                .descricao("Descricao")
                .nome("Nome")
                .build();

        // Act
        ResponseEntity<?> actualEditarResult = tipoDefeitoVistoriaServiceImpl.editar(1L, edicao);

        // Assert
        verify(tipoDefeitoVistoriaRepository).findByNome(eq("Nome"));
        verify(tipoDefeitoVistoriaRepository).findById(eq(1L));
        verify(tipoDefeitoVistoriaRepository).save(isA(TipoDefeitoVistoriaEntity.class));
        assertEquals(HttpStatus.OK, actualEditarResult.getStatusCode());
        assertTrue(actualEditarResult.hasBody());
        assertTrue(actualEditarResult.getHeaders().isEmpty());
    }

    /**
     * Method under test:
     * {@link TipoDefeitoVistoriaServiceImpl#editar(Long, EdicaoTipoDefeitoVistoriaDTO)}
     */
    @Test
    void testEditar3() {
        // Arrange
        TipoDefeitoVistoriaEntity tipoDefeitoVistoriaEntity = mock(TipoDefeitoVistoriaEntity.class);
        doNothing().when(tipoDefeitoVistoriaEntity).setAtivo(Mockito.<Boolean>any());
        doNothing().when(tipoDefeitoVistoriaEntity).setDataInclusao(Mockito.<LocalDate>any());
        doNothing().when(tipoDefeitoVistoriaEntity).setDescricao(Mockito.<String>any());
        doNothing().when(tipoDefeitoVistoriaEntity).setId(Mockito.<Long>any());
        doNothing().when(tipoDefeitoVistoriaEntity).setNome(Mockito.<String>any());
        tipoDefeitoVistoriaEntity.setAtivo(true);
        tipoDefeitoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoDefeitoVistoriaEntity.setDescricao("Descricao");
        tipoDefeitoVistoriaEntity.setId(1L);
        tipoDefeitoVistoriaEntity.setNome("Nome");
        Optional<TipoDefeitoVistoriaEntity> ofResult = Optional.of(tipoDefeitoVistoriaEntity);

        TipoDefeitoVistoriaEntity tipoDefeitoVistoriaEntity2 = new TipoDefeitoVistoriaEntity();
        tipoDefeitoVistoriaEntity2.setAtivo(true);
        tipoDefeitoVistoriaEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoDefeitoVistoriaEntity2.setDescricao("Descricao");
        tipoDefeitoVistoriaEntity2.setId(1L);
        tipoDefeitoVistoriaEntity2.setNome("Nome");
        when(tipoDefeitoVistoriaRepository.save(Mockito.<TipoDefeitoVistoriaEntity>any()))
                .thenReturn(tipoDefeitoVistoriaEntity2);
        Optional<TipoDefeitoVistoriaEntity> emptyResult = Optional.empty();
        when(tipoDefeitoVistoriaRepository.findByNome(Mockito.<String>any())).thenReturn(emptyResult);
        when(tipoDefeitoVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);
        EdicaoTipoDefeitoVistoriaDTO edicao = EdicaoTipoDefeitoVistoriaDTO.builder()
                .descricao("Descricao")
                .nome("Nome")
                .build();

        // Act
        ResponseEntity<?> actualEditarResult = tipoDefeitoVistoriaServiceImpl.editar(1L, edicao);

        // Assert
        verify(tipoDefeitoVistoriaEntity).setAtivo(eq(true));
        verify(tipoDefeitoVistoriaEntity).setDataInclusao(isA(LocalDate.class));
        verify(tipoDefeitoVistoriaEntity, atLeast(1)).setDescricao(eq("Descricao"));
        verify(tipoDefeitoVistoriaEntity).setId(eq(1L));
        verify(tipoDefeitoVistoriaEntity, atLeast(1)).setNome(eq("Nome"));
        verify(tipoDefeitoVistoriaRepository).findByNome(eq("Nome"));
        verify(tipoDefeitoVistoriaRepository).findById(eq(1L));
        verify(tipoDefeitoVistoriaRepository).save(isA(TipoDefeitoVistoriaEntity.class));
        assertEquals(HttpStatus.OK, actualEditarResult.getStatusCode());
        assertTrue(actualEditarResult.hasBody());
        assertTrue(actualEditarResult.getHeaders().isEmpty());
    }

    /**
     * Method under test:
     * {@link TipoDefeitoVistoriaServiceImpl#editar(Long, EdicaoTipoDefeitoVistoriaDTO)}
     */
    @Test
    void testEditar4() {
        // Arrange
        TipoDefeitoVistoriaEntity tipoDefeitoVistoriaEntity = mock(TipoDefeitoVistoriaEntity.class);
        doNothing().when(tipoDefeitoVistoriaEntity).setAtivo(Mockito.<Boolean>any());
        doNothing().when(tipoDefeitoVistoriaEntity).setDataInclusao(Mockito.<LocalDate>any());
        doNothing().when(tipoDefeitoVistoriaEntity).setDescricao(Mockito.<String>any());
        doNothing().when(tipoDefeitoVistoriaEntity).setId(Mockito.<Long>any());
        doNothing().when(tipoDefeitoVistoriaEntity).setNome(Mockito.<String>any());
        tipoDefeitoVistoriaEntity.setAtivo(true);
        tipoDefeitoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoDefeitoVistoriaEntity.setDescricao("Descricao");
        tipoDefeitoVistoriaEntity.setId(1L);
        tipoDefeitoVistoriaEntity.setNome("Nome");
        Optional<TipoDefeitoVistoriaEntity> ofResult = Optional.of(tipoDefeitoVistoriaEntity);

        TipoDefeitoVistoriaEntity tipoDefeitoVistoriaEntity2 = new TipoDefeitoVistoriaEntity();
        tipoDefeitoVistoriaEntity2.setAtivo(true);
        tipoDefeitoVistoriaEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoDefeitoVistoriaEntity2.setDescricao("Descricao");
        tipoDefeitoVistoriaEntity2.setId(1L);
        tipoDefeitoVistoriaEntity2.setNome("Nome");
        when(tipoDefeitoVistoriaRepository.save(Mockito.<TipoDefeitoVistoriaEntity>any()))
                .thenReturn(tipoDefeitoVistoriaEntity2);
        Optional<TipoDefeitoVistoriaEntity> emptyResult = Optional.empty();
        when(tipoDefeitoVistoriaRepository.findByNome(Mockito.<String>any())).thenReturn(emptyResult);
        when(tipoDefeitoVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);
        EdicaoTipoDefeitoVistoriaDTO.EdicaoTipoDefeitoVistoriaDTOBuilder edicaoTipoDefeitoVistoriaDTOBuilder = mock(
                EdicaoTipoDefeitoVistoriaDTO.EdicaoTipoDefeitoVistoriaDTOBuilder.class);
        when(edicaoTipoDefeitoVistoriaDTOBuilder.descricao(Mockito.<String>any()))
                .thenReturn(EdicaoTipoDefeitoVistoriaDTO.builder());
        EdicaoTipoDefeitoVistoriaDTO edicao = edicaoTipoDefeitoVistoriaDTOBuilder.descricao("Descricao")
                .nome("Nome")
                .build();

        // Act
        ResponseEntity<?> actualEditarResult = tipoDefeitoVistoriaServiceImpl.editar(1L, edicao);

        // Assert
        verify(tipoDefeitoVistoriaEntity).setAtivo(eq(true));
        verify(tipoDefeitoVistoriaEntity).setDataInclusao(isA(LocalDate.class));
        verify(tipoDefeitoVistoriaEntity).setDescricao(eq("Descricao"));
        verify(tipoDefeitoVistoriaEntity).setId(eq(1L));
        verify(tipoDefeitoVistoriaEntity, atLeast(1)).setNome(eq("Nome"));
        verify(edicaoTipoDefeitoVistoriaDTOBuilder).descricao(eq("Descricao"));
        verify(tipoDefeitoVistoriaRepository).findByNome(eq("Nome"));
        verify(tipoDefeitoVistoriaRepository).findById(eq(1L));
        verify(tipoDefeitoVistoriaRepository).save(isA(TipoDefeitoVistoriaEntity.class));
        assertEquals(HttpStatus.OK, actualEditarResult.getStatusCode());
        assertTrue(actualEditarResult.hasBody());
        assertTrue(actualEditarResult.getHeaders().isEmpty());
    }

    /**
     * Method under test: {@link TipoDefeitoVistoriaServiceImpl#desativar(Long)}
     */
    @Test
    void testDesativar() {
        // Arrange
        when(defeitosVistoriaRepository.findAllByCodTipoDefeito(Mockito.<TipoDefeitoVistoriaEntity>any()))
                .thenReturn(new ArrayList<>());

        TipoDefeitoVistoriaEntity tipoDefeitoVistoriaEntity = new TipoDefeitoVistoriaEntity();
        tipoDefeitoVistoriaEntity.setAtivo(true);
        tipoDefeitoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoDefeitoVistoriaEntity.setDescricao("Descricao");
        tipoDefeitoVistoriaEntity.setId(1L);
        tipoDefeitoVistoriaEntity.setNome("Nome");
        Optional<TipoDefeitoVistoriaEntity> ofResult = Optional.of(tipoDefeitoVistoriaEntity);

        TipoDefeitoVistoriaEntity tipoDefeitoVistoriaEntity2 = new TipoDefeitoVistoriaEntity();
        tipoDefeitoVistoriaEntity2.setAtivo(true);
        tipoDefeitoVistoriaEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoDefeitoVistoriaEntity2.setDescricao("Descricao");
        tipoDefeitoVistoriaEntity2.setId(1L);
        tipoDefeitoVistoriaEntity2.setNome("Nome");
        when(tipoDefeitoVistoriaRepository.save(Mockito.<TipoDefeitoVistoriaEntity>any()))
                .thenReturn(tipoDefeitoVistoriaEntity2);
        when(tipoDefeitoVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        // Act
        ResponseEntity<?> actualDesativarResult = tipoDefeitoVistoriaServiceImpl.desativar(1L);

        // Assert
        verify(defeitosVistoriaRepository).findAllByCodTipoDefeito(isA(TipoDefeitoVistoriaEntity.class));
        verify(tipoDefeitoVistoriaRepository).findById(eq(1L));
        verify(tipoDefeitoVistoriaRepository).save(isA(TipoDefeitoVistoriaEntity.class));
        assertNull(actualDesativarResult.getBody());
        assertEquals(HttpStatus.OK, actualDesativarResult.getStatusCode());
        assertTrue(actualDesativarResult.getHeaders().isEmpty());
    }

    /**
     * Method under test: {@link TipoDefeitoVistoriaServiceImpl#desativar(Long)}
     */
    @Test
    void testDesativar2() {
        // Arrange
        when(defeitosVistoriaRepository.findAllByCodTipoDefeito(Mockito.<TipoDefeitoVistoriaEntity>any()))
                .thenReturn(new ArrayList<>());

        TipoDefeitoVistoriaEntity tipoDefeitoVistoriaEntity = new TipoDefeitoVistoriaEntity();
        tipoDefeitoVistoriaEntity.setAtivo(true);
        tipoDefeitoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoDefeitoVistoriaEntity.setDescricao("Descricao");
        tipoDefeitoVistoriaEntity.setId(1L);
        tipoDefeitoVistoriaEntity.setNome("Nome");
        Optional<TipoDefeitoVistoriaEntity> ofResult = Optional.of(tipoDefeitoVistoriaEntity);
        when(tipoDefeitoVistoriaRepository.save(Mockito.<TipoDefeitoVistoriaEntity>any()))
                .thenThrow(new VistoriaExceptions("An error occurred"));
        when(tipoDefeitoVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        // Act and Assert
        assertThrows(VistoriaExceptions.class, () -> tipoDefeitoVistoriaServiceImpl.desativar(1L));
        verify(defeitosVistoriaRepository).findAllByCodTipoDefeito(isA(TipoDefeitoVistoriaEntity.class));
        verify(tipoDefeitoVistoriaRepository).findById(eq(1L));
        verify(tipoDefeitoVistoriaRepository).save(isA(TipoDefeitoVistoriaEntity.class));
    }

    /**
     * Method under test: {@link TipoDefeitoVistoriaServiceImpl#desativar(Long)}
     */
    @Test
    void testDesativar3() {
        // Arrange
        SubitemVistoriaEntity codSubitem = new SubitemVistoriaEntity();
        codSubitem.setAtivo(true);
        codSubitem.setDataInclusao(LocalDate.of(1970, 1, 1));
        codSubitem.setDescricao("Descricao");
        codSubitem.setId(1L);
        codSubitem.setNome("Nome");

        TipoDefeitoVistoriaEntity codTipoDefeito = new TipoDefeitoVistoriaEntity();
        codTipoDefeito.setAtivo(true);
        codTipoDefeito.setDataInclusao(LocalDate.of(1970, 1, 1));
        codTipoDefeito.setDescricao("Descricao");
        codTipoDefeito.setId(1L);
        codTipoDefeito.setNome("Nome");

        DefeitosVistoriaEntity defeitosVistoriaEntity = new DefeitosVistoriaEntity();
        defeitosVistoriaEntity.setAtivo(true);
        defeitosVistoriaEntity.setCodSubitem(codSubitem);
        defeitosVistoriaEntity.setCodTipoDefeito(codTipoDefeito);
        defeitosVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        defeitosVistoriaEntity.setId(1L);

        ArrayList<DefeitosVistoriaEntity> defeitosVistoriaEntityList = new ArrayList<>();
        defeitosVistoriaEntityList.add(defeitosVistoriaEntity);
        when(defeitosVistoriaRepository.findAllByCodTipoDefeito(Mockito.<TipoDefeitoVistoriaEntity>any()))
                .thenReturn(defeitosVistoriaEntityList);

        TipoDefeitoVistoriaEntity tipoDefeitoVistoriaEntity = new TipoDefeitoVistoriaEntity();
        tipoDefeitoVistoriaEntity.setAtivo(true);
        tipoDefeitoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoDefeitoVistoriaEntity.setDescricao("Descricao");
        tipoDefeitoVistoriaEntity.setId(1L);
        tipoDefeitoVistoriaEntity.setNome("Nome");
        Optional<TipoDefeitoVistoriaEntity> ofResult = Optional.of(tipoDefeitoVistoriaEntity);
        when(tipoDefeitoVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        // Act and Assert
        assertThrows(VistoriaExceptions.class, () -> tipoDefeitoVistoriaServiceImpl.desativar(1L));
        verify(defeitosVistoriaRepository).findAllByCodTipoDefeito(isA(TipoDefeitoVistoriaEntity.class));
        verify(tipoDefeitoVistoriaRepository).findById(eq(1L));
    }

    /**
     * Method under test: {@link TipoDefeitoVistoriaServiceImpl#desativar(Long)}
     */
    @Test
    void testDesativar4() {
        // Arrange
        when(defeitosVistoriaRepository.findAllByCodTipoDefeito(Mockito.<TipoDefeitoVistoriaEntity>any()))
                .thenReturn(new ArrayList<>());
        TipoDefeitoVistoriaEntity tipoDefeitoVistoriaEntity = mock(TipoDefeitoVistoriaEntity.class);
        doNothing().when(tipoDefeitoVistoriaEntity).setAtivo(Mockito.<Boolean>any());
        doNothing().when(tipoDefeitoVistoriaEntity).setDataInclusao(Mockito.<LocalDate>any());
        doNothing().when(tipoDefeitoVistoriaEntity).setDescricao(Mockito.<String>any());
        doNothing().when(tipoDefeitoVistoriaEntity).setId(Mockito.<Long>any());
        doNothing().when(tipoDefeitoVistoriaEntity).setNome(Mockito.<String>any());
        tipoDefeitoVistoriaEntity.setAtivo(true);
        tipoDefeitoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoDefeitoVistoriaEntity.setDescricao("Descricao");
        tipoDefeitoVistoriaEntity.setId(1L);
        tipoDefeitoVistoriaEntity.setNome("Nome");
        Optional<TipoDefeitoVistoriaEntity> ofResult = Optional.of(tipoDefeitoVistoriaEntity);

        TipoDefeitoVistoriaEntity tipoDefeitoVistoriaEntity2 = new TipoDefeitoVistoriaEntity();
        tipoDefeitoVistoriaEntity2.setAtivo(true);
        tipoDefeitoVistoriaEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoDefeitoVistoriaEntity2.setDescricao("Descricao");
        tipoDefeitoVistoriaEntity2.setId(1L);
        tipoDefeitoVistoriaEntity2.setNome("Nome");
        when(tipoDefeitoVistoriaRepository.save(Mockito.<TipoDefeitoVistoriaEntity>any()))
                .thenReturn(tipoDefeitoVistoriaEntity2);
        when(tipoDefeitoVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        // Act
        ResponseEntity<?> actualDesativarResult = tipoDefeitoVistoriaServiceImpl.desativar(1L);

        // Assert
        verify(tipoDefeitoVistoriaEntity, atLeast(1)).setAtivo(Mockito.<Boolean>any());
        verify(tipoDefeitoVistoriaEntity).setDataInclusao(isA(LocalDate.class));
        verify(tipoDefeitoVistoriaEntity).setDescricao(eq("Descricao"));
        verify(tipoDefeitoVistoriaEntity).setId(eq(1L));
        verify(tipoDefeitoVistoriaEntity).setNome(eq("Nome"));
        verify(defeitosVistoriaRepository).findAllByCodTipoDefeito(isA(TipoDefeitoVistoriaEntity.class));
        verify(tipoDefeitoVistoriaRepository).findById(eq(1L));
        verify(tipoDefeitoVistoriaRepository).save(isA(TipoDefeitoVistoriaEntity.class));
        assertNull(actualDesativarResult.getBody());
        assertEquals(HttpStatus.OK, actualDesativarResult.getStatusCode());
        assertTrue(actualDesativarResult.getHeaders().isEmpty());
    }

    /**
     * Method under test: {@link TipoDefeitoVistoriaServiceImpl#excluir(Long)}
     */
    @Test
    void testExcluir() {
        // Arrange
        when(defeitosVistoriaRepository.findAllByCodTipoDefeito(Mockito.<TipoDefeitoVistoriaEntity>any()))
                .thenReturn(new ArrayList<>());

        TipoDefeitoVistoriaEntity tipoDefeitoVistoriaEntity = new TipoDefeitoVistoriaEntity();
        tipoDefeitoVistoriaEntity.setAtivo(true);
        tipoDefeitoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoDefeitoVistoriaEntity.setDescricao("Descricao");
        tipoDefeitoVistoriaEntity.setId(1L);
        tipoDefeitoVistoriaEntity.setNome("Nome");
        Optional<TipoDefeitoVistoriaEntity> ofResult = Optional.of(tipoDefeitoVistoriaEntity);
        doNothing().when(tipoDefeitoVistoriaRepository).delete(Mockito.<TipoDefeitoVistoriaEntity>any());
        when(tipoDefeitoVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        // Act
        ResponseEntity<?> actualExcluirResult = tipoDefeitoVistoriaServiceImpl.excluir(1L);

        // Assert
        verify(defeitosVistoriaRepository).findAllByCodTipoDefeito(isA(TipoDefeitoVistoriaEntity.class));
        verify(tipoDefeitoVistoriaRepository).delete(isA(TipoDefeitoVistoriaEntity.class));
        verify(tipoDefeitoVistoriaRepository).findById(eq(1L));
        assertNull(actualExcluirResult.getBody());
        assertEquals(HttpStatus.OK, actualExcluirResult.getStatusCode());
        assertTrue(actualExcluirResult.getHeaders().isEmpty());
    }

    /**
     * Method under test: {@link TipoDefeitoVistoriaServiceImpl#excluir(Long)}
     */
    @Test
    void testExcluir2() {
        // Arrange
        when(defeitosVistoriaRepository.findAllByCodTipoDefeito(Mockito.<TipoDefeitoVistoriaEntity>any()))
                .thenReturn(new ArrayList<>());

        TipoDefeitoVistoriaEntity tipoDefeitoVistoriaEntity = new TipoDefeitoVistoriaEntity();
        tipoDefeitoVistoriaEntity.setAtivo(true);
        tipoDefeitoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoDefeitoVistoriaEntity.setDescricao("Descricao");
        tipoDefeitoVistoriaEntity.setId(1L);
        tipoDefeitoVistoriaEntity.setNome("Nome");
        Optional<TipoDefeitoVistoriaEntity> ofResult = Optional.of(tipoDefeitoVistoriaEntity);
        doThrow(new VistoriaExceptions("An error occurred")).when(tipoDefeitoVistoriaRepository)
                .delete(Mockito.<TipoDefeitoVistoriaEntity>any());
        when(tipoDefeitoVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        // Act and Assert
        assertThrows(VistoriaExceptions.class, () -> tipoDefeitoVistoriaServiceImpl.excluir(1L));
        verify(defeitosVistoriaRepository).findAllByCodTipoDefeito(isA(TipoDefeitoVistoriaEntity.class));
        verify(tipoDefeitoVistoriaRepository).delete(isA(TipoDefeitoVistoriaEntity.class));
        verify(tipoDefeitoVistoriaRepository).findById(eq(1L));
    }

    /**
     * Method under test: {@link TipoDefeitoVistoriaServiceImpl#excluir(Long)}
     */
    @Test
    void testExcluir3() {
        // Arrange
        SubitemVistoriaEntity codSubitem = new SubitemVistoriaEntity();
        codSubitem.setAtivo(true);
        codSubitem.setDataInclusao(LocalDate.of(1970, 1, 1));
        codSubitem.setDescricao("Descricao");
        codSubitem.setId(1L);
        codSubitem.setNome("Nome");

        TipoDefeitoVistoriaEntity codTipoDefeito = new TipoDefeitoVistoriaEntity();
        codTipoDefeito.setAtivo(true);
        codTipoDefeito.setDataInclusao(LocalDate.of(1970, 1, 1));
        codTipoDefeito.setDescricao("Descricao");
        codTipoDefeito.setId(1L);
        codTipoDefeito.setNome("Nome");

        DefeitosVistoriaEntity defeitosVistoriaEntity = new DefeitosVistoriaEntity();
        defeitosVistoriaEntity.setAtivo(true);
        defeitosVistoriaEntity.setCodSubitem(codSubitem);
        defeitosVistoriaEntity.setCodTipoDefeito(codTipoDefeito);
        defeitosVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        defeitosVistoriaEntity.setId(1L);

        ArrayList<DefeitosVistoriaEntity> defeitosVistoriaEntityList = new ArrayList<>();
        defeitosVistoriaEntityList.add(defeitosVistoriaEntity);
        when(defeitosVistoriaRepository.findAllByCodTipoDefeito(Mockito.<TipoDefeitoVistoriaEntity>any()))
                .thenReturn(defeitosVistoriaEntityList);

        TipoDefeitoVistoriaEntity tipoDefeitoVistoriaEntity = new TipoDefeitoVistoriaEntity();
        tipoDefeitoVistoriaEntity.setAtivo(true);
        tipoDefeitoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoDefeitoVistoriaEntity.setDescricao("Descricao");
        tipoDefeitoVistoriaEntity.setId(1L);
        tipoDefeitoVistoriaEntity.setNome("Nome");
        Optional<TipoDefeitoVistoriaEntity> ofResult = Optional.of(tipoDefeitoVistoriaEntity);
        when(tipoDefeitoVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        // Act and Assert
        assertThrows(VistoriaExceptions.class, () -> tipoDefeitoVistoriaServiceImpl.excluir(1L));
        verify(defeitosVistoriaRepository).findAllByCodTipoDefeito(isA(TipoDefeitoVistoriaEntity.class));
        verify(tipoDefeitoVistoriaRepository).findById(eq(1L));
    }

    /**
     * Method under test: {@link TipoDefeitoVistoriaServiceImpl#ativar(Long)}
     */
    @Test
    void testAtivar() {
        // Arrange
        TipoDefeitoVistoriaEntity tipoDefeitoVistoriaEntity = new TipoDefeitoVistoriaEntity();
        tipoDefeitoVistoriaEntity.setAtivo(true);
        tipoDefeitoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoDefeitoVistoriaEntity.setDescricao("Descricao");
        tipoDefeitoVistoriaEntity.setId(1L);
        tipoDefeitoVistoriaEntity.setNome("Nome");
        Optional<TipoDefeitoVistoriaEntity> ofResult = Optional.of(tipoDefeitoVistoriaEntity);

        TipoDefeitoVistoriaEntity tipoDefeitoVistoriaEntity2 = new TipoDefeitoVistoriaEntity();
        tipoDefeitoVistoriaEntity2.setAtivo(true);
        tipoDefeitoVistoriaEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoDefeitoVistoriaEntity2.setDescricao("Descricao");
        tipoDefeitoVistoriaEntity2.setId(1L);
        tipoDefeitoVistoriaEntity2.setNome("Nome");
        when(tipoDefeitoVistoriaRepository.save(Mockito.<TipoDefeitoVistoriaEntity>any()))
                .thenReturn(tipoDefeitoVistoriaEntity2);
        when(tipoDefeitoVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        // Act
        ResponseEntity<?> actualAtivarResult = tipoDefeitoVistoriaServiceImpl.ativar(1L);

        // Assert
        verify(tipoDefeitoVistoriaRepository).findById(eq(1L));
        verify(tipoDefeitoVistoriaRepository).save(isA(TipoDefeitoVistoriaEntity.class));
        assertNull(actualAtivarResult.getBody());
        assertEquals(HttpStatus.OK, actualAtivarResult.getStatusCode());
        assertTrue(actualAtivarResult.getHeaders().isEmpty());
    }

    /**
     * Method under test: {@link TipoDefeitoVistoriaServiceImpl#ativar(Long)}
     */
    @Test
    void testAtivar2() {
        // Arrange
        TipoDefeitoVistoriaEntity tipoDefeitoVistoriaEntity = new TipoDefeitoVistoriaEntity();
        tipoDefeitoVistoriaEntity.setAtivo(true);
        tipoDefeitoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoDefeitoVistoriaEntity.setDescricao("Descricao");
        tipoDefeitoVistoriaEntity.setId(1L);
        tipoDefeitoVistoriaEntity.setNome("Nome");
        Optional<TipoDefeitoVistoriaEntity> ofResult = Optional.of(tipoDefeitoVistoriaEntity);
        when(tipoDefeitoVistoriaRepository.save(Mockito.<TipoDefeitoVistoriaEntity>any()))
                .thenThrow(new VistoriaExceptions("An error occurred"));
        when(tipoDefeitoVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        // Act and Assert
        assertThrows(VistoriaExceptions.class, () -> tipoDefeitoVistoriaServiceImpl.ativar(1L));
        verify(tipoDefeitoVistoriaRepository).findById(eq(1L));
        verify(tipoDefeitoVistoriaRepository).save(isA(TipoDefeitoVistoriaEntity.class));
    }

    /**
     * Method under test: {@link TipoDefeitoVistoriaServiceImpl#ativar(Long)}
     */
    @Test
    void testAtivar3() {
        // Arrange
        TipoDefeitoVistoriaEntity tipoDefeitoVistoriaEntity = mock(TipoDefeitoVistoriaEntity.class);
        doNothing().when(tipoDefeitoVistoriaEntity).setAtivo(Mockito.<Boolean>any());
        doNothing().when(tipoDefeitoVistoriaEntity).setDataInclusao(Mockito.<LocalDate>any());
        doNothing().when(tipoDefeitoVistoriaEntity).setDescricao(Mockito.<String>any());
        doNothing().when(tipoDefeitoVistoriaEntity).setId(Mockito.<Long>any());
        doNothing().when(tipoDefeitoVistoriaEntity).setNome(Mockito.<String>any());
        tipoDefeitoVistoriaEntity.setAtivo(true);
        tipoDefeitoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoDefeitoVistoriaEntity.setDescricao("Descricao");
        tipoDefeitoVistoriaEntity.setId(1L);
        tipoDefeitoVistoriaEntity.setNome("Nome");
        Optional<TipoDefeitoVistoriaEntity> ofResult = Optional.of(tipoDefeitoVistoriaEntity);

        TipoDefeitoVistoriaEntity tipoDefeitoVistoriaEntity2 = new TipoDefeitoVistoriaEntity();
        tipoDefeitoVistoriaEntity2.setAtivo(true);
        tipoDefeitoVistoriaEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoDefeitoVistoriaEntity2.setDescricao("Descricao");
        tipoDefeitoVistoriaEntity2.setId(1L);
        tipoDefeitoVistoriaEntity2.setNome("Nome");
        when(tipoDefeitoVistoriaRepository.save(Mockito.<TipoDefeitoVistoriaEntity>any()))
                .thenReturn(tipoDefeitoVistoriaEntity2);
        when(tipoDefeitoVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        // Act
        ResponseEntity<?> actualAtivarResult = tipoDefeitoVistoriaServiceImpl.ativar(1L);

        // Assert
        verify(tipoDefeitoVistoriaEntity, atLeast(1)).setAtivo(eq(true));
        verify(tipoDefeitoVistoriaEntity).setDataInclusao(isA(LocalDate.class));
        verify(tipoDefeitoVistoriaEntity).setDescricao(eq("Descricao"));
        verify(tipoDefeitoVistoriaEntity).setId(eq(1L));
        verify(tipoDefeitoVistoriaEntity).setNome(eq("Nome"));
        verify(tipoDefeitoVistoriaRepository).findById(eq(1L));
        verify(tipoDefeitoVistoriaRepository).save(isA(TipoDefeitoVistoriaEntity.class));
        assertNull(actualAtivarResult.getBody());
        assertEquals(HttpStatus.OK, actualAtivarResult.getStatusCode());
        assertTrue(actualAtivarResult.getHeaders().isEmpty());
    }

    /**
     * Method under test: {@link TipoDefeitoVistoriaServiceImpl#listAllAtivos()}
     */
    @Test
    void testListAllAtivos() {
        // Arrange
        when(tipoDefeitoVistoriaRepository.findAll()).thenReturn(new ArrayList<>());

        // Act and Assert
        assertThrows(TipoDefeitoVistoriaException.class, () -> tipoDefeitoVistoriaServiceImpl.listAllAtivos());
        verify(tipoDefeitoVistoriaRepository).findAll();
    }

    /**
     * Method under test: {@link TipoDefeitoVistoriaServiceImpl#listAllAtivos()}
     */
    @Test
    void testListAllAtivos2() {
        // Arrange
        TipoDefeitoVistoriaEntity tipoDefeitoVistoriaEntity = new TipoDefeitoVistoriaEntity();
        tipoDefeitoVistoriaEntity.setAtivo(true);
        tipoDefeitoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoDefeitoVistoriaEntity.setDescricao("Nenhum tipo de defeito de vistoria encontrado.");
        tipoDefeitoVistoriaEntity.setId(1L);
        tipoDefeitoVistoriaEntity.setNome("Nenhum tipo de defeito de vistoria encontrado.");

        ArrayList<TipoDefeitoVistoriaEntity> tipoDefeitoVistoriaEntityList = new ArrayList<>();
        tipoDefeitoVistoriaEntityList.add(tipoDefeitoVistoriaEntity);
        when(tipoDefeitoVistoriaRepository.findAll()).thenReturn(tipoDefeitoVistoriaEntityList);

        // Act
        List<TipoDefeitoVistoriaDTO> actualListAllAtivosResult = tipoDefeitoVistoriaServiceImpl.listAllAtivos();

        // Assert
        verify(tipoDefeitoVistoriaRepository).findAll();
        assertEquals(1, actualListAllAtivosResult.size());
        TipoDefeitoVistoriaDTO getResult = actualListAllAtivosResult.get(0);
        assertEquals("1970-01-01", getResult.getDataInclusao().toString());
        assertEquals("Nenhum tipo de defeito de vistoria encontrado.", getResult.getDescricao());
        assertEquals("Nenhum tipo de defeito de vistoria encontrado.", getResult.getNome());
        assertEquals(1L, getResult.getId().longValue());
        assertTrue(getResult.getAtivo());
    }

    /**
     * Method under test: {@link TipoDefeitoVistoriaServiceImpl#listAllAtivos()}
     */
    @Test
    void testListAllAtivos3() {
        // Arrange
        TipoDefeitoVistoriaEntity tipoDefeitoVistoriaEntity = new TipoDefeitoVistoriaEntity();
        tipoDefeitoVistoriaEntity.setAtivo(true);
        tipoDefeitoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoDefeitoVistoriaEntity.setDescricao("Nenhum tipo de defeito de vistoria encontrado.");
        tipoDefeitoVistoriaEntity.setId(1L);
        tipoDefeitoVistoriaEntity.setNome("Nenhum tipo de defeito de vistoria encontrado.");

        TipoDefeitoVistoriaEntity tipoDefeitoVistoriaEntity2 = new TipoDefeitoVistoriaEntity();
        tipoDefeitoVistoriaEntity2.setAtivo(false);
        tipoDefeitoVistoriaEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoDefeitoVistoriaEntity2.setDescricao("br.gov.df.pm.sgv.domain.TipoDefeitoVistoriaEntity");
        tipoDefeitoVistoriaEntity2.setId(2L);
        tipoDefeitoVistoriaEntity2.setNome("br.gov.df.pm.sgv.domain.TipoDefeitoVistoriaEntity");

        ArrayList<TipoDefeitoVistoriaEntity> tipoDefeitoVistoriaEntityList = new ArrayList<>();
        tipoDefeitoVistoriaEntityList.add(tipoDefeitoVistoriaEntity2);
        tipoDefeitoVistoriaEntityList.add(tipoDefeitoVistoriaEntity);
        when(tipoDefeitoVistoriaRepository.findAll()).thenReturn(tipoDefeitoVistoriaEntityList);

        // Act
        List<TipoDefeitoVistoriaDTO> actualListAllAtivosResult = tipoDefeitoVistoriaServiceImpl.listAllAtivos();

        // Assert
        verify(tipoDefeitoVistoriaRepository).findAll();
        assertEquals(1, actualListAllAtivosResult.size());
        TipoDefeitoVistoriaDTO getResult = actualListAllAtivosResult.get(0);
        assertEquals("1970-01-01", getResult.getDataInclusao().toString());
        assertEquals("Nenhum tipo de defeito de vistoria encontrado.", getResult.getDescricao());
        assertEquals("Nenhum tipo de defeito de vistoria encontrado.", getResult.getNome());
        assertEquals(1L, getResult.getId().longValue());
        assertTrue(getResult.getAtivo());
    }

    /**
     * Method under test: {@link TipoDefeitoVistoriaServiceImpl#listAllAtivos()}
     */
    @Test
    void testListAllAtivos4() {
        // Arrange
        when(tipoDefeitoVistoriaRepository.findAll()).thenThrow(new VistoriaExceptions("An error occurred"));

        // Act and Assert
        assertThrows(VistoriaExceptions.class, () -> tipoDefeitoVistoriaServiceImpl.listAllAtivos());
        verify(tipoDefeitoVistoriaRepository).findAll();
    }

    /**
     * Method under test: {@link TipoDefeitoVistoriaServiceImpl#listAllAtivos()}
     */
    @Test
    void testListAllAtivos5() {
        // Arrange
        TipoDefeitoVistoriaEntity tipoDefeitoVistoriaEntity = mock(TipoDefeitoVistoriaEntity.class);
        when(tipoDefeitoVistoriaEntity.getId()).thenReturn(1L);
        when(tipoDefeitoVistoriaEntity.getDescricao()).thenReturn("Descricao");
        when(tipoDefeitoVistoriaEntity.getNome()).thenReturn("Nome");
        when(tipoDefeitoVistoriaEntity.getDataInclusao()).thenReturn(LocalDate.of(1970, 1, 1));
        when(tipoDefeitoVistoriaEntity.getAtivo()).thenReturn(true);
        doNothing().when(tipoDefeitoVistoriaEntity).setAtivo(Mockito.<Boolean>any());
        doNothing().when(tipoDefeitoVistoriaEntity).setDataInclusao(Mockito.<LocalDate>any());
        doNothing().when(tipoDefeitoVistoriaEntity).setDescricao(Mockito.<String>any());
        doNothing().when(tipoDefeitoVistoriaEntity).setId(Mockito.<Long>any());
        doNothing().when(tipoDefeitoVistoriaEntity).setNome(Mockito.<String>any());
        tipoDefeitoVistoriaEntity.setAtivo(true);
        tipoDefeitoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoDefeitoVistoriaEntity.setDescricao("Nenhum tipo de defeito de vistoria encontrado.");
        tipoDefeitoVistoriaEntity.setId(1L);
        tipoDefeitoVistoriaEntity.setNome("Nenhum tipo de defeito de vistoria encontrado.");

        ArrayList<TipoDefeitoVistoriaEntity> tipoDefeitoVistoriaEntityList = new ArrayList<>();
        tipoDefeitoVistoriaEntityList.add(tipoDefeitoVistoriaEntity);
        when(tipoDefeitoVistoriaRepository.findAll()).thenReturn(tipoDefeitoVistoriaEntityList);

        // Act
        List<TipoDefeitoVistoriaDTO> actualListAllAtivosResult = tipoDefeitoVistoriaServiceImpl.listAllAtivos();

        // Assert
        verify(tipoDefeitoVistoriaEntity, atLeast(1)).getAtivo();
        verify(tipoDefeitoVistoriaEntity).getDataInclusao();
        verify(tipoDefeitoVistoriaEntity).getDescricao();
        verify(tipoDefeitoVistoriaEntity).getId();
        verify(tipoDefeitoVistoriaEntity).getNome();
        verify(tipoDefeitoVistoriaEntity).setAtivo(eq(true));
        verify(tipoDefeitoVistoriaEntity).setDataInclusao(isA(LocalDate.class));
        verify(tipoDefeitoVistoriaEntity).setDescricao(eq("Nenhum tipo de defeito de vistoria encontrado."));
        verify(tipoDefeitoVistoriaEntity).setId(eq(1L));
        verify(tipoDefeitoVistoriaEntity).setNome(eq("Nenhum tipo de defeito de vistoria encontrado."));
        verify(tipoDefeitoVistoriaRepository).findAll();
        assertEquals(1, actualListAllAtivosResult.size());
        TipoDefeitoVistoriaDTO getResult = actualListAllAtivosResult.get(0);
        assertEquals("1970-01-01", getResult.getDataInclusao().toString());
        assertEquals("Descricao", getResult.getDescricao());
        assertEquals("Nome", getResult.getNome());
        assertEquals(1L, getResult.getId().longValue());
        assertTrue(getResult.getAtivo());
    }
}
