package br.gov.df.pm.sgv.service.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isA;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import br.gov.df.pm.sgv.domain.DiferencaOdometroEntity;
import br.gov.df.pm.sgv.domain.TipoEmpregoViaturaEntity;
import br.gov.df.pm.sgv.domain.TipoVistoriaEntity;
import br.gov.df.pm.sgv.domain.ViaturaEntity;
import br.gov.df.pm.sgv.domain.VistoriaViaturaEntity;
import br.gov.df.pm.sgv.domain.enums.VistoriaViaturaStatusEnum;
import br.gov.df.pm.sgv.dto.DiferencaDTO;
import br.gov.df.pm.sgv.dto.DiferencaOdometroDTO;
import br.gov.df.pm.sgv.dto.TipoVistoriaDTO;
import br.gov.df.pm.sgv.exceptions.VistoriaExceptions;
import br.gov.df.pm.sgv.repository.DiferencaOdometroRepository;
import br.gov.df.pm.sgv.repository.TipoVistoriaRepository;
import br.gov.df.pm.sgv.repository.app.ViaturaRepository;
import br.gov.df.pm.sgv.repository.app.VistoriaViaturaRepository;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ContextConfiguration(classes = {DiferencaOdometroServiceImpl.class})
@ExtendWith(SpringExtension.class)
class DiferencaOdometroServiceImplDiffblueTest {
    @MockBean
    private DiferencaOdometroRepository diferencaOdometroRepository;

    @Autowired
    private DiferencaOdometroServiceImpl diferencaOdometroServiceImpl;

    @MockBean
    private TipoVistoriaRepository tipoVistoriaRepository;

    @MockBean
    private ViaturaRepository viaturaRepository;

    @MockBean
    private VistoriaViaturaRepository vistoriaViaturaRepository;

    /**
     * Method under test: {@link DiferencaOdometroServiceImpl#buscarId(Long)}
     */
    @Test
    void testBuscarId() {
        // Arrange
        TipoVistoriaEntity referenciaFinal = new TipoVistoriaEntity();
        referenciaFinal.setAtivo(true);
        referenciaFinal.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaFinal.setDescricao("Descricao");
        referenciaFinal.setId(1L);
        referenciaFinal.setNome("Nome");
        referenciaFinal.setStatusAnterior("Status Anterior");
        referenciaFinal.setStatusPosterior("Status Posterior");

        TipoVistoriaEntity referenciaInicial = new TipoVistoriaEntity();
        referenciaInicial.setAtivo(true);
        referenciaInicial.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaInicial.setDescricao("Descricao");
        referenciaInicial.setId(1L);
        referenciaInicial.setNome("Nome");
        referenciaInicial.setStatusAnterior("Status Anterior");
        referenciaInicial.setStatusPosterior("Status Posterior");

        DiferencaOdometroEntity diferencaOdometroEntity = new DiferencaOdometroEntity();
        diferencaOdometroEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        diferencaOdometroEntity.setDataModificacao(LocalDate.of(1970, 1, 1));
        diferencaOdometroEntity.setDiferencaOdometro(10.0d);
        diferencaOdometroEntity.setId(1L);
        diferencaOdometroEntity.setReferenciaFinal(referenciaFinal);
        diferencaOdometroEntity.setReferenciaInicial(referenciaInicial);
        Optional<DiferencaOdometroEntity> ofResult = Optional.of(diferencaOdometroEntity);
        when(diferencaOdometroRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        // Act
        ResponseEntity<DiferencaOdometroDTO> actualBuscarIdResult = diferencaOdometroServiceImpl.buscarId(1L);

        // Assert
        verify(diferencaOdometroRepository).findById(eq(1L));
        DiferencaOdometroDTO body = actualBuscarIdResult.getBody();
        assertEquals("1970-01-01", body.getDataInclusao().toString());
        assertEquals("1970-01-01", body.getDataModificacao().toString());
        assertNull(body.getDiferencaPermitido());
        assertEquals(10.0d, body.getDiferencaOdometro().doubleValue());
        assertEquals(HttpStatus.OK, actualBuscarIdResult.getStatusCode());
        assertTrue(body.getReferenciaFinal().getAtivo());
        assertTrue(actualBuscarIdResult.hasBody());
        assertTrue(actualBuscarIdResult.getHeaders().isEmpty());
        assertEquals(referenciaFinal, body.getReferenciaInicial());
    }

    /**
     * Method under test: {@link DiferencaOdometroServiceImpl#buscarId(Long)}
     */
    @Test
    void testBuscarId2() {
        // Arrange
        TipoVistoriaEntity referenciaFinal = new TipoVistoriaEntity();
        referenciaFinal.setAtivo(true);
        referenciaFinal.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaFinal.setDescricao("Descricao");
        referenciaFinal.setId(1L);
        referenciaFinal.setNome("Nome");
        referenciaFinal.setStatusAnterior("Status Anterior");
        referenciaFinal.setStatusPosterior("Status Posterior");

        TipoVistoriaEntity referenciaInicial = new TipoVistoriaEntity();
        referenciaInicial.setAtivo(true);
        referenciaInicial.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaInicial.setDescricao("Descricao");
        referenciaInicial.setId(1L);
        referenciaInicial.setNome("Nome");
        referenciaInicial.setStatusAnterior("Status Anterior");
        referenciaInicial.setStatusPosterior("Status Posterior");

        TipoVistoriaEntity tipoVistoriaEntity = new TipoVistoriaEntity();
        tipoVistoriaEntity.setAtivo(true);
        tipoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoriaEntity.setDescricao("Descricao");
        tipoVistoriaEntity.setId(1L);
        tipoVistoriaEntity.setNome("Nome");
        tipoVistoriaEntity.setStatusAnterior("Status Anterior");
        tipoVistoriaEntity.setStatusPosterior("Status Posterior");

        TipoVistoriaEntity tipoVistoriaEntity2 = new TipoVistoriaEntity();
        tipoVistoriaEntity2.setAtivo(true);
        tipoVistoriaEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoriaEntity2.setDescricao("Descricao");
        tipoVistoriaEntity2.setId(1L);
        tipoVistoriaEntity2.setNome("Nome");
        tipoVistoriaEntity2.setStatusAnterior("Status Anterior");
        tipoVistoriaEntity2.setStatusPosterior("Status Posterior");
        DiferencaOdometroEntity diferencaOdometroEntity = mock(DiferencaOdometroEntity.class);
        when(diferencaOdometroEntity.getReferenciaFinal()).thenReturn(tipoVistoriaEntity);
        when(diferencaOdometroEntity.getReferenciaInicial()).thenReturn(tipoVistoriaEntity2);
        when(diferencaOdometroEntity.getDiferencaOdometro()).thenReturn(10.0d);
        when(diferencaOdometroEntity.getDataInclusao()).thenReturn(LocalDate.of(1970, 1, 1));
        when(diferencaOdometroEntity.getDataModificacao()).thenReturn(LocalDate.of(1970, 1, 1));
        doNothing().when(diferencaOdometroEntity).setDataInclusao(Mockito.<LocalDate>any());
        doNothing().when(diferencaOdometroEntity).setDataModificacao(Mockito.<LocalDate>any());
        doNothing().when(diferencaOdometroEntity).setDiferencaOdometro(Mockito.<Double>any());
        doNothing().when(diferencaOdometroEntity).setId(Mockito.<Long>any());
        doNothing().when(diferencaOdometroEntity).setReferenciaFinal(Mockito.<TipoVistoriaEntity>any());
        doNothing().when(diferencaOdometroEntity).setReferenciaInicial(Mockito.<TipoVistoriaEntity>any());
        diferencaOdometroEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        diferencaOdometroEntity.setDataModificacao(LocalDate.of(1970, 1, 1));
        diferencaOdometroEntity.setDiferencaOdometro(10.0d);
        diferencaOdometroEntity.setId(1L);
        diferencaOdometroEntity.setReferenciaFinal(referenciaFinal);
        diferencaOdometroEntity.setReferenciaInicial(referenciaInicial);
        Optional<DiferencaOdometroEntity> ofResult = Optional.of(diferencaOdometroEntity);
        when(diferencaOdometroRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        // Act
        ResponseEntity<DiferencaOdometroDTO> actualBuscarIdResult = diferencaOdometroServiceImpl.buscarId(1L);

        // Assert
        verify(diferencaOdometroEntity).getDataInclusao();
        verify(diferencaOdometroEntity).getDataModificacao();
        verify(diferencaOdometroEntity).getDiferencaOdometro();
        verify(diferencaOdometroEntity).getReferenciaFinal();
        verify(diferencaOdometroEntity).getReferenciaInicial();
        verify(diferencaOdometroEntity).setDataInclusao(isA(LocalDate.class));
        verify(diferencaOdometroEntity).setDataModificacao(isA(LocalDate.class));
        verify(diferencaOdometroEntity).setDiferencaOdometro(eq(10.0d));
        verify(diferencaOdometroEntity).setId(eq(1L));
        verify(diferencaOdometroEntity).setReferenciaFinal(isA(TipoVistoriaEntity.class));
        verify(diferencaOdometroEntity).setReferenciaInicial(isA(TipoVistoriaEntity.class));
        verify(diferencaOdometroRepository).findById(eq(1L));
        DiferencaOdometroDTO body = actualBuscarIdResult.getBody();
        assertEquals("1970-01-01", body.getDataInclusao().toString());
        assertEquals("1970-01-01", body.getDataModificacao().toString());
        assertNull(body.getDiferencaPermitido());
        assertEquals(10.0d, body.getDiferencaOdometro().doubleValue());
        assertEquals(HttpStatus.OK, actualBuscarIdResult.getStatusCode());
        assertTrue(body.getReferenciaFinal().getAtivo());
        assertTrue(actualBuscarIdResult.hasBody());
        assertTrue(actualBuscarIdResult.getHeaders().isEmpty());
        assertEquals(tipoVistoriaEntity, body.getReferenciaInicial());
    }

    /**
     * Method under test:
     * {@link DiferencaOdometroServiceImpl#buscar(String, Pageable)}
     */
    @Test
    void testBuscar() {
        // Arrange
        PageImpl<DiferencaOdometroEntity> pageImpl = new PageImpl<>(new ArrayList<>());
        when(diferencaOdometroRepository.findAll(Mockito.<Specification<DiferencaOdometroEntity>>any(),
                Mockito.<Pageable>any())).thenReturn(pageImpl);

        // Act
        Page<DiferencaOdometroEntity> actualBuscarResult = diferencaOdometroServiceImpl.buscar("Filter", null);

        // Assert
        verify(diferencaOdometroRepository).findAll(isA(Specification.class), (Pageable) isNull());
        assertTrue(actualBuscarResult.toList().isEmpty());
        assertSame(pageImpl, actualBuscarResult);
    }

    /**
     * Method under test:
     * {@link DiferencaOdometroServiceImpl#buscar(String, Pageable)}
     */
    @Test
    void testBuscar2() {
        // Arrange
        when(diferencaOdometroRepository.findAll(Mockito.<Specification<DiferencaOdometroEntity>>any(),
                Mockito.<Pageable>any())).thenThrow(new NumberFormatException("foo"));

        // Act and Assert
        assertThrows(NumberFormatException.class, () -> diferencaOdometroServiceImpl.buscar("Filter", null));
        verify(diferencaOdometroRepository).findAll(isA(Specification.class), (Pageable) isNull());
    }

    /**
     * Method under test:
     * {@link DiferencaOdometroServiceImpl#salvar(DiferencaOdometroDTO)}
     */
    @Test
    void testSalvar() {
        // Arrange
        TipoVistoriaEntity referenciaFinal = new TipoVistoriaEntity();
        referenciaFinal.setAtivo(true);
        referenciaFinal.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaFinal.setDescricao("Descricao");
        referenciaFinal.setId(1L);
        referenciaFinal.setNome("Nome");
        referenciaFinal.setStatusAnterior("Status Anterior");
        referenciaFinal.setStatusPosterior("Status Posterior");

        TipoVistoriaEntity referenciaInicial = new TipoVistoriaEntity();
        referenciaInicial.setAtivo(true);
        referenciaInicial.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaInicial.setDescricao("Descricao");
        referenciaInicial.setId(1L);
        referenciaInicial.setNome("Nome");
        referenciaInicial.setStatusAnterior("Status Anterior");
        referenciaInicial.setStatusPosterior("Status Posterior");

        DiferencaOdometroEntity diferencaOdometroEntity = new DiferencaOdometroEntity();
        diferencaOdometroEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        diferencaOdometroEntity.setDataModificacao(LocalDate.of(1970, 1, 1));
        diferencaOdometroEntity.setDiferencaOdometro(10.0d);
        diferencaOdometroEntity.setId(1L);
        diferencaOdometroEntity.setReferenciaFinal(referenciaFinal);
        diferencaOdometroEntity.setReferenciaInicial(referenciaInicial);
        Optional<DiferencaOdometroEntity> ofResult = Optional.of(diferencaOdometroEntity);
        when(diferencaOdometroRepository.findByReferenciaInicialAndReferenciaFinal(Mockito.<TipoVistoriaEntity>any(),
                Mockito.<TipoVistoriaEntity>any())).thenReturn(ofResult);

        TipoVistoriaEntity referenciaFinal2 = new TipoVistoriaEntity();
        referenciaFinal2.setAtivo(true);
        referenciaFinal2.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaFinal2.setDescricao("Descricao");
        referenciaFinal2.setId(1L);
        referenciaFinal2.setNome("Nome");
        referenciaFinal2.setStatusAnterior("Status Anterior");
        referenciaFinal2.setStatusPosterior("Status Posterior");
        DiferencaOdometroDTO.DiferencaOdometroDTOBuilder builderResult = DiferencaOdometroDTO.builder();
        DiferencaOdometroDTO.DiferencaOdometroDTOBuilder dataInclusaoResult = builderResult
                .dataInclusao(LocalDate.of(1970, 1, 1));
        DiferencaOdometroDTO.DiferencaOdometroDTOBuilder referenciaFinalResult = dataInclusaoResult
                .dataModificacao(LocalDate.of(1970, 1, 1))
                .diferencaOdometro(10.0d)
                .diferencaPermitido(true)
                .referenciaFinal(referenciaFinal2);

        TipoVistoriaEntity referenciaInicial2 = new TipoVistoriaEntity();
        referenciaInicial2.setAtivo(true);
        referenciaInicial2.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaInicial2.setDescricao("Descricao");
        referenciaInicial2.setId(1L);
        referenciaInicial2.setNome("Nome");
        referenciaInicial2.setStatusAnterior("Status Anterior");
        referenciaInicial2.setStatusPosterior("Status Posterior");
        DiferencaOdometroDTO diferencaOdometroDTO = referenciaFinalResult.referenciaInicial(referenciaInicial2).build();

        // Act and Assert
        assertThrows(VistoriaExceptions.class, () -> diferencaOdometroServiceImpl.salvar(diferencaOdometroDTO));
        verify(diferencaOdometroRepository).findByReferenciaInicialAndReferenciaFinal(isA(TipoVistoriaEntity.class),
                isA(TipoVistoriaEntity.class));
    }

    /**
     * Method under test:
     * {@link DiferencaOdometroServiceImpl#salvar(DiferencaOdometroDTO)}
     */
    @Test
    void testSalvar2() {
        // Arrange
        TipoVistoriaEntity referenciaFinal = new TipoVistoriaEntity();
        referenciaFinal.setAtivo(true);
        referenciaFinal.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaFinal.setDescricao("Descricao");
        referenciaFinal.setId(1L);
        referenciaFinal.setNome("Nome");
        referenciaFinal.setStatusAnterior("Status Anterior");
        referenciaFinal.setStatusPosterior("Status Posterior");

        TipoVistoriaEntity referenciaInicial = new TipoVistoriaEntity();
        referenciaInicial.setAtivo(true);
        referenciaInicial.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaInicial.setDescricao("Descricao");
        referenciaInicial.setId(1L);
        referenciaInicial.setNome("Nome");
        referenciaInicial.setStatusAnterior("Status Anterior");
        referenciaInicial.setStatusPosterior("Status Posterior");

        DiferencaOdometroEntity diferencaOdometroEntity = new DiferencaOdometroEntity();
        diferencaOdometroEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        diferencaOdometroEntity.setDataModificacao(LocalDate.of(1970, 1, 1));
        diferencaOdometroEntity.setDiferencaOdometro(10.0d);
        diferencaOdometroEntity.setId(1L);
        diferencaOdometroEntity.setReferenciaFinal(referenciaFinal);
        diferencaOdometroEntity.setReferenciaInicial(referenciaInicial);
        Optional<DiferencaOdometroEntity> ofResult = Optional.of(diferencaOdometroEntity);
        when(diferencaOdometroRepository.findByReferenciaInicialAndReferenciaFinal(Mockito.<TipoVistoriaEntity>any(),
                Mockito.<TipoVistoriaEntity>any())).thenReturn(ofResult);

        TipoVistoriaEntity tipoVistoriaEntity = new TipoVistoriaEntity();
        tipoVistoriaEntity.setAtivo(true);
        tipoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoriaEntity.setDescricao("Descricao");
        tipoVistoriaEntity.setId(1L);
        tipoVistoriaEntity.setNome("Nome");
        tipoVistoriaEntity.setStatusAnterior("Status Anterior");
        tipoVistoriaEntity.setStatusPosterior("Status Posterior");

        TipoVistoriaEntity tipoVistoriaEntity2 = new TipoVistoriaEntity();
        tipoVistoriaEntity2.setAtivo(true);
        tipoVistoriaEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoriaEntity2.setDescricao("Descricao");
        tipoVistoriaEntity2.setId(1L);
        tipoVistoriaEntity2.setNome("Nome");
        tipoVistoriaEntity2.setStatusAnterior("Status Anterior");
        tipoVistoriaEntity2.setStatusPosterior("Status Posterior");
        DiferencaOdometroDTO diferencaOdometroDTO = mock(DiferencaOdometroDTO.class);
        when(diferencaOdometroDTO.getReferenciaFinal()).thenReturn(tipoVistoriaEntity);
        when(diferencaOdometroDTO.getReferenciaInicial()).thenReturn(tipoVistoriaEntity2);

        // Act and Assert
        assertThrows(VistoriaExceptions.class, () -> diferencaOdometroServiceImpl.salvar(diferencaOdometroDTO));
        verify(diferencaOdometroDTO).getReferenciaFinal();
        verify(diferencaOdometroDTO).getReferenciaInicial();
        verify(diferencaOdometroRepository).findByReferenciaInicialAndReferenciaFinal(isA(TipoVistoriaEntity.class),
                isA(TipoVistoriaEntity.class));
    }

    /**
     * Method under test:
     * {@link DiferencaOdometroServiceImpl#editar(Long, DiferencaOdometroDTO)}
     */
    @Test
    void testEditar() {
        // Arrange
        when(diferencaOdometroRepository.findById(Mockito.<Long>any())).thenThrow(new NumberFormatException("foo"));

        // Act and Assert
        assertThrows(NumberFormatException.class, () -> diferencaOdometroServiceImpl.editar(1L, null));
        verify(diferencaOdometroRepository).findById(eq(1L));
    }

    /**
     * Method under test:
     * {@link DiferencaOdometroServiceImpl#editar(Long, DiferencaOdometroDTO)}
     */
    @Test
    void testEditar2() {
        // Arrange
        TipoVistoriaEntity referenciaFinal = new TipoVistoriaEntity();
        referenciaFinal.setAtivo(true);
        referenciaFinal.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaFinal.setDescricao("Descricao");
        referenciaFinal.setId(1L);
        referenciaFinal.setNome("Nome");
        referenciaFinal.setStatusAnterior("Status Anterior");
        referenciaFinal.setStatusPosterior("Status Posterior");

        TipoVistoriaEntity referenciaInicial = new TipoVistoriaEntity();
        referenciaInicial.setAtivo(true);
        referenciaInicial.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaInicial.setDescricao("Descricao");
        referenciaInicial.setId(1L);
        referenciaInicial.setNome("Nome");
        referenciaInicial.setStatusAnterior("Status Anterior");
        referenciaInicial.setStatusPosterior("Status Posterior");

        DiferencaOdometroEntity diferencaOdometroEntity = new DiferencaOdometroEntity();
        diferencaOdometroEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        diferencaOdometroEntity.setDataModificacao(LocalDate.of(1970, 1, 1));
        diferencaOdometroEntity.setDiferencaOdometro(10.0d);
        diferencaOdometroEntity.setId(1L);
        diferencaOdometroEntity.setReferenciaFinal(referenciaFinal);
        diferencaOdometroEntity.setReferenciaInicial(referenciaInicial);
        Optional<DiferencaOdometroEntity> ofResult = Optional.of(diferencaOdometroEntity);

        TipoVistoriaEntity referenciaFinal2 = new TipoVistoriaEntity();
        referenciaFinal2.setAtivo(true);
        referenciaFinal2.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaFinal2.setDescricao("Descricao");
        referenciaFinal2.setId(1L);
        referenciaFinal2.setNome("Nome");
        referenciaFinal2.setStatusAnterior("Status Anterior");
        referenciaFinal2.setStatusPosterior("Status Posterior");

        TipoVistoriaEntity referenciaInicial2 = new TipoVistoriaEntity();
        referenciaInicial2.setAtivo(true);
        referenciaInicial2.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaInicial2.setDescricao("Descricao");
        referenciaInicial2.setId(1L);
        referenciaInicial2.setNome("Nome");
        referenciaInicial2.setStatusAnterior("Status Anterior");
        referenciaInicial2.setStatusPosterior("Status Posterior");

        DiferencaOdometroEntity diferencaOdometroEntity2 = new DiferencaOdometroEntity();
        diferencaOdometroEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        diferencaOdometroEntity2.setDataModificacao(LocalDate.of(1970, 1, 1));
        diferencaOdometroEntity2.setDiferencaOdometro(10.0d);
        diferencaOdometroEntity2.setId(1L);
        diferencaOdometroEntity2.setReferenciaFinal(referenciaFinal2);
        diferencaOdometroEntity2.setReferenciaInicial(referenciaInicial2);
        when(diferencaOdometroRepository.save(Mockito.<DiferencaOdometroEntity>any())).thenReturn(diferencaOdometroEntity2);
        when(diferencaOdometroRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        TipoVistoriaEntity referenciaFinal3 = new TipoVistoriaEntity();
        referenciaFinal3.setAtivo(true);
        referenciaFinal3.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaFinal3.setDescricao("Descricao");
        referenciaFinal3.setId(1L);
        referenciaFinal3.setNome("Nome");
        referenciaFinal3.setStatusAnterior("Status Anterior");
        referenciaFinal3.setStatusPosterior("Status Posterior");
        DiferencaOdometroDTO.DiferencaOdometroDTOBuilder builderResult = DiferencaOdometroDTO.builder();
        DiferencaOdometroDTO.DiferencaOdometroDTOBuilder dataInclusaoResult = builderResult
                .dataInclusao(LocalDate.of(1970, 1, 1));
        DiferencaOdometroDTO.DiferencaOdometroDTOBuilder referenciaFinalResult = dataInclusaoResult
                .dataModificacao(LocalDate.of(1970, 1, 1))
                .diferencaOdometro(10.0d)
                .diferencaPermitido(true)
                .referenciaFinal(referenciaFinal3);

        TipoVistoriaEntity referenciaInicial3 = new TipoVistoriaEntity();
        referenciaInicial3.setAtivo(true);
        referenciaInicial3.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaInicial3.setDescricao("Descricao");
        referenciaInicial3.setId(1L);
        referenciaInicial3.setNome("Nome");
        referenciaInicial3.setStatusAnterior("Status Anterior");
        referenciaInicial3.setStatusPosterior("Status Posterior");
        DiferencaOdometroDTO edicao = referenciaFinalResult.referenciaInicial(referenciaInicial3).build();

        // Act
        ResponseEntity<?> actualEditarResult = diferencaOdometroServiceImpl.editar(1L, edicao);

        // Assert
        verify(diferencaOdometroRepository).findById(eq(1L));
        verify(diferencaOdometroRepository).save(isA(DiferencaOdometroEntity.class));
        assertEquals(HttpStatus.OK, actualEditarResult.getStatusCode());
        assertTrue(actualEditarResult.hasBody());
        assertTrue(actualEditarResult.getHeaders().isEmpty());
    }

    /**
     * Method under test:
     * {@link DiferencaOdometroServiceImpl#editar(Long, DiferencaOdometroDTO)}
     */
    @Test
    void testEditar3() {
        // Arrange
        TipoVistoriaEntity referenciaFinal = new TipoVistoriaEntity();
        referenciaFinal.setAtivo(true);
        referenciaFinal.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaFinal.setDescricao("Descricao");
        referenciaFinal.setId(1L);
        referenciaFinal.setNome("Nome");
        referenciaFinal.setStatusAnterior("Status Anterior");
        referenciaFinal.setStatusPosterior("Status Posterior");

        TipoVistoriaEntity referenciaInicial = new TipoVistoriaEntity();
        referenciaInicial.setAtivo(true);
        referenciaInicial.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaInicial.setDescricao("Descricao");
        referenciaInicial.setId(1L);
        referenciaInicial.setNome("Nome");
        referenciaInicial.setStatusAnterior("Status Anterior");
        referenciaInicial.setStatusPosterior("Status Posterior");

        DiferencaOdometroEntity diferencaOdometroEntity = new DiferencaOdometroEntity();
        diferencaOdometroEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        diferencaOdometroEntity.setDataModificacao(LocalDate.of(1970, 1, 1));
        diferencaOdometroEntity.setDiferencaOdometro(10.0d);
        diferencaOdometroEntity.setId(1L);
        diferencaOdometroEntity.setReferenciaFinal(referenciaFinal);
        diferencaOdometroEntity.setReferenciaInicial(referenciaInicial);
        Optional<DiferencaOdometroEntity> ofResult = Optional.of(diferencaOdometroEntity);
        when(diferencaOdometroRepository.save(Mockito.<DiferencaOdometroEntity>any()))
                .thenThrow(new NumberFormatException("foo"));
        when(diferencaOdometroRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        TipoVistoriaEntity referenciaFinal2 = new TipoVistoriaEntity();
        referenciaFinal2.setAtivo(true);
        referenciaFinal2.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaFinal2.setDescricao("Descricao");
        referenciaFinal2.setId(1L);
        referenciaFinal2.setNome("Nome");
        referenciaFinal2.setStatusAnterior("Status Anterior");
        referenciaFinal2.setStatusPosterior("Status Posterior");
        DiferencaOdometroDTO.DiferencaOdometroDTOBuilder builderResult = DiferencaOdometroDTO.builder();
        DiferencaOdometroDTO.DiferencaOdometroDTOBuilder dataInclusaoResult = builderResult
                .dataInclusao(LocalDate.of(1970, 1, 1));
        DiferencaOdometroDTO.DiferencaOdometroDTOBuilder referenciaFinalResult = dataInclusaoResult
                .dataModificacao(LocalDate.of(1970, 1, 1))
                .diferencaOdometro(10.0d)
                .diferencaPermitido(true)
                .referenciaFinal(referenciaFinal2);

        TipoVistoriaEntity referenciaInicial2 = new TipoVistoriaEntity();
        referenciaInicial2.setAtivo(true);
        referenciaInicial2.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaInicial2.setDescricao("Descricao");
        referenciaInicial2.setId(1L);
        referenciaInicial2.setNome("Nome");
        referenciaInicial2.setStatusAnterior("Status Anterior");
        referenciaInicial2.setStatusPosterior("Status Posterior");
        DiferencaOdometroDTO edicao = referenciaFinalResult.referenciaInicial(referenciaInicial2).build();

        // Act and Assert
        assertThrows(NumberFormatException.class, () -> diferencaOdometroServiceImpl.editar(1L, edicao));
        verify(diferencaOdometroRepository).findById(eq(1L));
        verify(diferencaOdometroRepository).save(isA(DiferencaOdometroEntity.class));
    }

    /**
     * Method under test: {@link DiferencaOdometroServiceImpl#excluir(Long)}
     */
    @Test
    void testExcluir() {
        // Arrange
        TipoVistoriaEntity referenciaFinal = new TipoVistoriaEntity();
        referenciaFinal.setAtivo(true);
        referenciaFinal.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaFinal.setDescricao("Descricao");
        referenciaFinal.setId(1L);
        referenciaFinal.setNome("Nome");
        referenciaFinal.setStatusAnterior("Status Anterior");
        referenciaFinal.setStatusPosterior("Status Posterior");

        TipoVistoriaEntity referenciaInicial = new TipoVistoriaEntity();
        referenciaInicial.setAtivo(true);
        referenciaInicial.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaInicial.setDescricao("Descricao");
        referenciaInicial.setId(1L);
        referenciaInicial.setNome("Nome");
        referenciaInicial.setStatusAnterior("Status Anterior");
        referenciaInicial.setStatusPosterior("Status Posterior");

        DiferencaOdometroEntity diferencaOdometroEntity = new DiferencaOdometroEntity();
        diferencaOdometroEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        diferencaOdometroEntity.setDataModificacao(LocalDate.of(1970, 1, 1));
        diferencaOdometroEntity.setDiferencaOdometro(10.0d);
        diferencaOdometroEntity.setId(1L);
        diferencaOdometroEntity.setReferenciaFinal(referenciaFinal);
        diferencaOdometroEntity.setReferenciaInicial(referenciaInicial);
        Optional<DiferencaOdometroEntity> ofResult = Optional.of(diferencaOdometroEntity);
        doNothing().when(diferencaOdometroRepository).delete(Mockito.<DiferencaOdometroEntity>any());
        when(diferencaOdometroRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        // Act
        ResponseEntity<?> actualExcluirResult = diferencaOdometroServiceImpl.excluir(1L);

        // Assert
        verify(diferencaOdometroRepository).delete(isA(DiferencaOdometroEntity.class));
        verify(diferencaOdometroRepository).findById(eq(1L));
        assertNull(actualExcluirResult);
    }

    /**
     * Method under test: {@link DiferencaOdometroServiceImpl#excluir(Long)}
     */
    @Test
    void testExcluir2() {
        // Arrange
        TipoVistoriaEntity referenciaFinal = new TipoVistoriaEntity();
        referenciaFinal.setAtivo(true);
        referenciaFinal.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaFinal.setDescricao("Descricao");
        referenciaFinal.setId(1L);
        referenciaFinal.setNome("Nome");
        referenciaFinal.setStatusAnterior("Status Anterior");
        referenciaFinal.setStatusPosterior("Status Posterior");

        TipoVistoriaEntity referenciaInicial = new TipoVistoriaEntity();
        referenciaInicial.setAtivo(true);
        referenciaInicial.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaInicial.setDescricao("Descricao");
        referenciaInicial.setId(1L);
        referenciaInicial.setNome("Nome");
        referenciaInicial.setStatusAnterior("Status Anterior");
        referenciaInicial.setStatusPosterior("Status Posterior");

        DiferencaOdometroEntity diferencaOdometroEntity = new DiferencaOdometroEntity();
        diferencaOdometroEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        diferencaOdometroEntity.setDataModificacao(LocalDate.of(1970, 1, 1));
        diferencaOdometroEntity.setDiferencaOdometro(10.0d);
        diferencaOdometroEntity.setId(1L);
        diferencaOdometroEntity.setReferenciaFinal(referenciaFinal);
        diferencaOdometroEntity.setReferenciaInicial(referenciaInicial);
        Optional<DiferencaOdometroEntity> ofResult = Optional.of(diferencaOdometroEntity);
        doThrow(new NumberFormatException("foo")).when(diferencaOdometroRepository)
                .delete(Mockito.<DiferencaOdometroEntity>any());
        when(diferencaOdometroRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        // Act and Assert
        assertThrows(NumberFormatException.class, () -> diferencaOdometroServiceImpl.excluir(1L));
        verify(diferencaOdometroRepository).delete(isA(DiferencaOdometroEntity.class));
        verify(diferencaOdometroRepository).findById(eq(1L));
    }

    /**
     * Method under test: {@link DiferencaOdometroServiceImpl#desativar(Long)}
     */
    @Test
    void testDesativar() {
        // Arrange
        TipoVistoriaEntity referenciaFinal = new TipoVistoriaEntity();
        referenciaFinal.setAtivo(true);
        referenciaFinal.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaFinal.setDescricao("Descricao");
        referenciaFinal.setId(1L);
        referenciaFinal.setNome("Nome");
        referenciaFinal.setStatusAnterior("Status Anterior");
        referenciaFinal.setStatusPosterior("Status Posterior");

        TipoVistoriaEntity referenciaInicial = new TipoVistoriaEntity();
        referenciaInicial.setAtivo(true);
        referenciaInicial.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaInicial.setDescricao("Descricao");
        referenciaInicial.setId(1L);
        referenciaInicial.setNome("Nome");
        referenciaInicial.setStatusAnterior("Status Anterior");
        referenciaInicial.setStatusPosterior("Status Posterior");

        DiferencaOdometroEntity diferencaOdometroEntity = new DiferencaOdometroEntity();
        diferencaOdometroEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        diferencaOdometroEntity.setDataModificacao(LocalDate.of(1970, 1, 1));
        diferencaOdometroEntity.setDiferencaOdometro(10.0d);
        diferencaOdometroEntity.setId(1L);
        diferencaOdometroEntity.setReferenciaFinal(referenciaFinal);
        diferencaOdometroEntity.setReferenciaInicial(referenciaInicial);
        Optional<DiferencaOdometroEntity> ofResult = Optional.of(diferencaOdometroEntity);
        when(diferencaOdometroRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        // Act
        ResponseEntity<?> actualDesativarResult = diferencaOdometroServiceImpl.desativar(1L);

        // Assert
        verify(diferencaOdometroRepository).findById(eq(1L));
        assertNull(actualDesativarResult);
    }

    /**
     * Method under test: {@link DiferencaOdometroServiceImpl#desativar(Long)}
     */
    @Test
    void testDesativar2() {
        // Arrange
        when(diferencaOdometroRepository.findById(Mockito.<Long>any())).thenThrow(new NumberFormatException("foo"));

        // Act and Assert
        assertThrows(NumberFormatException.class, () -> diferencaOdometroServiceImpl.desativar(1L));
        verify(diferencaOdometroRepository).findById(eq(1L));
    }

    /**
     * Method under test: {@link DiferencaOdometroServiceImpl#ativar(Long)}
     */
    @Test
    void testAtivar() {
        // Arrange
        TipoVistoriaEntity referenciaFinal = new TipoVistoriaEntity();
        referenciaFinal.setAtivo(true);
        referenciaFinal.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaFinal.setDescricao("Descricao");
        referenciaFinal.setId(1L);
        referenciaFinal.setNome("Nome");
        referenciaFinal.setStatusAnterior("Status Anterior");
        referenciaFinal.setStatusPosterior("Status Posterior");

        TipoVistoriaEntity referenciaInicial = new TipoVistoriaEntity();
        referenciaInicial.setAtivo(true);
        referenciaInicial.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaInicial.setDescricao("Descricao");
        referenciaInicial.setId(1L);
        referenciaInicial.setNome("Nome");
        referenciaInicial.setStatusAnterior("Status Anterior");
        referenciaInicial.setStatusPosterior("Status Posterior");

        DiferencaOdometroEntity diferencaOdometroEntity = new DiferencaOdometroEntity();
        diferencaOdometroEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        diferencaOdometroEntity.setDataModificacao(LocalDate.of(1970, 1, 1));
        diferencaOdometroEntity.setDiferencaOdometro(10.0d);
        diferencaOdometroEntity.setId(1L);
        diferencaOdometroEntity.setReferenciaFinal(referenciaFinal);
        diferencaOdometroEntity.setReferenciaInicial(referenciaInicial);
        Optional<DiferencaOdometroEntity> ofResult = Optional.of(diferencaOdometroEntity);
        when(diferencaOdometroRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        // Act
        ResponseEntity<?> actualAtivarResult = diferencaOdometroServiceImpl.ativar(1L);

        // Assert
        verify(diferencaOdometroRepository).findById(eq(1L));
        assertNull(actualAtivarResult);
    }

    /**
     * Method under test: {@link DiferencaOdometroServiceImpl#ativar(Long)}
     */
    @Test
    void testAtivar2() {
        // Arrange
        when(diferencaOdometroRepository.findById(Mockito.<Long>any())).thenThrow(new NumberFormatException("foo"));

        // Act and Assert
        assertThrows(NumberFormatException.class, () -> diferencaOdometroServiceImpl.ativar(1L));
        verify(diferencaOdometroRepository).findById(eq(1L));
    }

    /**
     * Method under test: {@link DiferencaOdometroServiceImpl#findAllTipoVistoria()}
     */
    @Test
    void testFindAllTipoVistoria() {
        // Arrange
        when(tipoVistoriaRepository.findAllByAtivo(Mockito.<Boolean>any())).thenReturn(new ArrayList<>());

        // Act
        ResponseEntity<List<TipoVistoriaEntity>> actualFindAllTipoVistoriaResult = diferencaOdometroServiceImpl
                .findAllTipoVistoria();

        // Assert
        verify(tipoVistoriaRepository).findAllByAtivo(eq(true));
        assertEquals(HttpStatus.OK, actualFindAllTipoVistoriaResult.getStatusCode());
        assertTrue(actualFindAllTipoVistoriaResult.hasBody());
        assertTrue(actualFindAllTipoVistoriaResult.getHeaders().isEmpty());
    }

    /**
     * Method under test: {@link DiferencaOdometroServiceImpl#findAllTipoVistoria()}
     */
    @Test
    void testFindAllTipoVistoria2() {
        // Arrange
        when(tipoVistoriaRepository.findAllByAtivo(Mockito.<Boolean>any())).thenThrow(new NumberFormatException("foo"));

        // Act and Assert
        assertThrows(NumberFormatException.class, () -> diferencaOdometroServiceImpl.findAllTipoVistoria());
        verify(tipoVistoriaRepository).findAllByAtivo(eq(true));
    }

    /**
     * Method under test:
     * {@link DiferencaOdometroServiceImpl#buscarDiferenca(DiferencaDTO)}
     */
    @Test
    void testBuscarDiferenca() {
        // Arrange
        TipoVistoriaEntity tipoVistoriaEntity = new TipoVistoriaEntity();
        tipoVistoriaEntity.setAtivo(true);
        tipoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoriaEntity.setDescricao("Descricao");
        tipoVistoriaEntity.setId(1L);
        tipoVistoriaEntity.setNome("Nome");
        tipoVistoriaEntity.setStatusAnterior("Status Anterior");
        tipoVistoriaEntity.setStatusPosterior("Status Posterior");
        Optional<TipoVistoriaEntity> ofResult = Optional.of(tipoVistoriaEntity);
        when(tipoVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        TipoEmpregoViaturaEntity tipoEmpregoViatura = new TipoEmpregoViaturaEntity();
        tipoEmpregoViatura.setAtivo(1);
        tipoEmpregoViatura.setId(1);
        tipoEmpregoViatura.setNome("Nome");

        ViaturaEntity viaturaEntity = new ViaturaEntity();
        viaturaEntity.setAtivo(true);
        viaturaEntity.setDataAtualizacao(LocalDate.of(1970, 1, 1));
        viaturaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        viaturaEntity.setId(1L);
        viaturaEntity.setListaUpm(new ArrayList<>());
        viaturaEntity.setMarcaModelo("Marca Modelo");
        viaturaEntity.setNrSei("Nr Sei");
        viaturaEntity.setPlaca("Placa");
        viaturaEntity.setPrefixo("Prefixo");
        viaturaEntity.setRenavam("Renavam");
        viaturaEntity.setStatus("Status");
        viaturaEntity.setTipoEmpregoViatura(tipoEmpregoViatura);
        viaturaEntity.setTombamento("alice.liddell@example.org");
        Optional<ViaturaEntity> ofResult2 = Optional.of(viaturaEntity);
        when(viaturaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult2);
        TipoVistoriaDTO tipoVistoria = mock(TipoVistoriaDTO.class);
        when(tipoVistoria.getId()).thenThrow(new NumberFormatException("foo"));

        DiferencaDTO diferencaDTO = new DiferencaDTO();
        diferencaDTO.setIdViatura(1L);
        diferencaDTO.setTipoVistoria(tipoVistoria);
        diferencaDTO.setUltimoOdometro(10.0f);

        // Act and Assert
        assertThrows(NumberFormatException.class, () -> diferencaOdometroServiceImpl.buscarDiferenca(diferencaDTO));
        verify(tipoVistoria).getId();
        verify(viaturaRepository).findById(eq(1L));
    }

    /**
     * Method under test:
     * {@link DiferencaOdometroServiceImpl#buscarDiferenca(DiferencaDTO)}
     */
    @Test
    void testBuscarDiferenca2() {
        // Arrange
        Optional<TipoVistoriaEntity> emptyResult = Optional.empty();
        when(tipoVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(emptyResult);

        TipoEmpregoViaturaEntity tipoEmpregoViatura = new TipoEmpregoViaturaEntity();
        tipoEmpregoViatura.setAtivo(1);
        tipoEmpregoViatura.setId(1);
        tipoEmpregoViatura.setNome("Nome");

        ViaturaEntity viaturaEntity = new ViaturaEntity();
        viaturaEntity.setAtivo(true);
        viaturaEntity.setDataAtualizacao(LocalDate.of(1970, 1, 1));
        viaturaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        viaturaEntity.setId(1L);
        viaturaEntity.setListaUpm(new ArrayList<>());
        viaturaEntity.setMarcaModelo("Marca Modelo");
        viaturaEntity.setNrSei("Nr Sei");
        viaturaEntity.setPlaca("Placa");
        viaturaEntity.setPrefixo("Prefixo");
        viaturaEntity.setRenavam("Renavam");
        viaturaEntity.setStatus("Status");
        viaturaEntity.setTipoEmpregoViatura(tipoEmpregoViatura);
        viaturaEntity.setTombamento("alice.liddell@example.org");
        Optional<ViaturaEntity> ofResult = Optional.of(viaturaEntity);
        when(viaturaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);
        TipoVistoriaDTO tipoVistoria = mock(TipoVistoriaDTO.class);
        when(tipoVistoria.getId()).thenReturn(1L);

        DiferencaDTO diferencaDTO = new DiferencaDTO();
        diferencaDTO.setIdViatura(1L);
        diferencaDTO.setTipoVistoria(tipoVistoria);
        diferencaDTO.setUltimoOdometro(10.0f);

        // Act and Assert
        assertThrows(VistoriaExceptions.class, () -> diferencaOdometroServiceImpl.buscarDiferenca(diferencaDTO));
        verify(tipoVistoria).getId();
        verify(tipoVistoriaRepository).findById(eq(1L));
        verify(viaturaRepository).findById(eq(1L));
    }

    /**
     * Method under test:
     * {@link DiferencaOdometroServiceImpl#buscarDiferenca(DiferencaDTO)}
     */
    @Test
    void testBuscarDiferenca3() {
        // Arrange
        TipoVistoriaEntity tipoVistoriaEntity = new TipoVistoriaEntity();
        tipoVistoriaEntity.setAtivo(true);
        tipoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoriaEntity.setDescricao("Descricao");
        tipoVistoriaEntity.setId(1L);
        tipoVistoriaEntity.setNome("Nome");
        tipoVistoriaEntity.setStatusAnterior("Status Anterior");
        tipoVistoriaEntity.setStatusPosterior("Status Posterior");
        Optional<TipoVistoriaEntity> ofResult = Optional.of(tipoVistoriaEntity);
        when(tipoVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);
        Optional<ViaturaEntity> emptyResult = Optional.empty();
        when(viaturaRepository.findById(Mockito.<Long>any())).thenReturn(emptyResult);

        DiferencaDTO diferencaDTO = new DiferencaDTO();
        diferencaDTO.setIdViatura(1L);
        diferencaDTO.setTipoVistoria(mock(TipoVistoriaDTO.class));
        diferencaDTO.setUltimoOdometro(10.0f);

        // Act and Assert
        assertThrows(VistoriaExceptions.class, () -> diferencaOdometroServiceImpl.buscarDiferenca(diferencaDTO));
        verify(viaturaRepository).findById(eq(1L));
    }

    /**
     * Method under test:
     * {@link DiferencaOdometroServiceImpl#buscarDiferenca(DiferencaDTO)}
     */
    @Test
    void testBuscarDiferenca4() {
        // Arrange
        when(diferencaOdometroRepository.findAllByReferenciaInicial(Mockito.<TipoVistoriaEntity>any()))
                .thenReturn(new ArrayList<>());

        TipoVistoriaEntity tipoVistoriaEntity = new TipoVistoriaEntity();
        tipoVistoriaEntity.setAtivo(true);
        tipoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoriaEntity.setDescricao("Descricao");
        tipoVistoriaEntity.setId(1L);
        tipoVistoriaEntity.setNome("Nome");
        tipoVistoriaEntity.setStatusAnterior("Status Anterior");
        tipoVistoriaEntity.setStatusPosterior("Status Posterior");
        Optional<TipoVistoriaEntity> ofResult = Optional.of(tipoVistoriaEntity);
        when(tipoVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        TipoEmpregoViaturaEntity tipoEmpregoViatura = new TipoEmpregoViaturaEntity();
        tipoEmpregoViatura.setAtivo(1);
        tipoEmpregoViatura.setId(1);
        tipoEmpregoViatura.setNome("Nome");

        ViaturaEntity viaturaEntity = new ViaturaEntity();
        viaturaEntity.setAtivo(true);
        viaturaEntity.setDataAtualizacao(LocalDate.of(1970, 1, 1));
        viaturaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        viaturaEntity.setId(1L);
        viaturaEntity.setListaUpm(new ArrayList<>());
        viaturaEntity.setMarcaModelo("Marca Modelo");
        viaturaEntity.setNrSei("Nr Sei");
        viaturaEntity.setPlaca("Placa");
        viaturaEntity.setPrefixo("Prefixo");
        viaturaEntity.setRenavam("Renavam");
        viaturaEntity.setStatus("Status");
        viaturaEntity.setTipoEmpregoViatura(tipoEmpregoViatura);
        viaturaEntity.setTombamento("alice.liddell@example.org");
        Optional<ViaturaEntity> ofResult2 = Optional.of(viaturaEntity);
        when(viaturaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult2);

        TipoVistoriaEntity referenciaFinal = new TipoVistoriaEntity();
        referenciaFinal.setAtivo(true);
        referenciaFinal.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaFinal.setDescricao("Descricao");
        referenciaFinal.setId(1L);
        referenciaFinal.setNome("Nome");
        referenciaFinal.setStatusAnterior("Status Anterior");
        referenciaFinal.setStatusPosterior("Status Posterior");

        TipoVistoriaEntity referenciaInicial = new TipoVistoriaEntity();
        referenciaInicial.setAtivo(true);
        referenciaInicial.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaInicial.setDescricao("Descricao");
        referenciaInicial.setId(1L);
        referenciaInicial.setNome("Nome");
        referenciaInicial.setStatusAnterior("Status Anterior");
        referenciaInicial.setStatusPosterior("Status Posterior");

        DiferencaOdometroEntity diferencaOdometro = new DiferencaOdometroEntity();
        diferencaOdometro.setDataInclusao(LocalDate.of(1970, 1, 1));
        diferencaOdometro.setDataModificacao(LocalDate.of(1970, 1, 1));
        diferencaOdometro.setDiferencaOdometro(10.0d);
        diferencaOdometro.setId(1L);
        diferencaOdometro.setReferenciaFinal(referenciaFinal);
        diferencaOdometro.setReferenciaInicial(referenciaInicial);

        TipoVistoriaEntity tipoVistoria = new TipoVistoriaEntity();
        tipoVistoria.setAtivo(true);
        tipoVistoria.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoria.setDescricao("Descricao");
        tipoVistoria.setId(1L);
        tipoVistoria.setNome("Nome");
        tipoVistoria.setStatusAnterior("Status Anterior");
        tipoVistoria.setStatusPosterior("Status Posterior");

        TipoEmpregoViaturaEntity tipoEmpregoViatura2 = new TipoEmpregoViaturaEntity();
        tipoEmpregoViatura2.setAtivo(4);
        tipoEmpregoViatura2.setId(1);
        tipoEmpregoViatura2.setNome("Nome");

        ViaturaEntity viatura = new ViaturaEntity();
        viatura.setAtivo(true);
        viatura.setDataAtualizacao(LocalDate.of(1970, 1, 1));
        viatura.setDataInclusao(LocalDate.of(1970, 1, 1));
        viatura.setId(1L);
        viatura.setListaUpm(new ArrayList<>());
        viatura.setMarcaModelo("Marca Modelo");
        viatura.setNrSei("Nr Sei");
        viatura.setPlaca("Placa");
        viatura.setPrefixo("Prefixo");
        viatura.setRenavam("Renavam");
        viatura.setStatus("Status");
        viatura.setTipoEmpregoViatura(tipoEmpregoViatura2);
        viatura.setTombamento("alice.liddell@example.org");

        VistoriaViaturaEntity vistoriaViaturaEntity = new VistoriaViaturaEntity();
        vistoriaViaturaEntity.setCheckLists(new ArrayList<>());
        vistoriaViaturaEntity.setDataVistoria(LocalDate.of(1970, 1, 1).atStartOfDay());
        vistoriaViaturaEntity.setDiferencaOdometro(diferencaOdometro);
        vistoriaViaturaEntity.setDiferencaVistoria(true);
        vistoriaViaturaEntity.setId(1L);
        vistoriaViaturaEntity.setIdPolicial(1);
        vistoriaViaturaEntity.setIdUpm(1);
        vistoriaViaturaEntity.setOdometroFinal(10.0f);
        vistoriaViaturaEntity.setOdometroInicial(10.0f);
        vistoriaViaturaEntity.setStatus(VistoriaViaturaStatusEnum.DISPONIVEL);
        vistoriaViaturaEntity.setTipoVistoria(tipoVistoria);
        vistoriaViaturaEntity.setViatura(viatura);
        vistoriaViaturaEntity.setVistoriaArquivoList(new ArrayList<>());
        vistoriaViaturaEntity.setVistoriaViaturaHistorico(new ArrayList<>());

        ArrayList<VistoriaViaturaEntity> vistoriaViaturaEntityList = new ArrayList<>();
        vistoriaViaturaEntityList.add(vistoriaViaturaEntity);
        when(vistoriaViaturaRepository.findAllByViatura(Mockito.<ViaturaEntity>any()))
                .thenReturn(vistoriaViaturaEntityList);
        TipoVistoriaDTO tipoVistoria2 = mock(TipoVistoriaDTO.class);
        when(tipoVistoria2.getId()).thenReturn(1L);

        DiferencaDTO diferencaDTO = new DiferencaDTO();
        diferencaDTO.setIdViatura(1L);
        diferencaDTO.setTipoVistoria(tipoVistoria2);
        diferencaDTO.setUltimoOdometro(10.0f);

        // Act
        DiferencaOdometroDTO actualBuscarDiferencaResult = diferencaOdometroServiceImpl.buscarDiferenca(diferencaDTO);

        // Assert
        verify(tipoVistoria2).getId();
        verify(diferencaOdometroRepository).findAllByReferenciaInicial(isA(TipoVistoriaEntity.class));
        verify(vistoriaViaturaRepository).findAllByViatura(isA(ViaturaEntity.class));
        verify(tipoVistoriaRepository).findById(eq(1L));
        verify(viaturaRepository).findById(eq(1L));
        assertNull(actualBuscarDiferencaResult.getReferenciaFinal());
        assertNull(actualBuscarDiferencaResult.getReferenciaInicial());
        assertNull(actualBuscarDiferencaResult.getDiferencaOdometro());
        assertNull(actualBuscarDiferencaResult.getDataInclusao());
        assertNull(actualBuscarDiferencaResult.getDataModificacao());
        assertTrue(actualBuscarDiferencaResult.getDiferencaPermitido());
    }

    /**
     * Method under test:
     * {@link DiferencaOdometroServiceImpl#buscarDiferenca(DiferencaDTO)}
     */
    @Test
    void testBuscarDiferenca5() {
        // Arrange
        TipoVistoriaEntity referenciaFinal = new TipoVistoriaEntity();
        referenciaFinal.setAtivo(true);
        referenciaFinal.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaFinal.setDescricao("Descricao");
        referenciaFinal.setId(1L);
        referenciaFinal.setNome("Nome");
        referenciaFinal.setStatusAnterior("Status Anterior");
        referenciaFinal.setStatusPosterior("Status Posterior");

        TipoVistoriaEntity referenciaInicial = new TipoVistoriaEntity();
        referenciaInicial.setAtivo(true);
        referenciaInicial.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaInicial.setDescricao("Descricao");
        referenciaInicial.setId(1L);
        referenciaInicial.setNome("Nome");
        referenciaInicial.setStatusAnterior("Status Anterior");
        referenciaInicial.setStatusPosterior("Status Posterior");

        DiferencaOdometroEntity diferencaOdometroEntity = new DiferencaOdometroEntity();
        diferencaOdometroEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        diferencaOdometroEntity.setDataModificacao(LocalDate.of(1970, 1, 1));
        diferencaOdometroEntity.setDiferencaOdometro(10.0d);
        diferencaOdometroEntity.setId(1L);
        diferencaOdometroEntity.setReferenciaFinal(referenciaFinal);
        diferencaOdometroEntity.setReferenciaInicial(referenciaInicial);

        ArrayList<DiferencaOdometroEntity> diferencaOdometroEntityList = new ArrayList<>();
        diferencaOdometroEntityList.add(diferencaOdometroEntity);
        when(diferencaOdometroRepository.findAllByReferenciaInicial(Mockito.<TipoVistoriaEntity>any()))
                .thenReturn(diferencaOdometroEntityList);

        TipoVistoriaEntity tipoVistoriaEntity = new TipoVistoriaEntity();
        tipoVistoriaEntity.setAtivo(true);
        tipoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoriaEntity.setDescricao("Descricao");
        tipoVistoriaEntity.setId(1L);
        tipoVistoriaEntity.setNome("Nome");
        tipoVistoriaEntity.setStatusAnterior("Status Anterior");
        tipoVistoriaEntity.setStatusPosterior("Status Posterior");
        Optional<TipoVistoriaEntity> ofResult = Optional.of(tipoVistoriaEntity);
        when(tipoVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        TipoEmpregoViaturaEntity tipoEmpregoViatura = new TipoEmpregoViaturaEntity();
        tipoEmpregoViatura.setAtivo(1);
        tipoEmpregoViatura.setId(1);
        tipoEmpregoViatura.setNome("Nome");

        ViaturaEntity viaturaEntity = new ViaturaEntity();
        viaturaEntity.setAtivo(true);
        viaturaEntity.setDataAtualizacao(LocalDate.of(1970, 1, 1));
        viaturaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        viaturaEntity.setId(1L);
        viaturaEntity.setListaUpm(new ArrayList<>());
        viaturaEntity.setMarcaModelo("Marca Modelo");
        viaturaEntity.setNrSei("Nr Sei");
        viaturaEntity.setPlaca("Placa");
        viaturaEntity.setPrefixo("Prefixo");
        viaturaEntity.setRenavam("Renavam");
        viaturaEntity.setStatus("Status");
        viaturaEntity.setTipoEmpregoViatura(tipoEmpregoViatura);
        viaturaEntity.setTombamento("alice.liddell@example.org");
        Optional<ViaturaEntity> ofResult2 = Optional.of(viaturaEntity);
        when(viaturaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult2);

        TipoVistoriaEntity referenciaFinal2 = new TipoVistoriaEntity();
        referenciaFinal2.setAtivo(true);
        referenciaFinal2.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaFinal2.setDescricao("Descricao");
        referenciaFinal2.setId(1L);
        referenciaFinal2.setNome("Nome");
        referenciaFinal2.setStatusAnterior("Status Anterior");
        referenciaFinal2.setStatusPosterior("Status Posterior");

        TipoVistoriaEntity referenciaInicial2 = new TipoVistoriaEntity();
        referenciaInicial2.setAtivo(true);
        referenciaInicial2.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaInicial2.setDescricao("Descricao");
        referenciaInicial2.setId(1L);
        referenciaInicial2.setNome("Nome");
        referenciaInicial2.setStatusAnterior("Status Anterior");
        referenciaInicial2.setStatusPosterior("Status Posterior");

        DiferencaOdometroEntity diferencaOdometro = new DiferencaOdometroEntity();
        diferencaOdometro.setDataInclusao(LocalDate.of(1970, 1, 1));
        diferencaOdometro.setDataModificacao(LocalDate.of(1970, 1, 1));
        diferencaOdometro.setDiferencaOdometro(10.0d);
        diferencaOdometro.setId(1L);
        diferencaOdometro.setReferenciaFinal(referenciaFinal2);
        diferencaOdometro.setReferenciaInicial(referenciaInicial2);

        TipoVistoriaEntity tipoVistoria = new TipoVistoriaEntity();
        tipoVistoria.setAtivo(true);
        tipoVistoria.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoria.setDescricao("Descricao");
        tipoVistoria.setId(1L);
        tipoVistoria.setNome("Nome");
        tipoVistoria.setStatusAnterior("Status Anterior");
        tipoVistoria.setStatusPosterior("Status Posterior");

        TipoEmpregoViaturaEntity tipoEmpregoViatura2 = new TipoEmpregoViaturaEntity();
        tipoEmpregoViatura2.setAtivo(4);
        tipoEmpregoViatura2.setId(1);
        tipoEmpregoViatura2.setNome("Nome");

        ViaturaEntity viatura = new ViaturaEntity();
        viatura.setAtivo(true);
        viatura.setDataAtualizacao(LocalDate.of(1970, 1, 1));
        viatura.setDataInclusao(LocalDate.of(1970, 1, 1));
        viatura.setId(1L);
        viatura.setListaUpm(new ArrayList<>());
        viatura.setMarcaModelo("Marca Modelo");
        viatura.setNrSei("Nr Sei");
        viatura.setPlaca("Placa");
        viatura.setPrefixo("Prefixo");
        viatura.setRenavam("Renavam");
        viatura.setStatus("Status");
        viatura.setTipoEmpregoViatura(tipoEmpregoViatura2);
        viatura.setTombamento("alice.liddell@example.org");

        VistoriaViaturaEntity vistoriaViaturaEntity = new VistoriaViaturaEntity();
        vistoriaViaturaEntity.setCheckLists(new ArrayList<>());
        vistoriaViaturaEntity.setDataVistoria(LocalDate.of(1970, 1, 1).atStartOfDay());
        vistoriaViaturaEntity.setDiferencaOdometro(diferencaOdometro);
        vistoriaViaturaEntity.setDiferencaVistoria(true);
        vistoriaViaturaEntity.setId(1L);
        vistoriaViaturaEntity.setIdPolicial(1);
        vistoriaViaturaEntity.setIdUpm(1);
        vistoriaViaturaEntity.setOdometroFinal(10.0f);
        vistoriaViaturaEntity.setOdometroInicial(10.0f);
        vistoriaViaturaEntity.setStatus(VistoriaViaturaStatusEnum.DISPONIVEL);
        vistoriaViaturaEntity.setTipoVistoria(tipoVistoria);
        vistoriaViaturaEntity.setViatura(viatura);
        vistoriaViaturaEntity.setVistoriaArquivoList(new ArrayList<>());
        vistoriaViaturaEntity.setVistoriaViaturaHistorico(new ArrayList<>());

        ArrayList<VistoriaViaturaEntity> vistoriaViaturaEntityList = new ArrayList<>();
        vistoriaViaturaEntityList.add(vistoriaViaturaEntity);
        when(vistoriaViaturaRepository.findAllByViatura(Mockito.<ViaturaEntity>any()))
                .thenReturn(vistoriaViaturaEntityList);
        TipoVistoriaDTO tipoVistoria2 = mock(TipoVistoriaDTO.class);
        when(tipoVistoria2.getId()).thenReturn(1L);

        DiferencaDTO diferencaDTO = new DiferencaDTO();
        diferencaDTO.setIdViatura(1L);
        diferencaDTO.setTipoVistoria(tipoVistoria2);
        diferencaDTO.setUltimoOdometro(10.0f);

        // Act
        DiferencaOdometroDTO actualBuscarDiferencaResult = diferencaOdometroServiceImpl.buscarDiferenca(diferencaDTO);

        // Assert
        verify(tipoVistoria2).getId();
        verify(diferencaOdometroRepository).findAllByReferenciaInicial(isA(TipoVistoriaEntity.class));
        verify(vistoriaViaturaRepository).findAllByViatura(isA(ViaturaEntity.class));
        verify(tipoVistoriaRepository).findById(eq(1L));
        verify(viaturaRepository).findById(eq(1L));
        assertEquals("1970-01-01", actualBuscarDiferencaResult.getDataInclusao().toString());
        assertEquals("1970-01-01", actualBuscarDiferencaResult.getDataModificacao().toString());
        assertEquals(10.0d, actualBuscarDiferencaResult.getDiferencaOdometro().doubleValue());
        assertTrue(actualBuscarDiferencaResult.getReferenciaFinal().getAtivo());
        assertTrue(actualBuscarDiferencaResult.getDiferencaPermitido());
        assertEquals(referenciaFinal, actualBuscarDiferencaResult.getReferenciaInicial());
    }
}
