package br.gov.df.pm.sgv.domain;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

import br.gov.df.pm.sgv.domain.enums.VistoriaViaturaStatusEnum;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

class VistoriaViaturaEntityDiffblueTest {
    /**
     * Methods under test:
     * <ul>
     *   <li>{@link VistoriaViaturaEntity#VistoriaViaturaEntity()}
     *   <li>{@link VistoriaViaturaEntity#setCheckLists(List)}
     *   <li>{@link VistoriaViaturaEntity#setDataVistoria(LocalDateTime)}
     *   <li>
     * {@link VistoriaViaturaEntity#setDiferencaOdometro(DiferencaOdometroEntity)}
     *   <li>{@link VistoriaViaturaEntity#setDiferencaVistoria(Boolean)}
     *   <li>{@link VistoriaViaturaEntity#setId(Long)}
     *   <li>{@link VistoriaViaturaEntity#setIdPolicial(Integer)}
     *   <li>{@link VistoriaViaturaEntity#setIdUpm(Integer)}
     *   <li>{@link VistoriaViaturaEntity#setOdometroFinal(Float)}
     *   <li>{@link VistoriaViaturaEntity#setOdometroInicial(Float)}
     *   <li>{@link VistoriaViaturaEntity#setStatus(VistoriaViaturaStatusEnum)}
     *   <li>{@link VistoriaViaturaEntity#setTipoVistoria(TipoVistoriaEntity)}
     *   <li>{@link VistoriaViaturaEntity#setViatura(ViaturaEntity)}
     *   <li>{@link VistoriaViaturaEntity#setVistoriaArquivoList(List)}
     *   <li>{@link VistoriaViaturaEntity#setVistoriaViaturaHistorico(List)}
     *   <li>{@link VistoriaViaturaEntity#getCheckLists()}
     *   <li>{@link VistoriaViaturaEntity#getDataVistoria()}
     *   <li>{@link VistoriaViaturaEntity#getDiferencaOdometro()}
     *   <li>{@link VistoriaViaturaEntity#getDiferencaVistoria()}
     *   <li>{@link VistoriaViaturaEntity#getId()}
     *   <li>{@link VistoriaViaturaEntity#getIdPolicial()}
     *   <li>{@link VistoriaViaturaEntity#getIdUpm()}
     *   <li>{@link VistoriaViaturaEntity#getOdometroFinal()}
     *   <li>{@link VistoriaViaturaEntity#getOdometroInicial()}
     *   <li>{@link VistoriaViaturaEntity#getStatus()}
     *   <li>{@link VistoriaViaturaEntity#getTipoVistoria()}
     *   <li>{@link VistoriaViaturaEntity#getViatura()}
     *   <li>{@link VistoriaViaturaEntity#getVistoriaArquivoList()}
     *   <li>{@link VistoriaViaturaEntity#getVistoriaViaturaHistorico()}
     * </ul>
     */
    @Test
    void testGettersAndSetters() {
        // Arrange and Act
        VistoriaViaturaEntity actualVistoriaViaturaEntity = new VistoriaViaturaEntity();
        ArrayList<ChecklistVistoriaEntity> checkLists = new ArrayList<>();
        actualVistoriaViaturaEntity.setCheckLists(checkLists);
        LocalDateTime dataVistoria = LocalDate.of(1970, 1, 1).atStartOfDay();
        actualVistoriaViaturaEntity.setDataVistoria(dataVistoria);
        TipoVistoriaEntity referenciaFinal = new TipoVistoriaEntity();
        referenciaFinal.setAtivo(true);
        referenciaFinal.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaFinal.setDescricao("Descricao");
        referenciaFinal.setId(1L);
        referenciaFinal.setNome("Nome");
        referenciaFinal.setStatusAnterior("Status Anterior");
        referenciaFinal.setStatusPosterior("Status Posterior");
        TipoVistoriaEntity referenciaInicial = new TipoVistoriaEntity();
        referenciaInicial.setAtivo(true);
        referenciaInicial.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaInicial.setDescricao("Descricao");
        referenciaInicial.setId(1L);
        referenciaInicial.setNome("Nome");
        referenciaInicial.setStatusAnterior("Status Anterior");
        referenciaInicial.setStatusPosterior("Status Posterior");
        DiferencaOdometroEntity diferencaOdometro = new DiferencaOdometroEntity();
        diferencaOdometro.setDataInclusao(LocalDate.of(1970, 1, 1));
        diferencaOdometro.setDataModificacao(LocalDate.of(1970, 1, 1));
        diferencaOdometro.setDiferencaOdometro(10.0d);
        diferencaOdometro.setId(1L);
        diferencaOdometro.setReferenciaFinal(referenciaFinal);
        diferencaOdometro.setReferenciaInicial(referenciaInicial);
        actualVistoriaViaturaEntity.setDiferencaOdometro(diferencaOdometro);
        actualVistoriaViaturaEntity.setDiferencaVistoria(true);
        actualVistoriaViaturaEntity.setId(1L);
        actualVistoriaViaturaEntity.setIdPolicial(1);
        actualVistoriaViaturaEntity.setIdUpm(1);
        actualVistoriaViaturaEntity.setOdometroFinal(10.0f);
        actualVistoriaViaturaEntity.setOdometroInicial(10.0f);
        actualVistoriaViaturaEntity.setStatus(VistoriaViaturaStatusEnum.DISPONIVEL);
        TipoVistoriaEntity tipoVistoria = new TipoVistoriaEntity();
        tipoVistoria.setAtivo(true);
        tipoVistoria.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoria.setDescricao("Descricao");
        tipoVistoria.setId(1L);
        tipoVistoria.setNome("Nome");
        tipoVistoria.setStatusAnterior("Status Anterior");
        tipoVistoria.setStatusPosterior("Status Posterior");
        actualVistoriaViaturaEntity.setTipoVistoria(tipoVistoria);
        TipoEmpregoViaturaEntity tipoEmpregoViatura = new TipoEmpregoViaturaEntity();
        tipoEmpregoViatura.setAtivo(1);
        tipoEmpregoViatura.setId(1);
        tipoEmpregoViatura.setNome("Nome");
        ViaturaEntity viatura = new ViaturaEntity();
        viatura.setAtivo(true);
        viatura.setDataAtualizacao(LocalDate.of(1970, 1, 1));
        viatura.setDataInclusao(LocalDate.of(1970, 1, 1));
        viatura.setId(1L);
        viatura.setListaUpm(new ArrayList<>());
        viatura.setMarcaModelo("Marca Modelo");
        viatura.setNrSei("Nr Sei");
        viatura.setPlaca("Placa");
        viatura.setPrefixo("Prefixo");
        viatura.setRenavam("Renavam");
        viatura.setStatus("Status");
        viatura.setTipoEmpregoViatura(tipoEmpregoViatura);
        viatura.setTombamento("alice.liddell@example.org");
        actualVistoriaViaturaEntity.setViatura(viatura);
        ArrayList<VistoriaArquivo> vistoriaArquivoList = new ArrayList<>();
        actualVistoriaViaturaEntity.setVistoriaArquivoList(vistoriaArquivoList);
        ArrayList<VistoriaViaturaHistoricoEntity> vistoriaViaturaHistorico = new ArrayList<>();
        actualVistoriaViaturaEntity.setVistoriaViaturaHistorico(vistoriaViaturaHistorico);
        List<ChecklistVistoriaEntity> actualCheckLists = actualVistoriaViaturaEntity.getCheckLists();
        LocalDateTime actualDataVistoria = actualVistoriaViaturaEntity.getDataVistoria();
        DiferencaOdometroEntity actualDiferencaOdometro = actualVistoriaViaturaEntity.getDiferencaOdometro();
        Boolean actualDiferencaVistoria = actualVistoriaViaturaEntity.getDiferencaVistoria();
        Long actualId = actualVistoriaViaturaEntity.getId();
        Integer actualIdPolicial = actualVistoriaViaturaEntity.getIdPolicial();
        Integer actualIdUpm = actualVistoriaViaturaEntity.getIdUpm();
        Float actualOdometroFinal = actualVistoriaViaturaEntity.getOdometroFinal();
        Float actualOdometroInicial = actualVistoriaViaturaEntity.getOdometroInicial();
        VistoriaViaturaStatusEnum actualStatus = actualVistoriaViaturaEntity.getStatus();
        TipoVistoriaEntity actualTipoVistoria = actualVistoriaViaturaEntity.getTipoVistoria();
        ViaturaEntity actualViatura = actualVistoriaViaturaEntity.getViatura();
        List<VistoriaArquivo> actualVistoriaArquivoList = actualVistoriaViaturaEntity.getVistoriaArquivoList();
        List<VistoriaViaturaHistoricoEntity> actualVistoriaViaturaHistorico = actualVistoriaViaturaEntity
                .getVistoriaViaturaHistorico();

        // Assert that nothing has changed
        assertEquals(1, actualIdPolicial.intValue());
        assertEquals(1, actualIdUpm.intValue());
        assertEquals(10.0f, actualOdometroFinal.floatValue());
        assertEquals(10.0f, actualOdometroInicial.floatValue());
        assertEquals(1L, actualId.longValue());
        assertEquals(VistoriaViaturaStatusEnum.DISPONIVEL, actualStatus);
        assertTrue(actualDiferencaVistoria);
        assertSame(diferencaOdometro, actualDiferencaOdometro);
        assertSame(tipoVistoria, actualTipoVistoria);
        assertSame(viatura, actualViatura);
        assertSame(checkLists, actualCheckLists);
        assertSame(vistoriaArquivoList, actualVistoriaArquivoList);
        assertSame(vistoriaViaturaHistorico, actualVistoriaViaturaHistorico);
        assertSame(dataVistoria, actualDataVistoria);
    }

    /**
     * Methods under test:
     * <ul>
     *   <li>
     * {@link VistoriaViaturaEntity#VistoriaViaturaEntity(Long, Integer, Integer, ViaturaEntity, TipoVistoriaEntity, List, List, DiferencaOdometroEntity, VistoriaViaturaStatusEnum, Float, Float, Boolean, LocalDateTime, List)}
     *   <li>{@link VistoriaViaturaEntity#setCheckLists(List)}
     *   <li>{@link VistoriaViaturaEntity#setDataVistoria(LocalDateTime)}
     *   <li>
     * {@link VistoriaViaturaEntity#setDiferencaOdometro(DiferencaOdometroEntity)}
     *   <li>{@link VistoriaViaturaEntity#setDiferencaVistoria(Boolean)}
     *   <li>{@link VistoriaViaturaEntity#setId(Long)}
     *   <li>{@link VistoriaViaturaEntity#setIdPolicial(Integer)}
     *   <li>{@link VistoriaViaturaEntity#setIdUpm(Integer)}
     *   <li>{@link VistoriaViaturaEntity#setOdometroFinal(Float)}
     *   <li>{@link VistoriaViaturaEntity#setOdometroInicial(Float)}
     *   <li>{@link VistoriaViaturaEntity#setStatus(VistoriaViaturaStatusEnum)}
     *   <li>{@link VistoriaViaturaEntity#setTipoVistoria(TipoVistoriaEntity)}
     *   <li>{@link VistoriaViaturaEntity#setViatura(ViaturaEntity)}
     *   <li>{@link VistoriaViaturaEntity#setVistoriaArquivoList(List)}
     *   <li>{@link VistoriaViaturaEntity#setVistoriaViaturaHistorico(List)}
     *   <li>{@link VistoriaViaturaEntity#getCheckLists()}
     *   <li>{@link VistoriaViaturaEntity#getDataVistoria()}
     *   <li>{@link VistoriaViaturaEntity#getDiferencaOdometro()}
     *   <li>{@link VistoriaViaturaEntity#getDiferencaVistoria()}
     *   <li>{@link VistoriaViaturaEntity#getId()}
     *   <li>{@link VistoriaViaturaEntity#getIdPolicial()}
     *   <li>{@link VistoriaViaturaEntity#getIdUpm()}
     *   <li>{@link VistoriaViaturaEntity#getOdometroFinal()}
     *   <li>{@link VistoriaViaturaEntity#getOdometroInicial()}
     *   <li>{@link VistoriaViaturaEntity#getStatus()}
     *   <li>{@link VistoriaViaturaEntity#getTipoVistoria()}
     *   <li>{@link VistoriaViaturaEntity#getViatura()}
     *   <li>{@link VistoriaViaturaEntity#getVistoriaArquivoList()}
     *   <li>{@link VistoriaViaturaEntity#getVistoriaViaturaHistorico()}
     * </ul>
     */
    @Test
    void testGettersAndSetters2() {
        // Arrange
        TipoEmpregoViaturaEntity tipoEmpregoViatura = new TipoEmpregoViaturaEntity();
        tipoEmpregoViatura.setAtivo(1);
        tipoEmpregoViatura.setId(1);
        tipoEmpregoViatura.setNome("Nome");

        ViaturaEntity viatura = new ViaturaEntity();
        viatura.setAtivo(true);
        viatura.setDataAtualizacao(LocalDate.of(1970, 1, 1));
        viatura.setDataInclusao(LocalDate.of(1970, 1, 1));
        viatura.setId(1L);
        ArrayList<ViaturaUpmEntity> listaUpm = new ArrayList<>();
        viatura.setListaUpm(listaUpm);
        viatura.setMarcaModelo("Marca Modelo");
        viatura.setNrSei("Nr Sei");
        viatura.setPlaca("Placa");
        viatura.setPrefixo("Prefixo");
        viatura.setRenavam("Renavam");
        viatura.setStatus("Status");
        viatura.setTipoEmpregoViatura(tipoEmpregoViatura);
        viatura.setTombamento("alice.liddell@example.org");

        TipoVistoriaEntity tipoVistoria = new TipoVistoriaEntity();
        tipoVistoria.setAtivo(true);
        tipoVistoria.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoria.setDescricao("Descricao");
        tipoVistoria.setId(1L);
        tipoVistoria.setNome("Nome");
        tipoVistoria.setStatusAnterior("Status Anterior");
        tipoVistoria.setStatusPosterior("Status Posterior");
        ArrayList<VistoriaViaturaHistoricoEntity> vistoriaViaturaHistorico = new ArrayList<>();
        ArrayList<VistoriaArquivo> vistoriaArquivoList = new ArrayList<>();

        TipoVistoriaEntity referenciaFinal = new TipoVistoriaEntity();
        referenciaFinal.setAtivo(true);
        referenciaFinal.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaFinal.setDescricao("Descricao");
        referenciaFinal.setId(1L);
        referenciaFinal.setNome("Nome");
        referenciaFinal.setStatusAnterior("Status Anterior");
        referenciaFinal.setStatusPosterior("Status Posterior");

        TipoVistoriaEntity referenciaInicial = new TipoVistoriaEntity();
        referenciaInicial.setAtivo(true);
        referenciaInicial.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaInicial.setDescricao("Descricao");
        referenciaInicial.setId(1L);
        referenciaInicial.setNome("Nome");
        referenciaInicial.setStatusAnterior("Status Anterior");
        referenciaInicial.setStatusPosterior("Status Posterior");

        DiferencaOdometroEntity diferencaOdometro = new DiferencaOdometroEntity();
        diferencaOdometro.setDataInclusao(LocalDate.of(1970, 1, 1));
        diferencaOdometro.setDataModificacao(LocalDate.of(1970, 1, 1));
        diferencaOdometro.setDiferencaOdometro(10.0d);
        diferencaOdometro.setId(1L);
        diferencaOdometro.setReferenciaFinal(referenciaFinal);
        diferencaOdometro.setReferenciaInicial(referenciaInicial);
        LocalDateTime dataVistoria = LocalDate.of(1970, 1, 1).atStartOfDay();

        // Act
        VistoriaViaturaEntity actualVistoriaViaturaEntity = new VistoriaViaturaEntity(1L, 1, 1, viatura, tipoVistoria,
                vistoriaViaturaHistorico, vistoriaArquivoList, diferencaOdometro, VistoriaViaturaStatusEnum.DISPONIVEL, 10.0f,
                10.0f, true, dataVistoria, new ArrayList<>());
        ArrayList<ChecklistVistoriaEntity> checkLists = new ArrayList<>();
        actualVistoriaViaturaEntity.setCheckLists(checkLists);
        LocalDateTime dataVistoria2 = LocalDate.of(1970, 1, 1).atStartOfDay();
        actualVistoriaViaturaEntity.setDataVistoria(dataVistoria2);
        TipoVistoriaEntity referenciaFinal2 = new TipoVistoriaEntity();
        referenciaFinal2.setAtivo(true);
        referenciaFinal2.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaFinal2.setDescricao("Descricao");
        referenciaFinal2.setId(1L);
        referenciaFinal2.setNome("Nome");
        referenciaFinal2.setStatusAnterior("Status Anterior");
        referenciaFinal2.setStatusPosterior("Status Posterior");
        TipoVistoriaEntity referenciaInicial2 = new TipoVistoriaEntity();
        referenciaInicial2.setAtivo(true);
        referenciaInicial2.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaInicial2.setDescricao("Descricao");
        referenciaInicial2.setId(1L);
        referenciaInicial2.setNome("Nome");
        referenciaInicial2.setStatusAnterior("Status Anterior");
        referenciaInicial2.setStatusPosterior("Status Posterior");
        DiferencaOdometroEntity diferencaOdometro2 = new DiferencaOdometroEntity();
        diferencaOdometro2.setDataInclusao(LocalDate.of(1970, 1, 1));
        diferencaOdometro2.setDataModificacao(LocalDate.of(1970, 1, 1));
        diferencaOdometro2.setDiferencaOdometro(10.0d);
        diferencaOdometro2.setId(1L);
        diferencaOdometro2.setReferenciaFinal(referenciaFinal2);
        diferencaOdometro2.setReferenciaInicial(referenciaInicial2);
        actualVistoriaViaturaEntity.setDiferencaOdometro(diferencaOdometro2);
        actualVistoriaViaturaEntity.setDiferencaVistoria(true);
        actualVistoriaViaturaEntity.setId(1L);
        actualVistoriaViaturaEntity.setIdPolicial(1);
        actualVistoriaViaturaEntity.setIdUpm(1);
        actualVistoriaViaturaEntity.setOdometroFinal(10.0f);
        actualVistoriaViaturaEntity.setOdometroInicial(10.0f);
        actualVistoriaViaturaEntity.setStatus(VistoriaViaturaStatusEnum.DISPONIVEL);
        TipoVistoriaEntity tipoVistoria2 = new TipoVistoriaEntity();
        tipoVistoria2.setAtivo(true);
        tipoVistoria2.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoria2.setDescricao("Descricao");
        tipoVistoria2.setId(1L);
        tipoVistoria2.setNome("Nome");
        tipoVistoria2.setStatusAnterior("Status Anterior");
        tipoVistoria2.setStatusPosterior("Status Posterior");
        actualVistoriaViaturaEntity.setTipoVistoria(tipoVistoria2);
        TipoEmpregoViaturaEntity tipoEmpregoViatura2 = new TipoEmpregoViaturaEntity();
        tipoEmpregoViatura2.setAtivo(1);
        tipoEmpregoViatura2.setId(1);
        tipoEmpregoViatura2.setNome("Nome");
        ViaturaEntity viatura2 = new ViaturaEntity();
        viatura2.setAtivo(true);
        viatura2.setDataAtualizacao(LocalDate.of(1970, 1, 1));
        viatura2.setDataInclusao(LocalDate.of(1970, 1, 1));
        viatura2.setId(1L);
        viatura2.setListaUpm(new ArrayList<>());
        viatura2.setMarcaModelo("Marca Modelo");
        viatura2.setNrSei("Nr Sei");
        viatura2.setPlaca("Placa");
        viatura2.setPrefixo("Prefixo");
        viatura2.setRenavam("Renavam");
        viatura2.setStatus("Status");
        viatura2.setTipoEmpregoViatura(tipoEmpregoViatura2);
        viatura2.setTombamento("alice.liddell@example.org");
        actualVistoriaViaturaEntity.setViatura(viatura2);
        ArrayList<VistoriaArquivo> vistoriaArquivoList2 = new ArrayList<>();
        actualVistoriaViaturaEntity.setVistoriaArquivoList(vistoriaArquivoList2);
        ArrayList<VistoriaViaturaHistoricoEntity> vistoriaViaturaHistorico2 = new ArrayList<>();
        actualVistoriaViaturaEntity.setVistoriaViaturaHistorico(vistoriaViaturaHistorico2);
        List<ChecklistVistoriaEntity> actualCheckLists = actualVistoriaViaturaEntity.getCheckLists();
        LocalDateTime actualDataVistoria = actualVistoriaViaturaEntity.getDataVistoria();
        DiferencaOdometroEntity actualDiferencaOdometro = actualVistoriaViaturaEntity.getDiferencaOdometro();
        Boolean actualDiferencaVistoria = actualVistoriaViaturaEntity.getDiferencaVistoria();
        Long actualId = actualVistoriaViaturaEntity.getId();
        Integer actualIdPolicial = actualVistoriaViaturaEntity.getIdPolicial();
        Integer actualIdUpm = actualVistoriaViaturaEntity.getIdUpm();
        Float actualOdometroFinal = actualVistoriaViaturaEntity.getOdometroFinal();
        Float actualOdometroInicial = actualVistoriaViaturaEntity.getOdometroInicial();
        VistoriaViaturaStatusEnum actualStatus = actualVistoriaViaturaEntity.getStatus();
        TipoVistoriaEntity actualTipoVistoria = actualVistoriaViaturaEntity.getTipoVistoria();
        ViaturaEntity actualViatura = actualVistoriaViaturaEntity.getViatura();
        List<VistoriaArquivo> actualVistoriaArquivoList = actualVistoriaViaturaEntity.getVistoriaArquivoList();
        List<VistoriaViaturaHistoricoEntity> actualVistoriaViaturaHistorico = actualVistoriaViaturaEntity
                .getVistoriaViaturaHistorico();

        // Assert that nothing has changed
        assertEquals(1, actualIdPolicial.intValue());
        assertEquals(1, actualIdUpm.intValue());
        assertEquals(10.0f, actualOdometroFinal.floatValue());
        assertEquals(10.0f, actualOdometroInicial.floatValue());
        assertEquals(1L, actualId.longValue());
        assertEquals(VistoriaViaturaStatusEnum.DISPONIVEL, actualStatus);
        assertTrue(actualDiferencaVistoria);
        assertEquals(diferencaOdometro, actualDiferencaOdometro);
        assertEquals(tipoVistoria, actualTipoVistoria);
        assertEquals(viatura, actualViatura);
        assertEquals(listaUpm, actualCheckLists);
        assertEquals(listaUpm, actualVistoriaArquivoList);
        assertEquals(listaUpm, actualVistoriaViaturaHistorico);
        assertSame(diferencaOdometro2, actualDiferencaOdometro);
        assertSame(tipoVistoria2, actualTipoVistoria);
        assertSame(viatura2, actualViatura);
        assertSame(checkLists, actualCheckLists);
        assertSame(vistoriaArquivoList2, actualVistoriaArquivoList);
        assertSame(vistoriaViaturaHistorico2, actualVistoriaViaturaHistorico);
        assertSame(dataVistoria2, actualDataVistoria);
    }
}
