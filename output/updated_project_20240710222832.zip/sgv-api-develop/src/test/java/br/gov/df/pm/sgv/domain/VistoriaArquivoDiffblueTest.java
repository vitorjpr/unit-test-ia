package br.gov.df.pm.sgv.domain;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;

import br.gov.df.pm.sgv.domain.enums.VistoriaViaturaStatusEnum;

import java.time.LocalDate;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Date;

import org.junit.jupiter.api.Test;

class VistoriaArquivoDiffblueTest {
    /**
     * Methods under test:
     * <ul>
     *   <li>{@link VistoriaArquivo#VistoriaArquivo()}
     *   <li>{@link VistoriaArquivo#setDataCriacao(Date)}
     *   <li>{@link VistoriaArquivo#setId(Long)}
     *   <li>{@link VistoriaArquivo#setIdentidade(String)}
     *   <li>{@link VistoriaArquivo#setNomeImagem(String)}
     *   <li>{@link VistoriaArquivo#setVistoriaViatura(VistoriaViaturaEntity)}
     *   <li>{@link VistoriaArquivo#getDataCriacao()}
     *   <li>{@link VistoriaArquivo#getId()}
     *   <li>{@link VistoriaArquivo#getIdentidade()}
     *   <li>{@link VistoriaArquivo#getNomeImagem()}
     *   <li>{@link VistoriaArquivo#getVistoriaViatura()}
     * </ul>
     */
    @Test
    void testGettersAndSetters() {
        // Arrange and Act
        VistoriaArquivo actualVistoriaArquivo = new VistoriaArquivo();
        Date dataCriacao = Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant());
        actualVistoriaArquivo.setDataCriacao(dataCriacao);
        actualVistoriaArquivo.setId(1L);
        actualVistoriaArquivo.setIdentidade("Identidade");
        actualVistoriaArquivo.setNomeImagem("Nome Imagem");
        TipoVistoriaEntity referenciaFinal = new TipoVistoriaEntity();
        referenciaFinal.setAtivo(true);
        referenciaFinal.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaFinal.setDescricao("Descricao");
        referenciaFinal.setId(1L);
        referenciaFinal.setNome("Nome");
        referenciaFinal.setStatusAnterior("Status Anterior");
        referenciaFinal.setStatusPosterior("Status Posterior");
        TipoVistoriaEntity referenciaInicial = new TipoVistoriaEntity();
        referenciaInicial.setAtivo(true);
        referenciaInicial.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaInicial.setDescricao("Descricao");
        referenciaInicial.setId(1L);
        referenciaInicial.setNome("Nome");
        referenciaInicial.setStatusAnterior("Status Anterior");
        referenciaInicial.setStatusPosterior("Status Posterior");
        DiferencaOdometroEntity diferencaOdometro = new DiferencaOdometroEntity();
        diferencaOdometro.setDataInclusao(LocalDate.of(1970, 1, 1));
        diferencaOdometro.setDataModificacao(LocalDate.of(1970, 1, 1));
        diferencaOdometro.setDiferencaOdometro(10.0d);
        diferencaOdometro.setId(1L);
        diferencaOdometro.setReferenciaFinal(referenciaFinal);
        diferencaOdometro.setReferenciaInicial(referenciaInicial);
        TipoVistoriaEntity tipoVistoria = new TipoVistoriaEntity();
        tipoVistoria.setAtivo(true);
        tipoVistoria.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoria.setDescricao("Descricao");
        tipoVistoria.setId(1L);
        tipoVistoria.setNome("Nome");
        tipoVistoria.setStatusAnterior("Status Anterior");
        tipoVistoria.setStatusPosterior("Status Posterior");
        TipoEmpregoViaturaEntity tipoEmpregoViatura = new TipoEmpregoViaturaEntity();
        tipoEmpregoViatura.setAtivo(1);
        tipoEmpregoViatura.setId(1);
        tipoEmpregoViatura.setNome("Nome");
        ViaturaEntity viatura = new ViaturaEntity();
        viatura.setAtivo(true);
        viatura.setDataAtualizacao(LocalDate.of(1970, 1, 1));
        viatura.setDataInclusao(LocalDate.of(1970, 1, 1));
        viatura.setId(1L);
        viatura.setListaUpm(new ArrayList<>());
        viatura.setMarcaModelo("Marca Modelo");
        viatura.setNrSei("Nr Sei");
        viatura.setPlaca("Placa");
        viatura.setPrefixo("Prefixo");
        viatura.setRenavam("Renavam");
        viatura.setStatus("Status");
        viatura.setTipoEmpregoViatura(tipoEmpregoViatura);
        viatura.setTombamento("alice.liddell@example.org");
        VistoriaViaturaEntity vistoriaViatura = new VistoriaViaturaEntity();
        vistoriaViatura.setCheckLists(new ArrayList<>());
        vistoriaViatura.setDataVistoria(LocalDate.of(1970, 1, 1).atStartOfDay());
        vistoriaViatura.setDiferencaOdometro(diferencaOdometro);
        vistoriaViatura.setDiferencaVistoria(true);
        vistoriaViatura.setId(1L);
        vistoriaViatura.setIdPolicial(1);
        vistoriaViatura.setIdUpm(1);
        vistoriaViatura.setOdometroFinal(10.0f);
        vistoriaViatura.setOdometroInicial(10.0f);
        vistoriaViatura.setStatus(VistoriaViaturaStatusEnum.DISPONIVEL);
        vistoriaViatura.setTipoVistoria(tipoVistoria);
        vistoriaViatura.setViatura(viatura);
        vistoriaViatura.setVistoriaArquivoList(new ArrayList<>());
        vistoriaViatura.setVistoriaViaturaHistorico(new ArrayList<>());
        actualVistoriaArquivo.setVistoriaViatura(vistoriaViatura);
        Date actualDataCriacao = actualVistoriaArquivo.getDataCriacao();
        Long actualId = actualVistoriaArquivo.getId();
        String actualIdentidade = actualVistoriaArquivo.getIdentidade();
        String actualNomeImagem = actualVistoriaArquivo.getNomeImagem();
        VistoriaViaturaEntity actualVistoriaViatura = actualVistoriaArquivo.getVistoriaViatura();

        // Assert that nothing has changed
        assertEquals("Identidade", actualIdentidade);
        assertEquals("Nome Imagem", actualNomeImagem);
        assertEquals(1L, actualId.longValue());
        assertSame(vistoriaViatura, actualVistoriaViatura);
        assertSame(dataCriacao, actualDataCriacao);
    }

    /**
     * Methods under test:
     * <ul>
     *   <li>
     * {@link VistoriaArquivo#VistoriaArquivo(Long, String, String, Date, VistoriaViaturaEntity)}
     *   <li>{@link VistoriaArquivo#setDataCriacao(Date)}
     *   <li>{@link VistoriaArquivo#setId(Long)}
     *   <li>{@link VistoriaArquivo#setIdentidade(String)}
     *   <li>{@link VistoriaArquivo#setNomeImagem(String)}
     *   <li>{@link VistoriaArquivo#setVistoriaViatura(VistoriaViaturaEntity)}
     *   <li>{@link VistoriaArquivo#getDataCriacao()}
     *   <li>{@link VistoriaArquivo#getId()}
     *   <li>{@link VistoriaArquivo#getIdentidade()}
     *   <li>{@link VistoriaArquivo#getNomeImagem()}
     *   <li>{@link VistoriaArquivo#getVistoriaViatura()}
     * </ul>
     */
    @Test
    void testGettersAndSetters2() {
        // Arrange
        Date dataCriacao = Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant());

        TipoVistoriaEntity referenciaFinal = new TipoVistoriaEntity();
        referenciaFinal.setAtivo(true);
        referenciaFinal.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaFinal.setDescricao("Descricao");
        referenciaFinal.setId(1L);
        referenciaFinal.setNome("Nome");
        referenciaFinal.setStatusAnterior("Status Anterior");
        referenciaFinal.setStatusPosterior("Status Posterior");

        TipoVistoriaEntity referenciaInicial = new TipoVistoriaEntity();
        referenciaInicial.setAtivo(true);
        referenciaInicial.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaInicial.setDescricao("Descricao");
        referenciaInicial.setId(1L);
        referenciaInicial.setNome("Nome");
        referenciaInicial.setStatusAnterior("Status Anterior");
        referenciaInicial.setStatusPosterior("Status Posterior");

        DiferencaOdometroEntity diferencaOdometro = new DiferencaOdometroEntity();
        diferencaOdometro.setDataInclusao(LocalDate.of(1970, 1, 1));
        diferencaOdometro.setDataModificacao(LocalDate.of(1970, 1, 1));
        diferencaOdometro.setDiferencaOdometro(10.0d);
        diferencaOdometro.setId(1L);
        diferencaOdometro.setReferenciaFinal(referenciaFinal);
        diferencaOdometro.setReferenciaInicial(referenciaInicial);

        TipoVistoriaEntity tipoVistoria = new TipoVistoriaEntity();
        tipoVistoria.setAtivo(true);
        tipoVistoria.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoria.setDescricao("Descricao");
        tipoVistoria.setId(1L);
        tipoVistoria.setNome("Nome");
        tipoVistoria.setStatusAnterior("Status Anterior");
        tipoVistoria.setStatusPosterior("Status Posterior");

        TipoEmpregoViaturaEntity tipoEmpregoViatura = new TipoEmpregoViaturaEntity();
        tipoEmpregoViatura.setAtivo(1);
        tipoEmpregoViatura.setId(1);
        tipoEmpregoViatura.setNome("Nome");

        ViaturaEntity viatura = new ViaturaEntity();
        viatura.setAtivo(true);
        viatura.setDataAtualizacao(LocalDate.of(1970, 1, 1));
        viatura.setDataInclusao(LocalDate.of(1970, 1, 1));
        viatura.setId(1L);
        viatura.setListaUpm(new ArrayList<>());
        viatura.setMarcaModelo("Marca Modelo");
        viatura.setNrSei("Nr Sei");
        viatura.setPlaca("Placa");
        viatura.setPrefixo("Prefixo");
        viatura.setRenavam("Renavam");
        viatura.setStatus("Status");
        viatura.setTipoEmpregoViatura(tipoEmpregoViatura);
        viatura.setTombamento("alice.liddell@example.org");

        VistoriaViaturaEntity vistoriaViatura = new VistoriaViaturaEntity();
        vistoriaViatura.setCheckLists(new ArrayList<>());
        vistoriaViatura.setDataVistoria(LocalDate.of(1970, 1, 1).atStartOfDay());
        vistoriaViatura.setDiferencaOdometro(diferencaOdometro);
        vistoriaViatura.setDiferencaVistoria(true);
        vistoriaViatura.setId(1L);
        vistoriaViatura.setIdPolicial(1);
        vistoriaViatura.setIdUpm(1);
        vistoriaViatura.setOdometroFinal(10.0f);
        vistoriaViatura.setOdometroInicial(10.0f);
        vistoriaViatura.setStatus(VistoriaViaturaStatusEnum.DISPONIVEL);
        vistoriaViatura.setTipoVistoria(tipoVistoria);
        vistoriaViatura.setViatura(viatura);
        vistoriaViatura.setVistoriaArquivoList(new ArrayList<>());
        vistoriaViatura.setVistoriaViaturaHistorico(new ArrayList<>());

        // Act
        VistoriaArquivo actualVistoriaArquivo = new VistoriaArquivo(1L, "Identidade", "Nome Imagem", dataCriacao,
                vistoriaViatura);
        Date dataCriacao2 = Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant());
        actualVistoriaArquivo.setDataCriacao(dataCriacao2);
        actualVistoriaArquivo.setId(1L);
        actualVistoriaArquivo.setIdentidade("Identidade");
        actualVistoriaArquivo.setNomeImagem("Nome Imagem");
        TipoVistoriaEntity referenciaFinal2 = new TipoVistoriaEntity();
        referenciaFinal2.setAtivo(true);
        referenciaFinal2.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaFinal2.setDescricao("Descricao");
        referenciaFinal2.setId(1L);
        referenciaFinal2.setNome("Nome");
        referenciaFinal2.setStatusAnterior("Status Anterior");
        referenciaFinal2.setStatusPosterior("Status Posterior");
        TipoVistoriaEntity referenciaInicial2 = new TipoVistoriaEntity();
        referenciaInicial2.setAtivo(true);
        referenciaInicial2.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaInicial2.setDescricao("Descricao");
        referenciaInicial2.setId(1L);
        referenciaInicial2.setNome("Nome");
        referenciaInicial2.setStatusAnterior("Status Anterior");
        referenciaInicial2.setStatusPosterior("Status Posterior");
        DiferencaOdometroEntity diferencaOdometro2 = new DiferencaOdometroEntity();
        diferencaOdometro2.setDataInclusao(LocalDate.of(1970, 1, 1));
        diferencaOdometro2.setDataModificacao(LocalDate.of(1970, 1, 1));
        diferencaOdometro2.setDiferencaOdometro(10.0d);
        diferencaOdometro2.setId(1L);
        diferencaOdometro2.setReferenciaFinal(referenciaFinal2);
        diferencaOdometro2.setReferenciaInicial(referenciaInicial2);
        TipoVistoriaEntity tipoVistoria2 = new TipoVistoriaEntity();
        tipoVistoria2.setAtivo(true);
        tipoVistoria2.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoria2.setDescricao("Descricao");
        tipoVistoria2.setId(1L);
        tipoVistoria2.setNome("Nome");
        tipoVistoria2.setStatusAnterior("Status Anterior");
        tipoVistoria2.setStatusPosterior("Status Posterior");
        TipoEmpregoViaturaEntity tipoEmpregoViatura2 = new TipoEmpregoViaturaEntity();
        tipoEmpregoViatura2.setAtivo(1);
        tipoEmpregoViatura2.setId(1);
        tipoEmpregoViatura2.setNome("Nome");
        ViaturaEntity viatura2 = new ViaturaEntity();
        viatura2.setAtivo(true);
        viatura2.setDataAtualizacao(LocalDate.of(1970, 1, 1));
        viatura2.setDataInclusao(LocalDate.of(1970, 1, 1));
        viatura2.setId(1L);
        viatura2.setListaUpm(new ArrayList<>());
        viatura2.setMarcaModelo("Marca Modelo");
        viatura2.setNrSei("Nr Sei");
        viatura2.setPlaca("Placa");
        viatura2.setPrefixo("Prefixo");
        viatura2.setRenavam("Renavam");
        viatura2.setStatus("Status");
        viatura2.setTipoEmpregoViatura(tipoEmpregoViatura2);
        viatura2.setTombamento("alice.liddell@example.org");
        VistoriaViaturaEntity vistoriaViatura2 = new VistoriaViaturaEntity();
        vistoriaViatura2.setCheckLists(new ArrayList<>());
        vistoriaViatura2.setDataVistoria(LocalDate.of(1970, 1, 1).atStartOfDay());
        vistoriaViatura2.setDiferencaOdometro(diferencaOdometro2);
        vistoriaViatura2.setDiferencaVistoria(true);
        vistoriaViatura2.setId(1L);
        vistoriaViatura2.setIdPolicial(1);
        vistoriaViatura2.setIdUpm(1);
        vistoriaViatura2.setOdometroFinal(10.0f);
        vistoriaViatura2.setOdometroInicial(10.0f);
        vistoriaViatura2.setStatus(VistoriaViaturaStatusEnum.DISPONIVEL);
        vistoriaViatura2.setTipoVistoria(tipoVistoria2);
        vistoriaViatura2.setViatura(viatura2);
        vistoriaViatura2.setVistoriaArquivoList(new ArrayList<>());
        vistoriaViatura2.setVistoriaViaturaHistorico(new ArrayList<>());
        actualVistoriaArquivo.setVistoriaViatura(vistoriaViatura2);
        Date actualDataCriacao = actualVistoriaArquivo.getDataCriacao();
        Long actualId = actualVistoriaArquivo.getId();
        String actualIdentidade = actualVistoriaArquivo.getIdentidade();
        String actualNomeImagem = actualVistoriaArquivo.getNomeImagem();
        VistoriaViaturaEntity actualVistoriaViatura = actualVistoriaArquivo.getVistoriaViatura();

        // Assert that nothing has changed
        assertEquals("Identidade", actualIdentidade);
        assertEquals("Nome Imagem", actualNomeImagem);
        assertEquals(1L, actualId.longValue());
        assertSame(vistoriaViatura2, actualVistoriaViatura);
        assertSame(dataCriacao2, actualDataCriacao);
    }
}
