package br.gov.df.pm.sgv.service.impl;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isA;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import br.gov.df.pm.sgv.domain.DefeitosVistoriaEntity;
import br.gov.df.pm.sgv.domain.ItemVistoriaEntity;
import br.gov.df.pm.sgv.domain.ItensVistoriaEntity;
import br.gov.df.pm.sgv.domain.SubitemVistoriaEntity;
import br.gov.df.pm.sgv.domain.SubitensVistoriaEntity;
import br.gov.df.pm.sgv.domain.TipoDefeitoVistoriaEntity;
import br.gov.df.pm.sgv.domain.TipoVistoriaEntity;
import br.gov.df.pm.sgv.dto.EdicaoItemVistoriaDTO;
import br.gov.df.pm.sgv.dto.ItemVistoriaDTO;
import br.gov.df.pm.sgv.dto.OcorrenciasDTO;
import br.gov.df.pm.sgv.exceptions.ItemVistoriaException;
import br.gov.df.pm.sgv.exceptions.VistoriaExceptions;
import br.gov.df.pm.sgv.repository.DefeitosVistoriaRepository;
import br.gov.df.pm.sgv.repository.ItemVistoriaRepository;
import br.gov.df.pm.sgv.repository.ItensVistoriaRepository;
import br.gov.df.pm.sgv.repository.SubitemVistoriaRepository;
import br.gov.df.pm.sgv.repository.SubitensVistoriaRepository;
import br.gov.df.pm.sgv.service.ItemVistoriaService;
import br.gov.df.pm.sgv.service.TipoVistoriaService;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ContextConfiguration(classes = {ItemVistoriaServiceImpl.class})
@ExtendWith(SpringExtension.class)
class ItemVistoriaServiceImplDiffblueTest {
    @MockBean
    private DefeitosVistoriaRepository defeitosVistoriaRepository;

    @MockBean
    private ItemVistoriaRepository itemVistoriaRepository;

    @Autowired
    private ItemVistoriaServiceImpl itemVistoriaServiceImpl;

    @MockBean
    private ItensVistoriaRepository itensVistoriaRepository;

    @MockBean
    private SubitemVistoriaRepository subitemVistoriaRepository;

    @MockBean
    private SubitensVistoriaRepository subitensVistoriaRepository;

    @MockBean
    private TipoVistoriaService tipoVistoriaService;

    @InjectMocks
    private ItemVistoriaServiceImpl itemVistoriaService;

    /**
     * Method under test: {@link ItemVistoriaServiceImpl#buscarId(Long)}
     */
    @Test
    void testBuscarId() {
        // Arrange
        ItemVistoriaEntity itemVistoriaEntity = new ItemVistoriaEntity();
        itemVistoriaEntity.setAtivo(true);
        itemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity.setDescricao("Descricao");
        itemVistoriaEntity.setId(1L);
        itemVistoriaEntity.setNome("Nome");
        Optional<ItemVistoriaEntity> ofResult = Optional.of(itemVistoriaEntity);
        when(itemVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        // Act
        ResponseEntity<ItemVistoriaDTO> actualBuscarIdResult = itemVistoriaServiceImpl.buscarId(1L);

        // Assert
        verify(itemVistoriaRepository).findById(eq(1L));
        ItemVistoriaDTO body = actualBuscarIdResult.getBody();
        assertEquals("1970-01-01", body.getDataInclusao().toString());
        assertEquals("Descricao", body.getDescricao());
        assertEquals("Nome", body.getNome());
        assertNull(body.getSubitens());
        assertEquals(1L, body.getId().longValue());
        assertEquals(HttpStatus.OK, actualBuscarIdResult.getStatusCode());
        assertTrue(body.getAtivo());
        assertTrue(actualBuscarIdResult.hasBody());
        assertTrue(actualBuscarIdResult.getHeaders().isEmpty());
    }

    /**
     * Method under test: {@link ItemVistoriaServiceImpl#buscarId(Long)}
     */
    @Test
    void testBuscarId2() {
        // Arrange
        ItemVistoriaEntity itemVistoriaEntity = mock(ItemVistoriaEntity.class);
        when(itemVistoriaEntity.getAtivo()).thenReturn(true);
        when(itemVistoriaEntity.getId()).thenReturn(1L);
        when(itemVistoriaEntity.getDescricao()).thenReturn("Descricao");
        when(itemVistoriaEntity.getNome()).thenReturn("Nome");
        when(itemVistoriaEntity.getDataInclusao()).thenReturn(LocalDate.of(1970, 1, 1));
        doNothing().when(itemVistoriaEntity).setAtivo(Mockito.<Boolean>any());
        doNothing().when(itemVistoriaEntity).setDataInclusao(Mockito.<LocalDate>any());
        doNothing().when(itemVistoriaEntity).setDescricao(Mockito.<String>any());
        doNothing().when(itemVistoriaEntity).setId(Mockito.<Long>any());
        doNothing().when(itemVistoriaEntity).setNome(Mockito.<String>any());
        itemVistoriaEntity.setAtivo(true);
        itemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity.setDescricao("Descricao");
        itemVistoriaEntity.setId(1L);
        itemVistoriaEntity.setNome("Nome");
        Optional<ItemVistoriaEntity> ofResult = Optional.of(itemVistoriaEntity);
        when(itemVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        // Act
        ResponseEntity<ItemVistoriaDTO> actualBuscarIdResult = itemVistoriaServiceImpl.buscarId(1L);

        // Assert
        verify(itemVistoriaEntity).getAtivo();
        verify(itemVistoriaEntity).getDataInclusao();
        verify(itemVistoriaEntity).getDescricao();
        verify(itemVistoriaEntity).getId();
        verify(itemVistoriaEntity).getNome();
        verify(itemVistoriaEntity).setAtivo(eq(true));
        verify(itemVistoriaEntity).setDataInclusao(isA(LocalDate.class));
        verify(itemVistoriaEntity).setDescricao(eq("Descricao"));
        verify(itemVistoriaEntity).setId(eq(1L));
        verify(itemVistoriaEntity).setNome(eq("Nome"));
        verify(itemVistoriaRepository).findById(eq(1L));
        ItemVistoriaDTO body = actualBuscarIdResult.getBody();
        assertEquals("1970-01-01", body.getDataInclusao().toString());
        assertEquals("Descricao", body.getDescricao());
        assertEquals("Nome", body.getNome());
        assertNull(body.getSubitens());
        assertEquals(1L, body.getId().longValue());
        assertEquals(HttpStatus.OK, actualBuscarIdResult.getStatusCode());
        assertTrue(body.getAtivo());
        assertTrue(actualBuscarIdResult.hasBody());
        assertTrue(actualBuscarIdResult.getHeaders().isEmpty());
    }

    /**
     * Method under test: {@link ItemVistoriaServiceImpl#buscar(String, Pageable)}
     */
    @Test
    void testBuscar() {
        // Arrange
        PageImpl<ItemVistoriaEntity> pageImpl = new PageImpl<>(new ArrayList<>());
        when(itemVistoriaRepository.findAll(Mockito.<Specification<ItemVistoriaEntity>>any(), Mockito.<Pageable>any()))
                .thenReturn(pageImpl);

        SubitemVistoriaEntity subitemVistoriaEntity = new SubitemVistoriaEntity();
        subitemVistoriaEntity.setAtivo(true);
        subitemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        subitemVistoriaEntity.setDescricao("Descricao");
        subitemVistoriaEntity.setId(1L);
        subitemVistoriaEntity.setNome("Nome");
        Optional<SubitemVistoriaEntity> ofResult = Optional.of(subitemVistoriaEntity);
        when(subitemVistoriaRepository.findByNome(Mockito.<String>any())).thenReturn(ofResult);
        when(subitensVistoriaRepository.findAllByCodSubitem(Mockito.<SubitemVistoriaEntity>any()))
                .thenReturn(new ArrayList<>());

        // Act
        Page<ItemVistoriaEntity> actualBuscarResult = itemVistoriaServiceImpl.buscar("Filter", null);

        // Assert
        verify(subitemVistoriaRepository).findByNome(eq("Filter"));
        verify(subitensVistoriaRepository).findAllByCodSubitem(isA(SubitemVistoriaEntity.class));
        verify(itemVistoriaRepository).findAll(isA(Specification.class), (Pageable) isNull());
        assertTrue(actualBuscarResult.toList().isEmpty());
        assertSame(pageImpl, actualBuscarResult);
    }

    /**
     * Method under test: {@link ItemVistoriaServiceImpl#buscar(String, Pageable)}
     */
    @Test
    void testBuscar2() {
        // Arrange
        SubitemVistoriaEntity subitemVistoriaEntity = new SubitemVistoriaEntity();
        subitemVistoriaEntity.setAtivo(true);
        subitemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        subitemVistoriaEntity.setDescricao("Descricao");
        subitemVistoriaEntity.setId(1L);
        subitemVistoriaEntity.setNome("Nome");
        Optional<SubitemVistoriaEntity> ofResult = Optional.of(subitemVistoriaEntity);
        when(subitemVistoriaRepository.findByNome(Mockito.<String>any())).thenReturn(ofResult);
        when(subitensVistoriaRepository.findAllByCodSubitem(Mockito.<SubitemVistoriaEntity>any()))
                .thenThrow(new VistoriaExceptions("An error occurred"));

        // Act and Assert
        assertThrows(VistoriaExceptions.class, () -> itemVistoriaServiceImpl.buscar("Filter", null));
        verify(subitemVistoriaRepository).findByNome(eq("Filter"));
        verify(subitensVistoriaRepository).findAllByCodSubitem(isA(SubitemVistoriaEntity.class));
    }

    /**
     * Method under test: {@link ItemVistoriaServiceImpl#buscar(String, Pageable)}
     */
    @Test
    void testBuscar3() {
        // Arrange
        PageImpl<ItemVistoriaEntity> pageImpl = new PageImpl<>(new ArrayList<>());
        when(itemVistoriaRepository.findAll(Mockito.<Specification<ItemVistoriaEntity>>any(), Mockito.<Pageable>any()))
                .thenReturn(pageImpl);
        Optional<SubitemVistoriaEntity> emptyResult = Optional.empty();
        when(subitemVistoriaRepository.findByNome(Mockito.<String>any())).thenReturn(emptyResult);

        // Act
        Page<ItemVistoriaEntity> actualBuscarResult = itemVistoriaServiceImpl.buscar("Filter", null);

        // Assert
        verify(subitemVistoriaRepository).findByNome(eq("Filter"));
        verify(itemVistoriaRepository).findAll(isA(Specification.class), (Pageable) isNull());
        assertTrue(actualBuscarResult.toList().isEmpty());
        assertSame(pageImpl, actualBuscarResult);
    }

    /**
     * Method under test: {@link ItemVistoriaServiceImpl#salvar(ItemVistoriaDTO)}
     */
    @Test
    void testSalvar() {
        // Arrange, Act and Assert
        assertThrows(VistoriaExceptions.class, () -> itemVistoriaServiceImpl.salvar(new ItemVistoriaDTO()));
    }

    /**
     * Method under test: {@link ItemVistoriaServiceImpl#salvar(ItemVistoriaDTO)}
     */
    @Test
    void testSalvar2() {
        // Arrange
        ItemVistoriaEntity itemVistoriaEntity = new ItemVistoriaEntity();
        itemVistoriaEntity.setAtivo(true);
        itemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity.setDescricao("Descricao");
        itemVistoriaEntity.setId(1L);
        itemVistoriaEntity.setNome("Nome");
        Optional<ItemVistoriaEntity> ofResult = Optional.of(itemVistoriaEntity);
        when(itemVistoriaRepository.findByNome(Mockito.<String>any())).thenReturn(ofResult);
        ItemVistoriaDTO.ItemVistoriaDTOBuilder ativoResult = ItemVistoriaDTO.builder().ativo(true);
        ItemVistoriaDTO.ItemVistoriaDTOBuilder nomeResult = ativoResult.dataInclusao(LocalDate.of(1970, 1, 1))
                .descricao("Descricao")
                .id(1L)
                .nome("Nome");
        ItemVistoriaDTO itemVistoria = nomeResult.subitens(new ArrayList<>()).build();

        // Act and Assert
        assertThrows(VistoriaExceptions.class, () -> itemVistoriaServiceImpl.salvar(itemVistoria));
        verify(itemVistoriaRepository).findByNome(eq("Nome"));
    }

    /**
     * Method under test: {@link ItemVistoriaServiceImpl#salvar(ItemVistoriaDTO)}
     */
    @Test
    void testSalvar3() {
        // Arrange
        ItemVistoriaEntity itemVistoriaEntity = new ItemVistoriaEntity();
        itemVistoriaEntity.setAtivo(true);
        itemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity.setDescricao("Descricao");
        itemVistoriaEntity.setId(1L);
        itemVistoriaEntity.setNome("Nome");
        when(itemVistoriaRepository.save(Mockito.<ItemVistoriaEntity>any())).thenReturn(itemVistoriaEntity);
        Optional<ItemVistoriaEntity> emptyResult = Optional.empty();
        when(itemVistoriaRepository.findByNome(Mockito.<String>any())).thenReturn(emptyResult);
        when(subitensVistoriaRepository.saveAll(Mockito.<Iterable<SubitensVistoriaEntity>>any()))
                .thenReturn(new ArrayList<>());
        ItemVistoriaDTO.ItemVistoriaDTOBuilder ativoResult = ItemVistoriaDTO.builder().ativo(true);
        ItemVistoriaDTO.ItemVistoriaDTOBuilder nomeResult = ativoResult.dataInclusao(LocalDate.of(1970, 1, 1))
                .descricao("Descricao")
                .id(1L)
                .nome("Nome");
        ItemVistoriaDTO itemVistoria = nomeResult.subitens(new ArrayList<>()).build();

        // Act
        ResponseEntity<?> actualSalvarResult = itemVistoriaServiceImpl.salvar(itemVistoria);

        // Assert
        verify(itemVistoriaRepository).findByNome(eq("Nome"));
        verify(subitensVistoriaRepository).saveAll(isA(Iterable.class));
        verify(itemVistoriaRepository).save(isA(ItemVistoriaEntity.class));
        assertEquals(HttpStatus.OK, actualSalvarResult.getStatusCode());
        assertTrue(actualSalvarResult.hasBody());
        assertTrue(actualSalvarResult.getHeaders().isEmpty());
    }

    /**
     * Method under test: {@link ItemVistoriaServiceImpl#salvar(ItemVistoriaDTO)}
     */
    @Test
    void testSalvar4() {
        // Arrange
        ItemVistoriaDTO.ItemVistoriaDTOBuilder ativoResult = ItemVistoriaDTO.builder().ativo(true);
        ItemVistoriaDTO.ItemVistoriaDTOBuilder nomeResult = ativoResult.dataInclusao(LocalDate.of(1970, 1, 1))
                .descricao("Descricao")
                .id(1L)
                .nome("");
        ItemVistoriaDTO itemVistoria = nomeResult.subitens(new ArrayList<>()).build();

        // Act and Assert
        assertThrows(VistoriaExceptions.class, () -> itemVistoriaServiceImpl.salvar(itemVistoria));
    }

    /**
     * Method under test: {@link ItemVistoriaServiceImpl#salvar(ItemVistoriaDTO)}
     */
    @Test
    void testSalvar5() {
        // Arrange
        ItemVistoriaEntity itemVistoriaEntity = new ItemVistoriaEntity();
        itemVistoriaEntity.setAtivo(true);
        itemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity.setDescricao("Descricao");
        itemVistoriaEntity.setId(1L);
        itemVistoriaEntity.setNome("Nome");
        when(itemVistoriaRepository.save(Mockito.<ItemVistoriaEntity>any())).thenReturn(itemVistoriaEntity);
        Optional<ItemVistoriaEntity> emptyResult = Optional.empty();
        when(itemVistoriaRepository.findByNome(Mockito.<String>any())).thenReturn(emptyResult);
        when(subitensVistoriaRepository.saveAll(Mockito.<Iterable<SubitensVistoriaEntity>>any()))
                .thenReturn(new ArrayList<>());

        SubitemVistoriaEntity subitemVistoriaEntity = new SubitemVistoriaEntity();
        subitemVistoriaEntity.setAtivo(true);
        subitemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        subitemVistoriaEntity.setDescricao("Descricao");
        subitemVistoriaEntity.setId(1L);
        subitemVistoriaEntity.setNome("Nome");

        ArrayList<SubitemVistoriaEntity> subitens = new ArrayList<>();
        subitens.add(subitemVistoriaEntity);
        ItemVistoriaDTO.ItemVistoriaDTOBuilder ativoResult = ItemVistoriaDTO.builder().ativo(true);
        ItemVistoriaDTO itemVistoria = ativoResult.dataInclusao(LocalDate.of(1970, 1, 1))
                .descricao("Descricao")
                .id(1L)
                .nome("Nome")
                .subitens(subitens)
                .build();

        // Act
        ResponseEntity<?> actualSalvarResult = itemVistoriaServiceImpl.salvar(itemVistoria);

        // Assert
        verify(itemVistoriaRepository).findByNome(eq("Nome"));
        verify(subitensVistoriaRepository).saveAll(isA(Iterable.class));
        verify(itemVistoriaRepository).save(isA(ItemVistoriaEntity.class));
        assertEquals(HttpStatus.OK, actualSalvarResult.getStatusCode());
        assertTrue(actualSalvarResult.hasBody());
        assertTrue(actualSalvarResult.getHeaders().isEmpty());
    }

    /**
     * Method under test: {@link ItemVistoriaServiceImpl#salvar(ItemVistoriaDTO)}
     */
    @Test
    void testSalvar6() {
        // Arrange
        ItemVistoriaEntity itemVistoriaEntity = new ItemVistoriaEntity();
        itemVistoriaEntity.setAtivo(true);
        itemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity.setDescricao("Descricao");
        itemVistoriaEntity.setId(1L);
        itemVistoriaEntity.setNome("Nome");
        when(itemVistoriaRepository.save(Mockito.<ItemVistoriaEntity>any())).thenReturn(itemVistoriaEntity);
        Optional<ItemVistoriaEntity> emptyResult = Optional.empty();
        when(itemVistoriaRepository.findByNome(Mockito.<String>any())).thenReturn(emptyResult);
        when(subitensVistoriaRepository.saveAll(Mockito.<Iterable<SubitensVistoriaEntity>>any()))
                .thenThrow(new VistoriaExceptions("An error occurred"));
        ItemVistoriaDTO.ItemVistoriaDTOBuilder ativoResult = ItemVistoriaDTO.builder().ativo(true);
        ItemVistoriaDTO.ItemVistoriaDTOBuilder nomeResult = ativoResult.dataInclusao(LocalDate.of(1970, 1, 1))
                .descricao("Descricao")
                .id(1L)
                .nome("Nome");
        ItemVistoriaDTO itemVistoria = nomeResult.subitens(new ArrayList<>()).build();

        // Act and Assert
        assertThrows(VistoriaExceptions.class, () -> itemVistoriaServiceImpl.salvar(itemVistoria));
        verify(itemVistoriaRepository).findByNome(eq("Nome"));
        verify(subitensVistoriaRepository).saveAll(isA(Iterable.class));
        verify(itemVistoriaRepository).save(isA(ItemVistoriaEntity.class));
    }

    /**
     * Method under test:
     * {@link ItemVistoriaServiceImpl#editar(Long, EdicaoItemVistoriaDTO)}
     */
    @Test
    void testEditar() {
        // Arrange
        ItemVistoriaEntity itemVistoriaEntity = new ItemVistoriaEntity();
        itemVistoriaEntity.setAtivo(true);
        itemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity.setDescricao("Descricao");
        itemVistoriaEntity.setId(1L);
        itemVistoriaEntity.setNome("Nome");
        Optional<ItemVistoriaEntity> ofResult = Optional.of(itemVistoriaEntity);
        when(itemVistoriaRepository.findByNome(Mockito.<String>any())).thenReturn(ofResult);
        EdicaoItemVistoriaDTO.EdicaoItemVistoriaDTOBuilder nomeResult = EdicaoItemVistoriaDTO.builder()
                .descricao("Descricao")
                .nome("Nome");
        EdicaoItemVistoriaDTO edicao = nomeResult.subitens(new ArrayList<>()).build();

        // Act and Assert
        assertThrows(VistoriaExceptions.class, () -> itemVistoriaServiceImpl.editar(1L, edicao));
        verify(itemVistoriaRepository).findByNome(eq("Nome"));
    }

    /**
     * Method under test:
     * {@link ItemVistoriaServiceImpl#editar(Long, EdicaoItemVistoriaDTO)}
     */
    @Test
    void testEditar2() {
        // Arrange
        ItemVistoriaEntity itemVistoriaEntity = new ItemVistoriaEntity();
        itemVistoriaEntity.setAtivo(true);
        itemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity.setDescricao("Descricao");
        itemVistoriaEntity.setId(1L);
        itemVistoriaEntity.setNome("Nome");
        Optional<ItemVistoriaEntity> ofResult = Optional.of(itemVistoriaEntity);

        ItemVistoriaEntity itemVistoriaEntity2 = new ItemVistoriaEntity();
        itemVistoriaEntity2.setAtivo(true);
        itemVistoriaEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity2.setDescricao("Descricao");
        itemVistoriaEntity2.setId(1L);
        itemVistoriaEntity2.setNome("Nome");
        when(itemVistoriaRepository.save(Mockito.<ItemVistoriaEntity>any())).thenReturn(itemVistoriaEntity2);
        Optional<ItemVistoriaEntity> emptyResult = Optional.empty();
        when(itemVistoriaRepository.findByNome(Mockito.<String>any())).thenReturn(emptyResult);
        when(itemVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);
        when(subitensVistoriaRepository.findAllByCodItem(Mockito.<ItemVistoriaEntity>any())).thenReturn(new ArrayList<>());
        EdicaoItemVistoriaDTO.EdicaoItemVistoriaDTOBuilder nomeResult = EdicaoItemVistoriaDTO.builder()
                .descricao("Descricao")
                .nome("Nome");
        EdicaoItemVistoriaDTO edicao = nomeResult.subitens(new ArrayList<>()).build();

        // Act
        ResponseEntity<?> actualEditarResult = itemVistoriaServiceImpl.editar(1L, edicao);

        // Assert
        verify(itemVistoriaRepository).findByNome(eq("Nome"));
        verify(subitensVistoriaRepository).findAllByCodItem(isA(ItemVistoriaEntity.class));
        verify(itemVistoriaRepository).findById(eq(1L));
        verify(itemVistoriaRepository).save(isA(ItemVistoriaEntity.class));
        assertEquals(HttpStatus.OK, actualEditarResult.getStatusCode());
        assertTrue(actualEditarResult.hasBody());
        assertTrue(actualEditarResult.getHeaders().isEmpty());
    }

    /**
     * Method under test:
     * {@link ItemVistoriaServiceImpl#editar(Long, EdicaoItemVistoriaDTO)}
     */
    @Test
    void testEditar3() {
        // Arrange
        ItemVistoriaEntity itemVistoriaEntity = new ItemVistoriaEntity();
        itemVistoriaEntity.setAtivo(true);
        itemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity.setDescricao("Descricao");
        itemVistoriaEntity.setId(1L);
        itemVistoriaEntity.setNome("Nome");
        Optional<ItemVistoriaEntity> ofResult = Optional.of(itemVistoriaEntity);
        Optional<ItemVistoriaEntity> emptyResult = Optional.empty();
        when(itemVistoriaRepository.findByNome(Mockito.<String>any())).thenReturn(emptyResult);
        when(itemVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);
        when(subitensVistoriaRepository.findAllByCodItem(Mockito.<ItemVistoriaEntity>any()))
                .thenThrow(new VistoriaExceptions("An error occurred"));
        EdicaoItemVistoriaDTO.EdicaoItemVistoriaDTOBuilder nomeResult = EdicaoItemVistoriaDTO.builder()
                .descricao("Descricao")
                .nome("Nome");
        EdicaoItemVistoriaDTO edicao = nomeResult.subitens(new ArrayList<>()).build();

        // Act and Assert
        assertThrows(VistoriaExceptions.class, () -> itemVistoriaServiceImpl.editar(1L, edicao));
        verify(itemVistoriaRepository).findByNome(eq("Nome"));
        verify(subitensVistoriaRepository).findAllByCodItem(isA(ItemVistoriaEntity.class));
        verify(itemVistoriaRepository).findById(eq(1L));
    }

    /**
     * Method under test:
     * {@link ItemVistoriaServiceImpl#editar(Long, EdicaoItemVistoriaDTO)}
     */
    @Test
    void testEditar4() {
        // Arrange
        ItemVistoriaEntity itemVistoriaEntity = mock(ItemVistoriaEntity.class);
        doNothing().when(itemVistoriaEntity).setAtivo(Mockito.<Boolean>any());
        doNothing().when(itemVistoriaEntity).setDataInclusao(Mockito.<LocalDate>any());
        doNothing().when(itemVistoriaEntity).setDescricao(Mockito.<String>any());
        doNothing().when(itemVistoriaEntity).setId(Mockito.<Long>any());
        doNothing().when(itemVistoriaEntity).setNome(Mockito.<String>any());
        itemVistoriaEntity.setAtivo(true);
        itemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity.setDescricao("Descricao");
        itemVistoriaEntity.setId(1L);
        itemVistoriaEntity.setNome("Nome");
        Optional<ItemVistoriaEntity> ofResult = Optional.of(itemVistoriaEntity);

        ItemVistoriaEntity itemVistoriaEntity2 = new ItemVistoriaEntity();
        itemVistoriaEntity2.setAtivo(true);
        itemVistoriaEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity2.setDescricao("Descricao");
        itemVistoriaEntity2.setId(1L);
        itemVistoriaEntity2.setNome("Nome");
        when(itemVistoriaRepository.save(Mockito.<ItemVistoriaEntity>any())).thenReturn(itemVistoriaEntity2);
        Optional<ItemVistoriaEntity> emptyResult = Optional.empty();
        when(itemVistoriaRepository.findByNome(Mockito.<String>any())).thenReturn(emptyResult);
        when(itemVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);
        when(subitensVistoriaRepository.findAllByCodItem(Mockito.<ItemVistoriaEntity>any())).thenReturn(new ArrayList<>());
        EdicaoItemVistoriaDTO.EdicaoItemVistoriaDTOBuilder nomeResult = EdicaoItemVistoriaDTO.builder()
                .descricao("Descricao")
                .nome("Nome");
        EdicaoItemVistoriaDTO edicao = nomeResult.subitens(new ArrayList<>()).build();

        // Act
        ResponseEntity<?> actualEditarResult = itemVistoriaServiceImpl.editar(1L, edicao);

        // Assert
        verify(itemVistoriaEntity).setAtivo(eq(true));
        verify(itemVistoriaEntity).setDataInclusao(isA(LocalDate.class));
        verify(itemVistoriaEntity, atLeast(1)).setDescricao(eq("Descricao"));
        verify(itemVistoriaEntity).setId(eq(1L));
        verify(itemVistoriaEntity, atLeast(1)).setNome(eq("Nome"));
        verify(itemVistoriaRepository).findByNome(eq("Nome"));
        verify(subitensVistoriaRepository).findAllByCodItem(isA(ItemVistoriaEntity.class));
        verify(itemVistoriaRepository).findById(eq(1L));
        verify(itemVistoriaRepository).save(isA(ItemVistoriaEntity.class));
        assertEquals(HttpStatus.OK, actualEditarResult.getStatusCode());
        assertTrue(actualEditarResult.hasBody());
        assertTrue(actualEditarResult.getHeaders().isEmpty());
    }

    /**
     * Method under test:
     * {@link ItemVistoriaServiceImpl#editar(Long, EdicaoItemVistoriaDTO)}
     */
    @Test
    void testEditar5() {
        // Arrange
        ItemVistoriaEntity itemVistoriaEntity = mock(ItemVistoriaEntity.class);
        doNothing().when(itemVistoriaEntity).setAtivo(Mockito.<Boolean>any());
        doNothing().when(itemVistoriaEntity).setDataInclusao(Mockito.<LocalDate>any());
        doNothing().when(itemVistoriaEntity).setDescricao(Mockito.<String>any());
        doNothing().when(itemVistoriaEntity).setId(Mockito.<Long>any());
        doNothing().when(itemVistoriaEntity).setNome(Mockito.<String>any());
        itemVistoriaEntity.setAtivo(true);
        itemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity.setDescricao("Descricao");
        itemVistoriaEntity.setId(1L);
        itemVistoriaEntity.setNome("Nome");
        Optional<ItemVistoriaEntity> ofResult = Optional.of(itemVistoriaEntity);

        ItemVistoriaEntity itemVistoriaEntity2 = new ItemVistoriaEntity();
        itemVistoriaEntity2.setAtivo(true);
        itemVistoriaEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity2.setDescricao("Descricao");
        itemVistoriaEntity2.setId(1L);
        itemVistoriaEntity2.setNome("Nome");
        when(itemVistoriaRepository.save(Mockito.<ItemVistoriaEntity>any())).thenReturn(itemVistoriaEntity2);
        Optional<ItemVistoriaEntity> emptyResult = Optional.empty();
        when(itemVistoriaRepository.findByNome(Mockito.<String>any())).thenReturn(emptyResult);
        when(itemVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        ItemVistoriaEntity codItem = new ItemVistoriaEntity();
        codItem.setAtivo(true);
        codItem.setDataInclusao(LocalDate.of(1970, 1, 1));
        codItem.setDescricao("Descricao");
        codItem.setId(1L);
        codItem.setNome("Nome");

        SubitemVistoriaEntity codSubitem = new SubitemVistoriaEntity();
        codSubitem.setAtivo(true);
        codSubitem.setDataInclusao(LocalDate.of(1970, 1, 1));
        codSubitem.setDescricao("Descricao");
        codSubitem.setId(1L);
        codSubitem.setNome("Nome");

        SubitensVistoriaEntity subitensVistoriaEntity = new SubitensVistoriaEntity();
        subitensVistoriaEntity.setAtivo(true);
        subitensVistoriaEntity.setCodItem(codItem);
        subitensVistoriaEntity.setCodSubitem(codSubitem);
        subitensVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        subitensVistoriaEntity.setId(1L);

        ArrayList<SubitensVistoriaEntity> subitensVistoriaEntityList = new ArrayList<>();
        subitensVistoriaEntityList.add(subitensVistoriaEntity);
        doNothing().when(subitensVistoriaRepository).deleteAll(Mockito.<Iterable<SubitensVistoriaEntity>>any());
        when(subitensVistoriaRepository.findAllByCodItem(Mockito.<ItemVistoriaEntity>any()))
                .thenReturn(subitensVistoriaEntityList);
        EdicaoItemVistoriaDTO.EdicaoItemVistoriaDTOBuilder nomeResult = EdicaoItemVistoriaDTO.builder()
                .descricao("Descricao")
                .nome("Nome");
        EdicaoItemVistoriaDTO edicao = nomeResult.subitens(new ArrayList<>()).build();

        // Act
        ResponseEntity<?> actualEditarResult = itemVistoriaServiceImpl.editar(1L, edicao);

        // Assert
        verify(itemVistoriaEntity).setAtivo(eq(true));
        verify(itemVistoriaEntity).setDataInclusao(isA(LocalDate.class));
        verify(itemVistoriaEntity, atLeast(1)).setDescricao(eq("Descricao"));
        verify(itemVistoriaEntity).setId(eq(1L));
        verify(itemVistoriaEntity, atLeast(1)).setNome(eq("Nome"));
        verify(itemVistoriaRepository).findByNome(eq("Nome"));
        verify(subitensVistoriaRepository).findAllByCodItem(isA(ItemVistoriaEntity.class));
        verify(subitensVistoriaRepository).deleteAll(isA(Iterable.class));
        verify(itemVistoriaRepository).findById(eq(1L));
        verify(itemVistoriaRepository).save(isA(ItemVistoriaEntity.class));
        assertEquals(HttpStatus.OK, actualEditarResult.getStatusCode());
        assertTrue(actualEditarResult.hasBody());
        assertTrue(actualEditarResult.getHeaders().isEmpty());
    }

    /**
     * Method under test: {@link ItemVistoriaServiceImpl#desativar(Long)}
     */
    @Test
    void testDesativar() {
        // Arrange
        when(itensVistoriaRepository.findAllByCodItem(Mockito.<ItemVistoriaEntity>any())).thenReturn(new ArrayList<>());

        ItemVistoriaEntity itemVistoriaEntity = new ItemVistoriaEntity();
        itemVistoriaEntity.setAtivo(true);
        itemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity.setDescricao("Descricao");
        itemVistoriaEntity.setId(1L);
        itemVistoriaEntity.setNome("Nome");
        Optional<ItemVistoriaEntity> ofResult = Optional.of(itemVistoriaEntity);

        ItemVistoriaEntity itemVistoriaEntity2 = new ItemVistoriaEntity();
        itemVistoriaEntity2.setAtivo(true);
        itemVistoriaEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity2.setDescricao("Descricao");
        itemVistoriaEntity2.setId(1L);
        itemVistoriaEntity2.setNome("Nome");
        when(itemVistoriaRepository.save(Mockito.<ItemVistoriaEntity>any())).thenReturn(itemVistoriaEntity2);
        when(itemVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        // Act
        ResponseEntity<?> actualDesativarResult = itemVistoriaServiceImpl.desativar(1L);

        // Assert
        verify(itensVistoriaRepository).findAllByCodItem(isA(ItemVistoriaEntity.class));
        verify(itemVistoriaRepository).findById(eq(1L));
        verify(itemVistoriaRepository).save(isA(ItemVistoriaEntity.class));
        assertNull(actualDesativarResult.getBody());
        assertEquals(HttpStatus.OK, actualDesativarResult.getStatusCode());
        assertTrue(actualDesativarResult.getHeaders().isEmpty());
    }

    /**
     * Method under test: {@link ItemVistoriaServiceImpl#desativar(Long)}
     */
    @Test
    void testDesativar2() {
        // Arrange
        when(itensVistoriaRepository.findAllByCodItem(Mockito.<ItemVistoriaEntity>any())).thenReturn(new ArrayList<>());

        ItemVistoriaEntity itemVistoriaEntity = new ItemVistoriaEntity();
        itemVistoriaEntity.setAtivo(true);
        itemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity.setDescricao("Descricao");
        itemVistoriaEntity.setId(1L);
        itemVistoriaEntity.setNome("Nome");
        Optional<ItemVistoriaEntity> ofResult = Optional.of(itemVistoriaEntity);
        when(itemVistoriaRepository.save(Mockito.<ItemVistoriaEntity>any()))
                .thenThrow(new VistoriaExceptions("An error occurred"));
        when(itemVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        // Act and Assert
        assertThrows(VistoriaExceptions.class, () -> itemVistoriaServiceImpl.desativar(1L));
        verify(itensVistoriaRepository).findAllByCodItem(isA(ItemVistoriaEntity.class));
        verify(itemVistoriaRepository).findById(eq(1L));
        verify(itemVistoriaRepository).save(isA(ItemVistoriaEntity.class));
    }

    /**
     * Method under test: {@link ItemVistoriaServiceImpl#desativar(Long)}
     */
    @Test
    void testDesativar3() {
        // Arrange
        ItemVistoriaEntity codItem = new ItemVistoriaEntity();
        codItem.setAtivo(true);
        codItem.setDataInclusao(LocalDate.of(1970, 1, 1));
        codItem.setDescricao("Descricao");
        codItem.setId(1L);
        codItem.setNome("Nome");

        TipoVistoriaEntity codTipo = new TipoVistoriaEntity();
        codTipo.setAtivo(true);
        codTipo.setDataInclusao(LocalDate.of(1970, 1, 1));
        codTipo.setDescricao("Descricao");
        codTipo.setId(1L);
        codTipo.setNome("Nome");
        codTipo.setStatusAnterior("Status Anterior");
        codTipo.setStatusPosterior("Status Posterior");

        ItensVistoriaEntity itensVistoriaEntity = new ItensVistoriaEntity();
        itensVistoriaEntity.setAtivo(true);
        itensVistoriaEntity.setCodItem(codItem);
        itensVistoriaEntity.setCodTipo(codTipo);
        itensVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itensVistoriaEntity.setId(1L);

        ArrayList<ItensVistoriaEntity> itensVistoriaEntityList = new ArrayList<>();
        itensVistoriaEntityList.add(itensVistoriaEntity);
        when(itensVistoriaRepository.findAllByCodItem(Mockito.<ItemVistoriaEntity>any()))
                .thenReturn(itensVistoriaEntityList);

        ItemVistoriaEntity itemVistoriaEntity = new ItemVistoriaEntity();
        itemVistoriaEntity.setAtivo(true);
        itemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity.setDescricao("Descricao");
        itemVistoriaEntity.setId(1L);
        itemVistoriaEntity.setNome("Nome");
        Optional<ItemVistoriaEntity> ofResult = Optional.of(itemVistoriaEntity);
        when(itemVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        // Act and Assert
        assertThrows(VistoriaExceptions.class, () -> itemVistoriaServiceImpl.desativar(1L));
        verify(itensVistoriaRepository).findAllByCodItem(isA(ItemVistoriaEntity.class));
        verify(itemVistoriaRepository).findById(eq(1L));
    }

    /**
     * Method under test: {@link ItemVistoriaServiceImpl#desativar(Long)}
     */
    @Test
    void testDesativar4() {
        // Arrange
        when(itensVistoriaRepository.findAllByCodItem(Mockito.<ItemVistoriaEntity>any())).thenReturn(new ArrayList<>());
        ItemVistoriaEntity itemVistoriaEntity = mock(ItemVistoriaEntity.class);
        doNothing().when(itemVistoriaEntity).setAtivo(Mockito.<Boolean>any());
        doNothing().when(itemVistoriaEntity).setDataInclusao(Mockito.<LocalDate>any());
        doNothing().when(itemVistoriaEntity).setDescricao(Mockito.<String>any());
        doNothing().when(itemVistoriaEntity).setId(Mockito.<Long>any());
        doNothing().when(itemVistoriaEntity).setNome(Mockito.<String>any());
        itemVistoriaEntity.setAtivo(true);
        itemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity.setDescricao("Descricao");
        itemVistoriaEntity.setId(1L);
        itemVistoriaEntity.setNome("Nome");
        Optional<ItemVistoriaEntity> ofResult = Optional.of(itemVistoriaEntity);

        ItemVistoriaEntity itemVistoriaEntity2 = new ItemVistoriaEntity();
        itemVistoriaEntity2.setAtivo(true);
        itemVistoriaEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity2.setDescricao("Descricao");
        itemVistoriaEntity2.setId(1L);
        itemVistoriaEntity2.setNome("Nome");
        when(itemVistoriaRepository.save(Mockito.<ItemVistoriaEntity>any())).thenReturn(itemVistoriaEntity2);
        when(itemVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        // Act
        ResponseEntity<?> actualDesativarResult = itemVistoriaServiceImpl.desativar(1L);

        // Assert
        verify(itemVistoriaEntity, atLeast(1)).setAtivo(Mockito.<Boolean>any());
        verify(itemVistoriaEntity).setDataInclusao(isA(LocalDate.class));
        verify(itemVistoriaEntity).setDescricao(eq("Descricao"));
        verify(itemVistoriaEntity).setId(eq(1L));
        verify(itemVistoriaEntity).setNome(eq("Nome"));
        verify(itensVistoriaRepository).findAllByCodItem(isA(ItemVistoriaEntity.class));
        verify(itemVistoriaRepository).findById(eq(1L));
        verify(itemVistoriaRepository).save(isA(ItemVistoriaEntity.class));
        assertNull(actualDesativarResult.getBody());
        assertEquals(HttpStatus.OK, actualDesativarResult.getStatusCode());
        assertTrue(actualDesativarResult.getHeaders().isEmpty());
    }

    /**
     * Method under test: {@link ItemVistoriaServiceImpl#excluir(Long)}
     */
    @Test
    void testExcluir() {
        // Arrange
        when(itensVistoriaRepository.findAllByCodItem(Mockito.<ItemVistoriaEntity>any())).thenReturn(new ArrayList<>());

        ItemVistoriaEntity itemVistoriaEntity = new ItemVistoriaEntity();
        itemVistoriaEntity.setAtivo(true);
        itemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity.setDescricao("Descricao");
        itemVistoriaEntity.setId(1L);
        itemVistoriaEntity.setNome("Nome");
        Optional<ItemVistoriaEntity> ofResult = Optional.of(itemVistoriaEntity);
        doNothing().when(itemVistoriaRepository).delete(Mockito.<ItemVistoriaEntity>any());
        when(itemVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        // Act
        ResponseEntity<?> actualExcluirResult = itemVistoriaServiceImpl.excluir(1L);

        // Assert
        verify(itensVistoriaRepository).findAllByCodItem(isA(ItemVistoriaEntity.class));
        verify(itemVistoriaRepository).delete(isA(ItemVistoriaEntity.class));
        verify(itemVistoriaRepository).findById(eq(1L));
        assertNull(actualExcluirResult.getBody());
        assertEquals(HttpStatus.OK, actualExcluirResult.getStatusCode());
        assertTrue(actualExcluirResult.getHeaders().isEmpty());
    }

    /**
     * Method under test: {@link ItemVistoriaServiceImpl#excluir(Long)}
     */
    @Test
    void testExcluir2() {
        // Arrange
        when(itensVistoriaRepository.findAllByCodItem(Mockito.<ItemVistoriaEntity>any())).thenReturn(new ArrayList<>());

        ItemVistoriaEntity itemVistoriaEntity = new ItemVistoriaEntity();
        itemVistoriaEntity.setAtivo(true);
        itemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity.setDescricao("Descricao");
        itemVistoriaEntity.setId(1L);
        itemVistoriaEntity.setNome("Nome");
        Optional<ItemVistoriaEntity> ofResult = Optional.of(itemVistoriaEntity);
        doThrow(new VistoriaExceptions("An error occurred")).when(itemVistoriaRepository)
                .delete(Mockito.<ItemVistoriaEntity>any());
        when(itemVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        // Act and Assert
        assertThrows(VistoriaExceptions.class, () -> itemVistoriaServiceImpl.excluir(1L));
        verify(itensVistoriaRepository).findAllByCodItem(isA(ItemVistoriaEntity.class));
        verify(itemVistoriaRepository).delete(isA(ItemVistoriaEntity.class));
        verify(itemVistoriaRepository).findById(eq(1L));
    }

    /**
     * Method under test: {@link ItemVistoriaServiceImpl#excluir(Long)}
     */
    @Test
    void testExcluir3() {
        // Arrange
        ItemVistoriaEntity codItem = new ItemVistoriaEntity();
        codItem.setAtivo(true);
        codItem.setDataInclusao(LocalDate.of(1970, 1, 1));
        codItem.setDescricao("Descricao");
        codItem.setId(1L);
        codItem.setNome("Nome");

        TipoVistoriaEntity codTipo = new TipoVistoriaEntity();
        codTipo.setAtivo(true);
        codTipo.setDataInclusao(LocalDate.of(1970, 1, 1));
        codTipo.setDescricao("Descricao");
        codTipo.setId(1L);
        codTipo.setNome("Nome");
        codTipo.setStatusAnterior("Status Anterior");
        codTipo.setStatusPosterior("Status Posterior");

        ItensVistoriaEntity itensVistoriaEntity = new ItensVistoriaEntity();
        itensVistoriaEntity.setAtivo(true);
        itensVistoriaEntity.setCodItem(codItem);
        itensVistoriaEntity.setCodTipo(codTipo);
        itensVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itensVistoriaEntity.setId(1L);

        ArrayList<ItensVistoriaEntity> itensVistoriaEntityList = new ArrayList<>();
        itensVistoriaEntityList.add(itensVistoriaEntity);
        when(itensVistoriaRepository.findAllByCodItem(Mockito.<ItemVistoriaEntity>any()))
                .thenReturn(itensVistoriaEntityList);

        ItemVistoriaEntity itemVistoriaEntity = new ItemVistoriaEntity();
        itemVistoriaEntity.setAtivo(true);
        itemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity.setDescricao("Descricao");
        itemVistoriaEntity.setId(1L);
        itemVistoriaEntity.setNome("Nome");
        Optional<ItemVistoriaEntity> ofResult = Optional.of(itemVistoriaEntity);
        when(itemVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        // Act and Assert
        assertThrows(VistoriaExceptions.class, () -> itemVistoriaServiceImpl.excluir(1L));
        verify(itensVistoriaRepository).findAllByCodItem(isA(ItemVistoriaEntity.class));
        verify(itemVistoriaRepository).findById(eq(1L));
    }

    /**
     * Method under test: {@link ItemVistoriaServiceImpl#ativar(Long)}
     */
    @Test
    void testAtivar() {
        // Arrange
        ItemVistoriaEntity itemVistoriaEntity = new ItemVistoriaEntity();
        itemVistoriaEntity.setAtivo(true);
        itemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity.setDescricao("Descricao");
        itemVistoriaEntity.setId(1L);
        itemVistoriaEntity.setNome("Nome");
        Optional<ItemVistoriaEntity> ofResult = Optional.of(itemVistoriaEntity);

        ItemVistoriaEntity itemVistoriaEntity2 = new ItemVistoriaEntity();
        itemVistoriaEntity2.setAtivo(true);
        itemVistoriaEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity2.setDescricao("Descricao");
        itemVistoriaEntity2.setId(1L);
        itemVistoriaEntity2.setNome("Nome");
        when(itemVistoriaRepository.save(Mockito.<ItemVistoriaEntity>any())).thenReturn(itemVistoriaEntity2);
        when(itemVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        // Act
        ResponseEntity<?> actualAtivarResult = itemVistoriaServiceImpl.ativar(1L);

        // Assert
        verify(itemVistoriaRepository).findById(eq(1L));
        verify(itemVistoriaRepository).save(isA(ItemVistoriaEntity.class));
        assertNull(actualAtivarResult.getBody());
        assertEquals(HttpStatus.OK, actualAtivarResult.getStatusCode());
        assertTrue(actualAtivarResult.getHeaders().isEmpty());
    }

    /**
     * Method under test: {@link ItemVistoriaServiceImpl#ativar(Long)}
     */
    @Test
    void testAtivar2() {
        // Arrange
        ItemVistoriaEntity itemVistoriaEntity = new ItemVistoriaEntity();
        itemVistoriaEntity.setAtivo(true);
        itemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity.setDescricao("Descricao");
        itemVistoriaEntity.setId(1L);
        itemVistoriaEntity.setNome("Nome");
        Optional<ItemVistoriaEntity> ofResult = Optional.of(itemVistoriaEntity);
        when(itemVistoriaRepository.save(Mockito.<ItemVistoriaEntity>any()))
                .thenThrow(new VistoriaExceptions("An error occurred"));
        when(itemVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        // Act and Assert
        assertThrows(VistoriaExceptions.class, () -> itemVistoriaServiceImpl.ativar(1L));
        verify(itemVistoriaRepository).findById(eq(1L));
        verify(itemVistoriaRepository).save(isA(ItemVistoriaEntity.class));
    }

    /**
     * Method under test: {@link ItemVistoriaServiceImpl#ativar(Long)}
     */
    @Test
    void testAtivar3() {
        // Arrange
        ItemVistoriaEntity itemVistoriaEntity = mock(ItemVistoriaEntity.class);
        doNothing().when(itemVistoriaEntity).setAtivo(Mockito.<Boolean>any());
        doNothing().when(itemVistoriaEntity).setDataInclusao(Mockito.<LocalDate>any());
        doNothing().when(itemVistoriaEntity).setDescricao(Mockito.<String>any());
        doNothing().when(itemVistoriaEntity).setId(Mockito.<Long>any());
        doNothing().when(itemVistoriaEntity).setNome(Mockito.<String>any());
        itemVistoriaEntity.setAtivo(true);
        itemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity.setDescricao("Descricao");
        itemVistoriaEntity.setId(1L);
        itemVistoriaEntity.setNome("Nome");
        Optional<ItemVistoriaEntity> ofResult = Optional.of(itemVistoriaEntity);

        ItemVistoriaEntity itemVistoriaEntity2 = new ItemVistoriaEntity();
        itemVistoriaEntity2.setAtivo(true);
        itemVistoriaEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity2.setDescricao("Descricao");
        itemVistoriaEntity2.setId(1L);
        itemVistoriaEntity2.setNome("Nome");
        when(itemVistoriaRepository.save(Mockito.<ItemVistoriaEntity>any())).thenReturn(itemVistoriaEntity2);
        when(itemVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        // Act
        ResponseEntity<?> actualAtivarResult = itemVistoriaServiceImpl.ativar(1L);

        // Assert
        verify(itemVistoriaEntity, atLeast(1)).setAtivo(eq(true));
        verify(itemVistoriaEntity).setDataInclusao(isA(LocalDate.class));
        verify(itemVistoriaEntity).setDescricao(eq("Descricao"));
        verify(itemVistoriaEntity).setId(eq(1L));
        verify(itemVistoriaEntity).setNome(eq("Nome"));
        verify(itemVistoriaRepository).findById(eq(1L));
        verify(itemVistoriaRepository).save(isA(ItemVistoriaEntity.class));
        assertNull(actualAtivarResult.getBody());
        assertEquals(HttpStatus.OK, actualAtivarResult.getStatusCode());
        assertTrue(actualAtivarResult.getHeaders().isEmpty());
    }

    /**
     * Method under test:
     * {@link ItemVistoriaServiceImpl#findAllSubitemVistoriaById(String)}
     */
    @Test
    void testFindAllSubitemVistoriaById() {
        // Arrange
        ItemVistoriaEntity itemVistoriaEntity = new ItemVistoriaEntity();
        itemVistoriaEntity.setAtivo(true);
        itemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity.setDescricao("Descricao");
        itemVistoriaEntity.setId(1L);
        itemVistoriaEntity.setNome("Nome");
        Optional<ItemVistoriaEntity> ofResult = Optional.of(itemVistoriaEntity);
        when(itemVistoriaRepository.findByNome(Mockito.<String>any())).thenReturn(ofResult);
        ArrayList<SubitensVistoriaEntity> subitensVistoriaEntityList = new ArrayList<>();
        when(subitensVistoriaRepository.findAllByCodItem(Mockito.<ItemVistoriaEntity>any()))
                .thenReturn(subitensVistoriaEntityList);

        // Act
        ResponseEntity<List<SubitemVistoriaEntity>> actualFindAllSubitemVistoriaByIdResult = itemVistoriaServiceImpl
                .findAllSubitemVistoriaById("Nome");

        // Assert
        verify(itemVistoriaRepository).findByNome(eq("Nome"));
        verify(subitensVistoriaRepository).findAllByCodItem(isA(ItemVistoriaEntity.class));
        assertEquals(HttpStatus.OK, actualFindAllSubitemVistoriaByIdResult.getStatusCode());
        assertTrue(actualFindAllSubitemVistoriaByIdResult.getHeaders().isEmpty());
        assertEquals(subitensVistoriaEntityList, actualFindAllSubitemVistoriaByIdResult.getBody());
    }

    /**
     * Method under test:
     * {@link ItemVistoriaServiceImpl#findAllSubitemVistoriaById(String)}
     */
    @Test
    void testFindAllSubitemVistoriaById2() {
        // Arrange
        ItemVistoriaEntity itemVistoriaEntity = new ItemVistoriaEntity();
        itemVistoriaEntity.setAtivo(true);
        itemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity.setDescricao("Descricao");
        itemVistoriaEntity.setId(1L);
        itemVistoriaEntity.setNome("Nome");
        Optional<ItemVistoriaEntity> ofResult = Optional.of(itemVistoriaEntity);
        when(itemVistoriaRepository.findByNome(Mockito.<String>any())).thenReturn(ofResult);
        when(subitensVistoriaRepository.findAllByCodItem(Mockito.<ItemVistoriaEntity>any()))
                .thenThrow(new VistoriaExceptions("An error occurred"));

        // Act and Assert
        assertThrows(VistoriaExceptions.class, () -> itemVistoriaServiceImpl.findAllSubitemVistoriaById("Nome"));
        verify(itemVistoriaRepository).findByNome(eq("Nome"));
        verify(subitensVistoriaRepository).findAllByCodItem(isA(ItemVistoriaEntity.class));
    }

    /**
     * Method under test:
     * {@link ItemVistoriaServiceImpl#findAllSubitemVistoriaById(String)}
     */
    @Test
    void testFindAllSubitemVistoriaById3() {
        // Arrange
        ItemVistoriaEntity itemVistoriaEntity = new ItemVistoriaEntity();
        itemVistoriaEntity.setAtivo(true);
        itemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity.setDescricao("Descricao");
        itemVistoriaEntity.setId(1L);
        itemVistoriaEntity.setNome("Nome");
        Optional<ItemVistoriaEntity> ofResult = Optional.of(itemVistoriaEntity);
        when(itemVistoriaRepository.findByNome(Mockito.<String>any())).thenReturn(ofResult);

        SubitemVistoriaEntity subitemVistoriaEntity = new SubitemVistoriaEntity();
        subitemVistoriaEntity.setAtivo(true);
        subitemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        subitemVistoriaEntity.setDescricao("Descricao");
        subitemVistoriaEntity.setId(1L);
        subitemVistoriaEntity.setNome("Nome");
        Optional<SubitemVistoriaEntity> ofResult2 = Optional.of(subitemVistoriaEntity);
        when(subitemVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult2);

        ItemVistoriaEntity codItem = new ItemVistoriaEntity();
        codItem.setAtivo(true);
        codItem.setDataInclusao(LocalDate.of(1970, 1, 1));
        codItem.setDescricao("Descricao");
        codItem.setId(1L);
        codItem.setNome("Nome");

        SubitemVistoriaEntity codSubitem = new SubitemVistoriaEntity();
        codSubitem.setAtivo(true);
        codSubitem.setDataInclusao(LocalDate.of(1970, 1, 1));
        codSubitem.setDescricao("Descricao");
        codSubitem.setId(1L);
        codSubitem.setNome("Nome");

        SubitensVistoriaEntity subitensVistoriaEntity = new SubitensVistoriaEntity();
        subitensVistoriaEntity.setAtivo(true);
        subitensVistoriaEntity.setCodItem(codItem);
        subitensVistoriaEntity.setCodSubitem(codSubitem);
        subitensVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        subitensVistoriaEntity.setId(1L);

        ArrayList<SubitensVistoriaEntity> subitensVistoriaEntityList = new ArrayList<>();
        subitensVistoriaEntityList.add(subitensVistoriaEntity);
        when(subitensVistoriaRepository.findAllByCodItem(Mockito.<ItemVistoriaEntity>any()))
                .thenReturn(subitensVistoriaEntityList);

        // Act
        ResponseEntity<List<SubitemVistoriaEntity>> actualFindAllSubitemVistoriaByIdResult = itemVistoriaServiceImpl
                .findAllSubitemVistoriaById("Nome");

        // Assert
        verify(itemVistoriaRepository).findByNome(eq("Nome"));
        verify(subitensVistoriaRepository).findAllByCodItem(isA(ItemVistoriaEntity.class));
        verify(subitemVistoriaRepository).findById(eq(1L));
        assertEquals(1, actualFindAllSubitemVistoriaByIdResult.getBody().size());
        assertEquals(HttpStatus.OK, actualFindAllSubitemVistoriaByIdResult.getStatusCode());
        assertTrue(actualFindAllSubitemVistoriaByIdResult.hasBody());
        assertTrue(actualFindAllSubitemVistoriaByIdResult.getHeaders().isEmpty());
    }

    /**
     * Method under test:
     * {@link ItemVistoriaServiceImpl#findAllSubitemVistoriaById(String)}
     */
    @Test
    void testFindAllSubitemVistoriaById4() {
        // Arrange
        ItemVistoriaEntity itemVistoriaEntity = new ItemVistoriaEntity();
        itemVistoriaEntity.setAtivo(true);
        itemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity.setDescricao("Descricao");
        itemVistoriaEntity.setId(1L);
        itemVistoriaEntity.setNome("Nome");
        Optional<ItemVistoriaEntity> ofResult = Optional.of(itemVistoriaEntity);
        when(itemVistoriaRepository.findByNome(Mockito.<String>any())).thenReturn(ofResult);

        SubitemVistoriaEntity subitemVistoriaEntity = new SubitemVistoriaEntity();
        subitemVistoriaEntity.setAtivo(true);
        subitemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        subitemVistoriaEntity.setDescricao("Descricao");
        subitemVistoriaEntity.setId(1L);
        subitemVistoriaEntity.setNome("Nome");
        Optional<SubitemVistoriaEntity> ofResult2 = Optional.of(subitemVistoriaEntity);
        when(subitemVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult2);

        ItemVistoriaEntity codItem = new ItemVistoriaEntity();
        codItem.setAtivo(true);
        codItem.setDataInclusao(LocalDate.of(1970, 1, 1));
        codItem.setDescricao("Descricao");
        codItem.setId(1L);
        codItem.setNome("Nome");

        SubitemVistoriaEntity codSubitem = new SubitemVistoriaEntity();
        codSubitem.setAtivo(true);
        codSubitem.setDataInclusao(LocalDate.of(1970, 1, 1));
        codSubitem.setDescricao("Descricao");
        codSubitem.setId(1L);
        codSubitem.setNome("Nome");

        SubitemVistoriaEntity subitemVistoriaEntity2 = new SubitemVistoriaEntity();
        subitemVistoriaEntity2.setAtivo(true);
        subitemVistoriaEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        subitemVistoriaEntity2.setDescricao("Descricao");
        subitemVistoriaEntity2.setId(1L);
        subitemVistoriaEntity2.setNome("Nome");
        SubitensVistoriaEntity subitensVistoriaEntity = mock(SubitensVistoriaEntity.class);
        when(subitensVistoriaEntity.getCodSubitem()).thenReturn(subitemVistoriaEntity2);
        doNothing().when(subitensVistoriaEntity).setAtivo(Mockito.<Boolean>any());
        doNothing().when(subitensVistoriaEntity).setCodItem(Mockito.<ItemVistoriaEntity>any());
        doNothing().when(subitensVistoriaEntity).setCodSubitem(Mockito.<SubitemVistoriaEntity>any());
        doNothing().when(subitensVistoriaEntity).setDataInclusao(Mockito.<LocalDate>any());
        doNothing().when(subitensVistoriaEntity).setId(Mockito.<Long>any());
        subitensVistoriaEntity.setAtivo(true);
        subitensVistoriaEntity.setCodItem(codItem);
        subitensVistoriaEntity.setCodSubitem(codSubitem);
        subitensVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        subitensVistoriaEntity.setId(1L);

        ArrayList<SubitensVistoriaEntity> subitensVistoriaEntityList = new ArrayList<>();
        subitensVistoriaEntityList.add(subitensVistoriaEntity);
        when(subitensVistoriaRepository.findAllByCodItem(Mockito.<ItemVistoriaEntity>any()))
                .thenReturn(subitensVistoriaEntityList);

        // Act
        ResponseEntity<List<SubitemVistoriaEntity>> actualFindAllSubitemVistoriaByIdResult = itemVistoriaServiceImpl
                .findAllSubitemVistoriaById("Nome");

        // Assert
        verify(subitensVistoriaEntity).getCodSubitem();
        verify(subitensVistoriaEntity).setAtivo(eq(true));
        verify(subitensVistoriaEntity).setCodItem(isA(ItemVistoriaEntity.class));
        verify(subitensVistoriaEntity).setCodSubitem(isA(SubitemVistoriaEntity.class));
        verify(subitensVistoriaEntity).setDataInclusao(isA(LocalDate.class));
        verify(subitensVistoriaEntity).setId(eq(1L));
        verify(itemVistoriaRepository).findByNome(eq("Nome"));
        verify(subitensVistoriaRepository).findAllByCodItem(isA(ItemVistoriaEntity.class));
        verify(subitemVistoriaRepository).findById(eq(1L));
        assertEquals(1, actualFindAllSubitemVistoriaByIdResult.getBody().size());
        assertEquals(HttpStatus.OK, actualFindAllSubitemVistoriaByIdResult.getStatusCode());
        assertTrue(actualFindAllSubitemVistoriaByIdResult.hasBody());
        assertTrue(actualFindAllSubitemVistoriaByIdResult.getHeaders().isEmpty());
    }

    /**
     * Method under test:
     * {@link ItemVistoriaServiceImpl#listAllAtivosByTipoVistoria(Long)}
     */
    @Test
    void testListAllAtivosByTipoVistoria() {
        // Arrange
        when(itensVistoriaRepository.findBycodTipoAndAtivo(Mockito.<TipoVistoriaEntity>any(), Mockito.<Boolean>any()))
                .thenReturn(new ArrayList<>());

        TipoVistoriaEntity tipoVistoriaEntity = new TipoVistoriaEntity();
        tipoVistoriaEntity.setAtivo(true);
        tipoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoriaEntity.setDescricao("Descricao");
        tipoVistoriaEntity.setId(1L);
        tipoVistoriaEntity.setNome("Nome");
        tipoVistoriaEntity.setStatusAnterior("Status Anterior");
        tipoVistoriaEntity.setStatusPosterior("Status Posterior");
        when(tipoVistoriaService.findByIdTipoVistoria(Mockito.<Long>any())).thenReturn(tipoVistoriaEntity);

        // Act and Assert
        assertThrows(ItemVistoriaException.class, () -> itemVistoriaServiceImpl.listAllAtivosByTipoVistoria(1L));
        verify(itensVistoriaRepository).findBycodTipoAndAtivo(isA(TipoVistoriaEntity.class), eq(true));
        verify(tipoVistoriaService).findByIdTipoVistoria(eq(1L));
    }

    /**
     * Method under test:
     * {@link ItemVistoriaServiceImpl#listAllAtivosByTipoVistoria(Long)}
     */
    @Test
    void testListAllAtivosByTipoVistoria2() {
        // Arrange
        when(tipoVistoriaService.findByIdTipoVistoria(Mockito.<Long>any()))
                .thenThrow(new VistoriaExceptions("An error occurred"));

        // Act and Assert
        assertThrows(VistoriaExceptions.class, () -> itemVistoriaServiceImpl.listAllAtivosByTipoVistoria(1L));
        verify(tipoVistoriaService).findByIdTipoVistoria(eq(1L));
    }

    /**
     * Method under test:
     * {@link ItemVistoriaServiceImpl#listAllAtivosByTipoVistoria(Long)}
     */
    @Test
    void testListAllAtivosByTipoVistoria3() {
        // Arrange
        ItemVistoriaEntity codItem = new ItemVistoriaEntity();
        codItem.setAtivo(true);
        codItem.setDataInclusao(LocalDate.of(1970, 1, 1));
        codItem.setDescricao("Descricao");
        codItem.setId(1L);
        codItem.setNome("Nome");

        TipoVistoriaEntity codTipo = new TipoVistoriaEntity();
        codTipo.setAtivo(true);
        codTipo.setDataInclusao(LocalDate.of(1970, 1, 1));
        codTipo.setDescricao("Descricao");
        codTipo.setId(1L);
        codTipo.setNome("Nome");
        codTipo.setStatusAnterior("Status Anterior");
        codTipo.setStatusPosterior("Status Posterior");

        ItensVistoriaEntity itensVistoriaEntity = new ItensVistoriaEntity();
        itensVistoriaEntity.setAtivo(true);
        itensVistoriaEntity.setCodItem(codItem);
        itensVistoriaEntity.setCodTipo(codTipo);
        itensVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itensVistoriaEntity.setId(1L);

        ArrayList<ItensVistoriaEntity> itensVistoriaEntityList = new ArrayList<>();
        itensVistoriaEntityList.add(itensVistoriaEntity);
        when(itensVistoriaRepository.findBycodTipoAndAtivo(Mockito.<TipoVistoriaEntity>any(), Mockito.<Boolean>any()))
                .thenReturn(itensVistoriaEntityList);
        when(subitensVistoriaRepository.findAllByCodItemAndAtivo(Mockito.<ItemVistoriaEntity>any(), Mockito.<Boolean>any()))
                .thenReturn(new ArrayList<>());

        TipoVistoriaEntity tipoVistoriaEntity = new TipoVistoriaEntity();
        tipoVistoriaEntity.setAtivo(true);
        tipoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoriaEntity.setDescricao("Descricao");
        tipoVistoriaEntity.setId(1L);
        tipoVistoriaEntity.setNome("Nome");
        tipoVistoriaEntity.setStatusAnterior("Status Anterior");
        tipoVistoriaEntity.setStatusPosterior("Status Posterior");
        when(tipoVistoriaService.findByIdTipoVistoria(Mockito.<Long>any())).thenReturn(tipoVistoriaEntity);

        // Act
        OcorrenciasDTO actualListAllAtivosByTipoVistoriaResult = itemVistoriaServiceImpl.listAllAtivosByTipoVistoria(1L);

        // Assert
        verify(itensVistoriaRepository).findBycodTipoAndAtivo(isA(TipoVistoriaEntity.class), eq(true));
        verify(subitensVistoriaRepository).findAllByCodItemAndAtivo(isA(ItemVistoriaEntity.class), eq(true));
        verify(tipoVistoriaService).findByIdTipoVistoria(eq(1L));
        assertEquals(1, actualListAllAtivosByTipoVistoriaResult.getItemVistoriaOcorrenciaDTOS().size());
    }

    /**
     * Method under test:
     * {@link ItemVistoriaServiceImpl#listAllAtivosByTipoVistoria(Long)}
     */
    @Test
    void testListAllAtivosByTipoVistoria4() {
        // Arrange
        ItemVistoriaEntity codItem = new ItemVistoriaEntity();
        codItem.setAtivo(true);
        codItem.setDataInclusao(LocalDate.of(1970, 1, 1));
        codItem.setDescricao("Descricao");
        codItem.setId(1L);
        codItem.setNome("Nome");

        TipoVistoriaEntity codTipo = new TipoVistoriaEntity();
        codTipo.setAtivo(true);
        codTipo.setDataInclusao(LocalDate.of(1970, 1, 1));
        codTipo.setDescricao("Descricao");
        codTipo.setId(1L);
        codTipo.setNome("Nome");
        codTipo.setStatusAnterior("Status Anterior");
        codTipo.setStatusPosterior("Status Posterior");
        ItemVistoriaEntity itemVistoriaEntity = mock(ItemVistoriaEntity.class);
        when(itemVistoriaEntity.getAtivo()).thenReturn(true);
        when(itemVistoriaEntity.getId()).thenReturn(1L);
        when(itemVistoriaEntity.getDescricao()).thenReturn("Descricao");
        when(itemVistoriaEntity.getNome()).thenReturn("Nome");
        when(itemVistoriaEntity.getDataInclusao()).thenReturn(LocalDate.of(1970, 1, 1));
        doNothing().when(itemVistoriaEntity).setAtivo(Mockito.<Boolean>any());
        doNothing().when(itemVistoriaEntity).setDataInclusao(Mockito.<LocalDate>any());
        doNothing().when(itemVistoriaEntity).setDescricao(Mockito.<String>any());
        doNothing().when(itemVistoriaEntity).setId(Mockito.<Long>any());
        doNothing().when(itemVistoriaEntity).setNome(Mockito.<String>any());
        itemVistoriaEntity.setAtivo(true);
        itemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity.setDescricao("Descricao");
        itemVistoriaEntity.setId(1L);
        itemVistoriaEntity.setNome("Nome");
        ItensVistoriaEntity itensVistoriaEntity = mock(ItensVistoriaEntity.class);
        when(itensVistoriaEntity.getCodItem()).thenReturn(itemVistoriaEntity);
        doNothing().when(itensVistoriaEntity).setAtivo(Mockito.<Boolean>any());
        doNothing().when(itensVistoriaEntity).setCodItem(Mockito.<ItemVistoriaEntity>any());
        doNothing().when(itensVistoriaEntity).setCodTipo(Mockito.<TipoVistoriaEntity>any());
        doNothing().when(itensVistoriaEntity).setDataInclusao(Mockito.<LocalDate>any());
        doNothing().when(itensVistoriaEntity).setId(Mockito.<Long>any());
        itensVistoriaEntity.setAtivo(true);
        itensVistoriaEntity.setCodItem(codItem);
        itensVistoriaEntity.setCodTipo(codTipo);
        itensVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itensVistoriaEntity.setId(1L);

        ArrayList<ItensVistoriaEntity> itensVistoriaEntityList = new ArrayList<>();
        itensVistoriaEntityList.add(itensVistoriaEntity);
        when(itensVistoriaRepository.findBycodTipoAndAtivo(Mockito.<TipoVistoriaEntity>any(), Mockito.<Boolean>any()))
                .thenReturn(itensVistoriaEntityList);
        when(subitensVistoriaRepository.findAllByCodItemAndAtivo(Mockito.<ItemVistoriaEntity>any(), Mockito.<Boolean>any()))
                .thenReturn(new ArrayList<>());

        TipoVistoriaEntity tipoVistoriaEntity = new TipoVistoriaEntity();
        tipoVistoriaEntity.setAtivo(true);
        tipoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoriaEntity.setDescricao("Descricao");
        tipoVistoriaEntity.setId(1L);
        tipoVistoriaEntity.setNome("Nome");
        tipoVistoriaEntity.setStatusAnterior("Status Anterior");
        tipoVistoriaEntity.setStatusPosterior("Status Posterior");
        when(tipoVistoriaService.findByIdTipoVistoria(Mockito.<Long>any())).thenReturn(tipoVistoriaEntity);

        // Act
        OcorrenciasDTO actualListAllAtivosByTipoVistoriaResult = itemVistoriaServiceImpl.listAllAtivosByTipoVistoria(1L);

        // Assert
        verify(itemVistoriaEntity).getAtivo();
        verify(itemVistoriaEntity).getDataInclusao();
        verify(itemVistoriaEntity).getDescricao();
        verify(itemVistoriaEntity).getId();
        verify(itemVistoriaEntity).getNome();
        verify(itemVistoriaEntity).setAtivo(eq(true));
        verify(itemVistoriaEntity).setDataInclusao(isA(LocalDate.class));
        verify(itemVistoriaEntity).setDescricao(eq("Descricao"));
        verify(itemVistoriaEntity).setId(eq(1L));
        verify(itemVistoriaEntity).setNome(eq("Nome"));
        verify(itensVistoriaEntity, atLeast(1)).getCodItem();
        verify(itensVistoriaEntity).setAtivo(eq(true));
        verify(itensVistoriaEntity).setCodItem(isA(ItemVistoriaEntity.class));
        verify(itensVistoriaEntity).setCodTipo(isA(TipoVistoriaEntity.class));
        verify(itensVistoriaEntity).setDataInclusao(isA(LocalDate.class));
        verify(itensVistoriaEntity).setId(eq(1L));
        verify(itensVistoriaRepository).findBycodTipoAndAtivo(isA(TipoVistoriaEntity.class), eq(true));
        verify(subitensVistoriaRepository).findAllByCodItemAndAtivo(isA(ItemVistoriaEntity.class), eq(true));
        verify(tipoVistoriaService).findByIdTipoVistoria(eq(1L));
        assertEquals(1, actualListAllAtivosByTipoVistoriaResult.getItemVistoriaOcorrenciaDTOS().size());
    }

    /**
     * Method under test:
     * {@link ItemVistoriaServiceImpl#listAllAtivosByTipoVistoria(Long)}
     */
    @Test
    void testListAllAtivosByTipoVistoria5() {
        // Arrange
        when(defeitosVistoriaRepository.findAllByCodSubitemAndAtivo(Mockito.<SubitemVistoriaEntity>any(),
                Mockito.<Boolean>any())).thenReturn(new ArrayList<>());

        ItemVistoriaEntity codItem = new ItemVistoriaEntity();
        codItem.setAtivo(true);
        codItem.setDataInclusao(LocalDate.of(1970, 1, 1));
        codItem.setDescricao("Descricao");
        codItem.setId(1L);
        codItem.setNome("Nome");

        TipoVistoriaEntity codTipo = new TipoVistoriaEntity();
        codTipo.setAtivo(true);
        codTipo.setDataInclusao(LocalDate.of(1970, 1, 1));
        codTipo.setDescricao("Descricao");
        codTipo.setId(1L);
        codTipo.setNome("Nome");
        codTipo.setStatusAnterior("Status Anterior");
        codTipo.setStatusPosterior("Status Posterior");
        ItemVistoriaEntity itemVistoriaEntity = mock(ItemVistoriaEntity.class);
        when(itemVistoriaEntity.getAtivo()).thenReturn(true);
        when(itemVistoriaEntity.getId()).thenReturn(1L);
        when(itemVistoriaEntity.getDescricao()).thenReturn("Descricao");
        when(itemVistoriaEntity.getNome()).thenReturn("Nome");
        when(itemVistoriaEntity.getDataInclusao()).thenReturn(LocalDate.of(1970, 1, 1));
        doNothing().when(itemVistoriaEntity).setAtivo(Mockito.<Boolean>any());
        doNothing().when(itemVistoriaEntity).setDataInclusao(Mockito.<LocalDate>any());
        doNothing().when(itemVistoriaEntity).setDescricao(Mockito.<String>any());
        doNothing().when(itemVistoriaEntity).setId(Mockito.<Long>any());
        doNothing().when(itemVistoriaEntity).setNome(Mockito.<String>any());
        itemVistoriaEntity.setAtivo(true);
        itemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity.setDescricao("Descricao");
        itemVistoriaEntity.setId(1L);
        itemVistoriaEntity.setNome("Nome");
        ItensVistoriaEntity itensVistoriaEntity = mock(ItensVistoriaEntity.class);
        when(itensVistoriaEntity.getCodItem()).thenReturn(itemVistoriaEntity);
        doNothing().when(itensVistoriaEntity).setAtivo(Mockito.<Boolean>any());
        doNothing().when(itensVistoriaEntity).setCodItem(Mockito.<ItemVistoriaEntity>any());
        doNothing().when(itensVistoriaEntity).setCodTipo(Mockito.<TipoVistoriaEntity>any());
        doNothing().when(itensVistoriaEntity).setDataInclusao(Mockito.<LocalDate>any());
        doNothing().when(itensVistoriaEntity).setId(Mockito.<Long>any());
        itensVistoriaEntity.setAtivo(true);
        itensVistoriaEntity.setCodItem(codItem);
        itensVistoriaEntity.setCodTipo(codTipo);
        itensVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itensVistoriaEntity.setId(1L);

        ArrayList<ItensVistoriaEntity> itensVistoriaEntityList = new ArrayList<>();
        itensVistoriaEntityList.add(itensVistoriaEntity);
        when(itensVistoriaRepository.findBycodTipoAndAtivo(Mockito.<TipoVistoriaEntity>any(), Mockito.<Boolean>any()))
                .thenReturn(itensVistoriaEntityList);

        ItemVistoriaEntity codItem2 = new ItemVistoriaEntity();
        codItem2.setAtivo(true);
        codItem2.setDataInclusao(LocalDate.of(1970, 1, 1));
        codItem2.setDescricao("Descricao");
        codItem2.setId(1L);
        codItem2.setNome("Nome");

        SubitemVistoriaEntity codSubitem = new SubitemVistoriaEntity();
        codSubitem.setAtivo(true);
        codSubitem.setDataInclusao(LocalDate.of(1970, 1, 1));
        codSubitem.setDescricao("Descricao");
        codSubitem.setId(1L);
        codSubitem.setNome("Nome");

        SubitensVistoriaEntity subitensVistoriaEntity = new SubitensVistoriaEntity();
        subitensVistoriaEntity.setAtivo(true);
        subitensVistoriaEntity.setCodItem(codItem2);
        subitensVistoriaEntity.setCodSubitem(codSubitem);
        subitensVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        subitensVistoriaEntity.setId(1L);

        ArrayList<SubitensVistoriaEntity> subitensVistoriaEntityList = new ArrayList<>();
        subitensVistoriaEntityList.add(subitensVistoriaEntity);
        when(subitensVistoriaRepository.findAllByCodItemAndAtivo(Mockito.<ItemVistoriaEntity>any(), Mockito.<Boolean>any()))
                .thenReturn(subitensVistoriaEntityList);

        TipoVistoriaEntity tipoVistoriaEntity = new TipoVistoriaEntity();
        tipoVistoriaEntity.setAtivo(true);
        tipoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoriaEntity.setDescricao("Descricao");
        tipoVistoriaEntity.setId(1L);
        tipoVistoriaEntity.setNome("Nome");
        tipoVistoriaEntity.setStatusAnterior("Status Anterior");
        tipoVistoriaEntity.setStatusPosterior("Status Posterior");
        when(tipoVistoriaService.findByIdTipoVistoria(Mockito.<Long>any())).thenReturn(tipoVistoriaEntity);

        // Act
        OcorrenciasDTO actualListAllAtivosByTipoVistoriaResult = itemVistoriaServiceImpl.listAllAtivosByTipoVistoria(1L);

        // Assert
        verify(itemVistoriaEntity).getAtivo();
        verify(itemVistoriaEntity).getDataInclusao();
        verify(itemVistoriaEntity).getDescricao();
        verify(itemVistoriaEntity).getId();
        verify(itemVistoriaEntity).getNome();
        verify(itemVistoriaEntity).setAtivo(eq(true));
        verify(itemVistoriaEntity).setDataInclusao(isA(LocalDate.class));
        verify(itemVistoriaEntity).setDescricao(eq("Descricao"));
        verify(itemVistoriaEntity).setId(eq(1L));
        verify(itemVistoriaEntity).setNome(eq("Nome"));
        verify(itensVistoriaEntity, atLeast(1)).getCodItem();
        verify(itensVistoriaEntity).setAtivo(eq(true));
        verify(itensVistoriaEntity).setCodItem(isA(ItemVistoriaEntity.class));
        verify(itensVistoriaEntity).setCodTipo(isA(TipoVistoriaEntity.class));
        verify(itensVistoriaEntity).setDataInclusao(isA(LocalDate.class));
        verify(itensVistoriaEntity).setId(eq(1L));
        verify(defeitosVistoriaRepository).findAllByCodSubitemAndAtivo(isA(SubitemVistoriaEntity.class), eq(true));
        verify(itensVistoriaRepository).findBycodTipoAndAtivo(isA(TipoVistoriaEntity.class), eq(true));
        verify(subitensVistoriaRepository).findAllByCodItemAndAtivo(isA(ItemVistoriaEntity.class), eq(true));
        verify(tipoVistoriaService).findByIdTipoVistoria(eq(1L));
        assertEquals(1, actualListAllAtivosByTipoVistoriaResult.getItemVistoriaOcorrenciaDTOS().size());
    }

    /**
     * Method under test:
     * {@link ItemVistoriaServiceImpl#listAllAtivosByTipoVistoria(Long)}
     */
    @Test
    void testListAllAtivosByTipoVistoria6() {
        // Arrange
        SubitemVistoriaEntity codSubitem = new SubitemVistoriaEntity();
        codSubitem.setAtivo(true);
        codSubitem.setDataInclusao(LocalDate.of(1970, 1, 1));
        codSubitem.setDescricao("Descricao");
        codSubitem.setId(1L);
        codSubitem.setNome("Nome");

        TipoDefeitoVistoriaEntity codTipoDefeito = new TipoDefeitoVistoriaEntity();
        codTipoDefeito.setAtivo(true);
        codTipoDefeito.setDataInclusao(LocalDate.of(1970, 1, 1));
        codTipoDefeito.setDescricao("Descricao");
        codTipoDefeito.setId(1L);
        codTipoDefeito.setNome("Nome");

        DefeitosVistoriaEntity defeitosVistoriaEntity = new DefeitosVistoriaEntity();
        defeitosVistoriaEntity.setAtivo(true);
        defeitosVistoriaEntity.setCodSubitem(codSubitem);
        defeitosVistoriaEntity.setCodTipoDefeito(codTipoDefeito);
        defeitosVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        defeitosVistoriaEntity.setId(1L);

        ArrayList<DefeitosVistoriaEntity> defeitosVistoriaEntityList = new ArrayList<>();
        defeitosVistoriaEntityList.add(defeitosVistoriaEntity);
        when(defeitosVistoriaRepository.findAllByCodSubitemAndAtivo(Mockito.<SubitemVistoriaEntity>any(),
                Mockito.<Boolean>any())).thenReturn(defeitosVistoriaEntityList);

        ItemVistoriaEntity codItem = new ItemVistoriaEntity();
        codItem.setAtivo(true);
        codItem.setDataInclusao(LocalDate.of(1970, 1, 1));
        codItem.setDescricao("Descricao");
        codItem.setId(1L);
        codItem.setNome("Nome");

        TipoVistoriaEntity codTipo = new TipoVistoriaEntity();
        codTipo.setAtivo(true);
        codTipo.setDataInclusao(LocalDate.of(1970, 1, 1));
        codTipo.setDescricao("Descricao");
        codTipo.setId(1L);
        codTipo.setNome("Nome");
        codTipo.setStatusAnterior("Status Anterior");
        codTipo.setStatusPosterior("Status Posterior");
        ItemVistoriaEntity itemVistoriaEntity = mock(ItemVistoriaEntity.class);
        when(itemVistoriaEntity.getAtivo()).thenReturn(true);
        when(itemVistoriaEntity.getId()).thenReturn(1L);
        when(itemVistoriaEntity.getDescricao()).thenReturn("Descricao");
        when(itemVistoriaEntity.getNome()).thenReturn("Nome");
        when(itemVistoriaEntity.getDataInclusao()).thenReturn(LocalDate.of(1970, 1, 1));
        doNothing().when(itemVistoriaEntity).setAtivo(Mockito.<Boolean>any());
        doNothing().when(itemVistoriaEntity).setDataInclusao(Mockito.<LocalDate>any());
        doNothing().when(itemVistoriaEntity).setDescricao(Mockito.<String>any());
        doNothing().when(itemVistoriaEntity).setId(Mockito.<Long>any());
        doNothing().when(itemVistoriaEntity).setNome(Mockito.<String>any());
        itemVistoriaEntity.setAtivo(true);
        itemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity.setDescricao("Descricao");
        itemVistoriaEntity.setId(1L);
        itemVistoriaEntity.setNome("Nome");
        ItensVistoriaEntity itensVistoriaEntity = mock(ItensVistoriaEntity.class);
        when(itensVistoriaEntity.getCodItem()).thenReturn(itemVistoriaEntity);
        doNothing().when(itensVistoriaEntity).setAtivo(Mockito.<Boolean>any());
        doNothing().when(itensVistoriaEntity).setCodItem(Mockito.<ItemVistoriaEntity>any());
        doNothing().when(itensVistoriaEntity).setCodTipo(Mockito.<TipoVistoriaEntity>any());
        doNothing().when(itensVistoriaEntity).setDataInclusao(Mockito.<LocalDate>any());
        doNothing().when(itensVistoriaEntity).setId(Mockito.<Long>any());
        itensVistoriaEntity.setAtivo(true);
        itensVistoriaEntity.setCodItem(codItem);
        itensVistoriaEntity.setCodTipo(codTipo);
        itensVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itensVistoriaEntity.setId(1L);

        ArrayList<ItensVistoriaEntity> itensVistoriaEntityList = new ArrayList<>();
        itensVistoriaEntityList.add(itensVistoriaEntity);
        when(itensVistoriaRepository.findBycodTipoAndAtivo(Mockito.<TipoVistoriaEntity>any(), Mockito.<Boolean>any()))
                .thenReturn(itensVistoriaEntityList);

        ItemVistoriaEntity codItem2 = new ItemVistoriaEntity();
        codItem2.setAtivo(true);
        codItem2.setDataInclusao(LocalDate.of(1970, 1, 1));
        codItem2.setDescricao("Descricao");
        codItem2.setId(1L);
        codItem2.setNome("Nome");

        SubitemVistoriaEntity codSubitem2 = new SubitemVistoriaEntity();
        codSubitem2.setAtivo(true);
        codSubitem2.setDataInclusao(LocalDate.of(1970, 1, 1));
        codSubitem2.setDescricao("Descricao");
        codSubitem2.setId(1L);
        codSubitem2.setNome("Nome");

        SubitensVistoriaEntity subitensVistoriaEntity = new SubitensVistoriaEntity();
        subitensVistoriaEntity.setAtivo(true);
        subitensVistoriaEntity.setCodItem(codItem2);
        subitensVistoriaEntity.setCodSubitem(codSubitem2);
        subitensVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        subitensVistoriaEntity.setId(1L);

        ArrayList<SubitensVistoriaEntity> subitensVistoriaEntityList = new ArrayList<>();
        subitensVistoriaEntityList.add(subitensVistoriaEntity);
        when(subitensVistoriaRepository.findAllByCodItemAndAtivo(Mockito.<ItemVistoriaEntity>any(), Mockito.<Boolean>any()))
                .thenReturn(subitensVistoriaEntityList);

        TipoVistoriaEntity tipoVistoriaEntity = new TipoVistoriaEntity();
        tipoVistoriaEntity.setAtivo(true);
        tipoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoriaEntity.setDescricao("Descricao");
        tipoVistoriaEntity.setId(1L);
        tipoVistoriaEntity.setNome("Nome");
        tipoVistoriaEntity.setStatusAnterior("Status Anterior");
        tipoVistoriaEntity.setStatusPosterior("Status Posterior");
        when(tipoVistoriaService.findByIdTipoVistoria(Mockito.<Long>any())).thenReturn(tipoVistoriaEntity);

        // Act
        OcorrenciasDTO actualListAllAtivosByTipoVistoriaResult = itemVistoriaServiceImpl.listAllAtivosByTipoVistoria(1L);

        // Assert
        verify(itemVistoriaEntity).getAtivo();
        verify(itemVistoriaEntity).getDataInclusao();
        verify(itemVistoriaEntity).getDescricao();
        verify(itemVistoriaEntity).getId();
        verify(itemVistoriaEntity).getNome();
        verify(itemVistoriaEntity).setAtivo(eq(true));
        verify(itemVistoriaEntity).setDataInclusao(isA(LocalDate.class));
        verify(itemVistoriaEntity).setDescricao(eq("Descricao"));
        verify(itemVistoriaEntity).setId(eq(1L));
        verify(itemVistoriaEntity).setNome(eq("Nome"));
        verify(itensVistoriaEntity, atLeast(1)).getCodItem();
        verify(itensVistoriaEntity).setAtivo(eq(true));
        verify(itensVistoriaEntity).setCodItem(isA(ItemVistoriaEntity.class));
        verify(itensVistoriaEntity).setCodTipo(isA(TipoVistoriaEntity.class));
        verify(itensVistoriaEntity).setDataInclusao(isA(LocalDate.class));
        verify(itensVistoriaEntity).setId(eq(1L));
        verify(defeitosVistoriaRepository).findAllByCodSubitemAndAtivo(isA(SubitemVistoriaEntity.class), eq(true));
        verify(itensVistoriaRepository).findBycodTipoAndAtivo(isA(TipoVistoriaEntity.class), eq(true));
        verify(subitensVistoriaRepository).findAllByCodItemAndAtivo(isA(ItemVistoriaEntity.class), eq(true));
        verify(tipoVistoriaService).findByIdTipoVistoria(eq(1L));
        assertEquals(1, actualListAllAtivosByTipoVistoriaResult.getItemVistoriaOcorrenciaDTOS().size());
    }

    /**
     * Method under test:
     * {@link ItemVistoriaServiceImpl#listAllAtivosByTipoVistoria(Long)}
     */
    @Test
    void testListAllAtivosByTipoVistoria7() {
        // Arrange
        SubitemVistoriaEntity codSubitem = new SubitemVistoriaEntity();
        codSubitem.setAtivo(true);
        codSubitem.setDataInclusao(LocalDate.of(1970, 1, 1));
        codSubitem.setDescricao("Descricao");
        codSubitem.setId(1L);
        codSubitem.setNome("Nome");

        TipoDefeitoVistoriaEntity codTipoDefeito = new TipoDefeitoVistoriaEntity();
        codTipoDefeito.setAtivo(true);
        codTipoDefeito.setDataInclusao(LocalDate.of(1970, 1, 1));
        codTipoDefeito.setDescricao("Descricao");
        codTipoDefeito.setId(1L);
        codTipoDefeito.setNome("Nome");

        DefeitosVistoriaEntity defeitosVistoriaEntity = new DefeitosVistoriaEntity();
        defeitosVistoriaEntity.setAtivo(true);
        defeitosVistoriaEntity.setCodSubitem(codSubitem);
        defeitosVistoriaEntity.setCodTipoDefeito(codTipoDefeito);
        defeitosVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        defeitosVistoriaEntity.setId(1L);

        SubitemVistoriaEntity codSubitem2 = new SubitemVistoriaEntity();
        codSubitem2.setAtivo(false);
        codSubitem2.setDataInclusao(LocalDate.of(1970, 1, 1));
        codSubitem2.setDescricao("br.gov.df.pm.sgv.domain.SubitemVistoriaEntity");
        codSubitem2.setId(2L);
        codSubitem2.setNome("br.gov.df.pm.sgv.domain.SubitemVistoriaEntity");

        TipoDefeitoVistoriaEntity codTipoDefeito2 = new TipoDefeitoVistoriaEntity();
        codTipoDefeito2.setAtivo(false);
        codTipoDefeito2.setDataInclusao(LocalDate.of(1970, 1, 1));
        codTipoDefeito2.setDescricao("br.gov.df.pm.sgv.domain.TipoDefeitoVistoriaEntity");
        codTipoDefeito2.setId(2L);
        codTipoDefeito2.setNome("br.gov.df.pm.sgv.domain.TipoDefeitoVistoriaEntity");

        DefeitosVistoriaEntity defeitosVistoriaEntity2 = new DefeitosVistoriaEntity();
        defeitosVistoriaEntity2.setAtivo(false);
        defeitosVistoriaEntity2.setCodSubitem(codSubitem2);
        defeitosVistoriaEntity2.setCodTipoDefeito(codTipoDefeito2);
        defeitosVistoriaEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        defeitosVistoriaEntity2.setId(2L);

        ArrayList<DefeitosVistoriaEntity> defeitosVistoriaEntityList = new ArrayList<>();
        defeitosVistoriaEntityList.add(defeitosVistoriaEntity2);
        defeitosVistoriaEntityList.add(defeitosVistoriaEntity);
        when(defeitosVistoriaRepository.findAllByCodSubitemAndAtivo(Mockito.<SubitemVistoriaEntity>any(),
                Mockito.<Boolean>any())).thenReturn(defeitosVistoriaEntityList);

        ItemVistoriaEntity codItem = new ItemVistoriaEntity();
        codItem.setAtivo(true);
        codItem.setDataInclusao(LocalDate.of(1970, 1, 1));
        codItem.setDescricao("Descricao");
        codItem.setId(1L);
        codItem.setNome("Nome");

        TipoVistoriaEntity codTipo = new TipoVistoriaEntity();
        codTipo.setAtivo(true);
        codTipo.setDataInclusao(LocalDate.of(1970, 1, 1));
        codTipo.setDescricao("Descricao");
        codTipo.setId(1L);
        codTipo.setNome("Nome");
        codTipo.setStatusAnterior("Status Anterior");
        codTipo.setStatusPosterior("Status Posterior");
        ItemVistoriaEntity itemVistoriaEntity = mock(ItemVistoriaEntity.class);
        when(itemVistoriaEntity.getAtivo()).thenReturn(true);
        when(itemVistoriaEntity.getId()).thenReturn(1L);
        when(itemVistoriaEntity.getDescricao()).thenReturn("Descricao");
        when(itemVistoriaEntity.getNome()).thenReturn("Nome");
        when(itemVistoriaEntity.getDataInclusao()).thenReturn(LocalDate.of(1970, 1, 1));
        doNothing().when(itemVistoriaEntity).setAtivo(Mockito.<Boolean>any());
        doNothing().when(itemVistoriaEntity).setDataInclusao(Mockito.<LocalDate>any());
        doNothing().when(itemVistoriaEntity).setDescricao(Mockito.<String>any());
        doNothing().when(itemVistoriaEntity).setId(Mockito.<Long>any());
        doNothing().when(itemVistoriaEntity).setNome(Mockito.<String>any());
        itemVistoriaEntity.setAtivo(true);
        itemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity.setDescricao("Descricao");
        itemVistoriaEntity.setId(1L);
        itemVistoriaEntity.setNome("Nome");
        ItensVistoriaEntity itensVistoriaEntity = mock(ItensVistoriaEntity.class);
        when(itensVistoriaEntity.getCodItem()).thenReturn(itemVistoriaEntity);
        doNothing().when(itensVistoriaEntity).setAtivo(Mockito.<Boolean>any());
        doNothing().when(itensVistoriaEntity).setCodItem(Mockito.<ItemVistoriaEntity>any());
        doNothing().when(itensVistoriaEntity).setCodTipo(Mockito.<TipoVistoriaEntity>any());
        doNothing().when(itensVistoriaEntity).setDataInclusao(Mockito.<LocalDate>any());
        doNothing().when(itensVistoriaEntity).setId(Mockito.<Long>any());
        itensVistoriaEntity.setAtivo(true);
        itensVistoriaEntity.setCodItem(codItem);
        itensVistoriaEntity.setCodTipo(codTipo);
        itensVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itensVistoriaEntity.setId(1L);

        ArrayList<ItensVistoriaEntity> itensVistoriaEntityList = new ArrayList<>();
        itensVistoriaEntityList.add(itensVistoriaEntity);
        when(itensVistoriaRepository.findBycodTipoAndAtivo(Mockito.<TipoVistoriaEntity>any(), Mockito.<Boolean>any()))
                .thenReturn(itensVistoriaEntityList);

        ItemVistoriaEntity codItem2 = new ItemVistoriaEntity();
        codItem2.setAtivo(true);
        codItem2.setDataInclusao(LocalDate.of(1970, 1, 1));
        codItem2.setDescricao("Descricao");
        codItem2.setId(1L);
        codItem2.setNome("Nome");

        SubitemVistoriaEntity codSubitem3 = new SubitemVistoriaEntity();
        codSubitem3.setAtivo(true);
        codSubitem3.setDataInclusao(LocalDate.of(1970, 1, 1));
        codSubitem3.setDescricao("Descricao");
        codSubitem3.setId(1L);
        codSubitem3.setNome("Nome");

        SubitensVistoriaEntity subitensVistoriaEntity = new SubitensVistoriaEntity();
        subitensVistoriaEntity.setAtivo(true);
        subitensVistoriaEntity.setCodItem(codItem2);
        subitensVistoriaEntity.setCodSubitem(codSubitem3);
        subitensVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        subitensVistoriaEntity.setId(1L);

        ArrayList<SubitensVistoriaEntity> subitensVistoriaEntityList = new ArrayList<>();
        subitensVistoriaEntityList.add(subitensVistoriaEntity);
        when(subitensVistoriaRepository.findAllByCodItemAndAtivo(Mockito.<ItemVistoriaEntity>any(), Mockito.<Boolean>any()))
                .thenReturn(subitensVistoriaEntityList);

        TipoVistoriaEntity tipoVistoriaEntity = new TipoVistoriaEntity();
        tipoVistoriaEntity.setAtivo(true);
        tipoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoriaEntity.setDescricao("Descricao");
        tipoVistoriaEntity.setId(1L);
        tipoVistoriaEntity.setNome("Nome");
        tipoVistoriaEntity.setStatusAnterior("Status Anterior");
        tipoVistoriaEntity.setStatusPosterior("Status Posterior");
        when(tipoVistoriaService.findByIdTipoVistoria(Mockito.<Long>any())).thenReturn(tipoVistoriaEntity);

        // Act
        OcorrenciasDTO actualListAllAtivosByTipoVistoriaResult = itemVistoriaServiceImpl.listAllAtivosByTipoVistoria(1L);

        // Assert
        verify(itemVistoriaEntity).getAtivo();
        verify(itemVistoriaEntity).getDataInclusao();
        verify(itemVistoriaEntity).getDescricao();
        verify(itemVistoriaEntity).getId();
        verify(itemVistoriaEntity).getNome();
        verify(itemVistoriaEntity).setAtivo(eq(true));
        verify(itemVistoriaEntity).setDataInclusao(isA(LocalDate.class));
        verify(itemVistoriaEntity).setDescricao(eq("Descricao"));
        verify(itemVistoriaEntity).setId(eq(1L));
        verify(itemVistoriaEntity).setNome(eq("Nome"));
        verify(itensVistoriaEntity, atLeast(1)).getCodItem();
        verify(itensVistoriaEntity).setAtivo(eq(true));
        verify(itensVistoriaEntity).setCodItem(isA(ItemVistoriaEntity.class));
        verify(itensVistoriaEntity).setCodTipo(isA(TipoVistoriaEntity.class));
        verify(itensVistoriaEntity).setDataInclusao(isA(LocalDate.class));
        verify(itensVistoriaEntity).setId(eq(1L));
        verify(defeitosVistoriaRepository).findAllByCodSubitemAndAtivo(isA(SubitemVistoriaEntity.class), eq(true));
        verify(itensVistoriaRepository).findBycodTipoAndAtivo(isA(TipoVistoriaEntity.class), eq(true));
        verify(subitensVistoriaRepository).findAllByCodItemAndAtivo(isA(ItemVistoriaEntity.class), eq(true));
        verify(tipoVistoriaService).findByIdTipoVistoria(eq(1L));
        assertEquals(1, actualListAllAtivosByTipoVistoriaResult.getItemVistoriaOcorrenciaDTOS().size());
    }




}
