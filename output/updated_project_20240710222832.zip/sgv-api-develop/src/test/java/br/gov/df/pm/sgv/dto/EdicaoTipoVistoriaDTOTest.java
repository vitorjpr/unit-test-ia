package br.gov.df.pm.sgv.dto;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

public class EdicaoTipoVistoriaDTOTest {
    private EdicaoTipoVistoriaDTO edicaoTipoVistoria = new EdicaoTipoVistoriaDTO("", "", "", "", new ArrayList<>());

    @BeforeEach
    void setUp() {
        edicaoTipoVistoria.setNome("Vidro");
        edicaoTipoVistoria.setDescricao("Vidro do Carro");
        edicaoTipoVistoria.setStatusAnterior("EM USO");
        edicaoTipoVistoria.setStatusPosterior("DISPONÍVEL");
        edicaoTipoVistoria.setItens(new ArrayList<>());
    }

    @Test
    void testEquals() {
        var edicaoTipoVistoria1 = EdicaoTipoVistoriaDTO.builder()
                .nome("Vidro")
                .descricao("Vidro do Carro")
                .statusAnterior("EM USO")
                .statusPosterior("DISPONÍVEL")
                .itens(new ArrayList<>())
                .build();
        assertEquals(edicaoTipoVistoria, edicaoTipoVistoria1);

        var edicaoTipoVistoria2 = EdicaoTipoVistoriaDTO.builder().nome("Janela").build();
        assertNotEquals(edicaoTipoVistoria, edicaoTipoVistoria2);


    }

    @Test
    void testHashCode() {
        var edicaoTipoVistoria1 = EdicaoTipoVistoriaDTO.builder()
                .nome("Vidro")
                .descricao("Vidro do Carro")
                .statusAnterior("EM USO")
                .statusPosterior("DISPONÍVEL")
                .itens(new ArrayList<>())
                .build();
        assertEquals(edicaoTipoVistoria.hashCode(), edicaoTipoVistoria1.hashCode());

        var edicaoTipoVistoria2 = EdicaoTipoVistoriaDTO.builder().build();
        assertNotEquals(edicaoTipoVistoria.hashCode(), edicaoTipoVistoria2.hashCode());
    }

    @Test
    void testToString() {
        assertNotNull(edicaoTipoVistoria.toString());
    }
}
