package br.gov.df.pm.sgv.domain;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;

import java.time.LocalDate;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import br.gov.df.pm.sgv.domain.sgpol.UnidadePolicialMilitar;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

class ViaturaUpmEntityDiffblueTest {
    /**
     * Method under test: {@link ViaturaUpmEntity#canEqual(Object)}
     */
    @Test
    void testCanEqual() {
        // Arrange, Act and Assert
        assertFalse((new ViaturaUpmEntity()).canEqual("Other"));
    }

    /**
     * Method under test: {@link ViaturaUpmEntity#canEqual(Object)}
     */
    @Test
    void testCanEqual2() {
        // Arrange
        TipoEmpregoViaturaEntity tipoEmpregoViatura = new TipoEmpregoViaturaEntity();
        tipoEmpregoViatura.setAtivo(1);
        tipoEmpregoViatura.setId(1);
        tipoEmpregoViatura.setNome("Nome");

        ViaturaEntity viatura = new ViaturaEntity();
        viatura.setAtivo(true);
        viatura.setDataAtualizacao(LocalDate.of(1970, 1, 1));
        viatura.setDataInclusao(LocalDate.of(1970, 1, 1));
        viatura.setId(1L);
        viatura.setListaUpm(new ArrayList<>());
        viatura.setMarcaModelo("Marca Modelo");
        viatura.setNrSei("Nr Sei");
        viatura.setPlaca("Placa");
        viatura.setPrefixo("Prefixo");
        viatura.setRenavam("Renavam");
        viatura.setStatus("Status");
        viatura.setTipoEmpregoViatura(tipoEmpregoViatura);
        viatura.setTombamento("alice.liddell@example.org");

        ViaturaUpmEntity viaturaUpmEntity = new ViaturaUpmEntity();
        viaturaUpmEntity.setAtivo(1);
        viaturaUpmEntity.setCodCadastranteEntrada(1);
        viaturaUpmEntity.setCodCadastranteSaida(1);
        viaturaUpmEntity
                .setDtEntrada(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
        viaturaUpmEntity
                .setDtMovimentacao(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
        viaturaUpmEntity.setDtSaida(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
        viaturaUpmEntity.setId(1);
        viaturaUpmEntity.setMotivoTransferenciaCodigo(1);
        viaturaUpmEntity.setMovimentadorCodigo(1);
        viaturaUpmEntity.setNrSei("Nr Sei");
        viaturaUpmEntity.setObservacao("Observacao");
       // viaturaUpmEntity.setUpmCodigo(1);
        viaturaUpmEntity.setViatura(viatura);

        TipoEmpregoViaturaEntity tipoEmpregoViatura2 = new TipoEmpregoViaturaEntity();
        tipoEmpregoViatura2.setAtivo(1);
        tipoEmpregoViatura2.setId(1);
        tipoEmpregoViatura2.setNome("Nome");

        ViaturaEntity viatura2 = new ViaturaEntity();
        viatura2.setAtivo(true);
        viatura2.setDataAtualizacao(LocalDate.of(1970, 1, 1));
        viatura2.setDataInclusao(LocalDate.of(1970, 1, 1));
        viatura2.setId(1L);
        viatura2.setListaUpm(new ArrayList<>());
        viatura2.setMarcaModelo("Marca Modelo");
        viatura2.setNrSei("Nr Sei");
        viatura2.setPlaca("Placa");
        viatura2.setPrefixo("Prefixo");
        viatura2.setRenavam("Renavam");
        viatura2.setStatus("Status");
        viatura2.setTipoEmpregoViatura(tipoEmpregoViatura2);
        viatura2.setTombamento("alice.liddell@example.org");

        ViaturaUpmEntity viaturaUpmEntity2 = new ViaturaUpmEntity();
        viaturaUpmEntity2.setAtivo(1);
        viaturaUpmEntity2.setCodCadastranteEntrada(1);
        viaturaUpmEntity2.setCodCadastranteSaida(1);
        viaturaUpmEntity2
                .setDtEntrada(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
        viaturaUpmEntity2
                .setDtMovimentacao(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
        viaturaUpmEntity2.setDtSaida(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
        viaturaUpmEntity2.setId(1);
        viaturaUpmEntity2.setMotivoTransferenciaCodigo(1);
        viaturaUpmEntity2.setMovimentadorCodigo(1);
        viaturaUpmEntity2.setNrSei("Nr Sei");
        viaturaUpmEntity2.setObservacao("Observacao");
        //viaturaUpmEntity2.setUpmCodigo(1);
        viaturaUpmEntity2.setViatura(viatura2);

        // Act and Assert
        assertTrue(viaturaUpmEntity.canEqual(viaturaUpmEntity2));
    }

    /**
     * Method under test: {@link ViaturaUpmEntity#equals(Object)}
     */
    @Test
    void testEquals() {
        // Arrange
        TipoEmpregoViaturaEntity tipoEmpregoViatura = new TipoEmpregoViaturaEntity();
        tipoEmpregoViatura.setAtivo(1);
        tipoEmpregoViatura.setId(1);
        tipoEmpregoViatura.setNome("Nome");

        ViaturaEntity viatura = new ViaturaEntity();
        viatura.setAtivo(true);
        viatura.setDataAtualizacao(LocalDate.of(1970, 1, 1));
        viatura.setDataInclusao(LocalDate.of(1970, 1, 1));
        viatura.setId(1L);
        viatura.setListaUpm(new ArrayList<>());
        viatura.setMarcaModelo("Marca Modelo");
        viatura.setNrSei("Nr Sei");
        viatura.setPlaca("Placa");
        viatura.setPrefixo("Prefixo");
        viatura.setRenavam("Renavam");
        viatura.setStatus("Status");
        viatura.setTipoEmpregoViatura(tipoEmpregoViatura);
        viatura.setTombamento("alice.liddell@example.org");

        ViaturaUpmEntity viaturaUpmEntity = new ViaturaUpmEntity();
        viaturaUpmEntity.setAtivo(1);
        viaturaUpmEntity.setCodCadastranteEntrada(1);
        viaturaUpmEntity.setCodCadastranteSaida(1);
        viaturaUpmEntity
                .setDtEntrada(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
        viaturaUpmEntity
                .setDtMovimentacao(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
        viaturaUpmEntity.setDtSaida(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
        viaturaUpmEntity.setId(1);
        viaturaUpmEntity.setMotivoTransferenciaCodigo(1);
        viaturaUpmEntity.setMovimentadorCodigo(1);
        viaturaUpmEntity.setNrSei("Nr Sei");
        viaturaUpmEntity.setObservacao("Observacao");
//        viaturaUpmEntity.setUpmCodigo(1);
        viaturaUpmEntity.setViatura(viatura);

        // Act and Assert
        assertNotEquals(viaturaUpmEntity, null);
    }

    /**
     * Method under test: {@link ViaturaUpmEntity#equals(Object)}
     */
    @Test
    void testEquals2() {
        // Arrange
        TipoEmpregoViaturaEntity tipoEmpregoViatura = new TipoEmpregoViaturaEntity();
        tipoEmpregoViatura.setAtivo(1);
        tipoEmpregoViatura.setId(1);
        tipoEmpregoViatura.setNome("Nome");

        ViaturaEntity viatura = new ViaturaEntity();
        viatura.setAtivo(true);
        viatura.setDataAtualizacao(LocalDate.of(1970, 1, 1));
        viatura.setDataInclusao(LocalDate.of(1970, 1, 1));
        viatura.setId(1L);
        viatura.setListaUpm(new ArrayList<>());
        viatura.setMarcaModelo("Marca Modelo");
        viatura.setNrSei("Nr Sei");
        viatura.setPlaca("Placa");
        viatura.setPrefixo("Prefixo");
        viatura.setRenavam("Renavam");
        viatura.setStatus("Status");
        viatura.setTipoEmpregoViatura(tipoEmpregoViatura);
        viatura.setTombamento("alice.liddell@example.org");

        ViaturaUpmEntity viaturaUpmEntity = new ViaturaUpmEntity();
        viaturaUpmEntity.setAtivo(1);
        viaturaUpmEntity.setCodCadastranteEntrada(1);
        viaturaUpmEntity.setCodCadastranteSaida(1);
        viaturaUpmEntity
                .setDtEntrada(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
        viaturaUpmEntity
                .setDtMovimentacao(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
        viaturaUpmEntity.setDtSaida(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
        viaturaUpmEntity.setId(1);
        viaturaUpmEntity.setMotivoTransferenciaCodigo(1);
        viaturaUpmEntity.setMovimentadorCodigo(1);
        viaturaUpmEntity.setNrSei("Nr Sei");
        viaturaUpmEntity.setObservacao("Observacao");
        //viaturaUpmEntity.setUpmCodigo(1);
        viaturaUpmEntity.setViatura(viatura);

        // Act and Assert
        assertNotEquals(viaturaUpmEntity, "Different type to ViaturaUpmEntity");
    }

    /**
     * Method under test: {@link ViaturaUpmEntity#equals(Object)}
     */
    @Test
    void testEquals3() {
        // Arrange
        TipoEmpregoViaturaEntity tipoEmpregoViatura = new TipoEmpregoViaturaEntity();
        tipoEmpregoViatura.setAtivo(1);
        tipoEmpregoViatura.setId(1);
        tipoEmpregoViatura.setNome("Nome");

        ViaturaEntity viatura = new ViaturaEntity();
        viatura.setAtivo(true);
        viatura.setDataAtualizacao(LocalDate.of(1970, 1, 1));
        viatura.setDataInclusao(LocalDate.of(1970, 1, 1));
        viatura.setId(1L);
        viatura.setListaUpm(new ArrayList<>());
        viatura.setMarcaModelo("Marca Modelo");
        viatura.setNrSei("Nr Sei");
        viatura.setPlaca("Placa");
        viatura.setPrefixo("Prefixo");
        viatura.setRenavam("Renavam");
        viatura.setStatus("Status");
        viatura.setTipoEmpregoViatura(tipoEmpregoViatura);
        viatura.setTombamento("alice.liddell@example.org");

        ViaturaUpmEntity viaturaUpmEntity = new ViaturaUpmEntity();
        viaturaUpmEntity.setAtivo(1);
        viaturaUpmEntity.setCodCadastranteEntrada(1);
        viaturaUpmEntity.setCodCadastranteSaida(1);
        viaturaUpmEntity
                .setDtEntrada(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
        viaturaUpmEntity
                .setDtMovimentacao(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
        viaturaUpmEntity.setDtSaida(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
        viaturaUpmEntity.setId(2);
        viaturaUpmEntity.setMotivoTransferenciaCodigo(1);
        viaturaUpmEntity.setMovimentadorCodigo(1);
        viaturaUpmEntity.setNrSei("Nr Sei");
        viaturaUpmEntity.setObservacao("Observacao");
       // viaturaUpmEntity.setUpmCodigo(1);
        viaturaUpmEntity.setViatura(viatura);

        TipoEmpregoViaturaEntity tipoEmpregoViatura2 = new TipoEmpregoViaturaEntity();
        tipoEmpregoViatura2.setAtivo(1);
        tipoEmpregoViatura2.setId(1);
        tipoEmpregoViatura2.setNome("Nome");

        ViaturaEntity viatura2 = new ViaturaEntity();
        viatura2.setAtivo(true);
        viatura2.setDataAtualizacao(LocalDate.of(1970, 1, 1));
        viatura2.setDataInclusao(LocalDate.of(1970, 1, 1));
        viatura2.setId(1L);
        viatura2.setListaUpm(new ArrayList<>());
        viatura2.setMarcaModelo("Marca Modelo");
        viatura2.setNrSei("Nr Sei");
        viatura2.setPlaca("Placa");
        viatura2.setPrefixo("Prefixo");
        viatura2.setRenavam("Renavam");
        viatura2.setStatus("Status");
        viatura2.setTipoEmpregoViatura(tipoEmpregoViatura2);
        viatura2.setTombamento("alice.liddell@example.org");

        ViaturaUpmEntity viaturaUpmEntity2 = new ViaturaUpmEntity();
        viaturaUpmEntity2.setAtivo(1);
        viaturaUpmEntity2.setCodCadastranteEntrada(1);
        viaturaUpmEntity2.setCodCadastranteSaida(1);
        viaturaUpmEntity2
                .setDtEntrada(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
        viaturaUpmEntity2
                .setDtMovimentacao(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
        viaturaUpmEntity2.setDtSaida(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
        viaturaUpmEntity2.setId(1);
        viaturaUpmEntity2.setMotivoTransferenciaCodigo(1);
        viaturaUpmEntity2.setMovimentadorCodigo(1);
        viaturaUpmEntity2.setNrSei("Nr Sei");
        viaturaUpmEntity2.setObservacao("Observacao");
       // viaturaUpmEntity2.setUpmCodigo(1);
        viaturaUpmEntity2.setViatura(viatura2);

        // Act and Assert
        assertNotEquals(viaturaUpmEntity, viaturaUpmEntity2);
    }

    /**
     * Method under test: {@link ViaturaUpmEntity#equals(Object)}
     */
    @Test
    void testEquals4() {
        // Arrange
        TipoEmpregoViaturaEntity tipoEmpregoViatura = new TipoEmpregoViaturaEntity();
        tipoEmpregoViatura.setAtivo(1);
        tipoEmpregoViatura.setId(1);
        tipoEmpregoViatura.setNome("Nome");

        ViaturaEntity viatura = new ViaturaEntity();
        viatura.setAtivo(true);
        viatura.setDataAtualizacao(LocalDate.of(1970, 1, 1));
        viatura.setDataInclusao(LocalDate.of(1970, 1, 1));
        viatura.setId(1L);
        viatura.setListaUpm(new ArrayList<>());
        viatura.setMarcaModelo("Marca Modelo");
        viatura.setNrSei("Nr Sei");
        viatura.setPlaca("Placa");
        viatura.setPrefixo("Prefixo");
        viatura.setRenavam("Renavam");
        viatura.setStatus("Status");
        viatura.setTipoEmpregoViatura(tipoEmpregoViatura);
        viatura.setTombamento("alice.liddell@example.org");

        ViaturaUpmEntity viaturaUpmEntity = new ViaturaUpmEntity();
        viaturaUpmEntity.setAtivo(1);
        viaturaUpmEntity.setCodCadastranteEntrada(1);
        viaturaUpmEntity.setCodCadastranteSaida(1);
        viaturaUpmEntity
                .setDtEntrada(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
        viaturaUpmEntity
                .setDtMovimentacao(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
        viaturaUpmEntity.setDtSaida(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
        viaturaUpmEntity.setId(null);
        viaturaUpmEntity.setMotivoTransferenciaCodigo(1);
        viaturaUpmEntity.setMovimentadorCodigo(1);
        viaturaUpmEntity.setNrSei("Nr Sei");
        viaturaUpmEntity.setObservacao("Observacao");
        //viaturaUpmEntity.setUpmCodigo(1);
        viaturaUpmEntity.setViatura(viatura);

        TipoEmpregoViaturaEntity tipoEmpregoViatura2 = new TipoEmpregoViaturaEntity();
        tipoEmpregoViatura2.setAtivo(1);
        tipoEmpregoViatura2.setId(1);
        tipoEmpregoViatura2.setNome("Nome");

        ViaturaEntity viatura2 = new ViaturaEntity();
        viatura2.setAtivo(true);
        viatura2.setDataAtualizacao(LocalDate.of(1970, 1, 1));
        viatura2.setDataInclusao(LocalDate.of(1970, 1, 1));
        viatura2.setId(1L);
        viatura2.setListaUpm(new ArrayList<>());
        viatura2.setMarcaModelo("Marca Modelo");
        viatura2.setNrSei("Nr Sei");
        viatura2.setPlaca("Placa");
        viatura2.setPrefixo("Prefixo");
        viatura2.setRenavam("Renavam");
        viatura2.setStatus("Status");
        viatura2.setTipoEmpregoViatura(tipoEmpregoViatura2);
        viatura2.setTombamento("alice.liddell@example.org");

        ViaturaUpmEntity viaturaUpmEntity2 = new ViaturaUpmEntity();
        viaturaUpmEntity2.setAtivo(1);
        viaturaUpmEntity2.setCodCadastranteEntrada(1);
        viaturaUpmEntity2.setCodCadastranteSaida(1);
        viaturaUpmEntity2
                .setDtEntrada(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
        viaturaUpmEntity2
                .setDtMovimentacao(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
        viaturaUpmEntity2.setDtSaida(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
        viaturaUpmEntity2.setId(1);
        viaturaUpmEntity2.setMotivoTransferenciaCodigo(1);
        viaturaUpmEntity2.setMovimentadorCodigo(1);
        viaturaUpmEntity2.setNrSei("Nr Sei");
        viaturaUpmEntity2.setObservacao("Observacao");
       // viaturaUpmEntity2.setUpmCodigo(1);
        viaturaUpmEntity2.setViatura(viatura2);

        // Act and Assert
        assertNotEquals(viaturaUpmEntity, viaturaUpmEntity2);
    }

    /**
     * Methods under test:
     * <ul>
     *   <li>{@link ViaturaUpmEntity#equals(Object)}
     *   <li>{@link ViaturaUpmEntity#hashCode()}
     * </ul>
     */
    @Test
    void testEqualsAndHashCode() {
        // Arrange
        TipoEmpregoViaturaEntity tipoEmpregoViatura = new TipoEmpregoViaturaEntity();
        tipoEmpregoViatura.setAtivo(1);
        tipoEmpregoViatura.setId(1);
        tipoEmpregoViatura.setNome("Nome");

        ViaturaEntity viatura = new ViaturaEntity();
        viatura.setAtivo(true);
        viatura.setDataAtualizacao(LocalDate.of(1970, 1, 1));
        viatura.setDataInclusao(LocalDate.of(1970, 1, 1));
        viatura.setId(1L);
        viatura.setListaUpm(new ArrayList<>());
        viatura.setMarcaModelo("Marca Modelo");
        viatura.setNrSei("Nr Sei");
        viatura.setPlaca("Placa");
        viatura.setPrefixo("Prefixo");
        viatura.setRenavam("Renavam");
        viatura.setStatus("Status");
        viatura.setTipoEmpregoViatura(tipoEmpregoViatura);
        viatura.setTombamento("alice.liddell@example.org");

        ViaturaUpmEntity viaturaUpmEntity = new ViaturaUpmEntity();
        viaturaUpmEntity.setAtivo(1);
        viaturaUpmEntity.setCodCadastranteEntrada(1);
        viaturaUpmEntity.setCodCadastranteSaida(1);
        viaturaUpmEntity
                .setDtEntrada(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
        viaturaUpmEntity
                .setDtMovimentacao(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
        viaturaUpmEntity.setDtSaida(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
        viaturaUpmEntity.setId(1);
        viaturaUpmEntity.setMotivoTransferenciaCodigo(1);
        viaturaUpmEntity.setMovimentadorCodigo(1);
        viaturaUpmEntity.setNrSei("Nr Sei");
        viaturaUpmEntity.setObservacao("Observacao");
       // viaturaUpmEntity.setUpmCodigo(1);
        viaturaUpmEntity.setViatura(viatura);

        // Act and Assert
        assertEquals(viaturaUpmEntity, viaturaUpmEntity);
        int expectedHashCodeResult = viaturaUpmEntity.hashCode();
        assertEquals(expectedHashCodeResult, viaturaUpmEntity.hashCode());
    }

    /**
     * Methods under test:
     * <ul>
     *   <li>{@link ViaturaUpmEntity#equals(Object)}
     *   <li>{@link ViaturaUpmEntity#hashCode()}
     * </ul>
     */
    @Test
    void testEqualsAndHashCode2() {
        // Arrange
        TipoEmpregoViaturaEntity tipoEmpregoViatura = new TipoEmpregoViaturaEntity();
        tipoEmpregoViatura.setAtivo(1);
        tipoEmpregoViatura.setId(1);
        tipoEmpregoViatura.setNome("Nome");

        ViaturaEntity viatura = new ViaturaEntity();
        viatura.setAtivo(true);
        viatura.setDataAtualizacao(LocalDate.of(1970, 1, 1));
        viatura.setDataInclusao(LocalDate.of(1970, 1, 1));
        viatura.setId(1L);
        viatura.setListaUpm(new ArrayList<>());
        viatura.setMarcaModelo("Marca Modelo");
        viatura.setNrSei("Nr Sei");
        viatura.setPlaca("Placa");
        viatura.setPrefixo("Prefixo");
        viatura.setRenavam("Renavam");
        viatura.setStatus("Status");
        viatura.setTipoEmpregoViatura(tipoEmpregoViatura);
        viatura.setTombamento("alice.liddell@example.org");

        ViaturaUpmEntity viaturaUpmEntity = new ViaturaUpmEntity();
        viaturaUpmEntity.setAtivo(1);
        viaturaUpmEntity.setCodCadastranteEntrada(1);
        viaturaUpmEntity.setCodCadastranteSaida(1);
        viaturaUpmEntity
                .setDtEntrada(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
        viaturaUpmEntity
                .setDtMovimentacao(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
        viaturaUpmEntity.setDtSaida(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
        viaturaUpmEntity.setId(1);
        viaturaUpmEntity.setMotivoTransferenciaCodigo(1);
        viaturaUpmEntity.setMovimentadorCodigo(1);
        viaturaUpmEntity.setNrSei("Nr Sei");
        viaturaUpmEntity.setObservacao("Observacao");
       // viaturaUpmEntity.setUpmCodigo(1);
        viaturaUpmEntity.setViatura(viatura);

        TipoEmpregoViaturaEntity tipoEmpregoViatura2 = new TipoEmpregoViaturaEntity();
        tipoEmpregoViatura2.setAtivo(1);
        tipoEmpregoViatura2.setId(1);
        tipoEmpregoViatura2.setNome("Nome");

        ViaturaEntity viatura2 = new ViaturaEntity();
        viatura2.setAtivo(true);
        viatura2.setDataAtualizacao(LocalDate.of(1970, 1, 1));
        viatura2.setDataInclusao(LocalDate.of(1970, 1, 1));
        viatura2.setId(1L);
        viatura2.setListaUpm(new ArrayList<>());
        viatura2.setMarcaModelo("Marca Modelo");
        viatura2.setNrSei("Nr Sei");
        viatura2.setPlaca("Placa");
        viatura2.setPrefixo("Prefixo");
        viatura2.setRenavam("Renavam");
        viatura2.setStatus("Status");
        viatura2.setTipoEmpregoViatura(tipoEmpregoViatura2);
        viatura2.setTombamento("alice.liddell@example.org");

        ViaturaUpmEntity viaturaUpmEntity2 = new ViaturaUpmEntity();
        viaturaUpmEntity2.setAtivo(1);
        viaturaUpmEntity2.setCodCadastranteEntrada(1);
        viaturaUpmEntity2.setCodCadastranteSaida(1);
        viaturaUpmEntity2
                .setDtEntrada(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
        viaturaUpmEntity2
                .setDtMovimentacao(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
        viaturaUpmEntity2.setDtSaida(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
        viaturaUpmEntity2.setId(1);
        viaturaUpmEntity2.setMotivoTransferenciaCodigo(1);
        viaturaUpmEntity2.setMovimentadorCodigo(1);
        viaturaUpmEntity2.setNrSei("Nr Sei");
        viaturaUpmEntity2.setObservacao("Observacao");
       // viaturaUpmEntity2.setUpmCodigo(1);
        viaturaUpmEntity2.setViatura(viatura2);

        // Act and Assert
        assertEquals(viaturaUpmEntity, viaturaUpmEntity2);
        int expectedHashCodeResult = viaturaUpmEntity.hashCode();
        assertEquals(expectedHashCodeResult, viaturaUpmEntity2.hashCode());
    }

    /**
     * Methods under test:
     * <ul>
     *   <li>{@link ViaturaUpmEntity#equals(Object)}
     *   <li>{@link ViaturaUpmEntity#hashCode()}
     * </ul>
     */
    @Test
    void testEqualsAndHashCode3() {
        // Arrange
        TipoEmpregoViaturaEntity tipoEmpregoViatura = new TipoEmpregoViaturaEntity();
        tipoEmpregoViatura.setAtivo(1);
        tipoEmpregoViatura.setId(1);
        tipoEmpregoViatura.setNome("Nome");
        ViaturaEntity viatura = mock(ViaturaEntity.class);
        doNothing().when(viatura).setAtivo(Mockito.<Boolean>any());
        doNothing().when(viatura).setDataAtualizacao(Mockito.<LocalDate>any());
        doNothing().when(viatura).setDataInclusao(Mockito.<LocalDate>any());
        doNothing().when(viatura).setId(Mockito.<Long>any());
        doNothing().when(viatura).setListaUpm(Mockito.<List<ViaturaUpmEntity>>any());
        doNothing().when(viatura).setMarcaModelo(Mockito.<String>any());
        doNothing().when(viatura).setNrSei(Mockito.<String>any());
        doNothing().when(viatura).setPlaca(Mockito.<String>any());
        doNothing().when(viatura).setPrefixo(Mockito.<String>any());
        doNothing().when(viatura).setRenavam(Mockito.<String>any());
        doNothing().when(viatura).setStatus(Mockito.<String>any());
        doNothing().when(viatura).setTipoEmpregoViatura(Mockito.<TipoEmpregoViaturaEntity>any());
        doNothing().when(viatura).setTombamento(Mockito.<String>any());
        viatura.setAtivo(true);
        viatura.setDataAtualizacao(LocalDate.of(1970, 1, 1));
        viatura.setDataInclusao(LocalDate.of(1970, 1, 1));
        viatura.setId(1L);
        viatura.setListaUpm(new ArrayList<>());
        viatura.setMarcaModelo("Marca Modelo");
        viatura.setNrSei("Nr Sei");
        viatura.setPlaca("Placa");
        viatura.setPrefixo("Prefixo");
        viatura.setRenavam("Renavam");
        viatura.setStatus("Status");
        viatura.setTipoEmpregoViatura(tipoEmpregoViatura);
        viatura.setTombamento("alice.liddell@example.org");

        ViaturaUpmEntity viaturaUpmEntity = new ViaturaUpmEntity();
        viaturaUpmEntity.setAtivo(1);
        viaturaUpmEntity.setCodCadastranteEntrada(1);
        viaturaUpmEntity.setCodCadastranteSaida(1);
        viaturaUpmEntity
                .setDtEntrada(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
        viaturaUpmEntity
                .setDtMovimentacao(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
        viaturaUpmEntity.setDtSaida(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
        viaturaUpmEntity.setId(1);
        viaturaUpmEntity.setMotivoTransferenciaCodigo(1);
        viaturaUpmEntity.setMovimentadorCodigo(1);
        viaturaUpmEntity.setNrSei("Nr Sei");
        viaturaUpmEntity.setObservacao("Observacao");
       // viaturaUpmEntity.setUpmCodigo(1);
        viaturaUpmEntity.setViatura(viatura);

        TipoEmpregoViaturaEntity tipoEmpregoViatura2 = new TipoEmpregoViaturaEntity();
        tipoEmpregoViatura2.setAtivo(1);
        tipoEmpregoViatura2.setId(1);
        tipoEmpregoViatura2.setNome("Nome");

        ViaturaEntity viatura2 = new ViaturaEntity();
        viatura2.setAtivo(true);
        viatura2.setDataAtualizacao(LocalDate.of(1970, 1, 1));
        viatura2.setDataInclusao(LocalDate.of(1970, 1, 1));
        viatura2.setId(1L);
        viatura2.setListaUpm(new ArrayList<>());
        viatura2.setMarcaModelo("Marca Modelo");
        viatura2.setNrSei("Nr Sei");
        viatura2.setPlaca("Placa");
        viatura2.setPrefixo("Prefixo");
        viatura2.setRenavam("Renavam");
        viatura2.setStatus("Status");
        viatura2.setTipoEmpregoViatura(tipoEmpregoViatura2);
        viatura2.setTombamento("alice.liddell@example.org");

        ViaturaUpmEntity viaturaUpmEntity2 = new ViaturaUpmEntity();
        viaturaUpmEntity2.setAtivo(1);
        viaturaUpmEntity2.setCodCadastranteEntrada(1);
        viaturaUpmEntity2.setCodCadastranteSaida(1);
        viaturaUpmEntity2
                .setDtEntrada(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
        viaturaUpmEntity2
                .setDtMovimentacao(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
        viaturaUpmEntity2.setDtSaida(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
        viaturaUpmEntity2.setId(1);
        viaturaUpmEntity2.setMotivoTransferenciaCodigo(1);
        viaturaUpmEntity2.setMovimentadorCodigo(1);
        viaturaUpmEntity2.setNrSei("Nr Sei");
        viaturaUpmEntity2.setObservacao("Observacao");
        //viaturaUpmEntity2.setUpmCodigo(1);
        viaturaUpmEntity2.setViatura(viatura2);

        // Act and Assert
        assertEquals(viaturaUpmEntity, viaturaUpmEntity2);
        int expectedHashCodeResult = viaturaUpmEntity.hashCode();
        assertEquals(expectedHashCodeResult, viaturaUpmEntity2.hashCode());
    }

    /**
     * Methods under test:
     * <ul>
     *   <li>{@link ViaturaUpmEntity#ViaturaUpmEntity()}
     *   <li>{@link ViaturaUpmEntity#setAtivo(int)}
     *   <li>{@link ViaturaUpmEntity#setCodCadastranteEntrada(int)}
     *   <li>{@link ViaturaUpmEntity#setCodCadastranteSaida(int)}
     *   <li>{@link ViaturaUpmEntity#setDtEntrada(Date)}
     *   <li>{@link ViaturaUpmEntity#setDtMovimentacao(Date)}
     *   <li>{@link ViaturaUpmEntity#setDtSaida(Date)}
     *   <li>{@link ViaturaUpmEntity#setId(Integer)}
     *   <li>{@link ViaturaUpmEntity#setMotivoTransferenciaCodigo(int)}
     *   <li>{@link ViaturaUpmEntity#setMovimentadorCodigo(int)}
     *   <li>{@link ViaturaUpmEntity#setNrSei(String)}
     *   <li>{@link ViaturaUpmEntity#setObservacao(String)}
     *   <li>{@link ViaturaUpmEntity#setViatura(ViaturaEntity)}
     *   <li>{@link ViaturaUpmEntity#getAtivo()}
     *   <li>{@link ViaturaUpmEntity#getCodCadastranteEntrada()}
     *   <li>{@link ViaturaUpmEntity#getCodCadastranteSaida()}
     *   <li>{@link ViaturaUpmEntity#getDtEntrada()}
     *   <li>{@link ViaturaUpmEntity#getDtMovimentacao()}
     *   <li>{@link ViaturaUpmEntity#getDtSaida()}
     *   <li>{@link ViaturaUpmEntity#getId()}
     *   <li>{@link ViaturaUpmEntity#getMotivoTransferenciaCodigo()}
     *   <li>{@link ViaturaUpmEntity#getMovimentadorCodigo()}
     *   <li>{@link ViaturaUpmEntity#getNrSei()}
     *   <li>{@link ViaturaUpmEntity#getObservacao()}
     *   <li>{@link ViaturaUpmEntity#getUpmCodigo()}
     *   <li>{@link ViaturaUpmEntity#getViatura()}
     * </ul>
     */
    @Test
    void testGettersAndSetters() {
        // Arrange and Act
        ViaturaUpmEntity actualViaturaUpmEntity = new ViaturaUpmEntity();
        actualViaturaUpmEntity.setAtivo(1);
        actualViaturaUpmEntity.setCodCadastranteEntrada(1);
        actualViaturaUpmEntity.setCodCadastranteSaida(1);
        Date dtEntrada = Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant());
        actualViaturaUpmEntity.setDtEntrada(dtEntrada);
        Date dtMovimentacao = Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant());
        actualViaturaUpmEntity.setDtMovimentacao(dtMovimentacao);
        Date dtSaida = Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant());
        actualViaturaUpmEntity.setDtSaida(dtSaida);
        actualViaturaUpmEntity.setId(1);
        actualViaturaUpmEntity.setMotivoTransferenciaCodigo(1);
        actualViaturaUpmEntity.setMovimentadorCodigo(1);
        actualViaturaUpmEntity.setNrSei("Nr Sei");
        actualViaturaUpmEntity.setObservacao("Observacao");
        //actualViaturaUpmEntity.setUpmCodigo(1);
        TipoEmpregoViaturaEntity tipoEmpregoViatura = new TipoEmpregoViaturaEntity();
        tipoEmpregoViatura.setAtivo(1);
        tipoEmpregoViatura.setId(1);
        tipoEmpregoViatura.setNome("Nome");
        ViaturaEntity viatura = new ViaturaEntity();
        viatura.setAtivo(true);
        viatura.setDataAtualizacao(LocalDate.of(1970, 1, 1));
        viatura.setDataInclusao(LocalDate.of(1970, 1, 1));
        viatura.setId(1L);
        viatura.setListaUpm(new ArrayList<>());
        viatura.setMarcaModelo("Marca Modelo");
        viatura.setNrSei("Nr Sei");
        viatura.setPlaca("Placa");
        viatura.setPrefixo("Prefixo");
        viatura.setRenavam("Renavam");
        viatura.setStatus("Status");
        viatura.setTipoEmpregoViatura(tipoEmpregoViatura);
        viatura.setTombamento("alice.liddell@example.org");
        actualViaturaUpmEntity.setViatura(viatura);
        int actualAtivo = actualViaturaUpmEntity.getAtivo();
        int actualCodCadastranteEntrada = actualViaturaUpmEntity.getCodCadastranteEntrada();
        int actualCodCadastranteSaida = actualViaturaUpmEntity.getCodCadastranteSaida();
        Date actualDtEntrada = actualViaturaUpmEntity.getDtEntrada();
        Date actualDtMovimentacao = actualViaturaUpmEntity.getDtMovimentacao();
        Date actualDtSaida = actualViaturaUpmEntity.getDtSaida();
        Integer actualId = actualViaturaUpmEntity.getId();
        int actualMotivoTransferenciaCodigo = actualViaturaUpmEntity.getMotivoTransferenciaCodigo();
        int actualMovimentadorCodigo = actualViaturaUpmEntity.getMovimentadorCodigo();
        String actualNrSei = actualViaturaUpmEntity.getNrSei();
        String actualObservacao = actualViaturaUpmEntity.getObservacao();
       // int actualUpmCodigo = actualViaturaUpmEntity.getUpmCodigo();
        ViaturaEntity actualViatura = actualViaturaUpmEntity.getViatura();

        // Assert that nothing has changed
        assertEquals("Nr Sei", actualNrSei);
        assertEquals("Observacao", actualObservacao);
        assertEquals(1, actualAtivo);
        assertEquals(1, actualCodCadastranteEntrada);
        assertEquals(1, actualCodCadastranteSaida);
        assertEquals(1, actualMotivoTransferenciaCodigo);
        assertEquals(1, actualMovimentadorCodigo);
      //  assertEquals(1, actualUpmCodigo);
        assertEquals(1, actualId.intValue());
        assertSame(viatura, actualViatura);
        assertSame(dtEntrada, actualDtEntrada);
        assertSame(dtMovimentacao, actualDtMovimentacao);
        assertSame(dtSaida, actualDtSaida);
    }

    /**
     * Methods under test:
     * <ul>
     *   <li>
     *   <li>{@link ViaturaUpmEntity#setAtivo(int)}
     *   <li>{@link ViaturaUpmEntity#setCodCadastranteEntrada(int)}
     *   <li>{@link ViaturaUpmEntity#setCodCadastranteSaida(int)}
     *   <li>{@link ViaturaUpmEntity#setDtEntrada(Date)}
     *   <li>{@link ViaturaUpmEntity#setDtMovimentacao(Date)}
     *   <li>{@link ViaturaUpmEntity#setDtSaida(Date)}
     *   <li>{@link ViaturaUpmEntity#setId(Integer)}
     *   <li>{@link ViaturaUpmEntity#setMotivoTransferenciaCodigo(int)}
     *   <li>{@link ViaturaUpmEntity#setMovimentadorCodigo(int)}
     *   <li>{@link ViaturaUpmEntity#setNrSei(String)}
     *   <li>{@link ViaturaUpmEntity#setObservacao(String)}
     *   <li>{@link ViaturaUpmEntity#setViatura(ViaturaEntity)}
     *   <li>{@link ViaturaUpmEntity#getAtivo()}
     *   <li>{@link ViaturaUpmEntity#getCodCadastranteEntrada()}
     *   <li>{@link ViaturaUpmEntity#getCodCadastranteSaida()}
     *   <li>{@link ViaturaUpmEntity#getDtEntrada()}
     *   <li>{@link ViaturaUpmEntity#getDtMovimentacao()}
     *   <li>{@link ViaturaUpmEntity#getDtSaida()}
     *   <li>{@link ViaturaUpmEntity#getId()}
     *   <li>{@link ViaturaUpmEntity#getMotivoTransferenciaCodigo()}
     *   <li>{@link ViaturaUpmEntity#getMovimentadorCodigo()}
     *   <li>{@link ViaturaUpmEntity#getNrSei()}
     *   <li>{@link ViaturaUpmEntity#getObservacao()}
     *   <li>{@link ViaturaUpmEntity#getUpmCodigo()}
     *   <li>{@link ViaturaUpmEntity#getViatura()}
     * </ul>
     */
    @Test
    void testGettersAndSetters2() {
        // Arrange
        TipoEmpregoViaturaEntity tipoEmpregoViatura = new TipoEmpregoViaturaEntity();
        tipoEmpregoViatura.setAtivo(1);
        tipoEmpregoViatura.setId(1);
        tipoEmpregoViatura.setNome("Nome");

        ViaturaEntity viatura = new ViaturaEntity();
        viatura.setAtivo(true);
        viatura.setDataAtualizacao(LocalDate.of(1970, 1, 1));
        viatura.setDataInclusao(LocalDate.of(1970, 1, 1));
        viatura.setId(1L);
        viatura.setListaUpm(new ArrayList<>());
        viatura.setMarcaModelo("Marca Modelo");
        viatura.setNrSei("Nr Sei");
        viatura.setPlaca("Placa");
        viatura.setPrefixo("Prefixo");
        viatura.setRenavam("Renavam");
        viatura.setStatus("Status");
        viatura.setTipoEmpregoViatura(tipoEmpregoViatura);
        viatura.setTombamento("alice.liddell@example.org");
        Date dtEntrada = Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant());
        Date dtSaida = Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant());

        // Act
        ViaturaUpmEntity actualViaturaUpmEntity = new ViaturaUpmEntity(1, viatura,new UnidadePolicialMilitar(), dtEntrada, dtSaida, "Nr Sei", 1, 1, 1,
                1, Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()), "Observacao", 1);
        actualViaturaUpmEntity.setAtivo(1);
        actualViaturaUpmEntity.setCodCadastranteEntrada(1);
        actualViaturaUpmEntity.setCodCadastranteSaida(1);
        Date dtEntrada2 = Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant());
        actualViaturaUpmEntity.setDtEntrada(dtEntrada2);
        Date dtMovimentacao = Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant());
        actualViaturaUpmEntity.setDtMovimentacao(dtMovimentacao);
        Date dtSaida2 = Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant());
        actualViaturaUpmEntity.setDtSaida(dtSaida2);
        actualViaturaUpmEntity.setId(1);
        actualViaturaUpmEntity.setMotivoTransferenciaCodigo(1);
        actualViaturaUpmEntity.setMovimentadorCodigo(1);
        actualViaturaUpmEntity.setNrSei("Nr Sei");
        actualViaturaUpmEntity.setObservacao("Observacao");
       // actualViaturaUpmEntity.setUpmCodigo(1);
        TipoEmpregoViaturaEntity tipoEmpregoViatura2 = new TipoEmpregoViaturaEntity();
        tipoEmpregoViatura2.setAtivo(1);
        tipoEmpregoViatura2.setId(1);
        tipoEmpregoViatura2.setNome("Nome");
        ViaturaEntity viatura2 = new ViaturaEntity();
        viatura2.setAtivo(true);
        viatura2.setDataAtualizacao(LocalDate.of(1970, 1, 1));
        viatura2.setDataInclusao(LocalDate.of(1970, 1, 1));
        viatura2.setId(1L);
        viatura2.setListaUpm(new ArrayList<>());
        viatura2.setMarcaModelo("Marca Modelo");
        viatura2.setNrSei("Nr Sei");
        viatura2.setPlaca("Placa");
        viatura2.setPrefixo("Prefixo");
        viatura2.setRenavam("Renavam");
        viatura2.setStatus("Status");
        viatura2.setTipoEmpregoViatura(tipoEmpregoViatura2);
        viatura2.setTombamento("alice.liddell@example.org");
        actualViaturaUpmEntity.setViatura(viatura2);
        int actualAtivo = actualViaturaUpmEntity.getAtivo();
        int actualCodCadastranteEntrada = actualViaturaUpmEntity.getCodCadastranteEntrada();
        int actualCodCadastranteSaida = actualViaturaUpmEntity.getCodCadastranteSaida();
        Date actualDtEntrada = actualViaturaUpmEntity.getDtEntrada();
        Date actualDtMovimentacao = actualViaturaUpmEntity.getDtMovimentacao();
        Date actualDtSaida = actualViaturaUpmEntity.getDtSaida();
        Integer actualId = actualViaturaUpmEntity.getId();
        int actualMotivoTransferenciaCodigo = actualViaturaUpmEntity.getMotivoTransferenciaCodigo();
        int actualMovimentadorCodigo = actualViaturaUpmEntity.getMovimentadorCodigo();
        String actualNrSei = actualViaturaUpmEntity.getNrSei();
        String actualObservacao = actualViaturaUpmEntity.getObservacao();
        //int actualUpmCodigo = actualViaturaUpmEntity.getUpmCodigo();
        ViaturaEntity actualViatura = actualViaturaUpmEntity.getViatura();

        // Assert that nothing has changed
        assertEquals("Nr Sei", actualNrSei);
        assertEquals("Observacao", actualObservacao);
        assertEquals(1, actualAtivo);
        assertEquals(1, actualCodCadastranteEntrada);
        assertEquals(1, actualCodCadastranteSaida);
        assertEquals(1, actualMotivoTransferenciaCodigo);
        assertEquals(1, actualMovimentadorCodigo);
       // assertEquals(1, actualUpmCodigo);
        assertEquals(1, actualId.intValue());
        assertEquals(viatura, actualViatura);
        assertSame(viatura2, actualViatura);
        assertSame(dtEntrada2, actualDtEntrada);
        assertSame(dtMovimentacao, actualDtMovimentacao);
        assertSame(dtSaida2, actualDtSaida);
    }
}
