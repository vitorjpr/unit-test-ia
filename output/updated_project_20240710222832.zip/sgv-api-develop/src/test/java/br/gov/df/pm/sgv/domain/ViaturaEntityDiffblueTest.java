package br.gov.df.pm.sgv.domain;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

class ViaturaEntityDiffblueTest {
    /**
     * Methods under test:
     * <ul>
     *   <li>{@link ViaturaEntity#ViaturaEntity()}
     *   <li>{@link ViaturaEntity#setAtivo(Boolean)}
     *   <li>{@link ViaturaEntity#setDataAtualizacao(LocalDate)}
     *   <li>{@link ViaturaEntity#setDataInclusao(LocalDate)}
     *   <li>{@link ViaturaEntity#setId(Long)}
     *   <li>{@link ViaturaEntity#setListaUpm(List)}
     *   <li>{@link ViaturaEntity#setMarcaModelo(String)}
     *   <li>{@link ViaturaEntity#setNrSei(String)}
     *   <li>{@link ViaturaEntity#setPlaca(String)}
     *   <li>{@link ViaturaEntity#setPrefixo(String)}
     *   <li>{@link ViaturaEntity#setRenavam(String)}
     *   <li>{@link ViaturaEntity#setStatus(String)}
     *   <li>{@link ViaturaEntity#setTipoEmpregoViatura(TipoEmpregoViaturaEntity)}
     *   <li>{@link ViaturaEntity#setTombamento(String)}
     *   <li>{@link ViaturaEntity#getAtivo()}
     *   <li>{@link ViaturaEntity#getDataAtualizacao()}
     *   <li>{@link ViaturaEntity#getDataInclusao()}
     *   <li>{@link ViaturaEntity#getId()}
     *   <li>{@link ViaturaEntity#getListaUpm()}
     *   <li>{@link ViaturaEntity#getMarcaModelo()}
     *   <li>{@link ViaturaEntity#getNrSei()}
     *   <li>{@link ViaturaEntity#getPlaca()}
     *   <li>{@link ViaturaEntity#getPrefixo()}
     *   <li>{@link ViaturaEntity#getRenavam()}
     *   <li>{@link ViaturaEntity#getStatus()}
     *   <li>{@link ViaturaEntity#getTipoEmpregoViatura()}
     *   <li>{@link ViaturaEntity#getTombamento()}
     * </ul>
     */
    @Test
    void testGettersAndSetters() {
        // Arrange and Act
        ViaturaEntity actualViaturaEntity = new ViaturaEntity();
        actualViaturaEntity.setAtivo(true);
        LocalDate dataAtualizacao = LocalDate.of(1970, 1, 1);
        actualViaturaEntity.setDataAtualizacao(dataAtualizacao);
        LocalDate dataInclusao = LocalDate.of(1970, 1, 1);
        actualViaturaEntity.setDataInclusao(dataInclusao);
        actualViaturaEntity.setId(1L);
        ArrayList<ViaturaUpmEntity> listaUpm = new ArrayList<>();
        actualViaturaEntity.setListaUpm(listaUpm);
        actualViaturaEntity.setMarcaModelo("Marca Modelo");
        actualViaturaEntity.setNrSei("Nr Sei");
        actualViaturaEntity.setPlaca("Placa");
        actualViaturaEntity.setPrefixo("Prefixo");
        actualViaturaEntity.setRenavam("Renavam");
        actualViaturaEntity.setStatus("Status");
        TipoEmpregoViaturaEntity tipoEmpregoViatura = new TipoEmpregoViaturaEntity();
        tipoEmpregoViatura.setAtivo(1);
        tipoEmpregoViatura.setId(1);
        tipoEmpregoViatura.setNome("Nome");
        actualViaturaEntity.setTipoEmpregoViatura(tipoEmpregoViatura);
        actualViaturaEntity.setTombamento("alice.liddell@example.org");
        Boolean actualAtivo = actualViaturaEntity.getAtivo();
        LocalDate actualDataAtualizacao = actualViaturaEntity.getDataAtualizacao();
        LocalDate actualDataInclusao = actualViaturaEntity.getDataInclusao();
        Long actualId = actualViaturaEntity.getId();
        List<ViaturaUpmEntity> actualListaUpm = actualViaturaEntity.getListaUpm();
        String actualMarcaModelo = actualViaturaEntity.getMarcaModelo();
        String actualNrSei = actualViaturaEntity.getNrSei();
        String actualPlaca = actualViaturaEntity.getPlaca();
        String actualPrefixo = actualViaturaEntity.getPrefixo();
        String actualRenavam = actualViaturaEntity.getRenavam();
        String actualStatus = actualViaturaEntity.getStatus();
        TipoEmpregoViaturaEntity actualTipoEmpregoViatura = actualViaturaEntity.getTipoEmpregoViatura();

        // Assert that nothing has changed
        assertEquals("Marca Modelo", actualMarcaModelo);
        assertEquals("Nr Sei", actualNrSei);
        assertEquals("Placa", actualPlaca);
        assertEquals("Prefixo", actualPrefixo);
        assertEquals("Renavam", actualRenavam);
        assertEquals("Status", actualStatus);
        assertEquals("alice.liddell@example.org", actualViaturaEntity.getTombamento());
        assertEquals(1L, actualId.longValue());
        assertTrue(actualAtivo);
        assertSame(tipoEmpregoViatura, actualTipoEmpregoViatura);
        assertSame(listaUpm, actualListaUpm);
        assertSame(dataAtualizacao, actualDataAtualizacao);
        assertSame(dataInclusao, actualDataInclusao);
    }

    /**
     * Methods under test:
     * <ul>
     *   <li>
     * {@link ViaturaEntity#ViaturaEntity(Long, String, String, String, String, String, String, LocalDate, LocalDate, Boolean, TipoEmpregoViaturaEntity, List, String)}
     *   <li>{@link ViaturaEntity#setAtivo(Boolean)}
     *   <li>{@link ViaturaEntity#setDataAtualizacao(LocalDate)}
     *   <li>{@link ViaturaEntity#setDataInclusao(LocalDate)}
     *   <li>{@link ViaturaEntity#setId(Long)}
     *   <li>{@link ViaturaEntity#setListaUpm(List)}
     *   <li>{@link ViaturaEntity#setMarcaModelo(String)}
     *   <li>{@link ViaturaEntity#setNrSei(String)}
     *   <li>{@link ViaturaEntity#setPlaca(String)}
     *   <li>{@link ViaturaEntity#setPrefixo(String)}
     *   <li>{@link ViaturaEntity#setRenavam(String)}
     *   <li>{@link ViaturaEntity#setStatus(String)}
     *   <li>{@link ViaturaEntity#setTipoEmpregoViatura(TipoEmpregoViaturaEntity)}
     *   <li>{@link ViaturaEntity#setTombamento(String)}
     *   <li>{@link ViaturaEntity#getAtivo()}
     *   <li>{@link ViaturaEntity#getDataAtualizacao()}
     *   <li>{@link ViaturaEntity#getDataInclusao()}
     *   <li>{@link ViaturaEntity#getId()}
     *   <li>{@link ViaturaEntity#getListaUpm()}
     *   <li>{@link ViaturaEntity#getMarcaModelo()}
     *   <li>{@link ViaturaEntity#getNrSei()}
     *   <li>{@link ViaturaEntity#getPlaca()}
     *   <li>{@link ViaturaEntity#getPrefixo()}
     *   <li>{@link ViaturaEntity#getRenavam()}
     *   <li>{@link ViaturaEntity#getStatus()}
     *   <li>{@link ViaturaEntity#getTipoEmpregoViatura()}
     *   <li>{@link ViaturaEntity#getTombamento()}
     * </ul>
     */
    @Test
    void testGettersAndSetters2() {
        // Arrange
        LocalDate dataInclusao = LocalDate.of(1970, 1, 1);
        LocalDate dataAtualizacao = LocalDate.of(1970, 1, 1);

        TipoEmpregoViaturaEntity tipoEmpregoViatura = new TipoEmpregoViaturaEntity();
        tipoEmpregoViatura.setAtivo(1);
        tipoEmpregoViatura.setId(1);
        tipoEmpregoViatura.setNome("Nome");
        ArrayList<ViaturaUpmEntity> listaUpm = new ArrayList<>();

        // Act
        ViaturaEntity actualViaturaEntity = new ViaturaEntity(1L, "Prefixo", "Nr Sei", "Placa", "Status",
                "alice.liddell@example.org", "Renavam", dataInclusao, dataAtualizacao, true, tipoEmpregoViatura, listaUpm,
                "Marca Modelo");
        actualViaturaEntity.setAtivo(true);
        LocalDate dataAtualizacao2 = LocalDate.of(1970, 1, 1);
        actualViaturaEntity.setDataAtualizacao(dataAtualizacao2);
        LocalDate dataInclusao2 = LocalDate.of(1970, 1, 1);
        actualViaturaEntity.setDataInclusao(dataInclusao2);
        actualViaturaEntity.setId(1L);
        ArrayList<ViaturaUpmEntity> listaUpm2 = new ArrayList<>();
        actualViaturaEntity.setListaUpm(listaUpm2);
        actualViaturaEntity.setMarcaModelo("Marca Modelo");
        actualViaturaEntity.setNrSei("Nr Sei");
        actualViaturaEntity.setPlaca("Placa");
        actualViaturaEntity.setPrefixo("Prefixo");
        actualViaturaEntity.setRenavam("Renavam");
        actualViaturaEntity.setStatus("Status");
        TipoEmpregoViaturaEntity tipoEmpregoViatura2 = new TipoEmpregoViaturaEntity();
        tipoEmpregoViatura2.setAtivo(1);
        tipoEmpregoViatura2.setId(1);
        tipoEmpregoViatura2.setNome("Nome");
        actualViaturaEntity.setTipoEmpregoViatura(tipoEmpregoViatura2);
        actualViaturaEntity.setTombamento("alice.liddell@example.org");
        Boolean actualAtivo = actualViaturaEntity.getAtivo();
        LocalDate actualDataAtualizacao = actualViaturaEntity.getDataAtualizacao();
        LocalDate actualDataInclusao = actualViaturaEntity.getDataInclusao();
        Long actualId = actualViaturaEntity.getId();
        List<ViaturaUpmEntity> actualListaUpm = actualViaturaEntity.getListaUpm();
        String actualMarcaModelo = actualViaturaEntity.getMarcaModelo();
        String actualNrSei = actualViaturaEntity.getNrSei();
        String actualPlaca = actualViaturaEntity.getPlaca();
        String actualPrefixo = actualViaturaEntity.getPrefixo();
        String actualRenavam = actualViaturaEntity.getRenavam();
        String actualStatus = actualViaturaEntity.getStatus();
        TipoEmpregoViaturaEntity actualTipoEmpregoViatura = actualViaturaEntity.getTipoEmpregoViatura();

        // Assert that nothing has changed
        assertEquals("Marca Modelo", actualMarcaModelo);
        assertEquals("Nr Sei", actualNrSei);
        assertEquals("Placa", actualPlaca);
        assertEquals("Prefixo", actualPrefixo);
        assertEquals("Renavam", actualRenavam);
        assertEquals("Status", actualStatus);
        assertEquals("alice.liddell@example.org", actualViaturaEntity.getTombamento());
        assertEquals(1L, actualId.longValue());
        assertTrue(actualAtivo);
        assertEquals(tipoEmpregoViatura, actualTipoEmpregoViatura);
        assertEquals(listaUpm, actualListaUpm);
        assertSame(tipoEmpregoViatura2, actualTipoEmpregoViatura);
        assertSame(listaUpm2, actualListaUpm);
        assertSame(dataAtualizacao2, actualDataAtualizacao);
        assertSame(dataInclusao2, actualDataInclusao);
    }
}
