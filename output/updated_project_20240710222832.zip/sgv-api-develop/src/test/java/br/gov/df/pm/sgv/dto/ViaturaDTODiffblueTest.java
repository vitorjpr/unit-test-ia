package br.gov.df.pm.sgv.dto;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

class ViaturaDTODiffblueTest {
    /**
     * Method under test: {@link ViaturaDTO#equals(Object)}
     */
    @Test
    void testEquals() {
        // Arrange
        ViaturaDTO.ViaturaDTOBuilder ativoResult = ViaturaDTO.builder().ativo(true);
        ViaturaDTO.ViaturaDTOBuilder dataAtualizacaoResult = ativoResult
                .dataAtualizacao(LocalDate.of(1970, 1, 1).atStartOfDay());
        ViaturaDTO.ViaturaDTOBuilder ultimoOdometroResult = dataAtualizacaoResult
                .dataInclusao(LocalDate.of(1970, 1, 1).atStartOfDay())
                .id(1L)
                .nrSei("Nr Sei")
                .placa("Placa")
                .prefixo("Prefixo")
                .renavam("Renavam")
                .status("Status")
                .tombamento("alice.liddell@example.org")
                .ultimoOdometro(10.0d);
        ViaturaDTO buildResult = ultimoOdometroResult.vistoriaViatura(new ArrayList<>()).build();

        // Act and Assert
        assertNotEquals(buildResult, null);
    }

    /**
     * Method under test: {@link ViaturaDTO#equals(Object)}
     */
    @Test
    void testEquals2() {
        // Arrange
        ViaturaDTO.ViaturaDTOBuilder ativoResult = ViaturaDTO.builder().ativo(true);
        ViaturaDTO.ViaturaDTOBuilder dataAtualizacaoResult = ativoResult
                .dataAtualizacao(LocalDate.of(1970, 1, 1).atStartOfDay());
        ViaturaDTO.ViaturaDTOBuilder ultimoOdometroResult = dataAtualizacaoResult
                .dataInclusao(LocalDate.of(1970, 1, 1).atStartOfDay())
                .id(1L)
                .nrSei("Nr Sei")
                .placa("Placa")
                .prefixo("Prefixo")
                .renavam("Renavam")
                .status("Status")
                .tombamento("alice.liddell@example.org")
                .ultimoOdometro(10.0d);
        ViaturaDTO buildResult = ultimoOdometroResult.vistoriaViatura(new ArrayList<>()).build();

        // Act and Assert
        assertNotEquals(buildResult, "Different type to ViaturaDTO");
    }

    /**
     * Method under test: {@link ViaturaDTO#equals(Object)}
     */
    @Test
    void testEquals3() {
        // Arrange
        ViaturaDTO.ViaturaDTOBuilder viaturaDTOBuilder = mock(ViaturaDTO.ViaturaDTOBuilder.class);
        when(viaturaDTOBuilder.ativo(Mockito.<Boolean>any())).thenReturn(ViaturaDTO.builder());
        ViaturaDTO.ViaturaDTOBuilder ativoResult = viaturaDTOBuilder.ativo(true);
        ViaturaDTO.ViaturaDTOBuilder dataAtualizacaoResult = ativoResult
                .dataAtualizacao(LocalDate.of(1970, 1, 1).atStartOfDay());
        ViaturaDTO.ViaturaDTOBuilder ultimoOdometroResult = dataAtualizacaoResult
                .dataInclusao(LocalDate.of(1970, 1, 1).atStartOfDay())
                .id(1L)
                .nrSei("Nr Sei")
                .placa("Placa")
                .prefixo("Prefixo")
                .renavam("Renavam")
                .status("Status")
                .tombamento("alice.liddell@example.org")
                .ultimoOdometro(10.0d);
        ViaturaDTO buildResult = ultimoOdometroResult.vistoriaViatura(new ArrayList<>()).build();
        ViaturaDTO.ViaturaDTOBuilder ativoResult2 = ViaturaDTO.builder().ativo(true);
        ViaturaDTO.ViaturaDTOBuilder dataAtualizacaoResult2 = ativoResult2
                .dataAtualizacao(LocalDate.of(1970, 1, 1).atStartOfDay());
        ViaturaDTO.ViaturaDTOBuilder ultimoOdometroResult2 = dataAtualizacaoResult2
                .dataInclusao(LocalDate.of(1970, 1, 1).atStartOfDay())
                .id(1L)
                .nrSei("Nr Sei")
                .placa("Placa")
                .prefixo("Prefixo")
                .renavam("Renavam")
                .status("Status")
                .tombamento("alice.liddell@example.org")
                .ultimoOdometro(10.0d);
        ViaturaDTO buildResult2 = ultimoOdometroResult2.vistoriaViatura(new ArrayList<>()).build();

        // Act and Assert
        assertNotEquals(buildResult, buildResult2);
    }

    /**
     * Method under test: {@link ViaturaDTO#equals(Object)}
     */
    @Test
    void testEquals4() {
        // Arrange
        ViaturaDTO.ViaturaDTOBuilder viaturaDTOBuilder = mock(ViaturaDTO.ViaturaDTOBuilder.class);
        when(viaturaDTOBuilder.ativo(Mockito.<Boolean>any())).thenReturn(ViaturaDTO.builder());
        ViaturaDTO.ViaturaDTOBuilder ativoResult = viaturaDTOBuilder.ativo(true);
        ViaturaDTO.ViaturaDTOBuilder dataAtualizacaoResult = ativoResult
                .dataAtualizacao(LocalDate.of(1970, 1, 1).atStartOfDay());
        ViaturaDTO.ViaturaDTOBuilder ultimoOdometroResult = dataAtualizacaoResult
                .dataInclusao(LocalDate.of(1970, 1, 1).atStartOfDay())
                .id(2L)
                .nrSei("Nr Sei")
                .placa("Placa")
                .prefixo("Prefixo")
                .renavam("Renavam")
                .status("Status")
                .tombamento("alice.liddell@example.org")
                .ultimoOdometro(10.0d);
        ViaturaDTO buildResult = ultimoOdometroResult.vistoriaViatura(new ArrayList<>()).build();
        ViaturaDTO.ViaturaDTOBuilder ativoResult2 = ViaturaDTO.builder().ativo(true);
        ViaturaDTO.ViaturaDTOBuilder dataAtualizacaoResult2 = ativoResult2
                .dataAtualizacao(LocalDate.of(1970, 1, 1).atStartOfDay());
        ViaturaDTO.ViaturaDTOBuilder ultimoOdometroResult2 = dataAtualizacaoResult2
                .dataInclusao(LocalDate.of(1970, 1, 1).atStartOfDay())
                .id(1L)
                .nrSei("Nr Sei")
                .placa("Placa")
                .prefixo("Prefixo")
                .renavam("Renavam")
                .status("Status")
                .tombamento("alice.liddell@example.org")
                .ultimoOdometro(10.0d);
        ViaturaDTO buildResult2 = ultimoOdometroResult2.vistoriaViatura(new ArrayList<>()).build();

        // Act and Assert
        assertNotEquals(buildResult, buildResult2);
    }

    /**
     * Method under test: {@link ViaturaDTO#equals(Object)}
     */
    @Test
    void testEquals5() {
        // Arrange
        ViaturaDTO.ViaturaDTOBuilder viaturaDTOBuilder = mock(ViaturaDTO.ViaturaDTOBuilder.class);
        when(viaturaDTOBuilder.ativo(Mockito.<Boolean>any())).thenReturn(ViaturaDTO.builder());
        ViaturaDTO.ViaturaDTOBuilder ativoResult = viaturaDTOBuilder.ativo(true);
        ViaturaDTO.ViaturaDTOBuilder dataAtualizacaoResult = ativoResult
                .dataAtualizacao(LocalDate.of(1970, 1, 1).atStartOfDay());
        ViaturaDTO.ViaturaDTOBuilder ultimoOdometroResult = dataAtualizacaoResult
                .dataInclusao(LocalDate.of(1970, 1, 1).atStartOfDay())
                .id(null)
                .nrSei("Nr Sei")
                .placa("Placa")
                .prefixo("Prefixo")
                .renavam("Renavam")
                .status("Status")
                .tombamento("alice.liddell@example.org")
                .ultimoOdometro(10.0d);
        ViaturaDTO buildResult = ultimoOdometroResult.vistoriaViatura(new ArrayList<>()).build();
        ViaturaDTO.ViaturaDTOBuilder ativoResult2 = ViaturaDTO.builder().ativo(true);
        ViaturaDTO.ViaturaDTOBuilder dataAtualizacaoResult2 = ativoResult2
                .dataAtualizacao(LocalDate.of(1970, 1, 1).atStartOfDay());
        ViaturaDTO.ViaturaDTOBuilder ultimoOdometroResult2 = dataAtualizacaoResult2
                .dataInclusao(LocalDate.of(1970, 1, 1).atStartOfDay())
                .id(1L)
                .nrSei("Nr Sei")
                .placa("Placa")
                .prefixo("Prefixo")
                .renavam("Renavam")
                .status("Status")
                .tombamento("alice.liddell@example.org")
                .ultimoOdometro(10.0d);
        ViaturaDTO buildResult2 = ultimoOdometroResult2.vistoriaViatura(new ArrayList<>()).build();

        // Act and Assert
        assertNotEquals(buildResult, buildResult2);
    }

    /**
     * Method under test: {@link ViaturaDTO#equals(Object)}
     */
    @Test
    void testEquals6() {
        // Arrange
        ViaturaDTO.ViaturaDTOBuilder viaturaDTOBuilder = mock(ViaturaDTO.ViaturaDTOBuilder.class);
        when(viaturaDTOBuilder.ativo(Mockito.<Boolean>any())).thenReturn(ViaturaDTO.builder());
        ViaturaDTO.ViaturaDTOBuilder ativoResult = viaturaDTOBuilder.ativo(true);
        ViaturaDTO.ViaturaDTOBuilder dataAtualizacaoResult = ativoResult
                .dataAtualizacao(LocalDate.of(1970, 1, 1).atStartOfDay());
        ViaturaDTO.ViaturaDTOBuilder ultimoOdometroResult = dataAtualizacaoResult
                .dataInclusao(LocalDate.of(1970, 1, 1).atStartOfDay())
                .id(1L)
                .nrSei("Nr Sei")
                .placa("Placa")
                .prefixo("Prefixo")
                .renavam("Renavam")
                .status("Status")
                .tombamento("alice.liddell@example.org")
                .ultimoOdometro(null);
        ViaturaDTO buildResult = ultimoOdometroResult.vistoriaViatura(new ArrayList<>()).build();
        ViaturaDTO.ViaturaDTOBuilder ativoResult2 = ViaturaDTO.builder().ativo(true);
        ViaturaDTO.ViaturaDTOBuilder dataAtualizacaoResult2 = ativoResult2
                .dataAtualizacao(LocalDate.of(1970, 1, 1).atStartOfDay());
        ViaturaDTO.ViaturaDTOBuilder ultimoOdometroResult2 = dataAtualizacaoResult2
                .dataInclusao(LocalDate.of(1970, 1, 1).atStartOfDay())
                .id(1L)
                .nrSei("Nr Sei")
                .placa("Placa")
                .prefixo("Prefixo")
                .renavam("Renavam")
                .status("Status")
                .tombamento("alice.liddell@example.org")
                .ultimoOdometro(10.0d);
        ViaturaDTO buildResult2 = ultimoOdometroResult2.vistoriaViatura(new ArrayList<>()).build();

        // Act and Assert
        assertNotEquals(buildResult, buildResult2);
    }

    /**
     * Method under test: {@link ViaturaDTO#equals(Object)}
     */
    @Test
    void testEquals7() {
        // Arrange
        ViaturaDTO.ViaturaDTOBuilder viaturaDTOBuilder = mock(ViaturaDTO.ViaturaDTOBuilder.class);
        when(viaturaDTOBuilder.ativo(Mockito.<Boolean>any())).thenReturn(ViaturaDTO.builder());
        ViaturaDTO.ViaturaDTOBuilder ativoResult = viaturaDTOBuilder.ativo(true);
        ViaturaDTO.ViaturaDTOBuilder dataAtualizacaoResult = ativoResult
                .dataAtualizacao(LocalDate.of(1970, 1, 1).atStartOfDay());
        ViaturaDTO.ViaturaDTOBuilder ultimoOdometroResult = dataAtualizacaoResult
                .dataInclusao(LocalDate.of(1970, 1, 1).atStartOfDay())
                .id(1L)
                .nrSei("Nr Sei")
                .placa("Placa")
                .prefixo("Prefixo")
                .renavam("Renavam")
                .status("Status")
                .tombamento("alice.liddell@example.org")
                .ultimoOdometro(0.5d);
        ViaturaDTO buildResult = ultimoOdometroResult.vistoriaViatura(new ArrayList<>()).build();
        ViaturaDTO.ViaturaDTOBuilder ativoResult2 = ViaturaDTO.builder().ativo(true);
        ViaturaDTO.ViaturaDTOBuilder dataAtualizacaoResult2 = ativoResult2
                .dataAtualizacao(LocalDate.of(1970, 1, 1).atStartOfDay());
        ViaturaDTO.ViaturaDTOBuilder ultimoOdometroResult2 = dataAtualizacaoResult2
                .dataInclusao(LocalDate.of(1970, 1, 1).atStartOfDay())
                .id(1L)
                .nrSei("Nr Sei")
                .placa("Placa")
                .prefixo("Prefixo")
                .renavam("Renavam")
                .status("Status")
                .tombamento("alice.liddell@example.org")
                .ultimoOdometro(10.0d);
        ViaturaDTO buildResult2 = ultimoOdometroResult2.vistoriaViatura(new ArrayList<>()).build();

        // Act and Assert
        assertNotEquals(buildResult, buildResult2);
    }

    /**
     * Method under test: {@link ViaturaDTO#equals(Object)}
     */
    @Test
    void testEquals8() {
        // Arrange
        ViaturaDTO.ViaturaDTOBuilder viaturaDTOBuilder = mock(ViaturaDTO.ViaturaDTOBuilder.class);
        when(viaturaDTOBuilder.dataAtualizacao(Mockito.<LocalDateTime>any())).thenReturn(ViaturaDTO.builder());
        ViaturaDTO.ViaturaDTOBuilder viaturaDTOBuilder2 = mock(ViaturaDTO.ViaturaDTOBuilder.class);
        when(viaturaDTOBuilder2.ativo(Mockito.<Boolean>any())).thenReturn(viaturaDTOBuilder);
        ViaturaDTO.ViaturaDTOBuilder ativoResult = viaturaDTOBuilder2.ativo(true);
        ViaturaDTO.ViaturaDTOBuilder dataAtualizacaoResult = ativoResult
                .dataAtualizacao(LocalDate.of(1970, 1, 1).atStartOfDay());
        ViaturaDTO.ViaturaDTOBuilder ultimoOdometroResult = dataAtualizacaoResult
                .dataInclusao(LocalDate.of(1970, 1, 1).atStartOfDay())
                .id(1L)
                .nrSei("Nr Sei")
                .placa("Placa")
                .prefixo("Prefixo")
                .renavam("Renavam")
                .status("Status")
                .tombamento("alice.liddell@example.org")
                .ultimoOdometro(10.0d);
        ViaturaDTO buildResult = ultimoOdometroResult.vistoriaViatura(new ArrayList<>()).build();
        ViaturaDTO.ViaturaDTOBuilder viaturaDTOBuilder3 = mock(ViaturaDTO.ViaturaDTOBuilder.class);
        when(viaturaDTOBuilder3.ativo(Mockito.<Boolean>any())).thenReturn(ViaturaDTO.builder());
        ViaturaDTO.ViaturaDTOBuilder ativoResult2 = viaturaDTOBuilder3.ativo(true);
        ViaturaDTO.ViaturaDTOBuilder dataAtualizacaoResult2 = ativoResult2
                .dataAtualizacao(LocalDate.of(1970, 1, 1).atStartOfDay());
        ViaturaDTO.ViaturaDTOBuilder ultimoOdometroResult2 = dataAtualizacaoResult2
                .dataInclusao(LocalDate.of(1970, 1, 1).atStartOfDay())
                .id(1L)
                .nrSei("Nr Sei")
                .placa("Placa")
                .prefixo("Prefixo")
                .renavam("Renavam")
                .status("Status")
                .tombamento("alice.liddell@example.org")
                .ultimoOdometro(10.0d);
        ViaturaDTO buildResult2 = ultimoOdometroResult2.vistoriaViatura(new ArrayList<>()).build();

        // Act and Assert
        assertNotEquals(buildResult, buildResult2);
    }

    /**
     * Method under test: {@link ViaturaDTO#equals(Object)}
     */
    @Test
    void testEquals9() {
        // Arrange
        ViaturaDTO.ViaturaDTOBuilder viaturaDTOBuilder = mock(ViaturaDTO.ViaturaDTOBuilder.class);
        when(viaturaDTOBuilder.dataInclusao(Mockito.<LocalDateTime>any())).thenReturn(ViaturaDTO.builder());
        ViaturaDTO.ViaturaDTOBuilder viaturaDTOBuilder2 = mock(ViaturaDTO.ViaturaDTOBuilder.class);
        when(viaturaDTOBuilder2.dataAtualizacao(Mockito.<LocalDateTime>any())).thenReturn(viaturaDTOBuilder);
        ViaturaDTO.ViaturaDTOBuilder viaturaDTOBuilder3 = mock(ViaturaDTO.ViaturaDTOBuilder.class);
        when(viaturaDTOBuilder3.ativo(Mockito.<Boolean>any())).thenReturn(viaturaDTOBuilder2);
        ViaturaDTO.ViaturaDTOBuilder ativoResult = viaturaDTOBuilder3.ativo(true);
        ViaturaDTO.ViaturaDTOBuilder dataAtualizacaoResult = ativoResult
                .dataAtualizacao(LocalDate.of(1970, 1, 1).atStartOfDay());
        ViaturaDTO.ViaturaDTOBuilder ultimoOdometroResult = dataAtualizacaoResult
                .dataInclusao(LocalDate.of(1970, 1, 1).atStartOfDay())
                .id(1L)
                .nrSei("Nr Sei")
                .placa("Placa")
                .prefixo("Prefixo")
                .renavam("Renavam")
                .status("Status")
                .tombamento("alice.liddell@example.org")
                .ultimoOdometro(10.0d);
        ViaturaDTO buildResult = ultimoOdometroResult.vistoriaViatura(new ArrayList<>()).build();
        ViaturaDTO.ViaturaDTOBuilder viaturaDTOBuilder4 = mock(ViaturaDTO.ViaturaDTOBuilder.class);
        when(viaturaDTOBuilder4.ativo(Mockito.<Boolean>any())).thenReturn(ViaturaDTO.builder());
        ViaturaDTO.ViaturaDTOBuilder ativoResult2 = viaturaDTOBuilder4.ativo(true);
        ViaturaDTO.ViaturaDTOBuilder dataAtualizacaoResult2 = ativoResult2
                .dataAtualizacao(LocalDate.of(1970, 1, 1).atStartOfDay());
        ViaturaDTO.ViaturaDTOBuilder ultimoOdometroResult2 = dataAtualizacaoResult2
                .dataInclusao(LocalDate.of(1970, 1, 1).atStartOfDay())
                .id(1L)
                .nrSei("Nr Sei")
                .placa("Placa")
                .prefixo("Prefixo")
                .renavam("Renavam")
                .status("Status")
                .tombamento("alice.liddell@example.org")
                .ultimoOdometro(10.0d);
        ViaturaDTO buildResult2 = ultimoOdometroResult2.vistoriaViatura(new ArrayList<>()).build();

        // Act and Assert
        assertNotEquals(buildResult, buildResult2);
    }

    /**
     * Method under test: {@link ViaturaDTO#equals(Object)}
     */
    @Test
    void testEquals10() {
        // Arrange
        ViaturaDTO.ViaturaDTOBuilder viaturaDTOBuilder = mock(ViaturaDTO.ViaturaDTOBuilder.class);
        when(viaturaDTOBuilder.dataInclusao(Mockito.<LocalDateTime>any())).thenReturn(ViaturaDTO.builder());
        ViaturaDTO.ViaturaDTOBuilder viaturaDTOBuilder2 = mock(ViaturaDTO.ViaturaDTOBuilder.class);
        when(viaturaDTOBuilder2.dataAtualizacao(Mockito.<LocalDateTime>any())).thenReturn(viaturaDTOBuilder);
        ViaturaDTO.ViaturaDTOBuilder viaturaDTOBuilder3 = mock(ViaturaDTO.ViaturaDTOBuilder.class);
        when(viaturaDTOBuilder3.ativo(Mockito.<Boolean>any())).thenReturn(viaturaDTOBuilder2);
        ViaturaDTO.ViaturaDTOBuilder ativoResult = viaturaDTOBuilder3.ativo(true);
        ViaturaDTO.ViaturaDTOBuilder dataAtualizacaoResult = ativoResult
                .dataAtualizacao(LocalDate.of(1970, 1, 1).atStartOfDay());
        ViaturaDTO.ViaturaDTOBuilder ultimoOdometroResult = dataAtualizacaoResult
                .dataInclusao(LocalDate.of(1970, 1, 1).atStartOfDay())
                .id(1L)
                .nrSei("Prefixo")
                .placa("Placa")
                .prefixo("Prefixo")
                .renavam("Renavam")
                .status("Status")
                .tombamento("alice.liddell@example.org")
                .ultimoOdometro(10.0d);
        ViaturaDTO buildResult = ultimoOdometroResult.vistoriaViatura(new ArrayList<>()).build();
        ViaturaDTO.ViaturaDTOBuilder viaturaDTOBuilder4 = mock(ViaturaDTO.ViaturaDTOBuilder.class);
        when(viaturaDTOBuilder4.ativo(Mockito.<Boolean>any())).thenReturn(ViaturaDTO.builder());
        ViaturaDTO.ViaturaDTOBuilder ativoResult2 = viaturaDTOBuilder4.ativo(true);
        ViaturaDTO.ViaturaDTOBuilder dataAtualizacaoResult2 = ativoResult2
                .dataAtualizacao(LocalDate.of(1970, 1, 1).atStartOfDay());
        ViaturaDTO.ViaturaDTOBuilder ultimoOdometroResult2 = dataAtualizacaoResult2
                .dataInclusao(LocalDate.of(1970, 1, 1).atStartOfDay())
                .id(1L)
                .nrSei("Nr Sei")
                .placa("Placa")
                .prefixo("Prefixo")
                .renavam("Renavam")
                .status("Status")
                .tombamento("alice.liddell@example.org")
                .ultimoOdometro(10.0d);
        ViaturaDTO buildResult2 = ultimoOdometroResult2.vistoriaViatura(new ArrayList<>()).build();

        // Act and Assert
        assertNotEquals(buildResult, buildResult2);
    }

    /**
     * Method under test: {@link ViaturaDTO#equals(Object)}
     */
    @Test
    void testEquals11() {
        // Arrange
        ViaturaDTO.ViaturaDTOBuilder viaturaDTOBuilder = mock(ViaturaDTO.ViaturaDTOBuilder.class);
        when(viaturaDTOBuilder.dataInclusao(Mockito.<LocalDateTime>any())).thenReturn(ViaturaDTO.builder());
        ViaturaDTO.ViaturaDTOBuilder viaturaDTOBuilder2 = mock(ViaturaDTO.ViaturaDTOBuilder.class);
        when(viaturaDTOBuilder2.dataAtualizacao(Mockito.<LocalDateTime>any())).thenReturn(viaturaDTOBuilder);
        ViaturaDTO.ViaturaDTOBuilder viaturaDTOBuilder3 = mock(ViaturaDTO.ViaturaDTOBuilder.class);
        when(viaturaDTOBuilder3.ativo(Mockito.<Boolean>any())).thenReturn(viaturaDTOBuilder2);
        ViaturaDTO.ViaturaDTOBuilder ativoResult = viaturaDTOBuilder3.ativo(true);
        ViaturaDTO.ViaturaDTOBuilder dataAtualizacaoResult = ativoResult
                .dataAtualizacao(LocalDate.of(1970, 1, 1).atStartOfDay());
        ViaturaDTO.ViaturaDTOBuilder ultimoOdometroResult = dataAtualizacaoResult
                .dataInclusao(LocalDate.of(1970, 1, 1).atStartOfDay())
                .id(1L)
                .nrSei(null)
                .placa("Placa")
                .prefixo("Prefixo")
                .renavam("Renavam")
                .status("Status")
                .tombamento("alice.liddell@example.org")
                .ultimoOdometro(10.0d);
        ViaturaDTO buildResult = ultimoOdometroResult.vistoriaViatura(new ArrayList<>()).build();
        ViaturaDTO.ViaturaDTOBuilder viaturaDTOBuilder4 = mock(ViaturaDTO.ViaturaDTOBuilder.class);
        when(viaturaDTOBuilder4.ativo(Mockito.<Boolean>any())).thenReturn(ViaturaDTO.builder());
        ViaturaDTO.ViaturaDTOBuilder ativoResult2 = viaturaDTOBuilder4.ativo(true);
        ViaturaDTO.ViaturaDTOBuilder dataAtualizacaoResult2 = ativoResult2
                .dataAtualizacao(LocalDate.of(1970, 1, 1).atStartOfDay());
        ViaturaDTO.ViaturaDTOBuilder ultimoOdometroResult2 = dataAtualizacaoResult2
                .dataInclusao(LocalDate.of(1970, 1, 1).atStartOfDay())
                .id(1L)
                .nrSei("Nr Sei")
                .placa("Placa")
                .prefixo("Prefixo")
                .renavam("Renavam")
                .status("Status")
                .tombamento("alice.liddell@example.org")
                .ultimoOdometro(10.0d);
        ViaturaDTO buildResult2 = ultimoOdometroResult2.vistoriaViatura(new ArrayList<>()).build();

        // Act and Assert
        assertNotEquals(buildResult, buildResult2);
    }

    /**
     * Method under test: {@link ViaturaDTO#equals(Object)}
     */
    @Test
    void testEquals12() {
        // Arrange
        ViaturaDTO.ViaturaDTOBuilder viaturaDTOBuilder = mock(ViaturaDTO.ViaturaDTOBuilder.class);
        when(viaturaDTOBuilder.dataInclusao(Mockito.<LocalDateTime>any())).thenReturn(ViaturaDTO.builder());
        ViaturaDTO.ViaturaDTOBuilder viaturaDTOBuilder2 = mock(ViaturaDTO.ViaturaDTOBuilder.class);
        when(viaturaDTOBuilder2.dataAtualizacao(Mockito.<LocalDateTime>any())).thenReturn(viaturaDTOBuilder);
        ViaturaDTO.ViaturaDTOBuilder viaturaDTOBuilder3 = mock(ViaturaDTO.ViaturaDTOBuilder.class);
        when(viaturaDTOBuilder3.ativo(Mockito.<Boolean>any())).thenReturn(viaturaDTOBuilder2);
        ViaturaDTO.ViaturaDTOBuilder ativoResult = viaturaDTOBuilder3.ativo(true);
        ViaturaDTO.ViaturaDTOBuilder dataAtualizacaoResult = ativoResult
                .dataAtualizacao(LocalDate.of(1970, 1, 1).atStartOfDay());
        ViaturaDTO.ViaturaDTOBuilder ultimoOdometroResult = dataAtualizacaoResult
                .dataInclusao(LocalDate.of(1970, 1, 1).atStartOfDay())
                .id(1L)
                .nrSei("Nr Sei")
                .placa("Prefixo")
                .prefixo("Prefixo")
                .renavam("Renavam")
                .status("Status")
                .tombamento("alice.liddell@example.org")
                .ultimoOdometro(10.0d);
        ViaturaDTO buildResult = ultimoOdometroResult.vistoriaViatura(new ArrayList<>()).build();
        ViaturaDTO.ViaturaDTOBuilder viaturaDTOBuilder4 = mock(ViaturaDTO.ViaturaDTOBuilder.class);
        when(viaturaDTOBuilder4.ativo(Mockito.<Boolean>any())).thenReturn(ViaturaDTO.builder());
        ViaturaDTO.ViaturaDTOBuilder ativoResult2 = viaturaDTOBuilder4.ativo(true);
        ViaturaDTO.ViaturaDTOBuilder dataAtualizacaoResult2 = ativoResult2
                .dataAtualizacao(LocalDate.of(1970, 1, 1).atStartOfDay());
        ViaturaDTO.ViaturaDTOBuilder ultimoOdometroResult2 = dataAtualizacaoResult2
                .dataInclusao(LocalDate.of(1970, 1, 1).atStartOfDay())
                .id(1L)
                .nrSei("Nr Sei")
                .placa("Placa")
                .prefixo("Prefixo")
                .renavam("Renavam")
                .status("Status")
                .tombamento("alice.liddell@example.org")
                .ultimoOdometro(10.0d);
        ViaturaDTO buildResult2 = ultimoOdometroResult2.vistoriaViatura(new ArrayList<>()).build();

        // Act and Assert
        assertNotEquals(buildResult, buildResult2);
    }

    /**
     * Method under test: {@link ViaturaDTO#equals(Object)}
     */
    @Test
    void testEquals13() {
        // Arrange
        ViaturaDTO.ViaturaDTOBuilder viaturaDTOBuilder = mock(ViaturaDTO.ViaturaDTOBuilder.class);
        when(viaturaDTOBuilder.dataInclusao(Mockito.<LocalDateTime>any())).thenReturn(ViaturaDTO.builder());
        ViaturaDTO.ViaturaDTOBuilder viaturaDTOBuilder2 = mock(ViaturaDTO.ViaturaDTOBuilder.class);
        when(viaturaDTOBuilder2.dataAtualizacao(Mockito.<LocalDateTime>any())).thenReturn(viaturaDTOBuilder);
        ViaturaDTO.ViaturaDTOBuilder viaturaDTOBuilder3 = mock(ViaturaDTO.ViaturaDTOBuilder.class);
        when(viaturaDTOBuilder3.ativo(Mockito.<Boolean>any())).thenReturn(viaturaDTOBuilder2);
        ViaturaDTO.ViaturaDTOBuilder ativoResult = viaturaDTOBuilder3.ativo(true);
        ViaturaDTO.ViaturaDTOBuilder dataAtualizacaoResult = ativoResult
                .dataAtualizacao(LocalDate.of(1970, 1, 1).atStartOfDay());
        ViaturaDTO.ViaturaDTOBuilder ultimoOdometroResult = dataAtualizacaoResult
                .dataInclusao(LocalDate.of(1970, 1, 1).atStartOfDay())
                .id(1L)
                .nrSei("Nr Sei")
                .placa(null)
                .prefixo("Prefixo")
                .renavam("Renavam")
                .status("Status")
                .tombamento("alice.liddell@example.org")
                .ultimoOdometro(10.0d);
        ViaturaDTO buildResult = ultimoOdometroResult.vistoriaViatura(new ArrayList<>()).build();
        ViaturaDTO.ViaturaDTOBuilder viaturaDTOBuilder4 = mock(ViaturaDTO.ViaturaDTOBuilder.class);
        when(viaturaDTOBuilder4.ativo(Mockito.<Boolean>any())).thenReturn(ViaturaDTO.builder());
        ViaturaDTO.ViaturaDTOBuilder ativoResult2 = viaturaDTOBuilder4.ativo(true);
        ViaturaDTO.ViaturaDTOBuilder dataAtualizacaoResult2 = ativoResult2
                .dataAtualizacao(LocalDate.of(1970, 1, 1).atStartOfDay());
        ViaturaDTO.ViaturaDTOBuilder ultimoOdometroResult2 = dataAtualizacaoResult2
                .dataInclusao(LocalDate.of(1970, 1, 1).atStartOfDay())
                .id(1L)
                .nrSei("Nr Sei")
                .placa("Placa")
                .prefixo("Prefixo")
                .renavam("Renavam")
                .status("Status")
                .tombamento("alice.liddell@example.org")
                .ultimoOdometro(10.0d);
        ViaturaDTO buildResult2 = ultimoOdometroResult2.vistoriaViatura(new ArrayList<>()).build();

        // Act and Assert
        assertNotEquals(buildResult, buildResult2);
    }

    /**
     * Method under test: {@link ViaturaDTO#equals(Object)}
     */
    @Test
    void testEquals14() {
        // Arrange
        ViaturaDTO.ViaturaDTOBuilder viaturaDTOBuilder = mock(ViaturaDTO.ViaturaDTOBuilder.class);
        when(viaturaDTOBuilder.dataInclusao(Mockito.<LocalDateTime>any())).thenReturn(ViaturaDTO.builder());
        ViaturaDTO.ViaturaDTOBuilder viaturaDTOBuilder2 = mock(ViaturaDTO.ViaturaDTOBuilder.class);
        when(viaturaDTOBuilder2.dataAtualizacao(Mockito.<LocalDateTime>any())).thenReturn(viaturaDTOBuilder);
        ViaturaDTO.ViaturaDTOBuilder viaturaDTOBuilder3 = mock(ViaturaDTO.ViaturaDTOBuilder.class);
        when(viaturaDTOBuilder3.ativo(Mockito.<Boolean>any())).thenReturn(viaturaDTOBuilder2);
        ViaturaDTO.ViaturaDTOBuilder ativoResult = viaturaDTOBuilder3.ativo(true);
        ViaturaDTO.ViaturaDTOBuilder dataAtualizacaoResult = ativoResult
                .dataAtualizacao(LocalDate.of(1970, 1, 1).atStartOfDay());
        ViaturaDTO.ViaturaDTOBuilder ultimoOdometroResult = dataAtualizacaoResult
                .dataInclusao(LocalDate.of(1970, 1, 1).atStartOfDay())
                .id(1L)
                .nrSei("Nr Sei")
                .placa("Placa")
                .prefixo("Nr Sei")
                .renavam("Renavam")
                .status("Status")
                .tombamento("alice.liddell@example.org")
                .ultimoOdometro(10.0d);
        ViaturaDTO buildResult = ultimoOdometroResult.vistoriaViatura(new ArrayList<>()).build();
        ViaturaDTO.ViaturaDTOBuilder viaturaDTOBuilder4 = mock(ViaturaDTO.ViaturaDTOBuilder.class);
        when(viaturaDTOBuilder4.ativo(Mockito.<Boolean>any())).thenReturn(ViaturaDTO.builder());
        ViaturaDTO.ViaturaDTOBuilder ativoResult2 = viaturaDTOBuilder4.ativo(true);
        ViaturaDTO.ViaturaDTOBuilder dataAtualizacaoResult2 = ativoResult2
                .dataAtualizacao(LocalDate.of(1970, 1, 1).atStartOfDay());
        ViaturaDTO.ViaturaDTOBuilder ultimoOdometroResult2 = dataAtualizacaoResult2
                .dataInclusao(LocalDate.of(1970, 1, 1).atStartOfDay())
                .id(1L)
                .nrSei("Nr Sei")
                .placa("Placa")
                .prefixo("Prefixo")
                .renavam("Renavam")
                .status("Status")
                .tombamento("alice.liddell@example.org")
                .ultimoOdometro(10.0d);
        ViaturaDTO buildResult2 = ultimoOdometroResult2.vistoriaViatura(new ArrayList<>()).build();

        // Act and Assert
        assertNotEquals(buildResult, buildResult2);
    }

    /**
     * Method under test: {@link ViaturaDTO#equals(Object)}
     */
    @Test
    void testEquals15() {
        // Arrange
        ViaturaDTO.ViaturaDTOBuilder viaturaDTOBuilder = mock(ViaturaDTO.ViaturaDTOBuilder.class);
        when(viaturaDTOBuilder.dataInclusao(Mockito.<LocalDateTime>any())).thenReturn(ViaturaDTO.builder());
        ViaturaDTO.ViaturaDTOBuilder viaturaDTOBuilder2 = mock(ViaturaDTO.ViaturaDTOBuilder.class);
        when(viaturaDTOBuilder2.dataAtualizacao(Mockito.<LocalDateTime>any())).thenReturn(viaturaDTOBuilder);
        ViaturaDTO.ViaturaDTOBuilder viaturaDTOBuilder3 = mock(ViaturaDTO.ViaturaDTOBuilder.class);
        when(viaturaDTOBuilder3.ativo(Mockito.<Boolean>any())).thenReturn(viaturaDTOBuilder2);
        ViaturaDTO.ViaturaDTOBuilder ativoResult = viaturaDTOBuilder3.ativo(true);
        ViaturaDTO.ViaturaDTOBuilder dataAtualizacaoResult = ativoResult
                .dataAtualizacao(LocalDate.of(1970, 1, 1).atStartOfDay());
        ViaturaDTO.ViaturaDTOBuilder ultimoOdometroResult = dataAtualizacaoResult
                .dataInclusao(LocalDate.of(1970, 1, 1).atStartOfDay())
                .id(1L)
                .nrSei("Nr Sei")
                .placa("Placa")
                .prefixo(null)
                .renavam("Renavam")
                .status("Status")
                .tombamento("alice.liddell@example.org")
                .ultimoOdometro(10.0d);
        ViaturaDTO buildResult = ultimoOdometroResult.vistoriaViatura(new ArrayList<>()).build();
        ViaturaDTO.ViaturaDTOBuilder viaturaDTOBuilder4 = mock(ViaturaDTO.ViaturaDTOBuilder.class);
        when(viaturaDTOBuilder4.ativo(Mockito.<Boolean>any())).thenReturn(ViaturaDTO.builder());
        ViaturaDTO.ViaturaDTOBuilder ativoResult2 = viaturaDTOBuilder4.ativo(true);
        ViaturaDTO.ViaturaDTOBuilder dataAtualizacaoResult2 = ativoResult2
                .dataAtualizacao(LocalDate.of(1970, 1, 1).atStartOfDay());
        ViaturaDTO.ViaturaDTOBuilder ultimoOdometroResult2 = dataAtualizacaoResult2
                .dataInclusao(LocalDate.of(1970, 1, 1).atStartOfDay())
                .id(1L)
                .nrSei("Nr Sei")
                .placa("Placa")
                .prefixo("Prefixo")
                .renavam("Renavam")
                .status("Status")
                .tombamento("alice.liddell@example.org")
                .ultimoOdometro(10.0d);
        ViaturaDTO buildResult2 = ultimoOdometroResult2.vistoriaViatura(new ArrayList<>()).build();

        // Act and Assert
        assertNotEquals(buildResult, buildResult2);
    }

    /**
     * Method under test: {@link ViaturaDTO#equals(Object)}
     */
    @Test
    void testEquals16() {
        // Arrange
        ViaturaDTO.ViaturaDTOBuilder viaturaDTOBuilder = mock(ViaturaDTO.ViaturaDTOBuilder.class);
        when(viaturaDTOBuilder.dataInclusao(Mockito.<LocalDateTime>any())).thenReturn(ViaturaDTO.builder());
        ViaturaDTO.ViaturaDTOBuilder viaturaDTOBuilder2 = mock(ViaturaDTO.ViaturaDTOBuilder.class);
        when(viaturaDTOBuilder2.dataAtualizacao(Mockito.<LocalDateTime>any())).thenReturn(viaturaDTOBuilder);
        ViaturaDTO.ViaturaDTOBuilder viaturaDTOBuilder3 = mock(ViaturaDTO.ViaturaDTOBuilder.class);
        when(viaturaDTOBuilder3.ativo(Mockito.<Boolean>any())).thenReturn(viaturaDTOBuilder2);
        ViaturaDTO.ViaturaDTOBuilder ativoResult = viaturaDTOBuilder3.ativo(true);
        ViaturaDTO.ViaturaDTOBuilder dataAtualizacaoResult = ativoResult
                .dataAtualizacao(LocalDate.of(1970, 1, 1).atStartOfDay());
        ViaturaDTO.ViaturaDTOBuilder ultimoOdometroResult = dataAtualizacaoResult
                .dataInclusao(LocalDate.of(1970, 1, 1).atStartOfDay())
                .id(1L)
                .nrSei("Nr Sei")
                .placa("Placa")
                .prefixo("Prefixo")
                .renavam("Prefixo")
                .status("Status")
                .tombamento("alice.liddell@example.org")
                .ultimoOdometro(10.0d);
        ViaturaDTO buildResult = ultimoOdometroResult.vistoriaViatura(new ArrayList<>()).build();
        ViaturaDTO.ViaturaDTOBuilder viaturaDTOBuilder4 = mock(ViaturaDTO.ViaturaDTOBuilder.class);
        when(viaturaDTOBuilder4.ativo(Mockito.<Boolean>any())).thenReturn(ViaturaDTO.builder());
        ViaturaDTO.ViaturaDTOBuilder ativoResult2 = viaturaDTOBuilder4.ativo(true);
        ViaturaDTO.ViaturaDTOBuilder dataAtualizacaoResult2 = ativoResult2
                .dataAtualizacao(LocalDate.of(1970, 1, 1).atStartOfDay());
        ViaturaDTO.ViaturaDTOBuilder ultimoOdometroResult2 = dataAtualizacaoResult2
                .dataInclusao(LocalDate.of(1970, 1, 1).atStartOfDay())
                .id(1L)
                .nrSei("Nr Sei")
                .placa("Placa")
                .prefixo("Prefixo")
                .renavam("Renavam")
                .status("Status")
                .tombamento("alice.liddell@example.org")
                .ultimoOdometro(10.0d);
        ViaturaDTO buildResult2 = ultimoOdometroResult2.vistoriaViatura(new ArrayList<>()).build();

        // Act and Assert
        assertNotEquals(buildResult, buildResult2);
    }

    /**
     * Method under test: {@link ViaturaDTO#equals(Object)}
     */
    @Test
    void testEquals17() {
        // Arrange
        ViaturaDTO.ViaturaDTOBuilder viaturaDTOBuilder = mock(ViaturaDTO.ViaturaDTOBuilder.class);
        when(viaturaDTOBuilder.dataInclusao(Mockito.<LocalDateTime>any())).thenReturn(ViaturaDTO.builder());
        ViaturaDTO.ViaturaDTOBuilder viaturaDTOBuilder2 = mock(ViaturaDTO.ViaturaDTOBuilder.class);
        when(viaturaDTOBuilder2.dataAtualizacao(Mockito.<LocalDateTime>any())).thenReturn(viaturaDTOBuilder);
        ViaturaDTO.ViaturaDTOBuilder viaturaDTOBuilder3 = mock(ViaturaDTO.ViaturaDTOBuilder.class);
        when(viaturaDTOBuilder3.ativo(Mockito.<Boolean>any())).thenReturn(viaturaDTOBuilder2);
        ViaturaDTO.ViaturaDTOBuilder ativoResult = viaturaDTOBuilder3.ativo(true);
        ViaturaDTO.ViaturaDTOBuilder dataAtualizacaoResult = ativoResult
                .dataAtualizacao(LocalDate.of(1970, 1, 1).atStartOfDay());
        ViaturaDTO.ViaturaDTOBuilder ultimoOdometroResult = dataAtualizacaoResult
                .dataInclusao(LocalDate.of(1970, 1, 1).atStartOfDay())
                .id(1L)
                .nrSei("Nr Sei")
                .placa("Placa")
                .prefixo("Prefixo")
                .renavam(null)
                .status("Status")
                .tombamento("alice.liddell@example.org")
                .ultimoOdometro(10.0d);
        ViaturaDTO buildResult = ultimoOdometroResult.vistoriaViatura(new ArrayList<>()).build();
        ViaturaDTO.ViaturaDTOBuilder viaturaDTOBuilder4 = mock(ViaturaDTO.ViaturaDTOBuilder.class);
        when(viaturaDTOBuilder4.ativo(Mockito.<Boolean>any())).thenReturn(ViaturaDTO.builder());
        ViaturaDTO.ViaturaDTOBuilder ativoResult2 = viaturaDTOBuilder4.ativo(true);
        ViaturaDTO.ViaturaDTOBuilder dataAtualizacaoResult2 = ativoResult2
                .dataAtualizacao(LocalDate.of(1970, 1, 1).atStartOfDay());
        ViaturaDTO.ViaturaDTOBuilder ultimoOdometroResult2 = dataAtualizacaoResult2
                .dataInclusao(LocalDate.of(1970, 1, 1).atStartOfDay())
                .id(1L)
                .nrSei("Nr Sei")
                .placa("Placa")
                .prefixo("Prefixo")
                .renavam("Renavam")
                .status("Status")
                .tombamento("alice.liddell@example.org")
                .ultimoOdometro(10.0d);
        ViaturaDTO buildResult2 = ultimoOdometroResult2.vistoriaViatura(new ArrayList<>()).build();

        // Act and Assert
        assertNotEquals(buildResult, buildResult2);
    }

    /**
     * Method under test: {@link ViaturaDTO#equals(Object)}
     */
    @Test
    void testEquals18() {
        // Arrange
        ViaturaDTO.ViaturaDTOBuilder viaturaDTOBuilder = mock(ViaturaDTO.ViaturaDTOBuilder.class);
        when(viaturaDTOBuilder.dataInclusao(Mockito.<LocalDateTime>any())).thenReturn(ViaturaDTO.builder());
        ViaturaDTO.ViaturaDTOBuilder viaturaDTOBuilder2 = mock(ViaturaDTO.ViaturaDTOBuilder.class);
        when(viaturaDTOBuilder2.dataAtualizacao(Mockito.<LocalDateTime>any())).thenReturn(viaturaDTOBuilder);
        ViaturaDTO.ViaturaDTOBuilder viaturaDTOBuilder3 = mock(ViaturaDTO.ViaturaDTOBuilder.class);
        when(viaturaDTOBuilder3.ativo(Mockito.<Boolean>any())).thenReturn(viaturaDTOBuilder2);
        ViaturaDTO.ViaturaDTOBuilder ativoResult = viaturaDTOBuilder3.ativo(true);
        ViaturaDTO.ViaturaDTOBuilder dataAtualizacaoResult = ativoResult
                .dataAtualizacao(LocalDate.of(1970, 1, 1).atStartOfDay());
        ViaturaDTO.ViaturaDTOBuilder ultimoOdometroResult = dataAtualizacaoResult
                .dataInclusao(LocalDate.of(1970, 1, 1).atStartOfDay())
                .id(1L)
                .nrSei("Nr Sei")
                .placa("Placa")
                .prefixo("Prefixo")
                .renavam("Renavam")
                .status("Prefixo")
                .tombamento("alice.liddell@example.org")
                .ultimoOdometro(10.0d);
        ViaturaDTO buildResult = ultimoOdometroResult.vistoriaViatura(new ArrayList<>()).build();
        ViaturaDTO.ViaturaDTOBuilder viaturaDTOBuilder4 = mock(ViaturaDTO.ViaturaDTOBuilder.class);
        when(viaturaDTOBuilder4.ativo(Mockito.<Boolean>any())).thenReturn(ViaturaDTO.builder());
        ViaturaDTO.ViaturaDTOBuilder ativoResult2 = viaturaDTOBuilder4.ativo(true);
        ViaturaDTO.ViaturaDTOBuilder dataAtualizacaoResult2 = ativoResult2
                .dataAtualizacao(LocalDate.of(1970, 1, 1).atStartOfDay());
        ViaturaDTO.ViaturaDTOBuilder ultimoOdometroResult2 = dataAtualizacaoResult2
                .dataInclusao(LocalDate.of(1970, 1, 1).atStartOfDay())
                .id(1L)
                .nrSei("Nr Sei")
                .placa("Placa")
                .prefixo("Prefixo")
                .renavam("Renavam")
                .status("Status")
                .tombamento("alice.liddell@example.org")
                .ultimoOdometro(10.0d);
        ViaturaDTO buildResult2 = ultimoOdometroResult2.vistoriaViatura(new ArrayList<>()).build();

        // Act and Assert
        assertNotEquals(buildResult, buildResult2);
    }

    /**
     * Method under test: {@link ViaturaDTO#equals(Object)}
     */
    @Test
    void testEquals19() {
        // Arrange
        ViaturaDTO.ViaturaDTOBuilder viaturaDTOBuilder = mock(ViaturaDTO.ViaturaDTOBuilder.class);
        when(viaturaDTOBuilder.dataInclusao(Mockito.<LocalDateTime>any())).thenReturn(ViaturaDTO.builder());
        ViaturaDTO.ViaturaDTOBuilder viaturaDTOBuilder2 = mock(ViaturaDTO.ViaturaDTOBuilder.class);
        when(viaturaDTOBuilder2.dataAtualizacao(Mockito.<LocalDateTime>any())).thenReturn(viaturaDTOBuilder);
        ViaturaDTO.ViaturaDTOBuilder viaturaDTOBuilder3 = mock(ViaturaDTO.ViaturaDTOBuilder.class);
        when(viaturaDTOBuilder3.ativo(Mockito.<Boolean>any())).thenReturn(viaturaDTOBuilder2);
        ViaturaDTO.ViaturaDTOBuilder ativoResult = viaturaDTOBuilder3.ativo(true);
        ViaturaDTO.ViaturaDTOBuilder dataAtualizacaoResult = ativoResult
                .dataAtualizacao(LocalDate.of(1970, 1, 1).atStartOfDay());
        ViaturaDTO.ViaturaDTOBuilder ultimoOdometroResult = dataAtualizacaoResult
                .dataInclusao(LocalDate.of(1970, 1, 1).atStartOfDay())
                .id(1L)
                .nrSei("Nr Sei")
                .placa("Placa")
                .prefixo("Prefixo")
                .renavam("Renavam")
                .status(null)
                .tombamento("alice.liddell@example.org")
                .ultimoOdometro(10.0d);
        ViaturaDTO buildResult = ultimoOdometroResult.vistoriaViatura(new ArrayList<>()).build();
        ViaturaDTO.ViaturaDTOBuilder viaturaDTOBuilder4 = mock(ViaturaDTO.ViaturaDTOBuilder.class);
        when(viaturaDTOBuilder4.ativo(Mockito.<Boolean>any())).thenReturn(ViaturaDTO.builder());
        ViaturaDTO.ViaturaDTOBuilder ativoResult2 = viaturaDTOBuilder4.ativo(true);
        ViaturaDTO.ViaturaDTOBuilder dataAtualizacaoResult2 = ativoResult2
                .dataAtualizacao(LocalDate.of(1970, 1, 1).atStartOfDay());
        ViaturaDTO.ViaturaDTOBuilder ultimoOdometroResult2 = dataAtualizacaoResult2
                .dataInclusao(LocalDate.of(1970, 1, 1).atStartOfDay())
                .id(1L)
                .nrSei("Nr Sei")
                .placa("Placa")
                .prefixo("Prefixo")
                .renavam("Renavam")
                .status("Status")
                .tombamento("alice.liddell@example.org")
                .ultimoOdometro(10.0d);
        ViaturaDTO buildResult2 = ultimoOdometroResult2.vistoriaViatura(new ArrayList<>()).build();

        // Act and Assert
        assertNotEquals(buildResult, buildResult2);
    }

    /**
     * Method under test: {@link ViaturaDTO#equals(Object)}
     */
    @Test
    void testEquals20() {
        // Arrange
        ViaturaDTO.ViaturaDTOBuilder viaturaDTOBuilder = mock(ViaturaDTO.ViaturaDTOBuilder.class);
        when(viaturaDTOBuilder.dataInclusao(Mockito.<LocalDateTime>any())).thenReturn(ViaturaDTO.builder());
        ViaturaDTO.ViaturaDTOBuilder viaturaDTOBuilder2 = mock(ViaturaDTO.ViaturaDTOBuilder.class);
        when(viaturaDTOBuilder2.dataAtualizacao(Mockito.<LocalDateTime>any())).thenReturn(viaturaDTOBuilder);
        ViaturaDTO.ViaturaDTOBuilder viaturaDTOBuilder3 = mock(ViaturaDTO.ViaturaDTOBuilder.class);
        when(viaturaDTOBuilder3.ativo(Mockito.<Boolean>any())).thenReturn(viaturaDTOBuilder2);
        ViaturaDTO.ViaturaDTOBuilder ativoResult = viaturaDTOBuilder3.ativo(true);
        ViaturaDTO.ViaturaDTOBuilder dataAtualizacaoResult = ativoResult
                .dataAtualizacao(LocalDate.of(1970, 1, 1).atStartOfDay());
        ViaturaDTO.ViaturaDTOBuilder ultimoOdometroResult = dataAtualizacaoResult
                .dataInclusao(LocalDate.of(1970, 1, 1).atStartOfDay())
                .id(1L)
                .nrSei("Nr Sei")
                .placa("Placa")
                .prefixo("Prefixo")
                .renavam("Renavam")
                .status("Status")
                .tombamento("Prefixo")
                .ultimoOdometro(10.0d);
        ViaturaDTO buildResult = ultimoOdometroResult.vistoriaViatura(new ArrayList<>()).build();
        ViaturaDTO.ViaturaDTOBuilder viaturaDTOBuilder4 = mock(ViaturaDTO.ViaturaDTOBuilder.class);
        when(viaturaDTOBuilder4.ativo(Mockito.<Boolean>any())).thenReturn(ViaturaDTO.builder());
        ViaturaDTO.ViaturaDTOBuilder ativoResult2 = viaturaDTOBuilder4.ativo(true);
        ViaturaDTO.ViaturaDTOBuilder dataAtualizacaoResult2 = ativoResult2
                .dataAtualizacao(LocalDate.of(1970, 1, 1).atStartOfDay());
        ViaturaDTO.ViaturaDTOBuilder ultimoOdometroResult2 = dataAtualizacaoResult2
                .dataInclusao(LocalDate.of(1970, 1, 1).atStartOfDay())
                .id(1L)
                .nrSei("Nr Sei")
                .placa("Placa")
                .prefixo("Prefixo")
                .renavam("Renavam")
                .status("Status")
                .tombamento("alice.liddell@example.org")
                .ultimoOdometro(10.0d);
        ViaturaDTO buildResult2 = ultimoOdometroResult2.vistoriaViatura(new ArrayList<>()).build();

        // Act and Assert
        assertNotEquals(buildResult, buildResult2);
    }

    /**
     * Method under test: {@link ViaturaDTO#equals(Object)}
     */
    @Test
    void testEquals21() {
        // Arrange
        ViaturaDTO.ViaturaDTOBuilder viaturaDTOBuilder = mock(ViaturaDTO.ViaturaDTOBuilder.class);
        when(viaturaDTOBuilder.dataInclusao(Mockito.<LocalDateTime>any())).thenReturn(ViaturaDTO.builder());
        ViaturaDTO.ViaturaDTOBuilder viaturaDTOBuilder2 = mock(ViaturaDTO.ViaturaDTOBuilder.class);
        when(viaturaDTOBuilder2.dataAtualizacao(Mockito.<LocalDateTime>any())).thenReturn(viaturaDTOBuilder);
        ViaturaDTO.ViaturaDTOBuilder viaturaDTOBuilder3 = mock(ViaturaDTO.ViaturaDTOBuilder.class);
        when(viaturaDTOBuilder3.ativo(Mockito.<Boolean>any())).thenReturn(viaturaDTOBuilder2);
        ViaturaDTO.ViaturaDTOBuilder ativoResult = viaturaDTOBuilder3.ativo(true);
        ViaturaDTO.ViaturaDTOBuilder dataAtualizacaoResult = ativoResult
                .dataAtualizacao(LocalDate.of(1970, 1, 1).atStartOfDay());
        ViaturaDTO.ViaturaDTOBuilder ultimoOdometroResult = dataAtualizacaoResult
                .dataInclusao(LocalDate.of(1970, 1, 1).atStartOfDay())
                .id(1L)
                .nrSei("Nr Sei")
                .placa("Placa")
                .prefixo("Prefixo")
                .renavam("Renavam")
                .status("Status")
                .tombamento(null)
                .ultimoOdometro(10.0d);
        ViaturaDTO buildResult = ultimoOdometroResult.vistoriaViatura(new ArrayList<>()).build();
        ViaturaDTO.ViaturaDTOBuilder viaturaDTOBuilder4 = mock(ViaturaDTO.ViaturaDTOBuilder.class);
        when(viaturaDTOBuilder4.ativo(Mockito.<Boolean>any())).thenReturn(ViaturaDTO.builder());
        ViaturaDTO.ViaturaDTOBuilder ativoResult2 = viaturaDTOBuilder4.ativo(true);
        ViaturaDTO.ViaturaDTOBuilder dataAtualizacaoResult2 = ativoResult2
                .dataAtualizacao(LocalDate.of(1970, 1, 1).atStartOfDay());
        ViaturaDTO.ViaturaDTOBuilder ultimoOdometroResult2 = dataAtualizacaoResult2
                .dataInclusao(LocalDate.of(1970, 1, 1).atStartOfDay())
                .id(1L)
                .nrSei("Nr Sei")
                .placa("Placa")
                .prefixo("Prefixo")
                .renavam("Renavam")
                .status("Status")
                .tombamento("alice.liddell@example.org")
                .ultimoOdometro(10.0d);
        ViaturaDTO buildResult2 = ultimoOdometroResult2.vistoriaViatura(new ArrayList<>()).build();

        // Act and Assert
        assertNotEquals(buildResult, buildResult2);
    }

    /**
     * Method under test: {@link ViaturaDTO#equals(Object)}
     */
    @Test
    void testEquals22() {
        // Arrange
        ViaturaDTO.ViaturaDTOBuilder builderResult = ViaturaDTO.builder();
        builderResult.ativo(true);
        ViaturaDTO.ViaturaDTOBuilder viaturaDTOBuilder = mock(ViaturaDTO.ViaturaDTOBuilder.class);
        when(viaturaDTOBuilder.dataInclusao(Mockito.<LocalDateTime>any())).thenReturn(builderResult);
        ViaturaDTO.ViaturaDTOBuilder viaturaDTOBuilder2 = mock(ViaturaDTO.ViaturaDTOBuilder.class);
        when(viaturaDTOBuilder2.dataAtualizacao(Mockito.<LocalDateTime>any())).thenReturn(viaturaDTOBuilder);
        ViaturaDTO.ViaturaDTOBuilder viaturaDTOBuilder3 = mock(ViaturaDTO.ViaturaDTOBuilder.class);
        when(viaturaDTOBuilder3.ativo(Mockito.<Boolean>any())).thenReturn(viaturaDTOBuilder2);
        ViaturaDTO.ViaturaDTOBuilder ativoResult = viaturaDTOBuilder3.ativo(true);
        ViaturaDTO.ViaturaDTOBuilder dataAtualizacaoResult = ativoResult
                .dataAtualizacao(LocalDate.of(1970, 1, 1).atStartOfDay());
        ViaturaDTO.ViaturaDTOBuilder ultimoOdometroResult = dataAtualizacaoResult
                .dataInclusao(LocalDate.of(1970, 1, 1).atStartOfDay())
                .id(1L)
                .nrSei("Nr Sei")
                .placa("Placa")
                .prefixo("Prefixo")
                .renavam("Renavam")
                .status("Status")
                .tombamento("alice.liddell@example.org")
                .ultimoOdometro(10.0d);
        ViaturaDTO buildResult = ultimoOdometroResult.vistoriaViatura(new ArrayList<>()).build();
        ViaturaDTO.ViaturaDTOBuilder viaturaDTOBuilder4 = mock(ViaturaDTO.ViaturaDTOBuilder.class);
        when(viaturaDTOBuilder4.ativo(Mockito.<Boolean>any())).thenReturn(ViaturaDTO.builder());
        ViaturaDTO.ViaturaDTOBuilder ativoResult2 = viaturaDTOBuilder4.ativo(true);
        ViaturaDTO.ViaturaDTOBuilder dataAtualizacaoResult2 = ativoResult2
                .dataAtualizacao(LocalDate.of(1970, 1, 1).atStartOfDay());
        ViaturaDTO.ViaturaDTOBuilder ultimoOdometroResult2 = dataAtualizacaoResult2
                .dataInclusao(LocalDate.of(1970, 1, 1).atStartOfDay())
                .id(1L)
                .nrSei("Nr Sei")
                .placa("Placa")
                .prefixo("Prefixo")
                .renavam("Renavam")
                .status("Status")
                .tombamento("alice.liddell@example.org")
                .ultimoOdometro(10.0d);
        ViaturaDTO buildResult2 = ultimoOdometroResult2.vistoriaViatura(new ArrayList<>()).build();

        // Act and Assert
        assertNotEquals(buildResult, buildResult2);
    }

    /**
     * Method under test: {@link ViaturaDTO#equals(Object)}
     */
    @Test
    void testEquals23() {
        // Arrange
        ViaturaDTO.ViaturaDTOBuilder viaturaDTOBuilder = mock(ViaturaDTO.ViaturaDTOBuilder.class);
        when(viaturaDTOBuilder.dataInclusao(Mockito.<LocalDateTime>any())).thenReturn(ViaturaDTO.builder());
        ViaturaDTO.ViaturaDTOBuilder viaturaDTOBuilder2 = mock(ViaturaDTO.ViaturaDTOBuilder.class);
        when(viaturaDTOBuilder2.dataAtualizacao(Mockito.<LocalDateTime>any())).thenReturn(viaturaDTOBuilder);
        ViaturaDTO.ViaturaDTOBuilder viaturaDTOBuilder3 = mock(ViaturaDTO.ViaturaDTOBuilder.class);
        when(viaturaDTOBuilder3.ativo(Mockito.<Boolean>any())).thenReturn(viaturaDTOBuilder2);
        ViaturaDTO.ViaturaDTOBuilder ativoResult = viaturaDTOBuilder3.ativo(true);
        ViaturaDTO.ViaturaDTOBuilder dataAtualizacaoResult = ativoResult
                .dataAtualizacao(LocalDate.of(1970, 1, 1).atStartOfDay());
        ViaturaDTO.ViaturaDTOBuilder ultimoOdometroResult = dataAtualizacaoResult
                .dataInclusao(LocalDate.of(1970, 1, 1).atStartOfDay())
                .id(1L)
                .nrSei(null)
                .placa("Placa")
                .prefixo("Prefixo")
                .renavam("Renavam")
                .status("Status")
                .tombamento("alice.liddell@example.org")
                .ultimoOdometro(10.0d);
        ViaturaDTO buildResult = ultimoOdometroResult.vistoriaViatura(new ArrayList<>()).build();
        ViaturaDTO.ViaturaDTOBuilder viaturaDTOBuilder4 = mock(ViaturaDTO.ViaturaDTOBuilder.class);
        when(viaturaDTOBuilder4.ativo(Mockito.<Boolean>any())).thenReturn(ViaturaDTO.builder());
        ViaturaDTO.ViaturaDTOBuilder ativoResult2 = viaturaDTOBuilder4.ativo(true);
        ViaturaDTO.ViaturaDTOBuilder dataAtualizacaoResult2 = ativoResult2
                .dataAtualizacao(LocalDate.of(1970, 1, 1).atStartOfDay());
        ViaturaDTO.ViaturaDTOBuilder ultimoOdometroResult2 = dataAtualizacaoResult2
                .dataInclusao(LocalDate.of(1970, 1, 1).atStartOfDay())
                .id(1L)
                .nrSei(null)
                .placa("Placa")
                .prefixo("Prefixo")
                .renavam("Renavam")
                .status("Status")
                .tombamento("alice.liddell@example.org")
                .ultimoOdometro(10.0d);
        ViaturaDTO buildResult2 = ultimoOdometroResult2.vistoriaViatura(new ArrayList<>()).build();

        // Act and Assert
        assertNotEquals(buildResult, buildResult2);
    }

    /**
     * Methods under test:
     * <ul>
     *   <li>{@link ViaturaDTO#equals(Object)}
     *   <li>{@link ViaturaDTO#hashCode()}
     * </ul>
     */
    @Test
    void testEqualsAndHashCode() {
        // Arrange
        ViaturaDTO.ViaturaDTOBuilder ativoResult = ViaturaDTO.builder().ativo(true);
        ViaturaDTO.ViaturaDTOBuilder dataAtualizacaoResult = ativoResult
                .dataAtualizacao(LocalDate.of(1970, 1, 1).atStartOfDay());
        ViaturaDTO.ViaturaDTOBuilder ultimoOdometroResult = dataAtualizacaoResult
                .dataInclusao(LocalDate.of(1970, 1, 1).atStartOfDay())
                .id(1L)
                .nrSei("Nr Sei")
                .placa("Placa")
                .prefixo("Prefixo")
                .renavam("Renavam")
                .status("Status")
                .tombamento("alice.liddell@example.org")
                .ultimoOdometro(10.0d);
        ViaturaDTO buildResult = ultimoOdometroResult.vistoriaViatura(new ArrayList<>()).build();

        // Act and Assert
        assertEquals(buildResult, buildResult);
        int expectedHashCodeResult = buildResult.hashCode();
        assertEquals(expectedHashCodeResult, buildResult.hashCode());
    }

    /**
     * Methods under test:
     * <ul>
     *   <li>{@link ViaturaDTO#equals(Object)}
     *   <li>{@link ViaturaDTO#hashCode()}
     * </ul>
     */
    @Test
    void testEqualsAndHashCode2() {
        // Arrange
        ViaturaDTO.ViaturaDTOBuilder ativoResult = ViaturaDTO.builder().ativo(true);
        ViaturaDTO.ViaturaDTOBuilder dataAtualizacaoResult = ativoResult
                .dataAtualizacao(LocalDate.of(1970, 1, 1).atStartOfDay());
        ViaturaDTO.ViaturaDTOBuilder ultimoOdometroResult = dataAtualizacaoResult
                .dataInclusao(LocalDate.of(1970, 1, 1).atStartOfDay())
                .id(1L)
                .nrSei("Nr Sei")
                .placa("Placa")
                .prefixo("Prefixo")
                .renavam("Renavam")
                .status("Status")
                .tombamento("alice.liddell@example.org")
                .ultimoOdometro(10.0d);
        ViaturaDTO buildResult = ultimoOdometroResult.vistoriaViatura(new ArrayList<>()).build();
        ViaturaDTO.ViaturaDTOBuilder ativoResult2 = ViaturaDTO.builder().ativo(true);
        ViaturaDTO.ViaturaDTOBuilder dataAtualizacaoResult2 = ativoResult2
                .dataAtualizacao(LocalDate.of(1970, 1, 1).atStartOfDay());
        ViaturaDTO.ViaturaDTOBuilder ultimoOdometroResult2 = dataAtualizacaoResult2
                .dataInclusao(LocalDate.of(1970, 1, 1).atStartOfDay())
                .id(1L)
                .nrSei("Nr Sei")
                .placa("Placa")
                .prefixo("Prefixo")
                .renavam("Renavam")
                .status("Status")
                .tombamento("alice.liddell@example.org")
                .ultimoOdometro(10.0d);
        ViaturaDTO buildResult2 = ultimoOdometroResult2.vistoriaViatura(new ArrayList<>()).build();

        // Act and Assert
        assertEquals(buildResult, buildResult2);
        int expectedHashCodeResult = buildResult.hashCode();
        assertEquals(expectedHashCodeResult, buildResult2.hashCode());
    }

    /**
     * Methods under test:
     * <ul>
     *   <li>{@link ViaturaDTO#equals(Object)}
     *   <li>{@link ViaturaDTO#hashCode()}
     * </ul>
     */
    @Test
    void testEqualsAndHashCode3() {
        // Arrange
        ViaturaDTO.ViaturaDTOBuilder viaturaDTOBuilder = mock(ViaturaDTO.ViaturaDTOBuilder.class);
        when(viaturaDTOBuilder.ativo(Mockito.<Boolean>any())).thenReturn(ViaturaDTO.builder());
        ViaturaDTO.ViaturaDTOBuilder ativoResult = viaturaDTOBuilder.ativo(true);
        ViaturaDTO.ViaturaDTOBuilder dataAtualizacaoResult = ativoResult
                .dataAtualizacao(LocalDate.of(1970, 1, 1).atStartOfDay());
        ViaturaDTO.ViaturaDTOBuilder ultimoOdometroResult = dataAtualizacaoResult
                .dataInclusao(LocalDate.of(1970, 1, 1).atStartOfDay())
                .id(1L)
                .nrSei("Nr Sei")
                .placa("Placa")
                .prefixo("Prefixo")
                .renavam("Renavam")
                .status("Status")
                .tombamento("alice.liddell@example.org")
                .ultimoOdometro(10.0d);
        ViaturaDTO buildResult = ultimoOdometroResult.vistoriaViatura(new ArrayList<>()).build();
        ViaturaDTO.ViaturaDTOBuilder viaturaDTOBuilder2 = mock(ViaturaDTO.ViaturaDTOBuilder.class);
        when(viaturaDTOBuilder2.ativo(Mockito.<Boolean>any())).thenReturn(ViaturaDTO.builder());
        ViaturaDTO.ViaturaDTOBuilder ativoResult2 = viaturaDTOBuilder2.ativo(true);
        ViaturaDTO.ViaturaDTOBuilder dataAtualizacaoResult2 = ativoResult2
                .dataAtualizacao(LocalDate.of(1970, 1, 1).atStartOfDay());
        ViaturaDTO.ViaturaDTOBuilder ultimoOdometroResult2 = dataAtualizacaoResult2
                .dataInclusao(LocalDate.of(1970, 1, 1).atStartOfDay())
                .id(1L)
                .nrSei("Nr Sei")
                .placa("Placa")
                .prefixo("Prefixo")
                .renavam("Renavam")
                .status("Status")
                .tombamento("alice.liddell@example.org")
                .ultimoOdometro(10.0d);
        ViaturaDTO buildResult2 = ultimoOdometroResult2.vistoriaViatura(new ArrayList<>()).build();

        // Act and Assert
        assertEquals(buildResult, buildResult2);
        int expectedHashCodeResult = buildResult.hashCode();
        assertEquals(expectedHashCodeResult, buildResult2.hashCode());
    }

    /**
     * Methods under test:
     * <ul>
     *   <li>
     * {@link ViaturaDTO#ViaturaDTO(Long, String, String, String, String, String, String, LocalDateTime, LocalDateTime, Double, List, Boolean)}
     *   <li>{@link ViaturaDTO#setAtivo(Boolean)}
     *   <li>{@link ViaturaDTO#setDataAtualizacao(LocalDateTime)}
     *   <li>{@link ViaturaDTO#setDataInclusao(LocalDateTime)}
     *   <li>{@link ViaturaDTO#setId(Long)}
     *   <li>{@link ViaturaDTO#setNrSei(String)}
     *   <li>{@link ViaturaDTO#setPlaca(String)}
     *   <li>{@link ViaturaDTO#setPrefixo(String)}
     *   <li>{@link ViaturaDTO#setRenavam(String)}
     *   <li>{@link ViaturaDTO#setStatus(String)}
     *   <li>{@link ViaturaDTO#setTombamento(String)}
     *   <li>{@link ViaturaDTO#setUltimoOdometro(Double)}
     *   <li>{@link ViaturaDTO#setVistoriaViatura(List)}
     *   <li>{@link ViaturaDTO#toString()}
     *   <li>{@link ViaturaDTO#getAtivo()}
     *   <li>{@link ViaturaDTO#getDataAtualizacao()}
     *   <li>{@link ViaturaDTO#getDataInclusao()}
     *   <li>{@link ViaturaDTO#getId()}
     *   <li>{@link ViaturaDTO#getNrSei()}
     *   <li>{@link ViaturaDTO#getPlaca()}
     *   <li>{@link ViaturaDTO#getPrefixo()}
     *   <li>{@link ViaturaDTO#getRenavam()}
     *   <li>{@link ViaturaDTO#getStatus()}
     *   <li>{@link ViaturaDTO#getTombamento()}
     *   <li>{@link ViaturaDTO#getUltimoOdometro()}
     *   <li>{@link ViaturaDTO#getVistoriaViatura()}
     * </ul>
     */
    @Test
    void testGettersAndSetters() {
        // Arrange
        LocalDateTime dataInclusao = LocalDate.of(1970, 1, 1).atStartOfDay();
        LocalDateTime dataAtualizacao = LocalDate.of(1970, 1, 1).atStartOfDay();
        ArrayList<VistoriaViaturaDTO> vistoriaViatura = new ArrayList<>();

        // Act
        ViaturaDTO actualViaturaDTO = new ViaturaDTO(1L, "Prefixo", "Nr Sei", "Placa", "Status",
                "alice.liddell@example.org", "Renavam", dataInclusao, dataAtualizacao, 10.0d, vistoriaViatura, true);
        actualViaturaDTO.setAtivo(true);
        LocalDateTime dataAtualizacao2 = LocalDate.of(1970, 1, 1).atStartOfDay();
        actualViaturaDTO.setDataAtualizacao(dataAtualizacao2);
        LocalDateTime dataInclusao2 = LocalDate.of(1970, 1, 1).atStartOfDay();
        actualViaturaDTO.setDataInclusao(dataInclusao2);
        actualViaturaDTO.setId(1L);
        actualViaturaDTO.setNrSei("Nr Sei");
        actualViaturaDTO.setPlaca("Placa");
        actualViaturaDTO.setPrefixo("Prefixo");
        actualViaturaDTO.setRenavam("Renavam");
        actualViaturaDTO.setStatus("Status");
        actualViaturaDTO.setTombamento("alice.liddell@example.org");
        actualViaturaDTO.setUltimoOdometro(10.0d);
        ArrayList<VistoriaViaturaDTO> vistoriaViatura2 = new ArrayList<>();
        actualViaturaDTO.setVistoriaViatura(vistoriaViatura2);
        String actualToStringResult = actualViaturaDTO.toString();
        Boolean actualAtivo = actualViaturaDTO.getAtivo();
        LocalDateTime actualDataAtualizacao = actualViaturaDTO.getDataAtualizacao();
        LocalDateTime actualDataInclusao = actualViaturaDTO.getDataInclusao();
        Long actualId = actualViaturaDTO.getId();
        String actualNrSei = actualViaturaDTO.getNrSei();
        String actualPlaca = actualViaturaDTO.getPlaca();
        String actualPrefixo = actualViaturaDTO.getPrefixo();
        String actualRenavam = actualViaturaDTO.getRenavam();
        String actualStatus = actualViaturaDTO.getStatus();
        String actualTombamento = actualViaturaDTO.getTombamento();
        Double actualUltimoOdometro = actualViaturaDTO.getUltimoOdometro();
        List<VistoriaViaturaDTO> actualVistoriaViatura = actualViaturaDTO.getVistoriaViatura();

        // Assert that nothing has changed
        assertEquals("Nr Sei", actualNrSei);
        assertEquals("Placa", actualPlaca);
        assertEquals("Prefixo", actualPrefixo);
        assertEquals("Renavam", actualRenavam);
        assertEquals("Status", actualStatus);
        assertEquals("ViaturaDTO(id=1, prefixo=Prefixo, nrSei=Nr Sei, placa=Placa, status=Status, tombamento=alice.liddell"
                + "@example.org, renavam=Renavam, dataInclusao=1970-01-01T00:00, dataAtualizacao=1970-01-01T00:00,"
                + " ultimoOdometro=10.0, vistoriaViatura=[], ativo=true)", actualToStringResult);
        assertEquals("alice.liddell@example.org", actualTombamento);
        assertEquals(10.0d, actualUltimoOdometro.doubleValue());
        assertEquals(1L, actualId.longValue());
        assertTrue(actualAtivo);
        assertEquals(vistoriaViatura, actualVistoriaViatura);
        assertSame(vistoriaViatura2, actualVistoriaViatura);
        assertSame(dataAtualizacao2, actualDataAtualizacao);
        assertSame(dataInclusao2, actualDataInclusao);
    }
}
