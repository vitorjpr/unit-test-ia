```java
package br.gov.df.pm.sgv.service.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isA;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import br.gov.df.pm.sgv.domain.DiferencaOdometroEntity;
import br.gov.df.pm.sgv.domain.TipoEmpregoViaturaEntity;
import br.gov.df.pm.sgv.domain.TipoVistoriaEntity;
import br.gov.df.pm.sgv.domain.ViaturaEntity;
import br.gov.df.pm.sgv.domain.VistoriaViaturaEntity;
import br.gov.df.pm.sgv.domain.enums.VistoriaViaturaStatusEnum;
import br.gov.df.pm.sgv.dto.DiferencaDTO;
import br.gov.df.pm.sgv.dto.DiferencaOdometroDTO;
import br.gov.df.pm.sgv.dto.TipoVistoriaDTO;
import br.gov.df.pm.sgv.exceptions.VistoriaExceptions;
import br.gov.df.pm.sgv.repository.DiferencaOdometroRepository;
import br.gov.df.pm.sgv.repository.TipoVistoriaRepository;
import br.gov.df.pm.sgv.repository.app.ViaturaRepository;
import br.gov.df.pm.sgv.repository.app.VistoriaViaturaRepository;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ContextConfiguration(classes = {DiferencaOdometroServiceImpl.class})
@ExtendWith(SpringExtension.class)
class DiferencaOdometroServiceImplDiffblueTest {
    @MockBean
    private DiferencaOdometroRepository diferencaOdometroRepository;

    @Autowired
    private DiferencaOdometroServiceImpl diferencaOdometroServiceImpl;

    @MockBean
    private TipoVistoriaRepository tipoVistoriaRepository;

    @MockBean
    private ViaturaRepository viaturaRepository;

    @MockBean
    private VistoriaViaturaRepository vistoriaViaturaRepository;

    /**
     * Method under test: {@link DiferencaOdometroServiceImpl#buscarId(Long)}
     */
    @Test
    void testBuscarId() {
        // Arrange
        TipoVistoriaEntity referenciaFinal = new TipoVistoriaEntity();
        referenciaFinal.setAtivo(true);
        referenciaFinal.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaFinal.setDescricao("Descricao");
        referenciaFinal.setId(1L);
        referenciaFinal.setNome("Nome");
        referenciaFinal.setStatusAnterior("Status Anterior");
        referenciaFinal.setStatusPosterior("Status Posterior");

        TipoVistoriaEntity referenciaInicial = new TipoVistoriaEntity();
        referenciaInicial.setAtivo(true);
        referenciaInicial.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaInicial.setDescricao("Descricao");
        referenciaInicial.setId(1L);
        referenciaInicial.setNome("Nome");
        referenciaInicial.setStatusAnterior("Status Anterior");
        referenciaInicial.setStatusPosterior("Status Posterior");

        DiferencaOdometroEntity diferencaOdometroEntity = new DiferencaOdometroEntity();
        diferencaOdometroEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        diferencaOdometroEntity.setDataModificacao(LocalDate.of(1970, 1, 1));
        diferencaOdometroEntity.setDiferencaOdometro(10.0d);
        diferencaOdometroEntity.setId(1L);
        diferencaOdometroEntity.setReferenciaFinal(referenciaFinal);
        diferencaOdometroEntity.setReferenciaInicial(referenciaInicial);
        Optional<DiferencaOdometroEntity> ofResult = Optional.of(diferencaOdometroEntity);
        when(diferencaOdometroRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        // Act
        ResponseEntity<DiferencaOdometroDTO> actualBuscarIdResult = diferencaOdometroServiceImpl.buscarId(1L);

        //