package br.gov.df.pm.sgv.service.impl;

import br.gov.df.pm.sgv.domain.*;
import br.gov.df.pm.sgv.dto.ItemVistoriaDTO;
import br.gov.df.pm.sgv.dto.OcorrenciasDTO;
import br.gov.df.pm.sgv.exceptions.ItemVistoriaException;
import br.gov.df.pm.sgv.exceptions.VistoriaExceptions;
import br.gov.df.pm.sgv.repository.ItemVistoriaRepository;
import br.gov.df.pm.sgv.repository.ItensVistoriaRepository;
import br.gov.df.pm.sgv.repository.SubitemVistoriaRepository;
import br.gov.df.pm.sgv.repository.SubitensVistoriaRepository;
import br.gov.df.pm.sgv.service.TipoVistoriaService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;
@ExtendWith(MockitoExtension.class)
class ItemVistoriaServiceImplTest {

    @Mock(lenient = true)
    private ItemVistoriaRepository itemVistoriaRepository;
    @Mock(lenient = true)
    private ItensVistoriaRepository itensVistoriaRepository;
    @Mock(lenient = true)
    private SubitemVistoriaRepository subitemVistoriaRepository;
    @Mock(lenient = true)
    private SubitensVistoriaRepository subitensVistoriaRepository;
    @Mock(lenient = true)
    private TipoVistoriaServiceImpl tipoVistoriaService;
    @InjectMocks
    private ItemVistoriaServiceImpl itemVistoriaService;

    private ItemVistoriaEntity itemVistoria;
    private SubitemVistoriaEntity subitemVistoria;
    private List<SubitemVistoriaEntity> subitemVistoriaList;
    private SubitensVistoriaEntity subitensVistoria;
    private List<SubitensVistoriaEntity> subitensVistoriaList;

    @BeforeEach
    void setUp() {
        itemVistoria = new ItemVistoriaEntity();
        itemVistoria.setId(1L);
        itemVistoria.setNome("nome");
        itemVistoria.setDescricao("descricao");
        itemVistoria.setAtivo(true);
        itemVistoria.setDataInclusao(LocalDate.MIN);

        subitemVistoria = new SubitemVistoriaEntity();
        subitemVistoria.setId(1L);
        subitemVistoria.setNome("nome");
        subitemVistoria.setDescricao("descricao");
        subitemVistoria.setAtivo(true);
        subitemVistoria.setDataInclusao(LocalDate.MIN);

        subitemVistoriaList = new ArrayList<>();
        subitemVistoriaList.add(subitemVistoria);

        subitensVistoria = new SubitensVistoriaEntity();
        subitensVistoria.setId(1L);
        subitensVistoria.setCodItem(itemVistoria);
        subitensVistoria.setCodSubitem(subitemVistoria);
        subitensVistoria.setAtivo(true);
        subitensVistoria.setDataInclusao(LocalDate.MIN);

        subitensVistoriaList = new ArrayList<>();
        subitensVistoriaList.add(subitensVistoria);

        when(itemVistoriaRepository.findByNome(itemVistoria.getNome())).thenReturn(Optional.of(itemVistoria));

    }

    @Test
    void salvar() {
        when(itemVistoriaRepository.save(itemVistoria)).thenReturn(itemVistoria);

       ItemVistoriaDTO itemVistoriaDTO = new ItemVistoriaDTO();
        itemVistoriaDTO.setId(1L);
        itemVistoriaDTO.setNome("nome");
        itemVistoriaDTO.setDescricao("descricao");
        itemVistoriaDTO.setAtivo(true);
        itemVistoriaDTO.setDataInclusao(LocalDate.MIN);
        itemVistoriaDTO.setSubitens(subitemVistoriaList);


        assertThrows(VistoriaExceptions.class, () -> itemVistoriaService.salvar(itemVistoriaDTO));
    }
    @Test
    void salvar2() {
        ItemVistoriaEntity itemVistoria2Entity = new ItemVistoriaEntity();
        itemVistoria2Entity.setId(2L);
        itemVistoria2Entity.setNome("nome2");
        itemVistoria2Entity.setDescricao("descricao2");
        itemVistoria2Entity.setAtivo(true);
        itemVistoria2Entity.setDataInclusao(LocalDate.MIN);

        ItemVistoriaDTO itemVistoria2DTO = new ItemVistoriaDTO();
        itemVistoria2DTO.setId(2L);
        itemVistoria2DTO.setNome("nome2");
        itemVistoria2DTO.setDescricao("descricao2");
        itemVistoria2DTO.setAtivo(true);
        itemVistoria2DTO.setDataInclusao(LocalDate.MIN);
        itemVistoria2DTO.setSubitens(subitemVistoriaList);

        when(itemVistoriaRepository.save(itemVistoria2Entity)).thenReturn(itemVistoria2Entity);
        when(subitensVistoriaRepository.saveAll(subitensVistoriaList)).thenReturn(subitensVistoriaList);

        ResponseEntity<?> salvar = itemVistoriaService.salvar(itemVistoria2DTO);
        assertNotNull(salvar);
    }

    @Test
    void findAllSubitensVistoria() {
        when(subitensVistoriaRepository.findAll()).thenReturn(subitensVistoriaList);

        ResponseEntity<List<SubitensVistoriaEntity>> allSubitensVistoria = itemVistoriaService.findAllSubitensVistoria();
        assertNotNull(allSubitensVistoria);

    }

    @Test
    void findAllSubitemVistoriaById() {
        when(subitensVistoriaRepository.findAllByCodItem(itemVistoria)).thenReturn(subitensVistoriaList);
        when(subitemVistoriaRepository.findById(subitensVistoria.getCodSubitem().getId())).thenReturn(Optional.of(subitemVistoria));

        ResponseEntity<List<SubitemVistoriaEntity>> allSubitemVistoriaById = itemVistoriaService.findAllSubitemVistoriaById(subitemVistoria.getNome());
        assertNotNull(allSubitemVistoriaById);

    }

    @Test
    void findAllSubitemVistoria() {
        when(subitemVistoriaRepository.findAll()).thenReturn(subitemVistoriaList);

        ResponseEntity<List<SubitemVistoriaEntity>> allSubitemVistoria = itemVistoriaService.findAllSubitemVistoria();
        assertNotNull(allSubitemVistoria);
    }

    @Test
    void listAllAtivosByTipoVistoria() {
//        TipoVistoriaEntity tipoVistoriaEntity = new TipoVistoriaEntity();
//        tipoVistoriaEntity.setId(1L);
//        tipoVistoriaEntity.setNome("nome");
//        tipoVistoriaEntity.setDescricao("descricao");
//        tipoVistoriaEntity.setAtivo(true);
//        tipoVistoriaEntity.setStatusAnterior("anterior");
//        tipoVistoriaEntity.setStatusPosterior("posterior");
//
//        List<ItensVistoriaEntity> itensVistoriaEntityList2 = new ArrayList<>();
//
//        when(tipoVistoriaService.findByIdTipoVistoria(tipoVistoriaEntity.getId())).thenReturn(tipoVistoriaEntity);
//        when(itensVistoriaRepository.findBycodTipoAndAtivo(tipoVistoriaEntity, true)).thenReturn(itensVistoriaEntityList2);
//
//
//
//        assertThrows(ItemVistoriaException.class, () -> itemVistoriaService.listAllAtivosByTipoVistoria(tipoVistoriaEntity.getId()));

    }

    @Test
    void listAllAtivosByTipoVistoria2() {

    }
}