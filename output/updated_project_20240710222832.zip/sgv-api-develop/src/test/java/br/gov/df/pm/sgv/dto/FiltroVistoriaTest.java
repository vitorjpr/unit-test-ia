package br.gov.df.pm.sgv.dto;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;

class FiltroVistoriaTest {

    private FiltroVistoria filtroVistoria;

    @BeforeEach
    void setUp() {
        filtroVistoria = new FiltroVistoria("prefixo", "placa", 1L, LocalDateTime.MIN, LocalDateTime.MAX, 1);
        filtroVistoria.setPrefixo("prefixo 1");
        filtroVistoria.setPlaca("placa 1");
        filtroVistoria.setDataFim(LocalDateTime.MIN);
        filtroVistoria.setDataInicio(LocalDateTime.MAX);
        filtroVistoria.setTipoVistoria(2L);
        filtroVistoria.setUnidade(2);
    }

    @Test
    void getPrefixo() {
        assertNotNull(filtroVistoria.getPrefixo());
    }

    @Test
    void getPlaca() {
        assertNotNull(filtroVistoria.getPlaca());
    }

    @Test
    void getTipoVistoria() {
        assertNotNull(filtroVistoria.getTipoVistoria());
    }

    @Test
    void getDataInicio() {
        assertNotNull(filtroVistoria.getDataInicio());
    }

    @Test
    void getDataFim() {
        assertNotNull(filtroVistoria.getDataFim());
    }

    @Test
    void getUnidade() {
        assertEquals(filtroVistoria.getUnidade(), 2);
    }

    @Test
    void testEquals() {
        FiltroVistoria filtroVistoria1 = new FiltroVistoria("prefixo", "placa", 1L, LocalDateTime.MIN, LocalDateTime.MAX, 1);
        filtroVistoria1.setPrefixo("prefixo 1");
        filtroVistoria1.setPlaca("placa 1");
        filtroVistoria1.setDataFim(LocalDateTime.MIN);
        filtroVistoria1.setDataInicio(LocalDateTime.MAX);
        filtroVistoria1.setTipoVistoria(2L);
        filtroVistoria1.setUnidade(2);

        assertEquals(filtroVistoria, filtroVistoria1);
    }

    @Test
    void testHashCode() {
        FiltroVistoria filtroVistoria1 = new FiltroVistoria("prefixo", "placa", 1L, LocalDateTime.MIN, LocalDateTime.MAX, 1);
        filtroVistoria1.setPrefixo("prefixo 1");
        filtroVistoria1.setPlaca("placa 1");
        filtroVistoria1.setDataFim(LocalDateTime.MIN);
        filtroVistoria1.setDataInicio(LocalDateTime.MAX);
        filtroVistoria1.setTipoVistoria(2L);
        filtroVistoria1.setUnidade(2);

        assertEquals(filtroVistoria.hashCode(), filtroVistoria1.hashCode());
    }

    @Test
    void testToString() {
        assertNotNull(filtroVistoria.toString());
    }

    @Test
    void builder() {
        FiltroVistoria filtroVistoriaBuilder = FiltroVistoria.builder()
                .prefixo("prefixo 1")
                .placa("placa 1")
                .dataFim(LocalDateTime.MIN)
                .dataInicio(LocalDateTime.MAX)
                .tipoVistoria(2L)
                .unidade(2)
                .build();

        assertNotNull(filtroVistoriaBuilder);
    }
}