package br.gov.df.pm.sgv.domain;

import br.gov.df.pm.sgv.domain.enums.VistoriaViaturaStatusEnum;

import java.time.LocalDate;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Date;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ChecklistVistoriaSubItemEntityDiffblueTest {
    /**
     * Methods under test:
     * <ul>
     *   <li>{@link ChecklistVistoriaSubItemEntity#ChecklistVistoriaSubItemEntity()}
     *   <li>
     * {@link ChecklistVistoriaSubItemEntity#setChecklistItemVistoria(ChecklistItemVistoriaEntity)}
     *   <li>{@link ChecklistVistoriaSubItemEntity#setDataCriacao(Date)}
     *   <li>{@link ChecklistVistoriaSubItemEntity#setId(Long)}
     *   <li>{@link ChecklistVistoriaSubItemEntity#setSelecionado(Boolean)}
     *   <li>
     * {@link ChecklistVistoriaSubItemEntity#setTipoDefeitoVistoria(TipoDefeitoVistoriaEntity)}
     *   <li>{@link ChecklistVistoriaSubItemEntity#getChecklistItemVistoria()}
     *   <li>{@link ChecklistVistoriaSubItemEntity#getDataCriacao()}
     *   <li>{@link ChecklistVistoriaSubItemEntity#getId()}
     *   <li>{@link ChecklistVistoriaSubItemEntity#getSelecionado()}
     *   <li>{@link ChecklistVistoriaSubItemEntity#getTipoDefeitoVistoria()}
     * </ul>
     */
    @Test
    void testGettersAndSetters() {
        // Arrange and Act
        ChecklistVistoriaSubItemEntity actualChecklistVistoriaSubItemEntity = new ChecklistVistoriaSubItemEntity();
        ItemVistoriaEntity itemVistoria = new ItemVistoriaEntity();
        itemVistoria.setAtivo(true);
        itemVistoria.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoria.setDescricao("Descricao");
        itemVistoria.setId(1L);
        itemVistoria.setNome("Nome");
        DiferencaOdometroEntity diferencaOdometro = new DiferencaOdometroEntity();
        diferencaOdometro.setDataInclusao(LocalDate.of(1970, 1, 1));
        diferencaOdometro.setDataModificacao(LocalDate.of(1970, 1, 1));
        diferencaOdometro.setDiferencaOdometro(10.0d);
        diferencaOdometro.setId(1L);
        diferencaOdometro.setReferenciaFinal(new TipoVistoriaEntity());
        diferencaOdometro.setReferenciaInicial(new TipoVistoriaEntity());
        TipoVistoriaEntity tipoVistoria = new TipoVistoriaEntity();
        tipoVistoria.setAtivo(true);
        tipoVistoria.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoria.setDescricao("Descricao");
        tipoVistoria.setId(1L);
        tipoVistoria.setNome("Nome");
        tipoVistoria.setStatusAnterior("Status Anterior");
        tipoVistoria.setStatusPosterior("Status Posterior");
        ViaturaEntity viatura = new ViaturaEntity();
        viatura.setAtivo(true);
        viatura.setDataAtualizacao(LocalDate.of(1970, 1, 1));
        viatura.setDataInclusao(LocalDate.of(1970, 1, 1));
        viatura.setId(1L);
        viatura.setListaUpm(new ArrayList<>());
        viatura.setMarcaModelo("Marca Modelo");
        viatura.setNrSei("Nr Sei");
        viatura.setPlaca("Placa");
        viatura.setPrefixo("Prefixo");
        viatura.setRenavam("Renavam");
        viatura.setStatus("Status");
        viatura.setTipoEmpregoViatura(new TipoEmpregoViaturaEntity());
        viatura.setTombamento("alice.liddell@example.org");
        VistoriaViaturaEntity vistoria = new VistoriaViaturaEntity();
        vistoria.setCheckLists(new ArrayList<>());
        vistoria.setDataVistoria(LocalDate.of(1970, 1, 1).atStartOfDay());
        vistoria.setDiferencaOdometro(diferencaOdometro);
        vistoria.setDiferencaVistoria(true);
        vistoria.setId(1L);
        vistoria.setIdPolicial(1);
        vistoria.setIdUpm(1);
        vistoria.setOdometroFinal(10.0f);
        vistoria.setOdometroInicial(10.0f);
        vistoria.setStatus(VistoriaViaturaStatusEnum.DISPONIVEL);
        vistoria.setTipoVistoria(tipoVistoria);
        vistoria.setViatura(viatura);
        vistoria.setVistoriaArquivoList(new ArrayList<>());
        vistoria.setVistoriaViaturaHistorico(new ArrayList<>());
        ChecklistVistoriaEntity checklistVistoria = new ChecklistVistoriaEntity();
        checklistVistoria.setChecklistItens(new ArrayList<>());
        checklistVistoria
                .setDataCriacao(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
        checklistVistoria.setId(1L);
        checklistVistoria.setItemVistoria(itemVistoria);
        checklistVistoria.setObservacao("Observacao");
        checklistVistoria.setVistoria(vistoria);
        SubitemVistoriaEntity subitemVistoria = new SubitemVistoriaEntity();
        subitemVistoria.setAtivo(true);
        subitemVistoria.setDataInclusao(LocalDate.of(1970, 1, 1));
        subitemVistoria.setDescricao("Descricao");
        subitemVistoria.setId(1L);
        subitemVistoria.setNome("Nome");
        ChecklistItemVistoriaEntity checklistItemVistoria = new ChecklistItemVistoriaEntity();
        checklistItemVistoria.setChecklistVistoria(checklistVistoria);
        checklistItemVistoria.setChecklistVistoriaSubItem(new ArrayList<>());
        checklistItemVistoria
                .setDatachCriacao(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
        checklistItemVistoria.setId(1L);
        checklistItemVistoria.setSubitemVistoria(subitemVistoria);
        actualChecklistVistoriaSubItemEntity.setChecklistItemVistoria(checklistItemVistoria);
        Date dataCriacao = Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant());
        actualChecklistVistoriaSubItemEntity.setDataCriacao(dataCriacao);
        actualChecklistVistoriaSubItemEntity.setId(1L);
        actualChecklistVistoriaSubItemEntity.setSelecionado(true);
        TipoDefeitoVistoriaEntity tipoDefeitoVistoria = new TipoDefeitoVistoriaEntity();
        tipoDefeitoVistoria.setAtivo(true);
        tipoDefeitoVistoria.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoDefeitoVistoria.setDescricao("Descricao");
        tipoDefeitoVistoria.setId(1L);
        tipoDefeitoVistoria.setNome("Nome");
        actualChecklistVistoriaSubItemEntity.setTipoDefeitoVistoria(tipoDefeitoVistoria);
        ChecklistItemVistoriaEntity actualChecklistItemVistoria = actualChecklistVistoriaSubItemEntity
                .getChecklistItemVistoria();
        Date actualDataCriacao = actualChecklistVistoriaSubItemEntity.getDataCriacao();
        Long actualId = actualChecklistVistoriaSubItemEntity.getId();
        Boolean actualSelecionado = actualChecklistVistoriaSubItemEntity.getSelecionado();
        TipoDefeitoVistoriaEntity actualTipoDefeitoVistoria = actualChecklistVistoriaSubItemEntity.getTipoDefeitoVistoria();

        // Assert that nothing has changed
        assertEquals(1L, actualId.longValue());
        assertTrue(actualSelecionado);
        assertSame(checklistItemVistoria, actualChecklistItemVistoria);
        assertSame(tipoDefeitoVistoria, actualTipoDefeitoVistoria);
        assertSame(dataCriacao, actualDataCriacao);
    }

    /**
     * Methods under test:
     * <ul>
     *   <li>
     * {@link ChecklistVistoriaSubItemEntity#ChecklistVistoriaSubItemEntity(Long, Boolean, Date, ChecklistItemVistoriaEntity, TipoDefeitoVistoriaEntity)}
     *   <li>
     * {@link ChecklistVistoriaSubItemEntity#setChecklistItemVistoria(ChecklistItemVistoriaEntity)}
     *   <li>{@link ChecklistVistoriaSubItemEntity#setDataCriacao(Date)}
     *   <li>{@link ChecklistVistoriaSubItemEntity#setId(Long)}
     *   <li>{@link ChecklistVistoriaSubItemEntity#setSelecionado(Boolean)}
     *   <li>
     * {@link ChecklistVistoriaSubItemEntity#setTipoDefeitoVistoria(TipoDefeitoVistoriaEntity)}
     *   <li>{@link ChecklistVistoriaSubItemEntity#getChecklistItemVistoria()}
     *   <li>{@link ChecklistVistoriaSubItemEntity#getDataCriacao()}
     *   <li>{@link ChecklistVistoriaSubItemEntity#getId()}
     *   <li>{@link ChecklistVistoriaSubItemEntity#getSelecionado()}
     *   <li>{@link ChecklistVistoriaSubItemEntity#getTipoDefeitoVistoria()}
     * </ul>
     */
    @Test
    void testGettersAndSetters2() {
        // Arrange
        Date dataCriacao = Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant());

        ItemVistoriaEntity itemVistoria = new ItemVistoriaEntity();
        itemVistoria.setAtivo(true);
        itemVistoria.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoria.setDescricao("Descricao");
        itemVistoria.setId(1L);
        itemVistoria.setNome("Nome");

        DiferencaOdometroEntity diferencaOdometro = new DiferencaOdometroEntity();
        diferencaOdometro.setDataInclusao(LocalDate.of(1970, 1, 1));
        diferencaOdometro.setDataModificacao(LocalDate.of(1970, 1, 1));
        diferencaOdometro.setDiferencaOdometro(10.0d);
        diferencaOdometro.setId(1L);
        diferencaOdometro.setReferenciaFinal(new TipoVistoriaEntity());
        diferencaOdometro.setReferenciaInicial(new TipoVistoriaEntity());

        TipoVistoriaEntity tipoVistoria = new TipoVistoriaEntity();
        tipoVistoria.setAtivo(true);
        tipoVistoria.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoria.setDescricao("Descricao");
        tipoVistoria.setId(1L);
        tipoVistoria.setNome("Nome");
        tipoVistoria.setStatusAnterior("Status Anterior");
        tipoVistoria.setStatusPosterior("Status Posterior");

        ViaturaEntity viatura = new ViaturaEntity();
        viatura.setAtivo(true);
        viatura.setDataAtualizacao(LocalDate.of(1970, 1, 1));
        viatura.setDataInclusao(LocalDate.of(1970, 1, 1));
        viatura.setId(1L);
        viatura.setListaUpm(new ArrayList<>());
        viatura.setMarcaModelo("Marca Modelo");
        viatura.setNrSei("Nr Sei");
        viatura.setPlaca("Placa");
        viatura.setPrefixo("Prefixo");
        viatura.setRenavam("Renavam");
        viatura.setStatus("Status");
        viatura.setTipoEmpregoViatura(new TipoEmpregoViaturaEntity());
        viatura.setTombamento("alice.liddell@example.org");

        VistoriaViaturaEntity vistoria = new VistoriaViaturaEntity();
        vistoria.setCheckLists(new ArrayList<>());
        vistoria.setDataVistoria(LocalDate.of(1970, 1, 1).atStartOfDay());
        vistoria.setDiferencaOdometro(diferencaOdometro);
        vistoria.setDiferencaVistoria(true);
        vistoria.setId(1L);
        vistoria.setIdPolicial(1);
        vistoria.setIdUpm(1);
        vistoria.setOdometroFinal(10.0f);
        vistoria.setOdometroInicial(10.0f);
        vistoria.setStatus(VistoriaViaturaStatusEnum.DISPONIVEL);
        vistoria.setTipoVistoria(tipoVistoria);
        vistoria.setViatura(viatura);
        vistoria.setVistoriaArquivoList(new ArrayList<>());
        vistoria.setVistoriaViaturaHistorico(new ArrayList<>());

        ChecklistVistoriaEntity checklistVistoria = new ChecklistVistoriaEntity();
        checklistVistoria.setChecklistItens(new ArrayList<>());
        checklistVistoria
                .setDataCriacao(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
        checklistVistoria.setId(1L);
        checklistVistoria.setItemVistoria(itemVistoria);
        checklistVistoria.setObservacao("Observacao");
        checklistVistoria.setVistoria(vistoria);

        SubitemVistoriaEntity subitemVistoria = new SubitemVistoriaEntity();
        subitemVistoria.setAtivo(true);
        subitemVistoria.setDataInclusao(LocalDate.of(1970, 1, 1));
        subitemVistoria.setDescricao("Descricao");
        subitemVistoria.setId(1L);
        subitemVistoria.setNome("Nome");

        ChecklistItemVistoriaEntity checklistItemVistoria = new ChecklistItemVistoriaEntity();
        checklistItemVistoria.setChecklistVistoria(checklistVistoria);
        checklistItemVistoria.setChecklistVistoriaSubItem(new ArrayList<>());
        checklistItemVistoria
                .setDatachCriacao(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
        checklistItemVistoria.setId(1L);
        checklistItemVistoria.setSubitemVistoria(subitemVistoria);

        TipoDefeitoVistoriaEntity tipoDefeitoVistoria = new TipoDefeitoVistoriaEntity();
        tipoDefeitoVistoria.setAtivo(true);
        tipoDefeitoVistoria.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoDefeitoVistoria.setDescricao("Descricao");
        tipoDefeitoVistoria.setId(1L);
        tipoDefeitoVistoria.setNome("Nome");

        // Act
        ChecklistVistoriaSubItemEntity actualChecklistVistoriaSubItemEntity = new ChecklistVistoriaSubItemEntity(1L, true,
                dataCriacao, checklistItemVistoria, tipoDefeitoVistoria);
        ItemVistoriaEntity itemVistoria2 = new ItemVistoriaEntity();
        itemVistoria2.setAtivo(true);
        itemVistoria2.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoria2.setDescricao("Descricao");
        itemVistoria2.setId(1L);
        itemVistoria2.setNome("Nome");
        DiferencaOdometroEntity diferencaOdometro2 = new DiferencaOdometroEntity();
        diferencaOdometro2.setDataInclusao(LocalDate.of(1970, 1, 1));
        diferencaOdometro2.setDataModificacao(LocalDate.of(1970, 1, 1));
        diferencaOdometro2.setDiferencaOdometro(10.0d);
        diferencaOdometro2.setId(1L);
        diferencaOdometro2.setReferenciaFinal(new TipoVistoriaEntity());
        diferencaOdometro2.setReferenciaInicial(new TipoVistoriaEntity());
        TipoVistoriaEntity tipoVistoria2 = new TipoVistoriaEntity();
        tipoVistoria2.setAtivo(true);
        tipoVistoria2.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoria2.setDescricao("Descricao");
        tipoVistoria2.setId(1L);
        tipoVistoria2.setNome("Nome");
        tipoVistoria2.setStatusAnterior("Status Anterior");
        tipoVistoria2.setStatusPosterior("Status Posterior");
        ViaturaEntity viatura2 = new ViaturaEntity();
        viatura2.setAtivo(true);
        viatura2.setDataAtualizacao(LocalDate.of(1970, 1, 1));
        viatura2.setDataInclusao(LocalDate.of(1970, 1, 1));
        viatura2.setId(1L);
        viatura2.setListaUpm(new ArrayList<>());
        viatura2.setMarcaModelo("Marca Modelo");
        viatura2.setNrSei("Nr Sei");
        viatura2.setPlaca("Placa");
        viatura2.setPrefixo("Prefixo");
        viatura2.setRenavam("Renavam");
        viatura2.setStatus("Status");
        viatura2.setTipoEmpregoViatura(new TipoEmpregoViaturaEntity());
        viatura2.setTombamento("alice.liddell@example.org");
        VistoriaViaturaEntity vistoria2 = new VistoriaViaturaEntity();
        vistoria2.setCheckLists(new ArrayList<>());
        vistoria2.setDataVistoria(LocalDate.of(1970, 1, 1).atStartOfDay());
        vistoria2.setDiferencaOdometro(diferencaOdometro2);
        vistoria2.setDiferencaVistoria(true);
        vistoria2.setId(1L);
        vistoria2.setIdPolicial(1);
        vistoria2.setIdUpm(1);
        vistoria2.setOdometroFinal(10.0f);
        vistoria2.setOdometroInicial(10.0f);
        vistoria2.setStatus(VistoriaViaturaStatusEnum.DISPONIVEL);
        vistoria2.setTipoVistoria(tipoVistoria2);
        vistoria2.setViatura(viatura2);
        vistoria2.setVistoriaArquivoList(new ArrayList<>());
        vistoria2.setVistoriaViaturaHistorico(new ArrayList<>());
        ChecklistVistoriaEntity checklistVistoria2 = new ChecklistVistoriaEntity();
        checklistVistoria2.setChecklistItens(new ArrayList<>());
        checklistVistoria2
                .setDataCriacao(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
        checklistVistoria2.setId(1L);
        checklistVistoria2.setItemVistoria(itemVistoria2);
        checklistVistoria2.setObservacao("Observacao");
        checklistVistoria2.setVistoria(vistoria2);
        SubitemVistoriaEntity subitemVistoria2 = new SubitemVistoriaEntity();
        subitemVistoria2.setAtivo(true);
        subitemVistoria2.setDataInclusao(LocalDate.of(1970, 1, 1));
        subitemVistoria2.setDescricao("Descricao");
        subitemVistoria2.setId(1L);
        subitemVistoria2.setNome("Nome");
        ChecklistItemVistoriaEntity checklistItemVistoria2 = new ChecklistItemVistoriaEntity();
        checklistItemVistoria2.setChecklistVistoria(checklistVistoria2);
        checklistItemVistoria2.setChecklistVistoriaSubItem(new ArrayList<>());
        checklistItemVistoria2
                .setDatachCriacao(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
        checklistItemVistoria2.setId(1L);
        checklistItemVistoria2.setSubitemVistoria(subitemVistoria2);
        actualChecklistVistoriaSubItemEntity.setChecklistItemVistoria(checklistItemVistoria2);
        Date dataCriacao2 = Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant());
        actualChecklistVistoriaSubItemEntity.setDataCriacao(dataCriacao2);
        actualChecklistVistoriaSubItemEntity.setId(1L);
        actualChecklistVistoriaSubItemEntity.setSelecionado(true);
        TipoDefeitoVistoriaEntity tipoDefeitoVistoria2 = new TipoDefeitoVistoriaEntity();
        tipoDefeitoVistoria2.setAtivo(true);
        tipoDefeitoVistoria2.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoDefeitoVistoria2.setDescricao("Descricao");
        tipoDefeitoVistoria2.setId(1L);
        tipoDefeitoVistoria2.setNome("Nome");
        actualChecklistVistoriaSubItemEntity.setTipoDefeitoVistoria(tipoDefeitoVistoria2);
        ChecklistItemVistoriaEntity actualChecklistItemVistoria = actualChecklistVistoriaSubItemEntity
                .getChecklistItemVistoria();
        Date actualDataCriacao = actualChecklistVistoriaSubItemEntity.getDataCriacao();
        Long actualId = actualChecklistVistoriaSubItemEntity.getId();
        Boolean actualSelecionado = actualChecklistVistoriaSubItemEntity.getSelecionado();
        TipoDefeitoVistoriaEntity actualTipoDefeitoVistoria = actualChecklistVistoriaSubItemEntity.getTipoDefeitoVistoria();

        // Assert that nothing has changed
        assertEquals(1L, actualId.longValue());
        assertTrue(actualSelecionado);
        assertEquals(checklistItemVistoria, actualChecklistItemVistoria);
        assertEquals(tipoDefeitoVistoria, actualTipoDefeitoVistoria);
        assertSame(checklistItemVistoria2, actualChecklistItemVistoria);
        assertSame(tipoDefeitoVistoria2, actualTipoDefeitoVistoria);
        assertSame(dataCriacao2, actualDataCriacao);
    }

    @Test
    void builder() {
        ChecklistVistoriaSubItemEntity checklistVistoriaSubItemEntity = ChecklistVistoriaSubItemEntity.builder()
                .id(1L)
                .dataCriacao(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()))
                .checklistItemVistoria(new ChecklistItemVistoriaEntity())
                .selecionado(true)
                .tipoDefeitoVistoria(new TipoDefeitoVistoriaEntity())
                .build();

        assertNotNull(checklistVistoriaSubItemEntity);
    }

}
