//package br.gov.df.pm.sgv.controller;
//
//import br.gov.df.pm.sgv.domain.*;
//import br.gov.df.pm.sgv.dto.EdicaoSubitemVistoriaDTO;
//import br.gov.df.pm.sgv.dto.EdicaoTipoDefeitoVistoriaDTO;
//import br.gov.df.pm.sgv.dto.SubitemVistoriaDTO;
//import br.gov.df.pm.sgv.dto.TipoDefeitoVistoriaDTO;
//import br.gov.df.pm.sgv.exceptions.VistoriaExceptions;
//import br.gov.df.pm.sgv.repository.DefeitosVistoriaRepository;
//import br.gov.df.pm.sgv.repository.SubitemVistoriaRepository;
//import br.gov.df.pm.sgv.repository.SubitensVistoriaRepository;
//import br.gov.df.pm.sgv.repository.TipoDefeitoVistoriaRepository;
//import br.gov.df.pm.sgv.util.TestUtils;
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.boot.test.mock.mockito.MockBean;
//import org.springframework.data.domain.PageImpl;
//import org.springframework.data.domain.PageRequest;
//import org.springframework.data.domain.Pageable;
//import org.springframework.data.jpa.domain.Specification;
//import org.springframework.hateoas.EntityModel;
//import org.springframework.hateoas.PagedModel;
//import org.springframework.http.ResponseEntity;
//import org.springframework.mock.web.MockHttpServletRequest;
//import org.springframework.web.context.request.RequestContextHolder;
//import org.springframework.web.context.request.ServletRequestAttributes;
//
//import javax.persistence.criteria.CriteriaBuilder;
//import javax.persistence.criteria.CriteriaQuery;
//import javax.persistence.criteria.Root;
//import java.time.LocalDate;
//import java.util.List;
//import java.util.Optional;
//
//import static org.junit.jupiter.api.Assertions.assertNotNull;
//import static org.junit.jupiter.api.Assertions.assertThrows;
//import static org.mockito.ArgumentMatchers.any;
//import static org.mockito.Mockito.*;
//import static org.mockito.Mockito.when;
//
//@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
//public class SubitemVistoriaControllerTest {
//
//    @MockBean
//    SubitemVistoriaRepository repository;
//    @MockBean
//    SubitensVistoriaRepository subitensRepository;
//
//    @MockBean
//    TipoDefeitoVistoriaRepository tipoDefeitoRepository;
//    @Autowired
//    SubitemVistoriaController controller;
//    @MockBean
//    DefeitosVistoriaRepository defeitosRepository;
//
//    SubitemVistoriaEntity subitemMock;
//    SubitemVistoriaDTO subitemMockDto;
//    EdicaoSubitemVistoriaDTO edicaoSubitemVistoriaMockDto;
//    SubitensVistoriaEntity subitensVistoriaEntity;
//    TipoDefeitoVistoriaEntity tipoDefeitoMock;
//    DefeitosVistoriaEntity defeitosVistoriaEntity;
//
//    @BeforeEach
//    void setUp() {
//        var request = new MockHttpServletRequest();
//        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(request));
//
//        tipoDefeitoMock = TipoDefeitoVistoriaEntity.builder()
//                .id(1L)
//                .nome("Vidro")
//                .descricao("Vidro da Viatura")
//                .ativo(true)
//                .dataInclusao(LocalDate.now())
//                .build();
//
//        subitemMock = SubitemVistoriaEntity.builder()
//                .id(1L)
//                .nome("Vidro")
//                .descricao("Vidro da Viatura")
//                .ativo(true)
//                .dataInclusao(LocalDate.now())
//                .build();
//
//        subitemMockDto = SubitemVistoriaDTO.builder()
//                .nome("Vidro")
//                .descricao("Vidro da Viatura")
//                .ativo(true)
//                .dataInclusao(LocalDate.now())
//                .defeitos(List.of(tipoDefeitoMock))
//                .build();
//
//        edicaoSubitemVistoriaMockDto = EdicaoSubitemVistoriaDTO.builder()
//                .nome("Vidro")
//                .descricao("Vidro da Vistoria")
//                .build();
//
//        subitensVistoriaEntity = SubitensVistoriaEntity.builder()
//                .id(1L)
//                .codItem(new ItemVistoriaEntity())
//                .codSubitem(new SubitemVistoriaEntity())
//                .dataInclusao(LocalDate.now())
//                .ativo(true)
//                .build();
//
//        defeitosVistoriaEntity = DefeitosVistoriaEntity.builder()
//                .id(1L)
//                .codTipoDefeito(tipoDefeitoMock)
//                .codSubitem(subitemMock)
//                .dataInclusao(LocalDate.now())
//                .ativo(true)
//                .build();
//
//        Specification<SubitemVistoriaEntity> spec = any();
//        Pageable pageable = any();
//        when(repository.findAll(spec, pageable)).then(TestUtils.callableAnswer(invocation -> {
//            Specification<SubitemVistoriaDTO> s = invocation.getArgument(0);
//            Root<SubitemVistoriaDTO> root = mock(Root.class, withSettings().defaultAnswer(RETURNS_MOCKS));
//            CriteriaQuery<SubitemVistoriaDTO> query = mock(CriteriaQuery.class, withSettings().defaultAnswer(RETURNS_MOCKS));
//            when(query.getResultType()).thenReturn(SubitemVistoriaDTO.class);
//            CriteriaBuilder builder = mock(CriteriaBuilder.class, withSettings().defaultAnswer(RETURNS_MOCKS));
//            s.toPredicate(root, query, builder);
//            return new PageImpl<>(List.of(subitemMock));
//        }));
//    }
//
//    @Test
//    void buscarId() {
//        when(repository.findById(1L)).thenReturn(Optional.of(subitemMock));
//        ResponseEntity<?> response = controller.buscarId(1L);
//        assertNotNull(response);
//    }
//
//    @Test
//    void buscar() {
//        var pageable = PageRequest.of(0, 1);
//        when(tipoDefeitoRepository.findByNome("Vidro")).thenReturn(Optional.of(tipoDefeitoMock));
//        when(defeitosRepository.findAllByCodTipoDefeito(TipoDefeitoVistoriaEntity.builder().build())).thenReturn(List.of(defeitosVistoriaEntity));
//        PagedModel<EntityModel<SubitemVistoriaDTO>> response = controller.buscar("Vidro", pageable);
//        assertNotNull(response);
//    }
//
//    @Test
//    void salvar() {
//        when(tipoDefeitoRepository.findByNome("Vidro")).thenReturn(Optional.of(tipoDefeitoMock));
//        when(repository.findById(1L)).thenReturn(Optional.of(subitemMock));
//        when(repository.save(any(SubitemVistoriaEntity.class))).thenReturn(subitemMock);
//        when(defeitosRepository.saveAll(List.of(defeitosVistoriaEntity))).thenReturn(List.of(defeitosVistoriaEntity));
//        assertNotNull(controller.salvar(subitemMockDto));
//    }
//
//    @Test
//    void editarJaCadastrado() {
//        when(repository.findById(1L)).thenReturn(Optional.of(subitemMock));
//        when(repository.findByNome("Vidro")).thenReturn(Optional.of(subitemMock));
//        assertThrows(VistoriaExceptions.class, () -> controller.editar(1L, edicaoSubitemVistoriaMockDto));
//    }
//
//    @Test
//    void editar() {
//        when(repository.findById(1L)).thenReturn(Optional.of(subitemMock));
//        when(repository.findByNome("Janela")).thenReturn(Optional.of(subitemMock));
//        assertNotNull(controller.editar(1L, edicaoSubitemVistoriaMockDto));
//    }
//
//    @Test
//    void excluir() {
//        when(repository.findById(1L)).thenReturn(Optional.of(subitemMock));
//        when(subitensRepository.findAllByCodItem(new ItemVistoriaEntity())).thenReturn(null);
//        assertNotNull(controller.excluir(1L));
//    }
//
//    @Test
//    void desativar() {
//        when(repository.findById(1L)).thenReturn(Optional.of(subitemMock));
//        when(subitensRepository.findAllByCodSubitem(new SubitemVistoriaEntity())).thenReturn(List.of(subitensVistoriaEntity));
//        assertNotNull(controller.desativar(1L));
//    }
//
//    @Test
//    void ativar() {
//        when(repository.findById(1L)).thenReturn(Optional.of(subitemMock));
//        when(repository.save(subitemMock)).thenReturn(subitemMock);
//        assertNotNull(controller.ativar(1L));
//    }
//}
