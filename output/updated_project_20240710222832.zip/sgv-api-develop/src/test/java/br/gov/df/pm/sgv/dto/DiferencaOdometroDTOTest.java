package br.gov.df.pm.sgv.dto;

import br.gov.df.pm.sgv.domain.TipoVistoriaEntity;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

class DiferencaOdometroDTOTest {

    private DiferencaOdometroDTO diferencaOdometroDTO;

    @BeforeEach
    void setUp() {
        diferencaOdometroDTO = new DiferencaOdometroDTO(
                new TipoVistoriaEntity(),
                new TipoVistoriaEntity(),
                1.0,
                LocalDate.MIN,
                LocalDate.MAX,
                true);
//        diferencaOdometroDTO.setDataModificacao();
//        diferencaOdometroDTO.setReferenciaInicial();
//        diferencaOdometroDTO.setReferenciaInicial();
//        diferencaOdometroDTO.setReferenciaInicial();
//        diferencaOdometroDTO.setReferenciaInicial();
//        diferencaOdometroDTO.setReferenciaInicial();
   }

    @Test
    void getReferenciaInicial() {

    }

    @Test
    void getReferenciaFinal() {
    }

    @Test
    void getDiferencaOdometro() {
    }

    @Test
    void getDataInclusao() {
    }

    @Test
    void getDataModificacao() {
    }

    @Test
    void getDiferencaPermitido() {
    }

    @Test
    void setReferenciaInicial() {
    }

    @Test
    void setReferenciaFinal() {
    }

    @Test
    void setDiferencaOdometro() {
    }

    @Test
    void setDataInclusao() {
    }

    @Test
    void setDataModificacao() {
    }

    @Test
    void setDiferencaPermitido() {
    }

    @Test
    void testEquals() {
    }

    @Test
    void canEqual() {
    }

    @Test
    void testHashCode() {
    }

    @Test
    void testToString() {
    }

    @Test
    void builder() {
    }
}