```java
package br.gov.df.pm.sgv.dto.app;

import br.gov.df.pm.sgv.domain.TipoVistoriaEntity;
import br.gov.df.pm.sgv.domain.ViaturaEntity;
import br.gov.df.pm.sgv.dto.VistoriaDTO;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class VistoriaDTOTest {
    private VistoriaDTO vistoria;

    @BeforeEach
    void setUp() {
        vistoria = VistoriaDTO.builder()
                .tipoVistoria(TipoVistoriaEntity.builder().id(1L).build())
                .viatura(ViaturaEntity.builder().id(1L).build())
                .build();
    }

    @Test
    void testEquals() {
        var vistoria1 = VistoriaDTO.builder()
                .tipoVistoria(TipoVistoriaEntity.builder().id(1L).build())
                .viatura(ViaturaEntity.builder().id(1L).build())
                .build();
        assertEquals(vistoria, vistoria1);

        var viatura2 = VistoriaDTO.builder().tipoVistoria(TipoVistoriaEntity.builder().build()).build();
        assertNotEquals(vistoria, viatura2);
    }

    @Test
    void testHashCode() {
        var vistoria1 = VistoriaDTO.builder()
                .tipoVistoria(TipoVistoriaEntity.builder().id(1L).build())
                .viatura(ViaturaEntity.builder().id(1L).build())
                .build();
        assertEquals(vistoria.hashCode(), vistoria1.hashCode());

        var viatura2 = VistoriaDTO.builder().tipoVistoria(TipoVistoriaEntity.builder().build()).build();
        assertNotEquals(vistoria.hashCode(), viatura2.hashCode());
    }

    @Test
    void testToString() {
        assertNotNull(vistoria.toString());
    }

    @Test
    void testGetTipoVistoria() {
        assertEquals(1L, vistoria.getTipoVistoria().getId());
    }

    @Test
    void testGetViatura() {
        assertEquals(1L, vistoria.getViatura().getId());
    }

    @Test
    void testSetTipoVistoria() {
        vistoria.setTipoVistoria(TipoVistoriaEntity.builder().id(2L).build());
        assertEquals(2L, vistoria.getTipoVistoria().getId());
    }

    @Test
    void testSetViatura() {
        vistoria.setViatura(ViaturaEntity.builder().id(2L).build());
        assertEquals(2L, vistoria.getViatura().getId());
    }
}
```