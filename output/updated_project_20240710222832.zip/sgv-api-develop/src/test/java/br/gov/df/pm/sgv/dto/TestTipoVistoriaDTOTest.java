Here are the unit tests for the provided Java code:

```java
package br.gov.df.pm.sgv.dto;

import br.gov.df.pm.sgv.domain.ItemVistoriaEntity;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class TipoVistoriaDTOTest {
    private TipoVistoriaDTO tipoVistoria;
    private LocalDate diaAtual;
    private ItemVistoriaEntity itens;

    @BeforeEach
    void setUp() {
        tipoVistoria = new TipoVistoriaDTO(null, "", "", "", "", null, null, null);
        diaAtual = LocalDate.now();
        itens = ItemVistoriaEntity.builder().build();

        tipoVistoria.setId(1L);
        tipoVistoria.setNome("Vidro");
        tipoVistoria.setDescricao("Vidro do Carro");
        tipoVistoria.setStatusAnterior("EM USO");
        tipoVistoria.setStatusPosterior("DISPONÍVEL");
        tipoVistoria.setDataInclusao(diaAtual);
        tipoVistoria.setAtivo(true);
        tipoVistoria.setItens(List.of(itens));
    }

    @Test
    void testEquals() {
        var tipoVistoria1 = TipoVistoriaDTO.builder()
                .id(1L)
                .nome("Vidro")
                .descricao("Vidro do Carro")
                .statusAnterior("EM USO")
                .statusPosterior("DISPONÍVEL")
                .dataInclusao(diaAtual)
                .ativo(true)
                .itens(List.of(itens))
                .build();
        assertEquals(tipoVistoria, tipoVistoria1);

        var tipoVistoria2 = TipoVistoriaDTO.builder().nome("Janela").build();
        assertNotEquals(tipoVistoria, tipoVistoria2);
    }

    @Test
    void testHashCode() {
        var tipoVistoria1 = TipoVistoriaDTO.builder()
                .id(1L)
                .nome("Vidro")
                .descricao("Vidro do Carro")
                .statusAnterior("EM USO")
                .statusPosterior("DISPONÍVEL")
                .dataInclusao(diaAtual)
                .ativo(true)
                .itens(List.of(itens))
                .build();
        assertEquals(tipoVistoria.hashCode(), tipoVistoria1.hashCode());

        var tipoVistoria2 = TipoVistoriaDTO.builder().build();
        assertNotEquals(tipoVistoria.hashCode(), tipoVistoria2.hashCode());
    }

    @Test
    void testToString() {
        assertNotNull(tipoVistoria.toString());
    }
}
```

These unit tests cover the `equals()`, `hashCode()`, and `toString()` methods of the `TipoVistoriaDTO` class. The tests ensure that the equality, hash code generation, and string representation of the objects are working as expected.