```java
package br.gov.df.pm.sgv.dto;

import br.gov.df.pm.sgv.domain.TipoDefeitoVistoriaEntity;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class SubitemVistoriaDTOTest {
    private SubitemVistoriaDTO subitemVistoria;
    private LocalDate diaAtual;
    private TipoDefeitoVistoriaEntity defeitos;

    @BeforeEach
    void setUp() {
        subitemVistoria = new SubitemVistoriaDTO(null, "", "", null, null, null);
        diaAtual = LocalDate.now();
        defeitos = TipoDefeitoVistoriaEntity.builder().build();

        subitemVistoria.setId(1L);
        subitemVistoria.setNome("Vidro");
        subitemVistoria.setDescricao("Vidro do Carro");
        subitemVistoria.setDataInclusao(diaAtual);
        subitemVistoria.setAtivo(true);
        subitemVistoria.setDefeitos(List.of(defeitos));
    }

    @Test
    void testEquals() {
        var subitemVistoria1 = SubitemVistoriaDTO.builder()
                .id(1L)
                .nome("Vidro")
                .descricao("Vidro do Carro")
                .dataInclusao(diaAtual)
                .ativo(true)
                .defeitos(List.of(defeitos))
                .build();
        assertEquals(subitemVistoria, subitemVistoria1);

        var subitemVistoria2 = SubitemVistoriaDTO.builder().nome("Janela").build();
        assertNotEquals(subitemVistoria, subitemVistoria2);
    }

    @Test
    void testHashCode() {
        var subitemVistoria1 = SubitemVistoriaDTO.builder()
                .id(1L)
                .nome("Vidro")
                .descricao("Vidro do Carro")
                .dataInclusao(diaAtual)
                .ativo(true)
                .defeitos(List.of(defeitos))
                .build();
        assertEquals(subitemVistoria.hashCode(), subitemVistoria1.hashCode());

        var subitemVistoria2 = SubitemVistoriaDTO.builder().build();
        assertNotEquals(subitemVistoria.hashCode(), subitemVistoria2.hashCode());
    }

    @Test
    void testToString() {
        assertNotNull(subitemVistoria.toString());
    }
}
```