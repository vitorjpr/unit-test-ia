//package br.gov.df.pm.sgv.controller.app;
//
//import br.gov.df.pm.sgv.controller.ViaturaController;
//import br.gov.df.pm.sgv.domain.ViaturaEntity;
//import br.gov.df.pm.sgv.repository.app.ViaturaRepository;
//import br.gov.df.pm.sgv.util.TestUtils;
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.boot.test.mock.mockito.MockBean;
//import org.springframework.data.domain.PageImpl;
//import org.springframework.data.domain.PageRequest;
//import org.springframework.data.domain.Pageable;
//import org.springframework.data.jpa.domain.Specification;
//import org.springframework.mock.web.MockHttpServletRequest;
//import org.springframework.web.context.request.RequestContextHolder;
//import org.springframework.web.context.request.ServletRequestAttributes;
//
//import javax.persistence.criteria.CriteriaBuilder;
//import javax.persistence.criteria.CriteriaQuery;
//import javax.persistence.criteria.Root;
//import java.time.LocalDate;
//import java.util.List;
//
//import static org.junit.jupiter.api.Assertions.assertNotNull;
//import static org.mockito.ArgumentMatchers.any;
//import static org.mockito.Mockito.*;
//
//@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
//public class ViaturaControllerTest {
//
//    @Autowired
//    ViaturaController viaturaController;
//    @MockBean
//    ViaturaRepository viaturaRepository;
//    ViaturaEntity viaturaMock;
//
//    @BeforeEach
//    void setUp() {
//        var request = new MockHttpServletRequest();
//        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(request));
//
//        viaturaMock = ViaturaEntity.builder()
//                .id(1L)
//                .ativo(1)
//                .placa("XXXXXX")
//                .nrSei("XXXXXXXXXXXXXXXXXXXX")
//                .dataInclusao(LocalDate.now())
//                .prefixo("PREFIXO")
//                .build();
//
//        Specification<ViaturaEntity> spec = any();
//        Pageable pageable = any();
//        when(viaturaRepository.findAll(spec, pageable)).then(TestUtils.callableAnswer(invocation -> {
//            Specification<ViaturaEntity> s = invocation.getArgument(0);
//            Root<ViaturaEntity> root = mock(Root.class, withSettings().defaultAnswer(RETURNS_MOCKS));
//            CriteriaQuery<ViaturaEntity> query = mock(CriteriaQuery.class, withSettings().defaultAnswer(RETURNS_MOCKS));
//            when(query.getResultType()).thenReturn(ViaturaEntity.class);
//            CriteriaBuilder builder = mock(CriteriaBuilder.class, withSettings().defaultAnswer(RETURNS_MOCKS));
//            s.toPredicate(root, query, builder);
//            return new PageImpl<>(List.of(viaturaMock));
//        }));
//    }
//
//    @Test
//    void buscar() {
//        var pageable = PageRequest.of(0, 1);
////        PagedModel<EntityModel<ViaturaDTO>> response = viaturaController.buscar(1, "", "", pageable);
////        assertNotNull(response);
//    }
//}
