```java
import br.gov.df.pm.sgv.controller.SubitemVistoriaController;
import br.gov.df.pm.sgv.dto.EdicaoSubitemVistoriaDTO;
import br.gov.df.pm.sgv.dto.SubitemVistoriaDTO;
import br.gov.df.pm.sgv.entity.DefeitosVistoriaEntity;
import br.gov.df.pm.sgv.entity.SubitemVistoriaEntity;
import br.gov.df.pm.sgv.entity.SubitensVistoriaEntity;
import br.gov.df.pm.sgv.entity.TipoDefeitoVistoriaEntity;
import br.gov.df.pm.sgv.exceptions.VistoriaExceptions;
import br.gov.df.pm.sgv.repository.DefeitosVistoriaRepository;
import br.gov.df.pm.sgv.repository.SubitemVistoriaRepository;
import br.gov.df.pm.sgv.repository.SubitensVistoriaRepository;
import br.gov.df.pm.sgv.repository.TipoDefeitoVistoriaRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.PagedModel;
import org.springframework.http.ResponseEntity;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

public class SubitemVistoriaControllerTest {

    @Mock
    SubitemVistoriaRepository repository;

    @Mock
    SubitensVistoriaRepository subitensRepository;

    @Mock
    TipoDefeitoVistoriaRepository tipoDefeitoRepository;

    @Mock
    DefeitosVistoriaRepository defeitosRepository;

    @InjectMocks
    SubitemVistoriaController controller;

    SubitemVistoriaEntity subitemMock;
    SubitemVistoriaDTO subitemMockDto;
    EdicaoSubitemVistoriaDTO edicaoSubitemVistoriaMockDto;
    SubitensVistoriaEntity subitensVistoriaEntity;
    TipoDefeitoVistoriaEntity tipoDefeitoMock;
    DefeitosVistoriaEntity defeitosVistoriaEntity;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);

        tipoDefeitoMock = TipoDefeitoVistoriaEntity.builder()
                .id(1L)
                .nome("Vidro")
                .descricao("Vidro da Viatura")
                .ativo(true)
                .dataInclusao(LocalDate.now())
                .build();

        subitemMock = SubitemVistoriaEntity.builder()
                .id(1L)
                .nome("Vidro")
                .descricao("Vidro da Viatura")
                .ativo(true)
                .dataInclusao(LocalDate.now())
                .build();

        subitemMockDto = SubitemVistoriaDTO.builder()
                .nome("Vidro")
                .descricao("Vidro da Viatura")
                .ativo(true)
                .dataInclusao(LocalDate.now())
                .defeitos(List.of(tipoDefeitoMock))
                .build();

        edicaoSubitemVistoriaMockDto = EdicaoSubitemVistoriaDTO.builder()
                .nome("Vidro")
                .descricao("Vidro da Vistoria")
                .build();

        subitensVistoriaEntity = SubitensVistoriaEntity.builder()
                .id(1L)
                .codItem(new ItemVistoriaEntity())
                .codSubitem(new SubitemVistoriaEntity())
                .dataInclusao(LocalDate.now())
                .ativo(true)
                .build();

        defeitosVistoriaEntity = DefeitosVistoriaEntity.builder()
                .id(1L)
                .codTipoDefeito(tipoDefeitoMock)
                .codSubitem(subitemMock)
                .dataInclusao(LocalDate.now())
                .ativo(true)
                .build();
    }

    @Test
    void buscarId() {
        when(repository.findById(1L)).thenReturn(Optional.of(subitemMock));
        ResponseEntity<?> response = controller.buscarId(1L);
        assertNotNull(response);
    }

    @Test
    void buscar() {
        var pageable = PageRequest.of(0, 1);
        when(tipoDefeitoRepository.findByNome("Vidro")).thenReturn(Optional.of(tipoDefeitoMock));
        when(defeitosRepository.findAllByCodTipoDefeito(tipoDefeitoMock)).thenReturn(List.of(defeitosVistoriaEntity));
        PagedModel<EntityModel<SubitemVistoriaDTO>> response = controller.buscar("Vidro", pageable);
        assertNotNull(response);
    }

