//package br.gov.df.pm.sgv.controller;
//
//import br.gov.df.pm.sgv.domain.*;
//import br.gov.df.pm.sgv.dto.EdicaoItemVistoriaDTO;
//import br.gov.df.pm.sgv.dto.EdicaoTipoVistoriaDTO;
//import br.gov.df.pm.sgv.dto.ItemVistoriaDTO;
//import br.gov.df.pm.sgv.dto.TipoVistoriaDTO;
//import br.gov.df.pm.sgv.exceptions.VistoriaExceptions;
//import br.gov.df.pm.sgv.repository.*;
//import br.gov.df.pm.sgv.util.TestUtils;
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.boot.test.mock.mockito.MockBean;
//import org.springframework.data.domain.PageImpl;
//import org.springframework.data.domain.PageRequest;
//import org.springframework.data.domain.Pageable;
//import org.springframework.data.jpa.domain.Specification;
//import org.springframework.hateoas.EntityModel;
//import org.springframework.hateoas.PagedModel;
//import org.springframework.http.ResponseEntity;
//import org.springframework.mock.web.MockHttpServletRequest;
//import org.springframework.web.context.request.RequestContextHolder;
//import org.springframework.web.context.request.ServletRequestAttributes;
//
//import javax.persistence.criteria.CriteriaBuilder;
//import javax.persistence.criteria.CriteriaQuery;
//import javax.persistence.criteria.Root;
//import java.time.LocalDate;
//import java.util.List;
//import java.util.Optional;
//
//import static org.junit.jupiter.api.Assertions.assertNotNull;
//import static org.junit.jupiter.api.Assertions.assertThrows;
//import static org.mockito.ArgumentMatchers.any;
//import static org.mockito.Mockito.*;
//
//@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
//public class TipoVistoriaControllerTest {
//
//    @MockBean
//    TipoVistoriaRepository repository;
//
//    @MockBean
//    ItemVistoriaRepository itemRepository;
//    @MockBean
//    ItensVistoriaRepository itensRepository;
//    @Autowired
//    TipoVistoriaController controller;
//    ItemVistoriaEntity itemMock;
//
//    TipoVistoriaEntity tipoMock;
//    TipoVistoriaDTO tipoMockDto;
//    EdicaoTipoVistoriaDTO edicaoTipoVistoriaMockDto;
//    ItensVistoriaEntity itensVistoriaEntity;
//    ItensVistoriaEntity tensVistoriaEntity;
//
//    @BeforeEach
//    void setUp() {
//        var request = new MockHttpServletRequest();
//        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(request));
//
//        tipoMock = TipoVistoriaEntity.builder()
//                .id(1L)
//                .nome("Vidro")
//                .descricao("Vidro da Viatura")
//                .ativo(true)
//                .dataInclusao(LocalDate.now())
//                .build();
//
//        itemMock = ItemVistoriaEntity.builder()
//                .id(1L)
//                .nome("Vidro")
//                .descricao("Vidro da Viatura")
//                .ativo(true)
//                .dataInclusao(LocalDate.now())
//                .build();
//
//        tipoMockDto = TipoVistoriaDTO.builder()
//                .nome("Vidro")
//                .descricao("Vidro da Viatura")
//                .ativo(true)
//                .dataInclusao(LocalDate.now())
//                .itens(List.of(itemMock))
//                .build();
//
//        edicaoTipoVistoriaMockDto = EdicaoTipoVistoriaDTO.builder()
//                .nome("Vidro")
//                .descricao("Vidro da Vistoria")
//                .build();
//
//        itensVistoriaEntity = ItensVistoriaEntity.builder()
//                .id(1L)
//                .codItem(new ItemVistoriaEntity())
//                .codTipo(new TipoVistoriaEntity())
//                .dataInclusao(LocalDate.now())
//                .ativo(true)
//                .build();
//
//        Specification<TipoVistoriaEntity> spec = any();
//        Pageable pageable = any();
//        when(repository.findAll(spec, pageable)).then(TestUtils.callableAnswer(invocation -> {
//            Specification<TipoVistoriaDTO> s = invocation.getArgument(0);
//            Root<TipoVistoriaDTO> root = mock(Root.class, withSettings().defaultAnswer(RETURNS_MOCKS));
//            CriteriaQuery<TipoVistoriaDTO> query = mock(CriteriaQuery.class, withSettings().defaultAnswer(RETURNS_MOCKS));
//            when(query.getResultType()).thenReturn(TipoVistoriaDTO.class);
//            CriteriaBuilder builder = mock(CriteriaBuilder.class, withSettings().defaultAnswer(RETURNS_MOCKS));
//            s.toPredicate(root, query, builder);
//            return new PageImpl<>(List.of(tipoMock));
//        }));
//    }
//    @Test
//    void buscarId() {
//        when(repository.findById(1L)).thenReturn(Optional.of(tipoMock));
//        ResponseEntity<?> response = controller.buscarId(1L);
//        assertNotNull(response);
//    }
//
//    @Test
//    void buscar() {
//        var pageable = PageRequest.of(0, 1);
//        when(itemRepository.findByNome("Vidro")).thenReturn(Optional.of(itemMock));
//        when(itensRepository.findAllByCodItem(new ItemVistoriaEntity())).thenReturn(List.of(itensVistoriaEntity));
//        PagedModel<EntityModel<TipoVistoriaDTO>> response = controller.buscar("Vidro", pageable);
//        assertNotNull(response);
//    }
//
//    @Test
//    void salvar() {
//        when(itemRepository.findByNome("Vidro")).thenReturn(Optional.of(itemMock));
//        when(repository.findById(1L)).thenReturn(Optional.of(tipoMock));
//        when(repository.save(any(TipoVistoriaEntity.class))).thenReturn(tipoMock);
//        when(itensRepository.saveAll(List.of(itensVistoriaEntity))).thenReturn(List.of(itensVistoriaEntity));
//        assertNotNull(controller.salvar(tipoMockDto));
//    }
//
//    @Test
//    void editarJaCadastrado() {
//        when(repository.findById(1L)).thenReturn(Optional.of(tipoMock));
//        when(repository.findByNome("Vidro")).thenReturn(Optional.of(tipoMock));
//        assertThrows(VistoriaExceptions.class, () -> controller.editar(1L, edicaoTipoVistoriaMockDto));
//    }
//
//    @Test
//    void editar() {
//        when(repository.findById(1L)).thenReturn(Optional.of(tipoMock));
//        when(repository.findByNome("Janela")).thenReturn(Optional.of(tipoMock));
//        assertNotNull(controller.editar(1L, edicaoTipoVistoriaMockDto));
//    }
//
//    @Test
//    void excluir() {
//        when(repository.findById(1L)).thenReturn(Optional.of(tipoMock));
//        when(itensRepository.findAllByCodItem(new ItemVistoriaEntity())).thenReturn(null);
//        assertNotNull(controller.excluir(1L));
//    }
//
//    @Test
//    void desativar() {
//        when(repository.findById(1L)).thenReturn(Optional.of(tipoMock));
//        when(itensRepository.findAllByCodItem(new ItemVistoriaEntity())).thenReturn(List.of(itensVistoriaEntity));
//        assertNotNull(controller.desativar(1L));
//    }
//
//    @Test
//    void ativar() {
//        when(repository.findById(1L)).thenReturn(Optional.of(tipoMock));
//        when(repository.save(tipoMock)).thenReturn(tipoMock);
//        assertNotNull(controller.ativar(1L));
//    }
//}
