```java
package br.gov.df.pm.sgv.dto;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

public class EdicaoItemVistoriaDTOTest {
    private EdicaoItemVistoriaDTO edicaoItemVistoria;

    @BeforeEach
    void setUp() {
        edicaoItemVistoria = new EdicaoItemVistoriaDTO("", "", null);
        edicaoItemVistoria.setNome("Vidro");
        edicaoItemVistoria.setDescricao("Vidro do Carro");
        edicaoItemVistoria.setSubitens(new ArrayList<>());
    }

    @Test
    void testEquals() {
        var edicaoItemVistoria1 = EdicaoItemVistoriaDTO.builder()
                .nome("Vidro")
                .descricao("Vidro do Carro")
                .subitens(new ArrayList<>())
                .build();
        assertEquals(edicaoItemVistoria, edicaoItemVistoria1);

        var edicaoItemVistoria2 = EdicaoItemVistoriaDTO.builder().nome("Janela").build();
        assertNotEquals(edicaoItemVistoria, edicaoItemVistoria2);
    }

    @Test
    void testHashCode() {
        var edicaoItemVistoria1 = EdicaoItemVistoriaDTO.builder()
                .nome("Vidro")
                .descricao("Vidro do Carro")
                .subitens(new ArrayList<>())
                .build();
        assertEquals(edicaoItemVistoria.hashCode(), edicaoItemVistoria1.hashCode());

        var edicaoItemVistoria2 = EdicaoItemVistoriaDTO.builder().build();
        assertNotEquals(edicaoItemVistoria.hashCode(), edicaoItemVistoria2.hashCode());
    }

    @Test
    void testToString() {
        assertNotNull(edicaoItemVistoria.toString());
    }
}
```