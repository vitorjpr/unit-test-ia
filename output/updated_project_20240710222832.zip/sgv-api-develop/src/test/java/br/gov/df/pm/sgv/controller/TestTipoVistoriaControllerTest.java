```java
import br.gov.df.pm.sgv.controller.TipoVistoriaController;
import br.gov.df.pm.sgv.domain.ItemVistoriaEntity;
import br.gov.df.pm.sgv.domain.ItensVistoriaEntity;
import br.gov.df.pm.sgv.domain.TipoVistoriaEntity;
import br.gov.df.pm.sgv.dto.EdicaoTipoVistoriaDTO;
import br.gov.df.pm.sgv.dto.TipoVistoriaDTO;
import br.gov.df.pm.sgv.exceptions.VistoriaExceptions;
import br.gov.df.pm.sgv.repository.ItemVistoriaRepository;
import br.gov.df.pm.sgv.repository.ItensVistoriaRepository;
import br.gov.df.pm.sgv.repository.TipoVistoriaRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.PagedModel;
import org.springframework.http.ResponseEntity;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class TipoVistoriaControllerTest {

    @Mock
    TipoVistoriaRepository repository;

    @Mock
    ItemVistoriaRepository itemRepository;

    @Mock
    ItensVistoriaRepository itensRepository;

    TipoVistoriaController controller;

    ItemVistoriaEntity itemMock;
    TipoVistoriaEntity tipoMock;
    TipoVistoriaDTO tipoMockDto;
    EdicaoTipoVistoriaDTO edicaoTipoVistoriaMockDto;
    ItensVistoriaEntity itensVistoriaEntity;

    @BeforeEach
    void setUp() {
        controller = new TipoVistoriaController();

        tipoMock = TipoVistoriaEntity.builder()
                .id(1L)
                .nome("Vidro")
                .descricao("Vidro da Viatura")
                .ativo(true)
                .dataInclusao(LocalDate.now())
                .build();

        itemMock = ItemVistoriaEntity.builder()
                .id(1L)
                .nome("Vidro")
                .descricao("Vidro da Viatura")
                .ativo(true)
                .dataInclusao(LocalDate.now())
                .build();

        tipoMockDto = TipoVistoriaDTO.builder()
                .nome("Vidro")
                .descricao("Vidro da Viatura")
                .ativo(true)
                .dataInclusao(LocalDate.now())
                .itens(List.of(itemMock))
                .build();

        edicaoTipoVistoriaMockDto = EdicaoTipoVistoriaDTO.builder()
                .nome("Vidro")
                .descricao("Vidro da Vistoria")
                .build();

        itensVistoriaEntity = ItensVistoriaEntity.builder()
                .id(1L)
                .codItem(new ItemVistoriaEntity())
                .codTipo(new TipoVistoriaEntity())
                .dataInclusao(LocalDate.now())
                .ativo(true)
                .build();

        Specification<TipoVistoriaEntity> spec = any();
        Pageable pageable = any();
        when(repository.findAll(spec, pageable)).then(TestUtils.callableAnswer(invocation -> {
            Specification<TipoVistoriaDTO> s = invocation.getArgument(0);
            Root<TipoVistoriaDTO> root = mock(Root.class, withSettings().defaultAnswer(RETURNS_MOCKS));
            CriteriaQuery<TipoVistoriaDTO> query = mock(CriteriaQuery.class, withSettings().defaultAnswer(RETURNS_MOCKS));
            when(query.getResultType()).thenReturn(TipoVistoriaDTO.class);
            CriteriaBuilder builder = mock(CriteriaBuilder.class, withSettings().defaultAnswer(RETURNS_MOCKS));
            s.toPredicate(root, query, builder);
            return new PageImpl<>(List.of(tipoMock));
        }));
    }

    @Test
    void buscarId() {
        when(repository.findById(1L)).thenReturn(Optional.of(tipoMock));
        ResponseEntity<?> response = controller.buscarId(1L);
        assertNotNull(response);
    }

    @Test
    void buscar() {
        var pageable = PageRequest.of(0, 1);
        when(itemRepository.findByNome("Vidro")).thenReturn(Optional.of(itemMock));
        when(itensRepository.findAllByCodItem(new ItemVistoriaEntity())).thenReturn(List.of(itensVistoriaEntity));
        PagedModel<EntityModel<TipoVistoriaDTO>> response = controller.buscar("Vidro", pageable);
        assertNotNull(response);
    }

    @Test
    void salvar() {
