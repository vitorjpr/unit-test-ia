package br.gov.df.pm.sgv.service.impl;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isA;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import br.gov.df.pm.sgv.domain.ChecklistItemVistoriaEntity;
import br.gov.df.pm.sgv.domain.ChecklistVistoriaEntity;
import br.gov.df.pm.sgv.domain.ChecklistVistoriaSubItemEntity;
import br.gov.df.pm.sgv.domain.DefeitosVistoriaEntity;
import br.gov.df.pm.sgv.domain.DiferencaOdometroEntity;
import br.gov.df.pm.sgv.domain.ItemVistoriaEntity;
import br.gov.df.pm.sgv.domain.ItensVistoriaEntity;
import br.gov.df.pm.sgv.domain.SubitemVistoriaEntity;
import br.gov.df.pm.sgv.domain.SubitensVistoriaEntity;
import br.gov.df.pm.sgv.domain.TipoDefeitoVistoriaEntity;
import br.gov.df.pm.sgv.domain.TipoEmpregoViaturaEntity;
import br.gov.df.pm.sgv.domain.TipoVistoriaEntity;
import br.gov.df.pm.sgv.domain.ViaturaEntity;
import br.gov.df.pm.sgv.domain.VistoriaViaturaEntity;
import br.gov.df.pm.sgv.domain.enums.VistoriaViaturaStatusEnum;
import br.gov.df.pm.sgv.dto.FiltroVistoria;
import br.gov.df.pm.sgv.exceptions.ResourceNotFoundException;
import br.gov.df.pm.sgv.exceptions.ViaturaException;
import br.gov.df.pm.sgv.exceptions.VistoriaExceptions;
import br.gov.df.pm.sgv.repository.CheckListVistoriaSubitemRepository;
import br.gov.df.pm.sgv.repository.ChecklistVistoriaItemRepository;
import br.gov.df.pm.sgv.repository.ChecklistVistoriaRepository;
import br.gov.df.pm.sgv.repository.DefeitosVistoriaRepository;
import br.gov.df.pm.sgv.repository.ItemVistoriaRepository;
import br.gov.df.pm.sgv.repository.ItensVistoriaRepository;
import br.gov.df.pm.sgv.repository.SubitemVistoriaRepository;
import br.gov.df.pm.sgv.repository.SubitensVistoriaRepository;
import br.gov.df.pm.sgv.repository.TipoDefeitoVistoriaRepository;
import br.gov.df.pm.sgv.repository.TipoVistoriaRepository;
import br.gov.df.pm.sgv.repository.VIstoriaArquivoRepository;
import br.gov.df.pm.sgv.repository.app.ViaturaRepository;
import br.gov.df.pm.sgv.repository.app.VistoriaViaturaHistoricoRepository;
import br.gov.df.pm.sgv.repository.app.VistoriaViaturaRepository;
import br.gov.df.pm.sgv.security.UserProvider;
import br.gov.df.pm.sgv.service.StorageService;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.multipart.MultipartFile;

@ContextConfiguration(classes = {VistoriaServiceImpl.class})
@ExtendWith(SpringExtension.class)
class VistoriaServiceImplDiffblueTest {
    @MockBean
    private CheckListVistoriaSubitemRepository checkListVistoriaSubitemRepository;

    @MockBean
    private ChecklistVistoriaItemRepository checklistVistoriaItemRepository;

    @MockBean
    private ChecklistVistoriaRepository checklistVistoriaRepository;

    @MockBean
    private DefeitosVistoriaRepository defeitosVistoriaRepository;

    @MockBean
    private ItemVistoriaRepository itemVistoriaRepository;

    @MockBean
    private ItensVistoriaRepository itensVistoriaRepository;

    @MockBean
    private StorageService storageService;

    @MockBean
    private SubitemVistoriaRepository subitemVistoriaRepository;

    @MockBean
    private SubitensVistoriaRepository subitensVistoriaRepository;

    @MockBean
    private TipoDefeitoVistoriaRepository tipoDefeitoVistoriaRepository;

    @MockBean
    private TipoVistoriaRepository tipoVistoriaRepository;

    @MockBean
    private UserProvider userProvider;

    @MockBean
    private VIstoriaArquivoRepository vIstoriaArquivoRepository;

    @MockBean
    private ViaturaRepository viaturaRepository;

    @Autowired
    private VistoriaServiceImpl vistoriaServiceImpl;

    @MockBean
    private VistoriaViaturaHistoricoRepository vistoriaViaturaHistoricoRepository;

    @MockBean
    private VistoriaViaturaRepository vistoriaViaturaRepository;

    /**
     * Method under test: {@link VistoriaServiceImpl#salvar(String, List)}
     */
    @Test
    void testSalvar() {
        // Arrange, Act and Assert
        assertThrows(RuntimeException.class,
                () -> vistoriaServiceImpl.salvar("Vistoria não encontrada", new ArrayList<>()));
        assertThrows(RuntimeException.class, () -> vistoriaServiceImpl.salvar("42", new ArrayList<>()));
        assertThrows(RuntimeException.class, () -> vistoriaServiceImpl.salvar("", new ArrayList<>()));
    }

    /**
     * Method under test: {@link VistoriaServiceImpl#salvar(String, List)}
     */

    @Test
    void testSalvar2() throws IOException {
        // Arrange
        ArrayList<MultipartFile> arquivos = new ArrayList<>();
        arquivos
                .add(new MockMultipartFile("Vistoria não encontrada", new ByteArrayInputStream("AXAXAXAX".getBytes("UTF-8"))));

        // Act and Assert
        assertThrows(RuntimeException.class, () -> vistoriaServiceImpl.salvar("Vistoria String", arquivos));
    }

    /**
     * Method under test: {@link VistoriaServiceImpl#salvar(String, List)}
     */
    @Test
    void testSalvar3() throws IOException {
        // Arrange
        ArrayList<MultipartFile> arquivos = new ArrayList<>();
        arquivos
                .add(new MockMultipartFile("Vistoria não encontrada", new ByteArrayInputStream("AXAXAXAX".getBytes("UTF-8"))));
        arquivos
                .add(new MockMultipartFile("Vistoria não encontrada", new ByteArrayInputStream("AXAXAXAX".getBytes("UTF-8"))));

        // Act and Assert
        assertThrows(RuntimeException.class, () -> vistoriaServiceImpl.salvar("Vistoria String", arquivos));
    }

    /**
     * Method under test: {@link VistoriaServiceImpl#findVistoriaById(Long)}
     */
    @Test
    void testFindVistoriaById() {
        // Arrange
        TipoVistoriaEntity referenciaFinal = new TipoVistoriaEntity();
        referenciaFinal.setAtivo(true);
        referenciaFinal.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaFinal.setDescricao("Descricao");
        referenciaFinal.setId(1L);
        referenciaFinal.setNome("Nome");
        referenciaFinal.setStatusAnterior("Status Anterior");
        referenciaFinal.setStatusPosterior("Status Posterior");

        TipoVistoriaEntity referenciaInicial = new TipoVistoriaEntity();
        referenciaInicial.setAtivo(true);
        referenciaInicial.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaInicial.setDescricao("Descricao");
        referenciaInicial.setId(1L);
        referenciaInicial.setNome("Nome");
        referenciaInicial.setStatusAnterior("Status Anterior");
        referenciaInicial.setStatusPosterior("Status Posterior");

        DiferencaOdometroEntity diferencaOdometro = new DiferencaOdometroEntity();
        diferencaOdometro.setDataInclusao(LocalDate.of(1970, 1, 1));
        diferencaOdometro.setDataModificacao(LocalDate.of(1970, 1, 1));
        diferencaOdometro.setDiferencaOdometro(10.0d);
        diferencaOdometro.setId(1L);
        diferencaOdometro.setReferenciaFinal(referenciaFinal);
        diferencaOdometro.setReferenciaInicial(referenciaInicial);

        TipoVistoriaEntity tipoVistoria = new TipoVistoriaEntity();
        tipoVistoria.setAtivo(true);
        tipoVistoria.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoria.setDescricao("Descricao");
        tipoVistoria.setId(1L);
        tipoVistoria.setNome("Nome");
        tipoVistoria.setStatusAnterior("Status Anterior");
        tipoVistoria.setStatusPosterior("Status Posterior");

        TipoEmpregoViaturaEntity tipoEmpregoViatura = new TipoEmpregoViaturaEntity();
        tipoEmpregoViatura.setAtivo(1);
        tipoEmpregoViatura.setId(1);
        tipoEmpregoViatura.setNome("Nome");

        ViaturaEntity viatura = new ViaturaEntity();
        viatura.setAtivo(true);
        viatura.setDataAtualizacao(LocalDate.of(1970, 1, 1));
        viatura.setDataInclusao(LocalDate.of(1970, 1, 1));
        viatura.setId(1L);
        viatura.setListaUpm(new ArrayList<>());
        viatura.setMarcaModelo("Marca Modelo");
        viatura.setNrSei("Nr Sei");
        viatura.setPlaca("Placa");
        viatura.setPrefixo("Prefixo");
        viatura.setRenavam("Renavam");
        viatura.setStatus("Status");
        viatura.setTipoEmpregoViatura(tipoEmpregoViatura);
        viatura.setTombamento("alice.liddell@example.org");

        VistoriaViaturaEntity vistoriaViaturaEntity = new VistoriaViaturaEntity();
        vistoriaViaturaEntity.setCheckLists(new ArrayList<>());
        vistoriaViaturaEntity.setDataVistoria(LocalDate.of(1970, 1, 1).atStartOfDay());
        vistoriaViaturaEntity.setDiferencaOdometro(diferencaOdometro);
        vistoriaViaturaEntity.setDiferencaVistoria(true);
        vistoriaViaturaEntity.setId(1L);
        vistoriaViaturaEntity.setIdPolicial(1);
        vistoriaViaturaEntity.setIdUpm(1);
        vistoriaViaturaEntity.setOdometroFinal(10.0f);
        vistoriaViaturaEntity.setOdometroInicial(10.0f);
        vistoriaViaturaEntity.setStatus(VistoriaViaturaStatusEnum.DISPONIVEL);
        vistoriaViaturaEntity.setTipoVistoria(tipoVistoria);
        vistoriaViaturaEntity.setViatura(viatura);
        vistoriaViaturaEntity.setVistoriaArquivoList(new ArrayList<>());
        vistoriaViaturaEntity.setVistoriaViaturaHistorico(new ArrayList<>());
        Optional<VistoriaViaturaEntity> ofResult = Optional.of(vistoriaViaturaEntity);
        when(vistoriaViaturaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        // Act
        ResponseEntity<VistoriaViaturaEntity> actualFindVistoriaByIdResult = vistoriaServiceImpl.findVistoriaById(1L);

        // Assert
        verify(vistoriaViaturaRepository).findById(eq(1L));
        assertEquals(HttpStatus.OK, actualFindVistoriaByIdResult.getStatusCode());
        assertTrue(actualFindVistoriaByIdResult.hasBody());
        assertTrue(actualFindVistoriaByIdResult.getHeaders().isEmpty());
    }

    /**
     * Method under test: {@link VistoriaServiceImpl#editVistoriaById(String, List)}
     */
    @Test
    void testEditVistoriaById() {
        // Arrange, Act and Assert
        assertThrows(VistoriaExceptions.class,
                () -> vistoriaServiceImpl.editVistoriaById("Vistoria String", new ArrayList<>()));
        assertThrows(VistoriaExceptions.class, () -> vistoriaServiceImpl
                .editVistoriaById("Problema ao converter String vistoria para objeto Vistoria DTO", new ArrayList<>()));
        assertThrows(VistoriaExceptions.class, () -> vistoriaServiceImpl.editVistoriaById("42", new ArrayList<>()));
        assertThrows(VistoriaExceptions.class, () -> vistoriaServiceImpl.editVistoriaById("", new ArrayList<>()));
    }

    /**
     * Method under test: {@link VistoriaServiceImpl#editVistoriaById(String, List)}
     */
    @Test
    void testEditVistoriaById2() throws IOException {
        // Arrange
        ArrayList<MultipartFile> arquivos = new ArrayList<>();
        arquivos.add(new MockMultipartFile("Problema ao converter String vistoria para objeto Vistoria DTO",
                new ByteArrayInputStream("AXAXAXAX".getBytes("UTF-8"))));

        // Act and Assert
        assertThrows(VistoriaExceptions.class, () -> vistoriaServiceImpl.editVistoriaById("Vistoria String", arquivos));
    }

    /**
     * Method under test: {@link VistoriaServiceImpl#editVistoriaById(String, List)}
     */
    @Test
    void testEditVistoriaById3() throws IOException {
        // Arrange
        ArrayList<MultipartFile> arquivos = new ArrayList<>();
        arquivos.add(new MockMultipartFile("Problema ao converter String vistoria para objeto Vistoria DTO",
                new ByteArrayInputStream("AXAXAXAX".getBytes("UTF-8"))));
        arquivos.add(new MockMultipartFile("Problema ao converter String vistoria para objeto Vistoria DTO",
                new ByteArrayInputStream("AXAXAXAX".getBytes("UTF-8"))));

        // Act and Assert
        assertThrows(VistoriaExceptions.class, () -> vistoriaServiceImpl.editVistoriaById("Vistoria String", arquivos));
    }

    /**
     * Method under test:
     * {@link VistoriaServiceImpl#buscar(FiltroVistoria, Pageable)}
     */
    @Test
    void testBuscar() {
        // Arrange
        PageImpl<VistoriaViaturaEntity> pageImpl = new PageImpl<>(new ArrayList<>());
        when(vistoriaViaturaRepository.findAllByFiltro(Mockito.<FiltroVistoria>any(), Mockito.<Pageable>any()))
                .thenReturn(pageImpl);

        // Act
        Page<VistoriaViaturaEntity> actualBuscarResult = vistoriaServiceImpl.buscar(null, null);

        // Assert
        verify(vistoriaViaturaRepository).findAllByFiltro(isNull(), isNull());
        assertTrue(actualBuscarResult.toList().isEmpty());
        assertSame(pageImpl, actualBuscarResult);
    }

    /**
     * Method under test:
     * {@link VistoriaServiceImpl#buscar(FiltroVistoria, Pageable)}
     */
    @Test
    void testBuscar2() {
        // Arrange
        when(vistoriaViaturaRepository.findAllByFiltro(Mockito.<FiltroVistoria>any(), Mockito.<Pageable>any()))
                .thenThrow(new RuntimeException("foo"));

        // Act and Assert
        assertThrows(RuntimeException.class, () -> vistoriaServiceImpl.buscar(null, null));
        verify(vistoriaViaturaRepository).findAllByFiltro(isNull(), isNull());
    }

    /**
     * Method under test:
     * {@link VistoriaServiceImpl#makeChecklistByTipoVistoria(Long)}
     */
    @Test
    void testMakeChecklistByTipoVistoria() {
        // Arrange
        ArrayList<ItensVistoriaEntity> itensVistoriaEntityList = new ArrayList<>();
        when(itensVistoriaRepository.findAllByCodTipo(Mockito.<TipoVistoriaEntity>any()))
                .thenReturn(itensVistoriaEntityList);

        TipoVistoriaEntity tipoVistoriaEntity = new TipoVistoriaEntity();
        tipoVistoriaEntity.setAtivo(true);
        tipoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoriaEntity.setDescricao("Descricao");
        tipoVistoriaEntity.setId(1L);
        tipoVistoriaEntity.setNome("Nome");
        tipoVistoriaEntity.setStatusAnterior("Status Anterior");
        tipoVistoriaEntity.setStatusPosterior("Status Posterior");
        Optional<TipoVistoriaEntity> ofResult = Optional.of(tipoVistoriaEntity);
        when(tipoVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        // Act
        ResponseEntity<ChecklistVistoriaEntity> actualMakeChecklistByTipoVistoriaResult = vistoriaServiceImpl
                .makeChecklistByTipoVistoria(1L);

        // Assert
        verify(itensVistoriaRepository).findAllByCodTipo(isA(TipoVistoriaEntity.class));
        verify(tipoVistoriaRepository).findById(eq(1L));
        assertEquals(HttpStatus.OK, actualMakeChecklistByTipoVistoriaResult.getStatusCode());
        assertTrue(actualMakeChecklistByTipoVistoriaResult.hasBody());
        assertTrue(actualMakeChecklistByTipoVistoriaResult.getHeaders().isEmpty());
        assertEquals(itensVistoriaEntityList, actualMakeChecklistByTipoVistoriaResult.getBody().getChecklistItens());
    }

    /**
     * Method under test:
     * {@link VistoriaServiceImpl#makeChecklistByTipoVistoria(Long)}
     */
    @Test
    void testMakeChecklistByTipoVistoria2() {
        // Arrange
        when(itensVistoriaRepository.findAllByCodTipo(Mockito.<TipoVistoriaEntity>any()))
                .thenThrow(new RuntimeException("foo"));

        TipoVistoriaEntity tipoVistoriaEntity = new TipoVistoriaEntity();
        tipoVistoriaEntity.setAtivo(true);
        tipoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoriaEntity.setDescricao("Descricao");
        tipoVistoriaEntity.setId(1L);
        tipoVistoriaEntity.setNome("Nome");
        tipoVistoriaEntity.setStatusAnterior("Status Anterior");
        tipoVistoriaEntity.setStatusPosterior("Status Posterior");
        Optional<TipoVistoriaEntity> ofResult = Optional.of(tipoVistoriaEntity);
        when(tipoVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        // Act and Assert
        assertThrows(RuntimeException.class, () -> vistoriaServiceImpl.makeChecklistByTipoVistoria(1L));
        verify(itensVistoriaRepository).findAllByCodTipo(isA(TipoVistoriaEntity.class));
        verify(tipoVistoriaRepository).findById(eq(1L));
    }

    /**
     * Method under test:
     * {@link VistoriaServiceImpl#makeChecklistByTipoVistoria(Long)}
     */
    @Test
    void testMakeChecklistByTipoVistoria3() {
        // Arrange
        ItemVistoriaEntity itemVistoriaEntity = new ItemVistoriaEntity();
        itemVistoriaEntity.setAtivo(true);
        itemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity.setDescricao("Descricao");
        itemVistoriaEntity.setId(1L);
        itemVistoriaEntity.setNome("Nome");
        Optional<ItemVistoriaEntity> ofResult = Optional.of(itemVistoriaEntity);
        when(itemVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        ItemVistoriaEntity codItem = new ItemVistoriaEntity();
        codItem.setAtivo(true);
        codItem.setDataInclusao(LocalDate.of(1970, 1, 1));
        codItem.setDescricao("Descricao");
        codItem.setId(1L);
        codItem.setNome("Nome");

        TipoVistoriaEntity codTipo = new TipoVistoriaEntity();
        codTipo.setAtivo(true);
        codTipo.setDataInclusao(LocalDate.of(1970, 1, 1));
        codTipo.setDescricao("Descricao");
        codTipo.setId(1L);
        codTipo.setNome("Nome");
        codTipo.setStatusAnterior("Status Anterior");
        codTipo.setStatusPosterior("Status Posterior");

        ItensVistoriaEntity itensVistoriaEntity = new ItensVistoriaEntity();
        itensVistoriaEntity.setAtivo(true);
        itensVistoriaEntity.setCodItem(codItem);
        itensVistoriaEntity.setCodTipo(codTipo);
        itensVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itensVistoriaEntity.setId(1L);

        ArrayList<ItensVistoriaEntity> itensVistoriaEntityList = new ArrayList<>();
        itensVistoriaEntityList.add(itensVistoriaEntity);
        when(itensVistoriaRepository.findAllByCodTipo(Mockito.<TipoVistoriaEntity>any()))
                .thenReturn(itensVistoriaEntityList);
        ArrayList<SubitensVistoriaEntity> subitensVistoriaEntityList = new ArrayList<>();
        when(subitensVistoriaRepository.findAllByCodItem(Mockito.<ItemVistoriaEntity>any()))
                .thenReturn(subitensVistoriaEntityList);

        TipoVistoriaEntity tipoVistoriaEntity = new TipoVistoriaEntity();
        tipoVistoriaEntity.setAtivo(true);
        tipoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoriaEntity.setDescricao("Descricao");
        tipoVistoriaEntity.setId(1L);
        tipoVistoriaEntity.setNome("Nome");
        tipoVistoriaEntity.setStatusAnterior("Status Anterior");
        tipoVistoriaEntity.setStatusPosterior("Status Posterior");
        Optional<TipoVistoriaEntity> ofResult2 = Optional.of(tipoVistoriaEntity);
        when(tipoVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult2);

        // Act
        ResponseEntity<ChecklistVistoriaEntity> actualMakeChecklistByTipoVistoriaResult = vistoriaServiceImpl
                .makeChecklistByTipoVistoria(1L);

        // Assert
        verify(itensVistoriaRepository).findAllByCodTipo(isA(TipoVistoriaEntity.class));
        verify(subitensVistoriaRepository).findAllByCodItem(isA(ItemVistoriaEntity.class));
        verify(itemVistoriaRepository).findById(eq(1L));
        verify(tipoVistoriaRepository).findById(eq(1L));
        assertEquals(HttpStatus.OK, actualMakeChecklistByTipoVistoriaResult.getStatusCode());
        ChecklistVistoriaEntity body = actualMakeChecklistByTipoVistoriaResult.getBody();
        assertTrue(body.getItemVistoria().getAtivo());
        assertTrue(actualMakeChecklistByTipoVistoriaResult.hasBody());
        assertTrue(actualMakeChecklistByTipoVistoriaResult.getHeaders().isEmpty());
        assertEquals(subitensVistoriaEntityList, body.getChecklistItens());
    }

    /**
     * Method under test:
     * {@link VistoriaServiceImpl#makeChecklistByTipoVistoria(Long)}
     */
    @Test
    void testMakeChecklistByTipoVistoria4() {
        // Arrange
        ItemVistoriaEntity itemVistoriaEntity = new ItemVistoriaEntity();
        itemVistoriaEntity.setAtivo(true);
        itemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity.setDescricao("Descricao");
        itemVistoriaEntity.setId(1L);
        itemVistoriaEntity.setNome("Nome");
        Optional<ItemVistoriaEntity> ofResult = Optional.of(itemVistoriaEntity);
        when(itemVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        ItemVistoriaEntity codItem = new ItemVistoriaEntity();
        codItem.setAtivo(true);
        codItem.setDataInclusao(LocalDate.of(1970, 1, 1));
        codItem.setDescricao("Descricao");
        codItem.setId(1L);
        codItem.setNome("Nome");

        TipoVistoriaEntity codTipo = new TipoVistoriaEntity();
        codTipo.setAtivo(true);
        codTipo.setDataInclusao(LocalDate.of(1970, 1, 1));
        codTipo.setDescricao("Descricao");
        codTipo.setId(1L);
        codTipo.setNome("Nome");
        codTipo.setStatusAnterior("Status Anterior");
        codTipo.setStatusPosterior("Status Posterior");

        ItensVistoriaEntity itensVistoriaEntity = new ItensVistoriaEntity();
        itensVistoriaEntity.setAtivo(true);
        itensVistoriaEntity.setCodItem(codItem);
        itensVistoriaEntity.setCodTipo(codTipo);
        itensVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itensVistoriaEntity.setId(1L);

        ArrayList<ItensVistoriaEntity> itensVistoriaEntityList = new ArrayList<>();
        itensVistoriaEntityList.add(itensVistoriaEntity);
        when(itensVistoriaRepository.findAllByCodTipo(Mockito.<TipoVistoriaEntity>any()))
                .thenReturn(itensVistoriaEntityList);
        when(subitensVistoriaRepository.findAllByCodItem(Mockito.<ItemVistoriaEntity>any()))
                .thenThrow(new RuntimeException("foo"));

        TipoVistoriaEntity tipoVistoriaEntity = new TipoVistoriaEntity();
        tipoVistoriaEntity.setAtivo(true);
        tipoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoriaEntity.setDescricao("Descricao");
        tipoVistoriaEntity.setId(1L);
        tipoVistoriaEntity.setNome("Nome");
        tipoVistoriaEntity.setStatusAnterior("Status Anterior");
        tipoVistoriaEntity.setStatusPosterior("Status Posterior");
        Optional<TipoVistoriaEntity> ofResult2 = Optional.of(tipoVistoriaEntity);
        when(tipoVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult2);

        // Act and Assert
        assertThrows(RuntimeException.class, () -> vistoriaServiceImpl.makeChecklistByTipoVistoria(1L));
        verify(itensVistoriaRepository).findAllByCodTipo(isA(TipoVistoriaEntity.class));
        verify(subitensVistoriaRepository).findAllByCodItem(isA(ItemVistoriaEntity.class));
        verify(itemVistoriaRepository).findById(eq(1L));
        verify(tipoVistoriaRepository).findById(eq(1L));
    }

    /**
     * Method under test:
     * {@link VistoriaServiceImpl#makeChecklistByTipoVistoria(Long)}
     */
    @Test
    void testMakeChecklistByTipoVistoria5() {
        // Arrange
        Optional<ItemVistoriaEntity> emptyResult = Optional.empty();
        when(itemVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(emptyResult);

        ItemVistoriaEntity codItem = new ItemVistoriaEntity();
        codItem.setAtivo(true);
        codItem.setDataInclusao(LocalDate.of(1970, 1, 1));
        codItem.setDescricao("Descricao");
        codItem.setId(1L);
        codItem.setNome("Nome");

        TipoVistoriaEntity codTipo = new TipoVistoriaEntity();
        codTipo.setAtivo(true);
        codTipo.setDataInclusao(LocalDate.of(1970, 1, 1));
        codTipo.setDescricao("Descricao");
        codTipo.setId(1L);
        codTipo.setNome("Nome");
        codTipo.setStatusAnterior("Status Anterior");
        codTipo.setStatusPosterior("Status Posterior");

        ItensVistoriaEntity itensVistoriaEntity = new ItensVistoriaEntity();
        itensVistoriaEntity.setAtivo(true);
        itensVistoriaEntity.setCodItem(codItem);
        itensVistoriaEntity.setCodTipo(codTipo);
        itensVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itensVistoriaEntity.setId(1L);

        ArrayList<ItensVistoriaEntity> itensVistoriaEntityList = new ArrayList<>();
        itensVistoriaEntityList.add(itensVistoriaEntity);
        when(itensVistoriaRepository.findAllByCodTipo(Mockito.<TipoVistoriaEntity>any()))
                .thenReturn(itensVistoriaEntityList);

        TipoVistoriaEntity tipoVistoriaEntity = new TipoVistoriaEntity();
        tipoVistoriaEntity.setAtivo(true);
        tipoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoriaEntity.setDescricao("Descricao");
        tipoVistoriaEntity.setId(1L);
        tipoVistoriaEntity.setNome("Nome");
        tipoVistoriaEntity.setStatusAnterior("Status Anterior");
        tipoVistoriaEntity.setStatusPosterior("Status Posterior");
        Optional<TipoVistoriaEntity> ofResult = Optional.of(tipoVistoriaEntity);
        when(tipoVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        // Act and Assert
        assertThrows(ResourceNotFoundException.class, () -> vistoriaServiceImpl.makeChecklistByTipoVistoria(1L));
        verify(itensVistoriaRepository).findAllByCodTipo(isA(TipoVistoriaEntity.class));
        verify(itemVistoriaRepository).findById(eq(1L));
        verify(tipoVistoriaRepository).findById(eq(1L));
    }

    /**
     * Method under test:
     * {@link VistoriaServiceImpl#makeChecklistByTipoVistoria(Long)}
     */
    @Test
    void testMakeChecklistByTipoVistoria6() {
        // Arrange
        ArrayList<DefeitosVistoriaEntity> defeitosVistoriaEntityList = new ArrayList<>();
        when(defeitosVistoriaRepository.findAllByCodSubitem(Mockito.<SubitemVistoriaEntity>any()))
                .thenReturn(defeitosVistoriaEntityList);

        ItemVistoriaEntity itemVistoriaEntity = new ItemVistoriaEntity();
        itemVistoriaEntity.setAtivo(true);
        itemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity.setDescricao("Descricao");
        itemVistoriaEntity.setId(1L);
        itemVistoriaEntity.setNome("Nome");
        Optional<ItemVistoriaEntity> ofResult = Optional.of(itemVistoriaEntity);
        when(itemVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        ItemVistoriaEntity codItem = new ItemVistoriaEntity();
        codItem.setAtivo(true);
        codItem.setDataInclusao(LocalDate.of(1970, 1, 1));
        codItem.setDescricao("Descricao");
        codItem.setId(1L);
        codItem.setNome("Nome");

        TipoVistoriaEntity codTipo = new TipoVistoriaEntity();
        codTipo.setAtivo(true);
        codTipo.setDataInclusao(LocalDate.of(1970, 1, 1));
        codTipo.setDescricao("Descricao");
        codTipo.setId(1L);
        codTipo.setNome("Nome");
        codTipo.setStatusAnterior("Status Anterior");
        codTipo.setStatusPosterior("Status Posterior");

        ItemVistoriaEntity itemVistoriaEntity2 = new ItemVistoriaEntity();
        itemVistoriaEntity2.setAtivo(true);
        itemVistoriaEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity2.setDescricao("Descricao");
        itemVistoriaEntity2.setId(1L);
        itemVistoriaEntity2.setNome("Nome");
        ItensVistoriaEntity itensVistoriaEntity = mock(ItensVistoriaEntity.class);
        when(itensVistoriaEntity.getCodItem()).thenReturn(itemVistoriaEntity2);
        doNothing().when(itensVistoriaEntity).setAtivo(Mockito.<Boolean>any());
        doNothing().when(itensVistoriaEntity).setCodItem(Mockito.<ItemVistoriaEntity>any());
        doNothing().when(itensVistoriaEntity).setCodTipo(Mockito.<TipoVistoriaEntity>any());
        doNothing().when(itensVistoriaEntity).setDataInclusao(Mockito.<LocalDate>any());
        doNothing().when(itensVistoriaEntity).setId(Mockito.<Long>any());
        itensVistoriaEntity.setAtivo(true);
        itensVistoriaEntity.setCodItem(codItem);
        itensVistoriaEntity.setCodTipo(codTipo);
        itensVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itensVistoriaEntity.setId(1L);

        ArrayList<ItensVistoriaEntity> itensVistoriaEntityList = new ArrayList<>();
        itensVistoriaEntityList.add(itensVistoriaEntity);
        when(itensVistoriaRepository.findAllByCodTipo(Mockito.<TipoVistoriaEntity>any()))
                .thenReturn(itensVistoriaEntityList);

        SubitemVistoriaEntity subitemVistoriaEntity = new SubitemVistoriaEntity();
        subitemVistoriaEntity.setAtivo(true);
        subitemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        subitemVistoriaEntity.setDescricao("Descricao");
        subitemVistoriaEntity.setId(1L);
        subitemVistoriaEntity.setNome("Nome");
        Optional<SubitemVistoriaEntity> ofResult2 = Optional.of(subitemVistoriaEntity);
        when(subitemVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult2);

        ItemVistoriaEntity codItem2 = new ItemVistoriaEntity();
        codItem2.setAtivo(true);
        codItem2.setDataInclusao(LocalDate.of(1970, 1, 1));
        codItem2.setDescricao("Descricao");
        codItem2.setId(1L);
        codItem2.setNome("Nome");

        SubitemVistoriaEntity codSubitem = new SubitemVistoriaEntity();
        codSubitem.setAtivo(true);
        codSubitem.setDataInclusao(LocalDate.of(1970, 1, 1));
        codSubitem.setDescricao("Descricao");
        codSubitem.setId(1L);
        codSubitem.setNome("Nome");

        SubitensVistoriaEntity subitensVistoriaEntity = new SubitensVistoriaEntity();
        subitensVistoriaEntity.setAtivo(true);
        subitensVistoriaEntity.setCodItem(codItem2);
        subitensVistoriaEntity.setCodSubitem(codSubitem);
        subitensVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        subitensVistoriaEntity.setId(1L);

        ArrayList<SubitensVistoriaEntity> subitensVistoriaEntityList = new ArrayList<>();
        subitensVistoriaEntityList.add(subitensVistoriaEntity);
        when(subitensVistoriaRepository.findAllByCodItem(Mockito.<ItemVistoriaEntity>any()))
                .thenReturn(subitensVistoriaEntityList);

        TipoVistoriaEntity tipoVistoriaEntity = new TipoVistoriaEntity();
        tipoVistoriaEntity.setAtivo(true);
        tipoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoriaEntity.setDescricao("Descricao");
        tipoVistoriaEntity.setId(1L);
        tipoVistoriaEntity.setNome("Nome");
        tipoVistoriaEntity.setStatusAnterior("Status Anterior");
        tipoVistoriaEntity.setStatusPosterior("Status Posterior");
        Optional<TipoVistoriaEntity> ofResult3 = Optional.of(tipoVistoriaEntity);
        when(tipoVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult3);

        // Act
        ResponseEntity<ChecklistVistoriaEntity> actualMakeChecklistByTipoVistoriaResult = vistoriaServiceImpl
                .makeChecklistByTipoVistoria(1L);

        // Assert
        verify(itensVistoriaEntity).getCodItem();
        verify(itensVistoriaEntity).setAtivo(eq(true));
        verify(itensVistoriaEntity).setCodItem(isA(ItemVistoriaEntity.class));
        verify(itensVistoriaEntity).setCodTipo(isA(TipoVistoriaEntity.class));
        verify(itensVistoriaEntity).setDataInclusao(isA(LocalDate.class));
        verify(itensVistoriaEntity).setId(eq(1L));
        verify(defeitosVistoriaRepository).findAllByCodSubitem(isA(SubitemVistoriaEntity.class));
        verify(itensVistoriaRepository).findAllByCodTipo(isA(TipoVistoriaEntity.class));
        verify(subitensVistoriaRepository).findAllByCodItem(isA(ItemVistoriaEntity.class));
        verify(itemVistoriaRepository).findById(eq(1L));
        verify(subitemVistoriaRepository).findById(eq(1L));
        verify(tipoVistoriaRepository).findById(eq(1L));
        List<ChecklistItemVistoriaEntity> checklistItens = actualMakeChecklistByTipoVistoriaResult.getBody()
                .getChecklistItens();
        assertEquals(1, checklistItens.size());
        ChecklistItemVistoriaEntity getResult = checklistItens.get(0).getChecklistVistoria().getChecklistItens().get(0);
        ChecklistVistoriaEntity checklistVistoria = getResult.getChecklistVistoria();
        assertNull(checklistVistoria.getDataCriacao());
        assertEquals(HttpStatus.OK, actualMakeChecklistByTipoVistoriaResult.getStatusCode());
        assertTrue(checklistVistoria.getItemVistoria().getAtivo());
        assertTrue(getResult.getSubitemVistoria().getAtivo());
        assertTrue(actualMakeChecklistByTipoVistoriaResult.hasBody());
        assertTrue(actualMakeChecklistByTipoVistoriaResult.getHeaders().isEmpty());
        assertEquals(defeitosVistoriaEntityList, getResult.getChecklistVistoriaSubItem());
    }

    /**
     * Method under test:
     * {@link VistoriaServiceImpl#makeChecklistByTipoVistoria(Long)}
     */
    @Test
    void testMakeChecklistByTipoVistoria7() {
        // Arrange
        when(defeitosVistoriaRepository.findAllByCodSubitem(Mockito.<SubitemVistoriaEntity>any()))
                .thenThrow(new RuntimeException("foo"));

        ItemVistoriaEntity itemVistoriaEntity = new ItemVistoriaEntity();
        itemVistoriaEntity.setAtivo(true);
        itemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity.setDescricao("Descricao");
        itemVistoriaEntity.setId(1L);
        itemVistoriaEntity.setNome("Nome");
        Optional<ItemVistoriaEntity> ofResult = Optional.of(itemVistoriaEntity);
        when(itemVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        ItemVistoriaEntity codItem = new ItemVistoriaEntity();
        codItem.setAtivo(true);
        codItem.setDataInclusao(LocalDate.of(1970, 1, 1));
        codItem.setDescricao("Descricao");
        codItem.setId(1L);
        codItem.setNome("Nome");

        TipoVistoriaEntity codTipo = new TipoVistoriaEntity();
        codTipo.setAtivo(true);
        codTipo.setDataInclusao(LocalDate.of(1970, 1, 1));
        codTipo.setDescricao("Descricao");
        codTipo.setId(1L);
        codTipo.setNome("Nome");
        codTipo.setStatusAnterior("Status Anterior");
        codTipo.setStatusPosterior("Status Posterior");

        ItemVistoriaEntity itemVistoriaEntity2 = new ItemVistoriaEntity();
        itemVistoriaEntity2.setAtivo(true);
        itemVistoriaEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity2.setDescricao("Descricao");
        itemVistoriaEntity2.setId(1L);
        itemVistoriaEntity2.setNome("Nome");
        ItensVistoriaEntity itensVistoriaEntity = mock(ItensVistoriaEntity.class);
        when(itensVistoriaEntity.getCodItem()).thenReturn(itemVistoriaEntity2);
        doNothing().when(itensVistoriaEntity).setAtivo(Mockito.<Boolean>any());
        doNothing().when(itensVistoriaEntity).setCodItem(Mockito.<ItemVistoriaEntity>any());
        doNothing().when(itensVistoriaEntity).setCodTipo(Mockito.<TipoVistoriaEntity>any());
        doNothing().when(itensVistoriaEntity).setDataInclusao(Mockito.<LocalDate>any());
        doNothing().when(itensVistoriaEntity).setId(Mockito.<Long>any());
        itensVistoriaEntity.setAtivo(true);
        itensVistoriaEntity.setCodItem(codItem);
        itensVistoriaEntity.setCodTipo(codTipo);
        itensVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itensVistoriaEntity.setId(1L);

        ArrayList<ItensVistoriaEntity> itensVistoriaEntityList = new ArrayList<>();
        itensVistoriaEntityList.add(itensVistoriaEntity);
        when(itensVistoriaRepository.findAllByCodTipo(Mockito.<TipoVistoriaEntity>any()))
                .thenReturn(itensVistoriaEntityList);

        SubitemVistoriaEntity subitemVistoriaEntity = new SubitemVistoriaEntity();
        subitemVistoriaEntity.setAtivo(true);
        subitemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        subitemVistoriaEntity.setDescricao("Descricao");
        subitemVistoriaEntity.setId(1L);
        subitemVistoriaEntity.setNome("Nome");
        Optional<SubitemVistoriaEntity> ofResult2 = Optional.of(subitemVistoriaEntity);
        when(subitemVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult2);

        ItemVistoriaEntity codItem2 = new ItemVistoriaEntity();
        codItem2.setAtivo(true);
        codItem2.setDataInclusao(LocalDate.of(1970, 1, 1));
        codItem2.setDescricao("Descricao");
        codItem2.setId(1L);
        codItem2.setNome("Nome");

        SubitemVistoriaEntity codSubitem = new SubitemVistoriaEntity();
        codSubitem.setAtivo(true);
        codSubitem.setDataInclusao(LocalDate.of(1970, 1, 1));
        codSubitem.setDescricao("Descricao");
        codSubitem.setId(1L);
        codSubitem.setNome("Nome");

        SubitensVistoriaEntity subitensVistoriaEntity = new SubitensVistoriaEntity();
        subitensVistoriaEntity.setAtivo(true);
        subitensVistoriaEntity.setCodItem(codItem2);
        subitensVistoriaEntity.setCodSubitem(codSubitem);
        subitensVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        subitensVistoriaEntity.setId(1L);

        ArrayList<SubitensVistoriaEntity> subitensVistoriaEntityList = new ArrayList<>();
        subitensVistoriaEntityList.add(subitensVistoriaEntity);
        when(subitensVistoriaRepository.findAllByCodItem(Mockito.<ItemVistoriaEntity>any()))
                .thenReturn(subitensVistoriaEntityList);

        TipoVistoriaEntity tipoVistoriaEntity = new TipoVistoriaEntity();
        tipoVistoriaEntity.setAtivo(true);
        tipoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoriaEntity.setDescricao("Descricao");
        tipoVistoriaEntity.setId(1L);
        tipoVistoriaEntity.setNome("Nome");
        tipoVistoriaEntity.setStatusAnterior("Status Anterior");
        tipoVistoriaEntity.setStatusPosterior("Status Posterior");
        Optional<TipoVistoriaEntity> ofResult3 = Optional.of(tipoVistoriaEntity);
        when(tipoVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult3);

        // Act and Assert
        assertThrows(RuntimeException.class, () -> vistoriaServiceImpl.makeChecklistByTipoVistoria(1L));
        verify(itensVistoriaEntity).getCodItem();
        verify(itensVistoriaEntity).setAtivo(eq(true));
        verify(itensVistoriaEntity).setCodItem(isA(ItemVistoriaEntity.class));
        verify(itensVistoriaEntity).setCodTipo(isA(TipoVistoriaEntity.class));
        verify(itensVistoriaEntity).setDataInclusao(isA(LocalDate.class));
        verify(itensVistoriaEntity).setId(eq(1L));
        verify(defeitosVistoriaRepository).findAllByCodSubitem(isA(SubitemVistoriaEntity.class));
        verify(itensVistoriaRepository).findAllByCodTipo(isA(TipoVistoriaEntity.class));
        verify(subitensVistoriaRepository).findAllByCodItem(isA(ItemVistoriaEntity.class));
        verify(itemVistoriaRepository).findById(eq(1L));
        verify(subitemVistoriaRepository).findById(eq(1L));
        verify(tipoVistoriaRepository).findById(eq(1L));
    }

    /**
     * Method under test:
     * {@link VistoriaServiceImpl#makeChecklistByTipoVistoria(Long)}
     */
    @Test
    void testMakeChecklistByTipoVistoria8() {
        // Arrange
        SubitemVistoriaEntity codSubitem = new SubitemVistoriaEntity();
        codSubitem.setAtivo(true);
        codSubitem.setDataInclusao(LocalDate.of(1970, 1, 1));
        codSubitem.setDescricao("Descricao");
        codSubitem.setId(1L);
        codSubitem.setNome("Nome");

        TipoDefeitoVistoriaEntity codTipoDefeito = new TipoDefeitoVistoriaEntity();
        codTipoDefeito.setAtivo(true);
        codTipoDefeito.setDataInclusao(LocalDate.of(1970, 1, 1));
        codTipoDefeito.setDescricao("Descricao");
        codTipoDefeito.setId(1L);
        codTipoDefeito.setNome("Nome");

        DefeitosVistoriaEntity defeitosVistoriaEntity = new DefeitosVistoriaEntity();
        defeitosVistoriaEntity.setAtivo(true);
        defeitosVistoriaEntity.setCodSubitem(codSubitem);
        defeitosVistoriaEntity.setCodTipoDefeito(codTipoDefeito);
        defeitosVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        defeitosVistoriaEntity.setId(1L);

        ArrayList<DefeitosVistoriaEntity> defeitosVistoriaEntityList = new ArrayList<>();
        defeitosVistoriaEntityList.add(defeitosVistoriaEntity);
        when(defeitosVistoriaRepository.findAllByCodSubitem(Mockito.<SubitemVistoriaEntity>any()))
                .thenReturn(defeitosVistoriaEntityList);

        ItemVistoriaEntity itemVistoriaEntity = new ItemVistoriaEntity();
        itemVistoriaEntity.setAtivo(true);
        itemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity.setDescricao("Descricao");
        itemVistoriaEntity.setId(1L);
        itemVistoriaEntity.setNome("Nome");
        Optional<ItemVistoriaEntity> ofResult = Optional.of(itemVistoriaEntity);
        when(itemVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        ItemVistoriaEntity codItem = new ItemVistoriaEntity();
        codItem.setAtivo(true);
        codItem.setDataInclusao(LocalDate.of(1970, 1, 1));
        codItem.setDescricao("Descricao");
        codItem.setId(1L);
        codItem.setNome("Nome");

        TipoVistoriaEntity codTipo = new TipoVistoriaEntity();
        codTipo.setAtivo(true);
        codTipo.setDataInclusao(LocalDate.of(1970, 1, 1));
        codTipo.setDescricao("Descricao");
        codTipo.setId(1L);
        codTipo.setNome("Nome");
        codTipo.setStatusAnterior("Status Anterior");
        codTipo.setStatusPosterior("Status Posterior");

        ItemVistoriaEntity itemVistoriaEntity2 = new ItemVistoriaEntity();
        itemVistoriaEntity2.setAtivo(true);
        itemVistoriaEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity2.setDescricao("Descricao");
        itemVistoriaEntity2.setId(1L);
        itemVistoriaEntity2.setNome("Nome");
        ItensVistoriaEntity itensVistoriaEntity = mock(ItensVistoriaEntity.class);
        when(itensVistoriaEntity.getCodItem()).thenReturn(itemVistoriaEntity2);
        doNothing().when(itensVistoriaEntity).setAtivo(Mockito.<Boolean>any());
        doNothing().when(itensVistoriaEntity).setCodItem(Mockito.<ItemVistoriaEntity>any());
        doNothing().when(itensVistoriaEntity).setCodTipo(Mockito.<TipoVistoriaEntity>any());
        doNothing().when(itensVistoriaEntity).setDataInclusao(Mockito.<LocalDate>any());
        doNothing().when(itensVistoriaEntity).setId(Mockito.<Long>any());
        itensVistoriaEntity.setAtivo(true);
        itensVistoriaEntity.setCodItem(codItem);
        itensVistoriaEntity.setCodTipo(codTipo);
        itensVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itensVistoriaEntity.setId(1L);

        ArrayList<ItensVistoriaEntity> itensVistoriaEntityList = new ArrayList<>();
        itensVistoriaEntityList.add(itensVistoriaEntity);
        when(itensVistoriaRepository.findAllByCodTipo(Mockito.<TipoVistoriaEntity>any()))
                .thenReturn(itensVistoriaEntityList);

        SubitemVistoriaEntity subitemVistoriaEntity = new SubitemVistoriaEntity();
        subitemVistoriaEntity.setAtivo(true);
        subitemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        subitemVistoriaEntity.setDescricao("Descricao");
        subitemVistoriaEntity.setId(1L);
        subitemVistoriaEntity.setNome("Nome");
        Optional<SubitemVistoriaEntity> ofResult2 = Optional.of(subitemVistoriaEntity);
        when(subitemVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult2);

        ItemVistoriaEntity codItem2 = new ItemVistoriaEntity();
        codItem2.setAtivo(true);
        codItem2.setDataInclusao(LocalDate.of(1970, 1, 1));
        codItem2.setDescricao("Descricao");
        codItem2.setId(1L);
        codItem2.setNome("Nome");

        SubitemVistoriaEntity codSubitem2 = new SubitemVistoriaEntity();
        codSubitem2.setAtivo(true);
        codSubitem2.setDataInclusao(LocalDate.of(1970, 1, 1));
        codSubitem2.setDescricao("Descricao");
        codSubitem2.setId(1L);
        codSubitem2.setNome("Nome");

        SubitensVistoriaEntity subitensVistoriaEntity = new SubitensVistoriaEntity();
        subitensVistoriaEntity.setAtivo(true);
        subitensVistoriaEntity.setCodItem(codItem2);
        subitensVistoriaEntity.setCodSubitem(codSubitem2);
        subitensVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        subitensVistoriaEntity.setId(1L);

        ArrayList<SubitensVistoriaEntity> subitensVistoriaEntityList = new ArrayList<>();
        subitensVistoriaEntityList.add(subitensVistoriaEntity);
        when(subitensVistoriaRepository.findAllByCodItem(Mockito.<ItemVistoriaEntity>any()))
                .thenReturn(subitensVistoriaEntityList);

        TipoDefeitoVistoriaEntity tipoDefeitoVistoriaEntity = new TipoDefeitoVistoriaEntity();
        tipoDefeitoVistoriaEntity.setAtivo(true);
        tipoDefeitoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoDefeitoVistoriaEntity.setDescricao("Descricao");
        tipoDefeitoVistoriaEntity.setId(1L);
        tipoDefeitoVistoriaEntity.setNome("Nome");
        Optional<TipoDefeitoVistoriaEntity> ofResult3 = Optional.of(tipoDefeitoVistoriaEntity);
        when(tipoDefeitoVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult3);

        TipoVistoriaEntity tipoVistoriaEntity = new TipoVistoriaEntity();
        tipoVistoriaEntity.setAtivo(true);
        tipoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoriaEntity.setDescricao("Descricao");
        tipoVistoriaEntity.setId(1L);
        tipoVistoriaEntity.setNome("Nome");
        tipoVistoriaEntity.setStatusAnterior("Status Anterior");
        tipoVistoriaEntity.setStatusPosterior("Status Posterior");
        Optional<TipoVistoriaEntity> ofResult4 = Optional.of(tipoVistoriaEntity);
        when(tipoVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult4);

        // Act
        ResponseEntity<ChecklistVistoriaEntity> actualMakeChecklistByTipoVistoriaResult = vistoriaServiceImpl
                .makeChecklistByTipoVistoria(1L);

        // Assert
        verify(itensVistoriaEntity).getCodItem();
        verify(itensVistoriaEntity).setAtivo(eq(true));
        verify(itensVistoriaEntity).setCodItem(isA(ItemVistoriaEntity.class));
        verify(itensVistoriaEntity).setCodTipo(isA(TipoVistoriaEntity.class));
        verify(itensVistoriaEntity).setDataInclusao(isA(LocalDate.class));
        verify(itensVistoriaEntity).setId(eq(1L));
        verify(defeitosVistoriaRepository).findAllByCodSubitem(isA(SubitemVistoriaEntity.class));
        verify(itensVistoriaRepository).findAllByCodTipo(isA(TipoVistoriaEntity.class));
        verify(subitensVistoriaRepository).findAllByCodItem(isA(ItemVistoriaEntity.class));
        verify(itemVistoriaRepository).findById(eq(1L));
        verify(subitemVistoriaRepository).findById(eq(1L));
        verify(tipoDefeitoVistoriaRepository).findById(eq(1L));
        verify(tipoVistoriaRepository).findById(eq(1L));
        List<ChecklistItemVistoriaEntity> checklistItens = actualMakeChecklistByTipoVistoriaResult.getBody()
                .getChecklistItens();
        assertEquals(1, checklistItens.size());
        ChecklistItemVistoriaEntity getResult = checklistItens.get(0);
        assertNull(getResult.getChecklistVistoriaSubItem().get(0).getChecklistItemVistoria().getDatachCriacao());
        ChecklistItemVistoriaEntity getResult2 = getResult.getChecklistVistoria().getChecklistItens().get(0);
        ChecklistVistoriaEntity checklistVistoria = getResult2.getChecklistVistoria();
        assertNull(checklistVistoria.getDataCriacao());
        List<ChecklistVistoriaSubItemEntity> checklistVistoriaSubItem = getResult2.getChecklistVistoriaSubItem();
        assertEquals(1, checklistVistoriaSubItem.size());
        assertEquals(HttpStatus.OK, actualMakeChecklistByTipoVistoriaResult.getStatusCode());
        assertTrue(checklistVistoria.getItemVistoria().getAtivo());
        assertTrue(actualMakeChecklistByTipoVistoriaResult.hasBody());
        assertTrue(actualMakeChecklistByTipoVistoriaResult.getHeaders().isEmpty());
        assertEquals(codSubitem, getResult2.getSubitemVistoria());
        assertEquals(codTipoDefeito, checklistVistoriaSubItem.get(0).getTipoDefeitoVistoria());
    }

    /**
     * Method under test: {@link VistoriaServiceImpl#iniciarVistoria(Long, Long)}
     */
    @Test
    void testIniciarVistoria() {
        // Arrange
        when(itensVistoriaRepository.findAllByCodTipo(Mockito.<TipoVistoriaEntity>any())).thenReturn(new ArrayList<>());

        TipoVistoriaEntity tipoVistoriaEntity = new TipoVistoriaEntity();
        tipoVistoriaEntity.setAtivo(true);
        tipoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoriaEntity.setDescricao("Descricao");
        tipoVistoriaEntity.setId(1L);
        tipoVistoriaEntity.setNome("Nome");
        tipoVistoriaEntity.setStatusAnterior("Status Anterior");
        tipoVistoriaEntity.setStatusPosterior("Status Posterior");
        Optional<TipoVistoriaEntity> ofResult = Optional.of(tipoVistoriaEntity);
        when(tipoVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        TipoEmpregoViaturaEntity tipoEmpregoViatura = new TipoEmpregoViaturaEntity();
        tipoEmpregoViatura.setAtivo(1);
        tipoEmpregoViatura.setId(1);
        tipoEmpregoViatura.setNome("Nome");

        ViaturaEntity viaturaEntity = new ViaturaEntity();
        viaturaEntity.setAtivo(true);
        viaturaEntity.setDataAtualizacao(LocalDate.of(1970, 1, 1));
        viaturaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        viaturaEntity.setId(1L);
        viaturaEntity.setListaUpm(new ArrayList<>());
        viaturaEntity.setMarcaModelo("Marca Modelo");
        viaturaEntity.setNrSei("Nr Sei");
        viaturaEntity.setPlaca("Placa");
        viaturaEntity.setPrefixo("Prefixo");
        viaturaEntity.setRenavam("Renavam");
        viaturaEntity.setStatus("Status");
        viaturaEntity.setTipoEmpregoViatura(tipoEmpregoViatura);
        viaturaEntity.setTombamento("alice.liddell@example.org");
        Optional<ViaturaEntity> ofResult2 = Optional.of(viaturaEntity);

        TipoEmpregoViaturaEntity tipoEmpregoViatura2 = new TipoEmpregoViaturaEntity();
        tipoEmpregoViatura2.setAtivo(1);
        tipoEmpregoViatura2.setId(1);
        tipoEmpregoViatura2.setNome("Nome");

        ViaturaEntity viaturaEntity2 = new ViaturaEntity();
        viaturaEntity2.setAtivo(true);
        viaturaEntity2.setDataAtualizacao(LocalDate.of(1970, 1, 1));
        viaturaEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        viaturaEntity2.setId(1L);
        viaturaEntity2.setListaUpm(new ArrayList<>());
        viaturaEntity2.setMarcaModelo("Marca Modelo");
        viaturaEntity2.setNrSei("Nr Sei");
        viaturaEntity2.setPlaca("Placa");
        viaturaEntity2.setPrefixo("Prefixo");
        viaturaEntity2.setRenavam("Renavam");
        viaturaEntity2.setStatus("Status");
        viaturaEntity2.setTipoEmpregoViatura(tipoEmpregoViatura2);
        viaturaEntity2.setTombamento("alice.liddell@example.org");
        when(viaturaRepository.save(Mockito.<ViaturaEntity>any())).thenReturn(viaturaEntity2);
        when(viaturaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult2);

        // Act
        ResponseEntity<VistoriaViaturaEntity> actualIniciarVistoriaResult = vistoriaServiceImpl.iniciarVistoria(1L, 1L);

        // Assert
        verify(itensVistoriaRepository).findAllByCodTipo(isA(TipoVistoriaEntity.class));
        verify(tipoVistoriaRepository).findById(eq(1L));
        verify(viaturaRepository).findById(eq(1L));
        verify(viaturaRepository).save(isA(ViaturaEntity.class));
        VistoriaViaturaEntity body = actualIniciarVistoriaResult.getBody();
        assertEquals(1, body.getCheckLists().size());
        assertEquals(HttpStatus.OK, actualIniciarVistoriaResult.getStatusCode());
        assertTrue(body.getViatura().getAtivo());
        assertTrue(actualIniciarVistoriaResult.hasBody());
        assertTrue(actualIniciarVistoriaResult.getHeaders().isEmpty());
    }

    /**
     * Method under test: {@link VistoriaServiceImpl#iniciarVistoria(Long, Long)}
     */
    @Test
    void testIniciarVistoria2() {
        // Arrange
        TipoVistoriaEntity tipoVistoriaEntity = new TipoVistoriaEntity();
        tipoVistoriaEntity.setAtivo(true);
        tipoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoriaEntity.setDescricao("Descricao");
        tipoVistoriaEntity.setId(1L);
        tipoVistoriaEntity.setNome("Nome");
        tipoVistoriaEntity.setStatusAnterior("Status Anterior");
        tipoVistoriaEntity.setStatusPosterior("Status Posterior");
        Optional<TipoVistoriaEntity> ofResult = Optional.of(tipoVistoriaEntity);
        when(tipoVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        TipoEmpregoViaturaEntity tipoEmpregoViatura = new TipoEmpregoViaturaEntity();
        tipoEmpregoViatura.setAtivo(1);
        tipoEmpregoViatura.setId(1);
        tipoEmpregoViatura.setNome("Nome");

        ViaturaEntity viaturaEntity = new ViaturaEntity();
        viaturaEntity.setAtivo(true);
        viaturaEntity.setDataAtualizacao(LocalDate.of(1970, 1, 1));
        viaturaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        viaturaEntity.setId(1L);
        viaturaEntity.setListaUpm(new ArrayList<>());
        viaturaEntity.setMarcaModelo("Marca Modelo");
        viaturaEntity.setNrSei("Nr Sei");
        viaturaEntity.setPlaca("Placa");
        viaturaEntity.setPrefixo("Prefixo");
        viaturaEntity.setRenavam("Renavam");
        viaturaEntity.setStatus("Status");
        viaturaEntity.setTipoEmpregoViatura(tipoEmpregoViatura);
        viaturaEntity.setTombamento("alice.liddell@example.org");
        Optional<ViaturaEntity> ofResult2 = Optional.of(viaturaEntity);
        when(viaturaRepository.save(Mockito.<ViaturaEntity>any())).thenThrow(new RuntimeException("EM VISTORIA"));
        when(viaturaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult2);

        // Act and Assert
        assertThrows(RuntimeException.class, () -> vistoriaServiceImpl.iniciarVistoria(1L, 1L));
        verify(viaturaRepository).findById(eq(1L));
        verify(viaturaRepository).save(isA(ViaturaEntity.class));
    }

    /**
     * Method under test: {@link VistoriaServiceImpl#iniciarVistoria(Long, Long)}
     */
    @Test
    void testIniciarVistoria3() {
        // Arrange
        ItemVistoriaEntity itemVistoriaEntity = new ItemVistoriaEntity();
        itemVistoriaEntity.setAtivo(true);
        itemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity.setDescricao("Descricao");
        itemVistoriaEntity.setId(1L);
        itemVistoriaEntity.setNome("Nome");
        Optional<ItemVistoriaEntity> ofResult = Optional.of(itemVistoriaEntity);
        when(itemVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        ItemVistoriaEntity codItem = new ItemVistoriaEntity();
        codItem.setAtivo(true);
        codItem.setDataInclusao(LocalDate.of(1970, 1, 1));
        codItem.setDescricao("EM VISTORIA");
        codItem.setId(1L);
        codItem.setNome("EM VISTORIA");

        TipoVistoriaEntity codTipo = new TipoVistoriaEntity();
        codTipo.setAtivo(true);
        codTipo.setDataInclusao(LocalDate.of(1970, 1, 1));
        codTipo.setDescricao("EM VISTORIA");
        codTipo.setId(1L);
        codTipo.setNome("EM VISTORIA");
        codTipo.setStatusAnterior("EM VISTORIA");
        codTipo.setStatusPosterior("EM VISTORIA");

        ItensVistoriaEntity itensVistoriaEntity = new ItensVistoriaEntity();
        itensVistoriaEntity.setAtivo(true);
        itensVistoriaEntity.setCodItem(codItem);
        itensVistoriaEntity.setCodTipo(codTipo);
        itensVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itensVistoriaEntity.setId(1L);

        ArrayList<ItensVistoriaEntity> itensVistoriaEntityList = new ArrayList<>();
        itensVistoriaEntityList.add(itensVistoriaEntity);
        when(itensVistoriaRepository.findAllByCodTipo(Mockito.<TipoVistoriaEntity>any()))
                .thenReturn(itensVistoriaEntityList);
        when(subitensVistoriaRepository.findAllByCodItem(Mockito.<ItemVistoriaEntity>any())).thenReturn(new ArrayList<>());

        TipoVistoriaEntity tipoVistoriaEntity = new TipoVistoriaEntity();
        tipoVistoriaEntity.setAtivo(true);
        tipoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoriaEntity.setDescricao("Descricao");
        tipoVistoriaEntity.setId(1L);
        tipoVistoriaEntity.setNome("Nome");
        tipoVistoriaEntity.setStatusAnterior("Status Anterior");
        tipoVistoriaEntity.setStatusPosterior("Status Posterior");
        Optional<TipoVistoriaEntity> ofResult2 = Optional.of(tipoVistoriaEntity);
        when(tipoVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult2);

        TipoEmpregoViaturaEntity tipoEmpregoViatura = new TipoEmpregoViaturaEntity();
        tipoEmpregoViatura.setAtivo(1);
        tipoEmpregoViatura.setId(1);
        tipoEmpregoViatura.setNome("Nome");

        ViaturaEntity viaturaEntity = new ViaturaEntity();
        viaturaEntity.setAtivo(true);
        viaturaEntity.setDataAtualizacao(LocalDate.of(1970, 1, 1));
        viaturaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        viaturaEntity.setId(1L);
        viaturaEntity.setListaUpm(new ArrayList<>());
        viaturaEntity.setMarcaModelo("Marca Modelo");
        viaturaEntity.setNrSei("Nr Sei");
        viaturaEntity.setPlaca("Placa");
        viaturaEntity.setPrefixo("Prefixo");
        viaturaEntity.setRenavam("Renavam");
        viaturaEntity.setStatus("Status");
        viaturaEntity.setTipoEmpregoViatura(tipoEmpregoViatura);
        viaturaEntity.setTombamento("alice.liddell@example.org");
        Optional<ViaturaEntity> ofResult3 = Optional.of(viaturaEntity);

        TipoEmpregoViaturaEntity tipoEmpregoViatura2 = new TipoEmpregoViaturaEntity();
        tipoEmpregoViatura2.setAtivo(1);
        tipoEmpregoViatura2.setId(1);
        tipoEmpregoViatura2.setNome("Nome");

        ViaturaEntity viaturaEntity2 = new ViaturaEntity();
        viaturaEntity2.setAtivo(true);
        viaturaEntity2.setDataAtualizacao(LocalDate.of(1970, 1, 1));
        viaturaEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        viaturaEntity2.setId(1L);
        viaturaEntity2.setListaUpm(new ArrayList<>());
        viaturaEntity2.setMarcaModelo("Marca Modelo");
        viaturaEntity2.setNrSei("Nr Sei");
        viaturaEntity2.setPlaca("Placa");
        viaturaEntity2.setPrefixo("Prefixo");
        viaturaEntity2.setRenavam("Renavam");
        viaturaEntity2.setStatus("Status");
        viaturaEntity2.setTipoEmpregoViatura(tipoEmpregoViatura2);
        viaturaEntity2.setTombamento("alice.liddell@example.org");
        when(viaturaRepository.save(Mockito.<ViaturaEntity>any())).thenReturn(viaturaEntity2);
        when(viaturaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult3);

        // Act
        ResponseEntity<VistoriaViaturaEntity> actualIniciarVistoriaResult = vistoriaServiceImpl.iniciarVistoria(1L, 1L);

        // Assert
        verify(itensVistoriaRepository).findAllByCodTipo(isA(TipoVistoriaEntity.class));
        verify(subitensVistoriaRepository).findAllByCodItem(isA(ItemVistoriaEntity.class));
        verify(itemVistoriaRepository).findById(eq(1L));
        verify(tipoVistoriaRepository).findById(eq(1L));
        verify(viaturaRepository).findById(eq(1L));
        verify(viaturaRepository).save(isA(ViaturaEntity.class));
        VistoriaViaturaEntity body = actualIniciarVistoriaResult.getBody();
        assertEquals(1, body.getCheckLists().size());
        assertEquals(HttpStatus.OK, actualIniciarVistoriaResult.getStatusCode());
        assertTrue(body.getViatura().getAtivo());
        assertTrue(actualIniciarVistoriaResult.hasBody());
        assertTrue(actualIniciarVistoriaResult.getHeaders().isEmpty());
    }

    /**
     * Method under test: {@link VistoriaServiceImpl#iniciarVistoria(Long, Long)}
     */
    @Test
    void testIniciarVistoria4() {
        // Arrange
        ItemVistoriaEntity itemVistoriaEntity = new ItemVistoriaEntity();
        itemVistoriaEntity.setAtivo(true);
        itemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity.setDescricao("Descricao");
        itemVistoriaEntity.setId(1L);
        itemVistoriaEntity.setNome("Nome");
        Optional<ItemVistoriaEntity> ofResult = Optional.of(itemVistoriaEntity);
        when(itemVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        ItemVistoriaEntity codItem = new ItemVistoriaEntity();
        codItem.setAtivo(true);
        codItem.setDataInclusao(LocalDate.of(1970, 1, 1));
        codItem.setDescricao("EM VISTORIA");
        codItem.setId(1L);
        codItem.setNome("EM VISTORIA");

        TipoVistoriaEntity codTipo = new TipoVistoriaEntity();
        codTipo.setAtivo(true);
        codTipo.setDataInclusao(LocalDate.of(1970, 1, 1));
        codTipo.setDescricao("EM VISTORIA");
        codTipo.setId(1L);
        codTipo.setNome("EM VISTORIA");
        codTipo.setStatusAnterior("EM VISTORIA");
        codTipo.setStatusPosterior("EM VISTORIA");

        ItensVistoriaEntity itensVistoriaEntity = new ItensVistoriaEntity();
        itensVistoriaEntity.setAtivo(true);
        itensVistoriaEntity.setCodItem(codItem);
        itensVistoriaEntity.setCodTipo(codTipo);
        itensVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itensVistoriaEntity.setId(1L);

        ArrayList<ItensVistoriaEntity> itensVistoriaEntityList = new ArrayList<>();
        itensVistoriaEntityList.add(itensVistoriaEntity);
        when(itensVistoriaRepository.findAllByCodTipo(Mockito.<TipoVistoriaEntity>any()))
                .thenReturn(itensVistoriaEntityList);
        when(subitensVistoriaRepository.findAllByCodItem(Mockito.<ItemVistoriaEntity>any()))
                .thenThrow(new RuntimeException("EM VISTORIA"));

        TipoVistoriaEntity tipoVistoriaEntity = new TipoVistoriaEntity();
        tipoVistoriaEntity.setAtivo(true);
        tipoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoriaEntity.setDescricao("Descricao");
        tipoVistoriaEntity.setId(1L);
        tipoVistoriaEntity.setNome("Nome");
        tipoVistoriaEntity.setStatusAnterior("Status Anterior");
        tipoVistoriaEntity.setStatusPosterior("Status Posterior");
        Optional<TipoVistoriaEntity> ofResult2 = Optional.of(tipoVistoriaEntity);
        when(tipoVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult2);

        TipoEmpregoViaturaEntity tipoEmpregoViatura = new TipoEmpregoViaturaEntity();
        tipoEmpregoViatura.setAtivo(1);
        tipoEmpregoViatura.setId(1);
        tipoEmpregoViatura.setNome("Nome");

        ViaturaEntity viaturaEntity = new ViaturaEntity();
        viaturaEntity.setAtivo(true);
        viaturaEntity.setDataAtualizacao(LocalDate.of(1970, 1, 1));
        viaturaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        viaturaEntity.setId(1L);
        viaturaEntity.setListaUpm(new ArrayList<>());
        viaturaEntity.setMarcaModelo("Marca Modelo");
        viaturaEntity.setNrSei("Nr Sei");
        viaturaEntity.setPlaca("Placa");
        viaturaEntity.setPrefixo("Prefixo");
        viaturaEntity.setRenavam("Renavam");
        viaturaEntity.setStatus("Status");
        viaturaEntity.setTipoEmpregoViatura(tipoEmpregoViatura);
        viaturaEntity.setTombamento("alice.liddell@example.org");
        Optional<ViaturaEntity> ofResult3 = Optional.of(viaturaEntity);

        TipoEmpregoViaturaEntity tipoEmpregoViatura2 = new TipoEmpregoViaturaEntity();
        tipoEmpregoViatura2.setAtivo(1);
        tipoEmpregoViatura2.setId(1);
        tipoEmpregoViatura2.setNome("Nome");

        ViaturaEntity viaturaEntity2 = new ViaturaEntity();
        viaturaEntity2.setAtivo(true);
        viaturaEntity2.setDataAtualizacao(LocalDate.of(1970, 1, 1));
        viaturaEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        viaturaEntity2.setId(1L);
        viaturaEntity2.setListaUpm(new ArrayList<>());
        viaturaEntity2.setMarcaModelo("Marca Modelo");
        viaturaEntity2.setNrSei("Nr Sei");
        viaturaEntity2.setPlaca("Placa");
        viaturaEntity2.setPrefixo("Prefixo");
        viaturaEntity2.setRenavam("Renavam");
        viaturaEntity2.setStatus("Status");
        viaturaEntity2.setTipoEmpregoViatura(tipoEmpregoViatura2);
        viaturaEntity2.setTombamento("alice.liddell@example.org");
        when(viaturaRepository.save(Mockito.<ViaturaEntity>any())).thenReturn(viaturaEntity2);
        when(viaturaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult3);

        // Act and Assert
        assertThrows(RuntimeException.class, () -> vistoriaServiceImpl.iniciarVistoria(1L, 1L));
        verify(itensVistoriaRepository).findAllByCodTipo(isA(TipoVistoriaEntity.class));
        verify(subitensVistoriaRepository).findAllByCodItem(isA(ItemVistoriaEntity.class));
        verify(itemVistoriaRepository).findById(eq(1L));
        verify(tipoVistoriaRepository).findById(eq(1L));
        verify(viaturaRepository).findById(eq(1L));
        verify(viaturaRepository).save(isA(ViaturaEntity.class));
    }

    /**
     * Method under test: {@link VistoriaServiceImpl#iniciarVistoria(Long, Long)}
     */
    @Test
    void testIniciarVistoria5() {
        // Arrange
        Optional<ItemVistoriaEntity> emptyResult = Optional.empty();
        when(itemVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(emptyResult);

        ItemVistoriaEntity codItem = new ItemVistoriaEntity();
        codItem.setAtivo(true);
        codItem.setDataInclusao(LocalDate.of(1970, 1, 1));
        codItem.setDescricao("EM VISTORIA");
        codItem.setId(1L);
        codItem.setNome("EM VISTORIA");

        TipoVistoriaEntity codTipo = new TipoVistoriaEntity();
        codTipo.setAtivo(true);
        codTipo.setDataInclusao(LocalDate.of(1970, 1, 1));
        codTipo.setDescricao("EM VISTORIA");
        codTipo.setId(1L);
        codTipo.setNome("EM VISTORIA");
        codTipo.setStatusAnterior("EM VISTORIA");
        codTipo.setStatusPosterior("EM VISTORIA");

        ItensVistoriaEntity itensVistoriaEntity = new ItensVistoriaEntity();
        itensVistoriaEntity.setAtivo(true);
        itensVistoriaEntity.setCodItem(codItem);
        itensVistoriaEntity.setCodTipo(codTipo);
        itensVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itensVistoriaEntity.setId(1L);

        ArrayList<ItensVistoriaEntity> itensVistoriaEntityList = new ArrayList<>();
        itensVistoriaEntityList.add(itensVistoriaEntity);
        when(itensVistoriaRepository.findAllByCodTipo(Mockito.<TipoVistoriaEntity>any()))
                .thenReturn(itensVistoriaEntityList);

        TipoVistoriaEntity tipoVistoriaEntity = new TipoVistoriaEntity();
        tipoVistoriaEntity.setAtivo(true);
        tipoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoriaEntity.setDescricao("Descricao");
        tipoVistoriaEntity.setId(1L);
        tipoVistoriaEntity.setNome("Nome");
        tipoVistoriaEntity.setStatusAnterior("Status Anterior");
        tipoVistoriaEntity.setStatusPosterior("Status Posterior");
        Optional<TipoVistoriaEntity> ofResult = Optional.of(tipoVistoriaEntity);
        when(tipoVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        TipoEmpregoViaturaEntity tipoEmpregoViatura = new TipoEmpregoViaturaEntity();
        tipoEmpregoViatura.setAtivo(1);
        tipoEmpregoViatura.setId(1);
        tipoEmpregoViatura.setNome("Nome");

        ViaturaEntity viaturaEntity = new ViaturaEntity();
        viaturaEntity.setAtivo(true);
        viaturaEntity.setDataAtualizacao(LocalDate.of(1970, 1, 1));
        viaturaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        viaturaEntity.setId(1L);
        viaturaEntity.setListaUpm(new ArrayList<>());
        viaturaEntity.setMarcaModelo("Marca Modelo");
        viaturaEntity.setNrSei("Nr Sei");
        viaturaEntity.setPlaca("Placa");
        viaturaEntity.setPrefixo("Prefixo");
        viaturaEntity.setRenavam("Renavam");
        viaturaEntity.setStatus("Status");
        viaturaEntity.setTipoEmpregoViatura(tipoEmpregoViatura);
        viaturaEntity.setTombamento("alice.liddell@example.org");
        Optional<ViaturaEntity> ofResult2 = Optional.of(viaturaEntity);

        TipoEmpregoViaturaEntity tipoEmpregoViatura2 = new TipoEmpregoViaturaEntity();
        tipoEmpregoViatura2.setAtivo(1);
        tipoEmpregoViatura2.setId(1);
        tipoEmpregoViatura2.setNome("Nome");

        ViaturaEntity viaturaEntity2 = new ViaturaEntity();
        viaturaEntity2.setAtivo(true);
        viaturaEntity2.setDataAtualizacao(LocalDate.of(1970, 1, 1));
        viaturaEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        viaturaEntity2.setId(1L);
        viaturaEntity2.setListaUpm(new ArrayList<>());
        viaturaEntity2.setMarcaModelo("Marca Modelo");
        viaturaEntity2.setNrSei("Nr Sei");
        viaturaEntity2.setPlaca("Placa");
        viaturaEntity2.setPrefixo("Prefixo");
        viaturaEntity2.setRenavam("Renavam");
        viaturaEntity2.setStatus("Status");
        viaturaEntity2.setTipoEmpregoViatura(tipoEmpregoViatura2);
        viaturaEntity2.setTombamento("alice.liddell@example.org");
        when(viaturaRepository.save(Mockito.<ViaturaEntity>any())).thenReturn(viaturaEntity2);
        when(viaturaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult2);

        // Act and Assert
        assertThrows(ResourceNotFoundException.class, () -> vistoriaServiceImpl.iniciarVistoria(1L, 1L));
        verify(itensVistoriaRepository).findAllByCodTipo(isA(TipoVistoriaEntity.class));
        verify(itemVistoriaRepository).findById(eq(1L));
        verify(tipoVistoriaRepository).findById(eq(1L));
        verify(viaturaRepository).findById(eq(1L));
        verify(viaturaRepository).save(isA(ViaturaEntity.class));
    }

    /**
     * Method under test: {@link VistoriaServiceImpl#iniciarVistoria(Long, Long)}
     */
    @Test
    void testIniciarVistoria6() {
        // Arrange
        when(defeitosVistoriaRepository.findAllByCodSubitem(Mockito.<SubitemVistoriaEntity>any()))
                .thenReturn(new ArrayList<>());

        ItemVistoriaEntity itemVistoriaEntity = new ItemVistoriaEntity();
        itemVistoriaEntity.setAtivo(true);
        itemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity.setDescricao("Descricao");
        itemVistoriaEntity.setId(1L);
        itemVistoriaEntity.setNome("Nome");
        Optional<ItemVistoriaEntity> ofResult = Optional.of(itemVistoriaEntity);
        when(itemVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        ItemVistoriaEntity codItem = new ItemVistoriaEntity();
        codItem.setAtivo(true);
        codItem.setDataInclusao(LocalDate.of(1970, 1, 1));
        codItem.setDescricao("EM VISTORIA");
        codItem.setId(1L);
        codItem.setNome("EM VISTORIA");

        TipoVistoriaEntity codTipo = new TipoVistoriaEntity();
        codTipo.setAtivo(true);
        codTipo.setDataInclusao(LocalDate.of(1970, 1, 1));
        codTipo.setDescricao("EM VISTORIA");
        codTipo.setId(1L);
        codTipo.setNome("EM VISTORIA");
        codTipo.setStatusAnterior("EM VISTORIA");
        codTipo.setStatusPosterior("EM VISTORIA");

        ItemVistoriaEntity itemVistoriaEntity2 = new ItemVistoriaEntity();
        itemVistoriaEntity2.setAtivo(true);
        itemVistoriaEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity2.setDescricao("Descricao");
        itemVistoriaEntity2.setId(1L);
        itemVistoriaEntity2.setNome("Nome");
        ItensVistoriaEntity itensVistoriaEntity = mock(ItensVistoriaEntity.class);
        when(itensVistoriaEntity.getCodItem()).thenReturn(itemVistoriaEntity2);
        doNothing().when(itensVistoriaEntity).setAtivo(Mockito.<Boolean>any());
        doNothing().when(itensVistoriaEntity).setCodItem(Mockito.<ItemVistoriaEntity>any());
        doNothing().when(itensVistoriaEntity).setCodTipo(Mockito.<TipoVistoriaEntity>any());
        doNothing().when(itensVistoriaEntity).setDataInclusao(Mockito.<LocalDate>any());
        doNothing().when(itensVistoriaEntity).setId(Mockito.<Long>any());
        itensVistoriaEntity.setAtivo(true);
        itensVistoriaEntity.setCodItem(codItem);
        itensVistoriaEntity.setCodTipo(codTipo);
        itensVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itensVistoriaEntity.setId(1L);

        ArrayList<ItensVistoriaEntity> itensVistoriaEntityList = new ArrayList<>();
        itensVistoriaEntityList.add(itensVistoriaEntity);
        when(itensVistoriaRepository.findAllByCodTipo(Mockito.<TipoVistoriaEntity>any()))
                .thenReturn(itensVistoriaEntityList);

        SubitemVistoriaEntity subitemVistoriaEntity = new SubitemVistoriaEntity();
        subitemVistoriaEntity.setAtivo(true);
        subitemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        subitemVistoriaEntity.setDescricao("Descricao");
        subitemVistoriaEntity.setId(1L);
        subitemVistoriaEntity.setNome("Nome");
        Optional<SubitemVistoriaEntity> ofResult2 = Optional.of(subitemVistoriaEntity);
        when(subitemVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult2);

        ItemVistoriaEntity codItem2 = new ItemVistoriaEntity();
        codItem2.setAtivo(true);
        codItem2.setDataInclusao(LocalDate.of(1970, 1, 1));
        codItem2.setDescricao("Descricao");
        codItem2.setId(1L);
        codItem2.setNome("Nome");

        SubitemVistoriaEntity codSubitem = new SubitemVistoriaEntity();
        codSubitem.setAtivo(true);
        codSubitem.setDataInclusao(LocalDate.of(1970, 1, 1));
        codSubitem.setDescricao("Descricao");
        codSubitem.setId(1L);
        codSubitem.setNome("Nome");

        SubitensVistoriaEntity subitensVistoriaEntity = new SubitensVistoriaEntity();
        subitensVistoriaEntity.setAtivo(true);
        subitensVistoriaEntity.setCodItem(codItem2);
        subitensVistoriaEntity.setCodSubitem(codSubitem);
        subitensVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        subitensVistoriaEntity.setId(1L);

        ArrayList<SubitensVistoriaEntity> subitensVistoriaEntityList = new ArrayList<>();
        subitensVistoriaEntityList.add(subitensVistoriaEntity);
        when(subitensVistoriaRepository.findAllByCodItem(Mockito.<ItemVistoriaEntity>any()))
                .thenReturn(subitensVistoriaEntityList);

        TipoVistoriaEntity tipoVistoriaEntity = new TipoVistoriaEntity();
        tipoVistoriaEntity.setAtivo(true);
        tipoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoriaEntity.setDescricao("Descricao");
        tipoVistoriaEntity.setId(1L);
        tipoVistoriaEntity.setNome("Nome");
        tipoVistoriaEntity.setStatusAnterior("Status Anterior");
        tipoVistoriaEntity.setStatusPosterior("Status Posterior");
        Optional<TipoVistoriaEntity> ofResult3 = Optional.of(tipoVistoriaEntity);
        when(tipoVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult3);

        TipoEmpregoViaturaEntity tipoEmpregoViatura = new TipoEmpregoViaturaEntity();
        tipoEmpregoViatura.setAtivo(1);
        tipoEmpregoViatura.setId(1);
        tipoEmpregoViatura.setNome("Nome");

        ViaturaEntity viaturaEntity = new ViaturaEntity();
        viaturaEntity.setAtivo(true);
        viaturaEntity.setDataAtualizacao(LocalDate.of(1970, 1, 1));
        viaturaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        viaturaEntity.setId(1L);
        viaturaEntity.setListaUpm(new ArrayList<>());
        viaturaEntity.setMarcaModelo("Marca Modelo");
        viaturaEntity.setNrSei("Nr Sei");
        viaturaEntity.setPlaca("Placa");
        viaturaEntity.setPrefixo("Prefixo");
        viaturaEntity.setRenavam("Renavam");
        viaturaEntity.setStatus("Status");
        viaturaEntity.setTipoEmpregoViatura(tipoEmpregoViatura);
        viaturaEntity.setTombamento("alice.liddell@example.org");
        Optional<ViaturaEntity> ofResult4 = Optional.of(viaturaEntity);

        TipoEmpregoViaturaEntity tipoEmpregoViatura2 = new TipoEmpregoViaturaEntity();
        tipoEmpregoViatura2.setAtivo(1);
        tipoEmpregoViatura2.setId(1);
        tipoEmpregoViatura2.setNome("Nome");

        ViaturaEntity viaturaEntity2 = new ViaturaEntity();
        viaturaEntity2.setAtivo(true);
        viaturaEntity2.setDataAtualizacao(LocalDate.of(1970, 1, 1));
        viaturaEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        viaturaEntity2.setId(1L);
        viaturaEntity2.setListaUpm(new ArrayList<>());
        viaturaEntity2.setMarcaModelo("Marca Modelo");
        viaturaEntity2.setNrSei("Nr Sei");
        viaturaEntity2.setPlaca("Placa");
        viaturaEntity2.setPrefixo("Prefixo");
        viaturaEntity2.setRenavam("Renavam");
        viaturaEntity2.setStatus("Status");
        viaturaEntity2.setTipoEmpregoViatura(tipoEmpregoViatura2);
        viaturaEntity2.setTombamento("alice.liddell@example.org");
        when(viaturaRepository.save(Mockito.<ViaturaEntity>any())).thenReturn(viaturaEntity2);
        when(viaturaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult4);

        // Act
        ResponseEntity<VistoriaViaturaEntity> actualIniciarVistoriaResult = vistoriaServiceImpl.iniciarVistoria(1L, 1L);

        // Assert
        verify(itensVistoriaEntity).getCodItem();
        verify(itensVistoriaEntity).setAtivo(eq(true));
        verify(itensVistoriaEntity).setCodItem(isA(ItemVistoriaEntity.class));
        verify(itensVistoriaEntity).setCodTipo(isA(TipoVistoriaEntity.class));
        verify(itensVistoriaEntity).setDataInclusao(isA(LocalDate.class));
        verify(itensVistoriaEntity).setId(eq(1L));
        verify(defeitosVistoriaRepository).findAllByCodSubitem(isA(SubitemVistoriaEntity.class));
        verify(itensVistoriaRepository).findAllByCodTipo(isA(TipoVistoriaEntity.class));
        verify(subitensVistoriaRepository).findAllByCodItem(isA(ItemVistoriaEntity.class));
        verify(itemVistoriaRepository).findById(eq(1L));
        verify(subitemVistoriaRepository).findById(eq(1L));
        verify(tipoVistoriaRepository).findById(eq(1L));
        verify(viaturaRepository).findById(eq(1L));
        verify(viaturaRepository).save(isA(ViaturaEntity.class));
        VistoriaViaturaEntity body = actualIniciarVistoriaResult.getBody();
        assertEquals(1, body.getCheckLists().size());
        assertEquals(HttpStatus.OK, actualIniciarVistoriaResult.getStatusCode());
        assertTrue(body.getViatura().getAtivo());
        assertTrue(actualIniciarVistoriaResult.hasBody());
        assertTrue(actualIniciarVistoriaResult.getHeaders().isEmpty());
    }

    /**
     * Method under test: {@link VistoriaServiceImpl#iniciarVistoria(Long, Long)}
     */
    @Test
    void testIniciarVistoria7() {
        // Arrange
        when(defeitosVistoriaRepository.findAllByCodSubitem(Mockito.<SubitemVistoriaEntity>any()))
                .thenThrow(new RuntimeException("EM VISTORIA"));

        ItemVistoriaEntity itemVistoriaEntity = new ItemVistoriaEntity();
        itemVistoriaEntity.setAtivo(true);
        itemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity.setDescricao("Descricao");
        itemVistoriaEntity.setId(1L);
        itemVistoriaEntity.setNome("Nome");
        Optional<ItemVistoriaEntity> ofResult = Optional.of(itemVistoriaEntity);
        when(itemVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        ItemVistoriaEntity codItem = new ItemVistoriaEntity();
        codItem.setAtivo(true);
        codItem.setDataInclusao(LocalDate.of(1970, 1, 1));
        codItem.setDescricao("EM VISTORIA");
        codItem.setId(1L);
        codItem.setNome("EM VISTORIA");

        TipoVistoriaEntity codTipo = new TipoVistoriaEntity();
        codTipo.setAtivo(true);
        codTipo.setDataInclusao(LocalDate.of(1970, 1, 1));
        codTipo.setDescricao("EM VISTORIA");
        codTipo.setId(1L);
        codTipo.setNome("EM VISTORIA");
        codTipo.setStatusAnterior("EM VISTORIA");
        codTipo.setStatusPosterior("EM VISTORIA");

        ItemVistoriaEntity itemVistoriaEntity2 = new ItemVistoriaEntity();
        itemVistoriaEntity2.setAtivo(true);
        itemVistoriaEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity2.setDescricao("Descricao");
        itemVistoriaEntity2.setId(1L);
        itemVistoriaEntity2.setNome("Nome");
        ItensVistoriaEntity itensVistoriaEntity = mock(ItensVistoriaEntity.class);
        when(itensVistoriaEntity.getCodItem()).thenReturn(itemVistoriaEntity2);
        doNothing().when(itensVistoriaEntity).setAtivo(Mockito.<Boolean>any());
        doNothing().when(itensVistoriaEntity).setCodItem(Mockito.<ItemVistoriaEntity>any());
        doNothing().when(itensVistoriaEntity).setCodTipo(Mockito.<TipoVistoriaEntity>any());
        doNothing().when(itensVistoriaEntity).setDataInclusao(Mockito.<LocalDate>any());
        doNothing().when(itensVistoriaEntity).setId(Mockito.<Long>any());
        itensVistoriaEntity.setAtivo(true);
        itensVistoriaEntity.setCodItem(codItem);
        itensVistoriaEntity.setCodTipo(codTipo);
        itensVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itensVistoriaEntity.setId(1L);

        ArrayList<ItensVistoriaEntity> itensVistoriaEntityList = new ArrayList<>();
        itensVistoriaEntityList.add(itensVistoriaEntity);
        when(itensVistoriaRepository.findAllByCodTipo(Mockito.<TipoVistoriaEntity>any()))
                .thenReturn(itensVistoriaEntityList);

        SubitemVistoriaEntity subitemVistoriaEntity = new SubitemVistoriaEntity();
        subitemVistoriaEntity.setAtivo(true);
        subitemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        subitemVistoriaEntity.setDescricao("Descricao");
        subitemVistoriaEntity.setId(1L);
        subitemVistoriaEntity.setNome("Nome");
        Optional<SubitemVistoriaEntity> ofResult2 = Optional.of(subitemVistoriaEntity);
        when(subitemVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult2);

        ItemVistoriaEntity codItem2 = new ItemVistoriaEntity();
        codItem2.setAtivo(true);
        codItem2.setDataInclusao(LocalDate.of(1970, 1, 1));
        codItem2.setDescricao("Descricao");
        codItem2.setId(1L);
        codItem2.setNome("Nome");

        SubitemVistoriaEntity codSubitem = new SubitemVistoriaEntity();
        codSubitem.setAtivo(true);
        codSubitem.setDataInclusao(LocalDate.of(1970, 1, 1));
        codSubitem.setDescricao("Descricao");
        codSubitem.setId(1L);
        codSubitem.setNome("Nome");

        SubitensVistoriaEntity subitensVistoriaEntity = new SubitensVistoriaEntity();
        subitensVistoriaEntity.setAtivo(true);
        subitensVistoriaEntity.setCodItem(codItem2);
        subitensVistoriaEntity.setCodSubitem(codSubitem);
        subitensVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        subitensVistoriaEntity.setId(1L);

        ArrayList<SubitensVistoriaEntity> subitensVistoriaEntityList = new ArrayList<>();
        subitensVistoriaEntityList.add(subitensVistoriaEntity);
        when(subitensVistoriaRepository.findAllByCodItem(Mockito.<ItemVistoriaEntity>any()))
                .thenReturn(subitensVistoriaEntityList);

        TipoVistoriaEntity tipoVistoriaEntity = new TipoVistoriaEntity();
        tipoVistoriaEntity.setAtivo(true);
        tipoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoriaEntity.setDescricao("Descricao");
        tipoVistoriaEntity.setId(1L);
        tipoVistoriaEntity.setNome("Nome");
        tipoVistoriaEntity.setStatusAnterior("Status Anterior");
        tipoVistoriaEntity.setStatusPosterior("Status Posterior");
        Optional<TipoVistoriaEntity> ofResult3 = Optional.of(tipoVistoriaEntity);
        when(tipoVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult3);

        TipoEmpregoViaturaEntity tipoEmpregoViatura = new TipoEmpregoViaturaEntity();
        tipoEmpregoViatura.setAtivo(1);
        tipoEmpregoViatura.setId(1);
        tipoEmpregoViatura.setNome("Nome");

        ViaturaEntity viaturaEntity = new ViaturaEntity();
        viaturaEntity.setAtivo(true);
        viaturaEntity.setDataAtualizacao(LocalDate.of(1970, 1, 1));
        viaturaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        viaturaEntity.setId(1L);
        viaturaEntity.setListaUpm(new ArrayList<>());
        viaturaEntity.setMarcaModelo("Marca Modelo");
        viaturaEntity.setNrSei("Nr Sei");
        viaturaEntity.setPlaca("Placa");
        viaturaEntity.setPrefixo("Prefixo");
        viaturaEntity.setRenavam("Renavam");
        viaturaEntity.setStatus("Status");
        viaturaEntity.setTipoEmpregoViatura(tipoEmpregoViatura);
        viaturaEntity.setTombamento("alice.liddell@example.org");
        Optional<ViaturaEntity> ofResult4 = Optional.of(viaturaEntity);

        TipoEmpregoViaturaEntity tipoEmpregoViatura2 = new TipoEmpregoViaturaEntity();
        tipoEmpregoViatura2.setAtivo(1);
        tipoEmpregoViatura2.setId(1);
        tipoEmpregoViatura2.setNome("Nome");

        ViaturaEntity viaturaEntity2 = new ViaturaEntity();
        viaturaEntity2.setAtivo(true);
        viaturaEntity2.setDataAtualizacao(LocalDate.of(1970, 1, 1));
        viaturaEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        viaturaEntity2.setId(1L);
        viaturaEntity2.setListaUpm(new ArrayList<>());
        viaturaEntity2.setMarcaModelo("Marca Modelo");
        viaturaEntity2.setNrSei("Nr Sei");
        viaturaEntity2.setPlaca("Placa");
        viaturaEntity2.setPrefixo("Prefixo");
        viaturaEntity2.setRenavam("Renavam");
        viaturaEntity2.setStatus("Status");
        viaturaEntity2.setTipoEmpregoViatura(tipoEmpregoViatura2);
        viaturaEntity2.setTombamento("alice.liddell@example.org");
        when(viaturaRepository.save(Mockito.<ViaturaEntity>any())).thenReturn(viaturaEntity2);
        when(viaturaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult4);

        // Act and Assert
        assertThrows(RuntimeException.class, () -> vistoriaServiceImpl.iniciarVistoria(1L, 1L));
        verify(itensVistoriaEntity).getCodItem();
        verify(itensVistoriaEntity).setAtivo(eq(true));
        verify(itensVistoriaEntity).setCodItem(isA(ItemVistoriaEntity.class));
        verify(itensVistoriaEntity).setCodTipo(isA(TipoVistoriaEntity.class));
        verify(itensVistoriaEntity).setDataInclusao(isA(LocalDate.class));
        verify(itensVistoriaEntity).setId(eq(1L));
        verify(defeitosVistoriaRepository).findAllByCodSubitem(isA(SubitemVistoriaEntity.class));
        verify(itensVistoriaRepository).findAllByCodTipo(isA(TipoVistoriaEntity.class));
        verify(subitensVistoriaRepository).findAllByCodItem(isA(ItemVistoriaEntity.class));
        verify(itemVistoriaRepository).findById(eq(1L));
        verify(subitemVistoriaRepository).findById(eq(1L));
        verify(tipoVistoriaRepository).findById(eq(1L));
        verify(viaturaRepository).findById(eq(1L));
        verify(viaturaRepository).save(isA(ViaturaEntity.class));
    }

    /**
     * Method under test: {@link VistoriaServiceImpl#iniciarVistoria(Long, Long)}
     */
    @Test
    void testIniciarVistoria8() {
        // Arrange
        SubitemVistoriaEntity codSubitem = new SubitemVistoriaEntity();
        codSubitem.setAtivo(true);
        codSubitem.setDataInclusao(LocalDate.of(1970, 1, 1));
        codSubitem.setDescricao("EM VISTORIA");
        codSubitem.setId(1L);
        codSubitem.setNome("EM VISTORIA");

        TipoDefeitoVistoriaEntity codTipoDefeito = new TipoDefeitoVistoriaEntity();
        codTipoDefeito.setAtivo(true);
        codTipoDefeito.setDataInclusao(LocalDate.of(1970, 1, 1));
        codTipoDefeito.setDescricao("EM VISTORIA");
        codTipoDefeito.setId(1L);
        codTipoDefeito.setNome("EM VISTORIA");

        DefeitosVistoriaEntity defeitosVistoriaEntity = new DefeitosVistoriaEntity();
        defeitosVistoriaEntity.setAtivo(true);
        defeitosVistoriaEntity.setCodSubitem(codSubitem);
        defeitosVistoriaEntity.setCodTipoDefeito(codTipoDefeito);
        defeitosVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        defeitosVistoriaEntity.setId(1L);

        ArrayList<DefeitosVistoriaEntity> defeitosVistoriaEntityList = new ArrayList<>();
        defeitosVistoriaEntityList.add(defeitosVistoriaEntity);
        when(defeitosVistoriaRepository.findAllByCodSubitem(Mockito.<SubitemVistoriaEntity>any()))
                .thenReturn(defeitosVistoriaEntityList);

        ItemVistoriaEntity itemVistoriaEntity = new ItemVistoriaEntity();
        itemVistoriaEntity.setAtivo(true);
        itemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity.setDescricao("Descricao");
        itemVistoriaEntity.setId(1L);
        itemVistoriaEntity.setNome("Nome");
        Optional<ItemVistoriaEntity> ofResult = Optional.of(itemVistoriaEntity);
        when(itemVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        ItemVistoriaEntity codItem = new ItemVistoriaEntity();
        codItem.setAtivo(true);
        codItem.setDataInclusao(LocalDate.of(1970, 1, 1));
        codItem.setDescricao("EM VISTORIA");
        codItem.setId(1L);
        codItem.setNome("EM VISTORIA");

        TipoVistoriaEntity codTipo = new TipoVistoriaEntity();
        codTipo.setAtivo(true);
        codTipo.setDataInclusao(LocalDate.of(1970, 1, 1));
        codTipo.setDescricao("EM VISTORIA");
        codTipo.setId(1L);
        codTipo.setNome("EM VISTORIA");
        codTipo.setStatusAnterior("EM VISTORIA");
        codTipo.setStatusPosterior("EM VISTORIA");

        ItemVistoriaEntity itemVistoriaEntity2 = new ItemVistoriaEntity();
        itemVistoriaEntity2.setAtivo(true);
        itemVistoriaEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity2.setDescricao("Descricao");
        itemVistoriaEntity2.setId(1L);
        itemVistoriaEntity2.setNome("Nome");
        ItensVistoriaEntity itensVistoriaEntity = mock(ItensVistoriaEntity.class);
        when(itensVistoriaEntity.getCodItem()).thenReturn(itemVistoriaEntity2);
        doNothing().when(itensVistoriaEntity).setAtivo(Mockito.<Boolean>any());
        doNothing().when(itensVistoriaEntity).setCodItem(Mockito.<ItemVistoriaEntity>any());
        doNothing().when(itensVistoriaEntity).setCodTipo(Mockito.<TipoVistoriaEntity>any());
        doNothing().when(itensVistoriaEntity).setDataInclusao(Mockito.<LocalDate>any());
        doNothing().when(itensVistoriaEntity).setId(Mockito.<Long>any());
        itensVistoriaEntity.setAtivo(true);
        itensVistoriaEntity.setCodItem(codItem);
        itensVistoriaEntity.setCodTipo(codTipo);
        itensVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itensVistoriaEntity.setId(1L);

        ArrayList<ItensVistoriaEntity> itensVistoriaEntityList = new ArrayList<>();
        itensVistoriaEntityList.add(itensVistoriaEntity);
        when(itensVistoriaRepository.findAllByCodTipo(Mockito.<TipoVistoriaEntity>any()))
                .thenReturn(itensVistoriaEntityList);

        SubitemVistoriaEntity subitemVistoriaEntity = new SubitemVistoriaEntity();
        subitemVistoriaEntity.setAtivo(true);
        subitemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        subitemVistoriaEntity.setDescricao("Descricao");
        subitemVistoriaEntity.setId(1L);
        subitemVistoriaEntity.setNome("Nome");
        Optional<SubitemVistoriaEntity> ofResult2 = Optional.of(subitemVistoriaEntity);
        when(subitemVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult2);

        ItemVistoriaEntity codItem2 = new ItemVistoriaEntity();
        codItem2.setAtivo(true);
        codItem2.setDataInclusao(LocalDate.of(1970, 1, 1));
        codItem2.setDescricao("Descricao");
        codItem2.setId(1L);
        codItem2.setNome("Nome");

        SubitemVistoriaEntity codSubitem2 = new SubitemVistoriaEntity();
        codSubitem2.setAtivo(true);
        codSubitem2.setDataInclusao(LocalDate.of(1970, 1, 1));
        codSubitem2.setDescricao("Descricao");
        codSubitem2.setId(1L);
        codSubitem2.setNome("Nome");

        SubitensVistoriaEntity subitensVistoriaEntity = new SubitensVistoriaEntity();
        subitensVistoriaEntity.setAtivo(true);
        subitensVistoriaEntity.setCodItem(codItem2);
        subitensVistoriaEntity.setCodSubitem(codSubitem2);
        subitensVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        subitensVistoriaEntity.setId(1L);

        ArrayList<SubitensVistoriaEntity> subitensVistoriaEntityList = new ArrayList<>();
        subitensVistoriaEntityList.add(subitensVistoriaEntity);
        when(subitensVistoriaRepository.findAllByCodItem(Mockito.<ItemVistoriaEntity>any()))
                .thenReturn(subitensVistoriaEntityList);

        TipoDefeitoVistoriaEntity tipoDefeitoVistoriaEntity = new TipoDefeitoVistoriaEntity();
        tipoDefeitoVistoriaEntity.setAtivo(true);
        tipoDefeitoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoDefeitoVistoriaEntity.setDescricao("Descricao");
        tipoDefeitoVistoriaEntity.setId(1L);
        tipoDefeitoVistoriaEntity.setNome("Nome");
        Optional<TipoDefeitoVistoriaEntity> ofResult3 = Optional.of(tipoDefeitoVistoriaEntity);
        when(tipoDefeitoVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult3);

        TipoVistoriaEntity tipoVistoriaEntity = new TipoVistoriaEntity();
        tipoVistoriaEntity.setAtivo(true);
        tipoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoriaEntity.setDescricao("Descricao");
        tipoVistoriaEntity.setId(1L);
        tipoVistoriaEntity.setNome("Nome");
        tipoVistoriaEntity.setStatusAnterior("Status Anterior");
        tipoVistoriaEntity.setStatusPosterior("Status Posterior");
        Optional<TipoVistoriaEntity> ofResult4 = Optional.of(tipoVistoriaEntity);
        when(tipoVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult4);

        TipoEmpregoViaturaEntity tipoEmpregoViatura = new TipoEmpregoViaturaEntity();
        tipoEmpregoViatura.setAtivo(1);
        tipoEmpregoViatura.setId(1);
        tipoEmpregoViatura.setNome("Nome");

        ViaturaEntity viaturaEntity = new ViaturaEntity();
        viaturaEntity.setAtivo(true);
        viaturaEntity.setDataAtualizacao(LocalDate.of(1970, 1, 1));
        viaturaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        viaturaEntity.setId(1L);
        viaturaEntity.setListaUpm(new ArrayList<>());
        viaturaEntity.setMarcaModelo("Marca Modelo");
        viaturaEntity.setNrSei("Nr Sei");
        viaturaEntity.setPlaca("Placa");
        viaturaEntity.setPrefixo("Prefixo");
        viaturaEntity.setRenavam("Renavam");
        viaturaEntity.setStatus("Status");
        viaturaEntity.setTipoEmpregoViatura(tipoEmpregoViatura);
        viaturaEntity.setTombamento("alice.liddell@example.org");
        Optional<ViaturaEntity> ofResult5 = Optional.of(viaturaEntity);

        TipoEmpregoViaturaEntity tipoEmpregoViatura2 = new TipoEmpregoViaturaEntity();
        tipoEmpregoViatura2.setAtivo(1);
        tipoEmpregoViatura2.setId(1);
        tipoEmpregoViatura2.setNome("Nome");

        ViaturaEntity viaturaEntity2 = new ViaturaEntity();
        viaturaEntity2.setAtivo(true);
        viaturaEntity2.setDataAtualizacao(LocalDate.of(1970, 1, 1));
        viaturaEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        viaturaEntity2.setId(1L);
        viaturaEntity2.setListaUpm(new ArrayList<>());
        viaturaEntity2.setMarcaModelo("Marca Modelo");
        viaturaEntity2.setNrSei("Nr Sei");
        viaturaEntity2.setPlaca("Placa");
        viaturaEntity2.setPrefixo("Prefixo");
        viaturaEntity2.setRenavam("Renavam");
        viaturaEntity2.setStatus("Status");
        viaturaEntity2.setTipoEmpregoViatura(tipoEmpregoViatura2);
        viaturaEntity2.setTombamento("alice.liddell@example.org");
        when(viaturaRepository.save(Mockito.<ViaturaEntity>any())).thenReturn(viaturaEntity2);
        when(viaturaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult5);

        // Act
        ResponseEntity<VistoriaViaturaEntity> actualIniciarVistoriaResult = vistoriaServiceImpl.iniciarVistoria(1L, 1L);

        // Assert
        verify(itensVistoriaEntity).getCodItem();
        verify(itensVistoriaEntity).setAtivo(eq(true));
        verify(itensVistoriaEntity).setCodItem(isA(ItemVistoriaEntity.class));
        verify(itensVistoriaEntity).setCodTipo(isA(TipoVistoriaEntity.class));
        verify(itensVistoriaEntity).setDataInclusao(isA(LocalDate.class));
        verify(itensVistoriaEntity).setId(eq(1L));
        verify(defeitosVistoriaRepository).findAllByCodSubitem(isA(SubitemVistoriaEntity.class));
        verify(itensVistoriaRepository).findAllByCodTipo(isA(TipoVistoriaEntity.class));
        verify(subitensVistoriaRepository).findAllByCodItem(isA(ItemVistoriaEntity.class));
        verify(itemVistoriaRepository).findById(eq(1L));
        verify(subitemVistoriaRepository).findById(eq(1L));
        verify(tipoDefeitoVistoriaRepository).findById(eq(1L));
        verify(tipoVistoriaRepository).findById(eq(1L));
        verify(viaturaRepository).findById(eq(1L));
        verify(viaturaRepository).save(isA(ViaturaEntity.class));
        VistoriaViaturaEntity body = actualIniciarVistoriaResult.getBody();
        assertEquals(1, body.getCheckLists().size());
        assertEquals(HttpStatus.OK, actualIniciarVistoriaResult.getStatusCode());
        assertTrue(body.getViatura().getAtivo());
        assertTrue(actualIniciarVistoriaResult.hasBody());
        assertTrue(actualIniciarVistoriaResult.getHeaders().isEmpty());
    }
}
