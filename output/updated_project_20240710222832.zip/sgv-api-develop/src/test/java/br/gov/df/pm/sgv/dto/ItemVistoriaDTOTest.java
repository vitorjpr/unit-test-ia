package br.gov.df.pm.sgv.dto;

import br.gov.df.pm.sgv.domain.SubitemVistoriaEntity;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class ItemVistoriaDTOTest {
    private ItemVistoriaDTO itemVistoria = new ItemVistoriaDTO(null, "", "", null, null, null);
    private LocalDate diaAtual = LocalDate.now();
    private SubitemVistoriaEntity subitens = SubitemVistoriaEntity.builder().build();


    @BeforeEach
    void setUp() {
        itemVistoria.setId(1L);
        itemVistoria.setNome("Vidro");
        itemVistoria.setDescricao("Vidro do Carro");
        itemVistoria.setDataInclusao(diaAtual);
        itemVistoria.setAtivo(true);
        itemVistoria.setSubitens(List.of(subitens));
    }

    @Test
    void testEquals() {
        var itemVistoria1 = ItemVistoriaDTO.builder()
                .id(1L)
                .nome("Vidro")
                .descricao("Vidro do Carro")
                .dataInclusao(diaAtual)
                .ativo(true)
                .subitens(List.of(subitens))
                .build();
        assertEquals(itemVistoria, itemVistoria1);

        var itemVistoria2 = ItemVistoriaDTO.builder().nome("Janela").build();
        assertNotEquals(itemVistoria, itemVistoria2);


    }

    @Test
    void testHashCode() {
        var itemVistoria1 = ItemVistoriaDTO.builder()
                .id(1L)
                .nome("Vidro")
                .descricao("Vidro do Carro")
                .dataInclusao(diaAtual)
                .ativo(true)
                .subitens(List.of(subitens))
                .build();
        assertEquals(itemVistoria.hashCode(), itemVistoria1.hashCode());

        var itemVistoria2 = ItemVistoriaDTO.builder().build();
        assertNotEquals(itemVistoria.hashCode(), itemVistoria2.hashCode());
    }

    @Test
    void testToString() {
        assertNotNull(itemVistoria.toString());
    }
}
