//package br.gov.df.pm.sgv.dto.app;
//
//import br.gov.df.pm.sgv.domain.TipoVistoriaEntity;
//import br.gov.df.pm.sgv.domain.ViaturaEntity;
//import br.gov.df.pm.sgv.dto.VistoriaDTO;
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//
//import static org.junit.jupiter.api.Assertions.*;
//
//public class VistoriaDTOTest {
//    private VistoriaDTO vistoria = new VistoriaDTO();
//
//    @BeforeEach
//    void setUp() {
//        vistoria.setTipoVistoria(TipoVistoriaEntity.builder().id(1L).build());
//        vistoria.setViatura(ViaturaEntity.builder().id(1L).build());
//    }
//
//    @Test
//    void testEquals() {
//        var vistoria1 = VistoriaDTO.builder()
//                .tipoVistoria(TipoVistoriaEntity.builder().id(1L).build())
//                .viatura(ViaturaEntity.builder().id(1L).build())
//                .build();
//        assertEquals(vistoria, vistoria1);
//
//        var viatura2 = VistoriaDTO.builder().tipoVistoria(TipoVistoriaEntity.builder().build()).build();
//        assertNotEquals(vistoria, viatura2);
//    }
//
//    @Test
//    void testHashCode() {
//        var vistoria1 = VistoriaDTO.builder()
//                .tipoVistoria(TipoVistoriaEntity.builder().id(1L).build())
//                .viatura(ViaturaEntity.builder().id(1L).build())
//                .build();
//        assertEquals(vistoria.hashCode(), vistoria1.hashCode());
//
//        var viatura2 = VistoriaDTO.builder().tipoVistoria(TipoVistoriaEntity.builder().build()).build();
//        assertNotEquals(vistoria.hashCode(), viatura2.hashCode());
//    }
//
//    @Test
//    void testToString() { assertNotNull(vistoria.toString());}
//
//}
