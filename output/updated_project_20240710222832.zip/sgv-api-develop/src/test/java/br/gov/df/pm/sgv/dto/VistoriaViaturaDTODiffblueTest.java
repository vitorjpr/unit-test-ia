package br.gov.df.pm.sgv.dto;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import br.gov.df.pm.sgv.domain.DiferencaOdometroEntity;
import br.gov.df.pm.sgv.domain.TipoVistoriaEntity;
import br.gov.df.pm.sgv.domain.VistoriaViaturaHistoricoEntity;
import br.gov.df.pm.sgv.domain.enums.VistoriaViaturaStatusEnum;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

class VistoriaViaturaDTODiffblueTest {
    /**
     * Method under test: {@link VistoriaViaturaDTO#canEqual(Object)}
     */
    @Test
    void testCanEqual() {
        // Arrange
        TipoVistoriaEntity tipoVistoria = new TipoVistoriaEntity();
        ArrayList<VistoriaViaturaHistoricoEntity> vistoriaViaturaHistorico = new ArrayList<>();
        DiferencaOdometroEntity diferencaOdometro = new DiferencaOdometroEntity();

        // Act and Assert
        assertFalse((new VistoriaViaturaDTO(tipoVistoria, vistoriaViaturaHistorico, diferencaOdometro,
                VistoriaViaturaStatusEnum.DISPONIVEL, LocalDate.of(1970, 1, 1).atStartOfDay())).canEqual("Other"));
    }

    /**
     * Method under test: {@link VistoriaViaturaDTO#canEqual(Object)}
     */
    @Test
    void testCanEqual2() {
        // Arrange
        TipoVistoriaEntity referenciaFinal = new TipoVistoriaEntity();
        referenciaFinal.setAtivo(true);
        referenciaFinal.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaFinal.setDescricao("Descricao");
        referenciaFinal.setId(1L);
        referenciaFinal.setNome("Nome");
        referenciaFinal.setStatusAnterior("Status Anterior");
        referenciaFinal.setStatusPosterior("Status Posterior");

        TipoVistoriaEntity referenciaInicial = new TipoVistoriaEntity();
        referenciaInicial.setAtivo(true);
        referenciaInicial.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaInicial.setDescricao("Descricao");
        referenciaInicial.setId(1L);
        referenciaInicial.setNome("Nome");
        referenciaInicial.setStatusAnterior("Status Anterior");
        referenciaInicial.setStatusPosterior("Status Posterior");

        DiferencaOdometroEntity diferencaOdometro = new DiferencaOdometroEntity();
        diferencaOdometro.setDataInclusao(LocalDate.of(1970, 1, 1));
        diferencaOdometro.setDataModificacao(LocalDate.of(1970, 1, 1));
        diferencaOdometro.setDiferencaOdometro(10.0d);
        diferencaOdometro.setId(1L);
        diferencaOdometro.setReferenciaFinal(referenciaFinal);
        diferencaOdometro.setReferenciaInicial(referenciaInicial);
        VistoriaViaturaDTO.VistoriaViaturaDTOBuilder builderResult = VistoriaViaturaDTO.builder();
        VistoriaViaturaDTO.VistoriaViaturaDTOBuilder statusResult = builderResult
                .dataVistoria(LocalDate.of(1970, 1, 1).atStartOfDay())
                .diferencaOdometro(diferencaOdometro)
                .status(VistoriaViaturaStatusEnum.DISPONIVEL);

        TipoVistoriaEntity tipoVistoria = new TipoVistoriaEntity();
        tipoVistoria.setAtivo(true);
        tipoVistoria.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoria.setDescricao("Descricao");
        tipoVistoria.setId(1L);
        tipoVistoria.setNome("Nome");
        tipoVistoria.setStatusAnterior("Status Anterior");
        tipoVistoria.setStatusPosterior("Status Posterior");
        VistoriaViaturaDTO.VistoriaViaturaDTOBuilder tipoVistoriaResult = statusResult.tipoVistoria(tipoVistoria);
        VistoriaViaturaDTO buildResult = tipoVistoriaResult.vistoriaViaturaHistorico(new ArrayList<>()).build();

        TipoVistoriaEntity referenciaFinal2 = new TipoVistoriaEntity();
        referenciaFinal2.setAtivo(true);
        referenciaFinal2.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaFinal2.setDescricao("Descricao");
        referenciaFinal2.setId(1L);
        referenciaFinal2.setNome("Nome");
        referenciaFinal2.setStatusAnterior("Status Anterior");
        referenciaFinal2.setStatusPosterior("Status Posterior");

        TipoVistoriaEntity referenciaInicial2 = new TipoVistoriaEntity();
        referenciaInicial2.setAtivo(true);
        referenciaInicial2.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaInicial2.setDescricao("Descricao");
        referenciaInicial2.setId(1L);
        referenciaInicial2.setNome("Nome");
        referenciaInicial2.setStatusAnterior("Status Anterior");
        referenciaInicial2.setStatusPosterior("Status Posterior");

        DiferencaOdometroEntity diferencaOdometro2 = new DiferencaOdometroEntity();
        diferencaOdometro2.setDataInclusao(LocalDate.of(1970, 1, 1));
        diferencaOdometro2.setDataModificacao(LocalDate.of(1970, 1, 1));
        diferencaOdometro2.setDiferencaOdometro(10.0d);
        diferencaOdometro2.setId(1L);
        diferencaOdometro2.setReferenciaFinal(referenciaFinal2);
        diferencaOdometro2.setReferenciaInicial(referenciaInicial2);
        VistoriaViaturaDTO.VistoriaViaturaDTOBuilder builderResult2 = VistoriaViaturaDTO.builder();
        VistoriaViaturaDTO.VistoriaViaturaDTOBuilder statusResult2 = builderResult2
                .dataVistoria(LocalDate.of(1970, 1, 1).atStartOfDay())
                .diferencaOdometro(diferencaOdometro2)
                .status(VistoriaViaturaStatusEnum.DISPONIVEL);

        TipoVistoriaEntity tipoVistoria2 = new TipoVistoriaEntity();
        tipoVistoria2.setAtivo(true);
        tipoVistoria2.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoria2.setDescricao("Descricao");
        tipoVistoria2.setId(1L);
        tipoVistoria2.setNome("Nome");
        tipoVistoria2.setStatusAnterior("Status Anterior");
        tipoVistoria2.setStatusPosterior("Status Posterior");
        VistoriaViaturaDTO.VistoriaViaturaDTOBuilder tipoVistoriaResult2 = statusResult2.tipoVistoria(tipoVistoria2);
        VistoriaViaturaDTO buildResult2 = tipoVistoriaResult2.vistoriaViaturaHistorico(new ArrayList<>()).build();

        // Act and Assert
        assertTrue(buildResult.canEqual(buildResult2));
    }

    /**
     * Method under test: {@link VistoriaViaturaDTO#equals(Object)}
     */
    @Test
    void testEquals() {
        // Arrange
        TipoVistoriaEntity referenciaFinal = new TipoVistoriaEntity();
        referenciaFinal.setAtivo(true);
        referenciaFinal.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaFinal.setDescricao("Descricao");
        referenciaFinal.setId(1L);
        referenciaFinal.setNome("Nome");
        referenciaFinal.setStatusAnterior("Status Anterior");
        referenciaFinal.setStatusPosterior("Status Posterior");

        TipoVistoriaEntity referenciaInicial = new TipoVistoriaEntity();
        referenciaInicial.setAtivo(true);
        referenciaInicial.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaInicial.setDescricao("Descricao");
        referenciaInicial.setId(1L);
        referenciaInicial.setNome("Nome");
        referenciaInicial.setStatusAnterior("Status Anterior");
        referenciaInicial.setStatusPosterior("Status Posterior");

        DiferencaOdometroEntity diferencaOdometro = new DiferencaOdometroEntity();
        diferencaOdometro.setDataInclusao(LocalDate.of(1970, 1, 1));
        diferencaOdometro.setDataModificacao(LocalDate.of(1970, 1, 1));
        diferencaOdometro.setDiferencaOdometro(10.0d);
        diferencaOdometro.setId(1L);
        diferencaOdometro.setReferenciaFinal(referenciaFinal);
        diferencaOdometro.setReferenciaInicial(referenciaInicial);
        VistoriaViaturaDTO.VistoriaViaturaDTOBuilder builderResult = VistoriaViaturaDTO.builder();
        VistoriaViaturaDTO.VistoriaViaturaDTOBuilder statusResult = builderResult
                .dataVistoria(LocalDate.of(1970, 1, 1).atStartOfDay())
                .diferencaOdometro(diferencaOdometro)
                .status(VistoriaViaturaStatusEnum.DISPONIVEL);

        TipoVistoriaEntity tipoVistoria = new TipoVistoriaEntity();
        tipoVistoria.setAtivo(true);
        tipoVistoria.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoria.setDescricao("Descricao");
        tipoVistoria.setId(1L);
        tipoVistoria.setNome("Nome");
        tipoVistoria.setStatusAnterior("Status Anterior");
        tipoVistoria.setStatusPosterior("Status Posterior");
        VistoriaViaturaDTO.VistoriaViaturaDTOBuilder tipoVistoriaResult = statusResult.tipoVistoria(tipoVistoria);
        VistoriaViaturaDTO buildResult = tipoVistoriaResult.vistoriaViaturaHistorico(new ArrayList<>()).build();

        // Act and Assert
        assertNotEquals(buildResult, null);
    }

    /**
     * Method under test: {@link VistoriaViaturaDTO#equals(Object)}
     */
    @Test
    void testEquals2() {
        // Arrange
        TipoVistoriaEntity referenciaFinal = new TipoVistoriaEntity();
        referenciaFinal.setAtivo(true);
        referenciaFinal.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaFinal.setDescricao("Descricao");
        referenciaFinal.setId(1L);
        referenciaFinal.setNome("Nome");
        referenciaFinal.setStatusAnterior("Status Anterior");
        referenciaFinal.setStatusPosterior("Status Posterior");

        TipoVistoriaEntity referenciaInicial = new TipoVistoriaEntity();
        referenciaInicial.setAtivo(true);
        referenciaInicial.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaInicial.setDescricao("Descricao");
        referenciaInicial.setId(1L);
        referenciaInicial.setNome("Nome");
        referenciaInicial.setStatusAnterior("Status Anterior");
        referenciaInicial.setStatusPosterior("Status Posterior");

        DiferencaOdometroEntity diferencaOdometro = new DiferencaOdometroEntity();
        diferencaOdometro.setDataInclusao(LocalDate.of(1970, 1, 1));
        diferencaOdometro.setDataModificacao(LocalDate.of(1970, 1, 1));
        diferencaOdometro.setDiferencaOdometro(10.0d);
        diferencaOdometro.setId(1L);
        diferencaOdometro.setReferenciaFinal(referenciaFinal);
        diferencaOdometro.setReferenciaInicial(referenciaInicial);
        VistoriaViaturaDTO.VistoriaViaturaDTOBuilder builderResult = VistoriaViaturaDTO.builder();
        VistoriaViaturaDTO.VistoriaViaturaDTOBuilder statusResult = builderResult
                .dataVistoria(LocalDate.of(1970, 1, 1).atStartOfDay())
                .diferencaOdometro(diferencaOdometro)
                .status(VistoriaViaturaStatusEnum.DISPONIVEL);

        TipoVistoriaEntity tipoVistoria = new TipoVistoriaEntity();
        tipoVistoria.setAtivo(true);
        tipoVistoria.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoria.setDescricao("Descricao");
        tipoVistoria.setId(1L);
        tipoVistoria.setNome("Nome");
        tipoVistoria.setStatusAnterior("Status Anterior");
        tipoVistoria.setStatusPosterior("Status Posterior");
        VistoriaViaturaDTO.VistoriaViaturaDTOBuilder tipoVistoriaResult = statusResult.tipoVistoria(tipoVistoria);
        VistoriaViaturaDTO buildResult = tipoVistoriaResult.vistoriaViaturaHistorico(new ArrayList<>()).build();

        // Act and Assert
        assertNotEquals(buildResult, "Different type to VistoriaViaturaDTO");
    }

    /**
     * Method under test: {@link VistoriaViaturaDTO#equals(Object)}
     */
    @Test
    void testEquals3() {
        // Arrange
        VistoriaViaturaDTO.VistoriaViaturaDTOBuilder vistoriaViaturaDTOBuilder = mock(
                VistoriaViaturaDTO.VistoriaViaturaDTOBuilder.class);
        when(vistoriaViaturaDTOBuilder.dataVistoria(Mockito.<LocalDateTime>any())).thenReturn(VistoriaViaturaDTO.builder());
        VistoriaViaturaDTO.VistoriaViaturaDTOBuilder dataVistoriaResult = vistoriaViaturaDTOBuilder
                .dataVistoria(LocalDate.of(1970, 1, 1).atStartOfDay());

        TipoVistoriaEntity referenciaFinal = new TipoVistoriaEntity();
        referenciaFinal.setAtivo(true);
        referenciaFinal.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaFinal.setDescricao("Descricao");
        referenciaFinal.setId(1L);
        referenciaFinal.setNome("Nome");
        referenciaFinal.setStatusAnterior("Status Anterior");
        referenciaFinal.setStatusPosterior("Status Posterior");

        TipoVistoriaEntity referenciaInicial = new TipoVistoriaEntity();
        referenciaInicial.setAtivo(true);
        referenciaInicial.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaInicial.setDescricao("Descricao");
        referenciaInicial.setId(1L);
        referenciaInicial.setNome("Nome");
        referenciaInicial.setStatusAnterior("Status Anterior");
        referenciaInicial.setStatusPosterior("Status Posterior");

        DiferencaOdometroEntity diferencaOdometro = new DiferencaOdometroEntity();
        diferencaOdometro.setDataInclusao(LocalDate.of(1970, 1, 1));
        diferencaOdometro.setDataModificacao(LocalDate.of(1970, 1, 1));
        diferencaOdometro.setDiferencaOdometro(10.0d);
        diferencaOdometro.setId(1L);
        diferencaOdometro.setReferenciaFinal(referenciaFinal);
        diferencaOdometro.setReferenciaInicial(referenciaInicial);
        VistoriaViaturaDTO.VistoriaViaturaDTOBuilder statusResult = dataVistoriaResult.diferencaOdometro(diferencaOdometro)
                .status(VistoriaViaturaStatusEnum.DISPONIVEL);

        TipoVistoriaEntity tipoVistoria = new TipoVistoriaEntity();
        tipoVistoria.setAtivo(true);
        tipoVistoria.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoria.setDescricao("Descricao");
        tipoVistoria.setId(1L);
        tipoVistoria.setNome("Nome");
        tipoVistoria.setStatusAnterior("Status Anterior");
        tipoVistoria.setStatusPosterior("Status Posterior");
        VistoriaViaturaDTO.VistoriaViaturaDTOBuilder tipoVistoriaResult = statusResult.tipoVistoria(tipoVistoria);
        VistoriaViaturaDTO buildResult = tipoVistoriaResult.vistoriaViaturaHistorico(new ArrayList<>()).build();

        TipoVistoriaEntity referenciaFinal2 = new TipoVistoriaEntity();
        referenciaFinal2.setAtivo(true);
        referenciaFinal2.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaFinal2.setDescricao("Descricao");
        referenciaFinal2.setId(1L);
        referenciaFinal2.setNome("Nome");
        referenciaFinal2.setStatusAnterior("Status Anterior");
        referenciaFinal2.setStatusPosterior("Status Posterior");

        TipoVistoriaEntity referenciaInicial2 = new TipoVistoriaEntity();
        referenciaInicial2.setAtivo(true);
        referenciaInicial2.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaInicial2.setDescricao("Descricao");
        referenciaInicial2.setId(1L);
        referenciaInicial2.setNome("Nome");
        referenciaInicial2.setStatusAnterior("Status Anterior");
        referenciaInicial2.setStatusPosterior("Status Posterior");

        DiferencaOdometroEntity diferencaOdometro2 = new DiferencaOdometroEntity();
        diferencaOdometro2.setDataInclusao(LocalDate.of(1970, 1, 1));
        diferencaOdometro2.setDataModificacao(LocalDate.of(1970, 1, 1));
        diferencaOdometro2.setDiferencaOdometro(10.0d);
        diferencaOdometro2.setId(1L);
        diferencaOdometro2.setReferenciaFinal(referenciaFinal2);
        diferencaOdometro2.setReferenciaInicial(referenciaInicial2);
        VistoriaViaturaDTO.VistoriaViaturaDTOBuilder builderResult = VistoriaViaturaDTO.builder();
        VistoriaViaturaDTO.VistoriaViaturaDTOBuilder statusResult2 = builderResult
                .dataVistoria(LocalDate.of(1970, 1, 1).atStartOfDay())
                .diferencaOdometro(diferencaOdometro2)
                .status(VistoriaViaturaStatusEnum.DISPONIVEL);

        TipoVistoriaEntity tipoVistoria2 = new TipoVistoriaEntity();
        tipoVistoria2.setAtivo(true);
        tipoVistoria2.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoria2.setDescricao("Descricao");
        tipoVistoria2.setId(1L);
        tipoVistoria2.setNome("Nome");
        tipoVistoria2.setStatusAnterior("Status Anterior");
        tipoVistoria2.setStatusPosterior("Status Posterior");
        VistoriaViaturaDTO.VistoriaViaturaDTOBuilder tipoVistoriaResult2 = statusResult2.tipoVistoria(tipoVistoria2);
        VistoriaViaturaDTO buildResult2 = tipoVistoriaResult2.vistoriaViaturaHistorico(new ArrayList<>()).build();

        // Act and Assert
        assertNotEquals(buildResult, buildResult2);
    }

    /**
     * Method under test: {@link VistoriaViaturaDTO#equals(Object)}
     */
    @Test
    void testEquals4() {
        // Arrange
        VistoriaViaturaDTO.VistoriaViaturaDTOBuilder vistoriaViaturaDTOBuilder = mock(
                VistoriaViaturaDTO.VistoriaViaturaDTOBuilder.class);
        when(vistoriaViaturaDTOBuilder.diferencaOdometro(Mockito.<DiferencaOdometroEntity>any()))
                .thenReturn(VistoriaViaturaDTO.builder());
        VistoriaViaturaDTO.VistoriaViaturaDTOBuilder vistoriaViaturaDTOBuilder2 = mock(
                VistoriaViaturaDTO.VistoriaViaturaDTOBuilder.class);
        when(vistoriaViaturaDTOBuilder2.dataVistoria(Mockito.<LocalDateTime>any())).thenReturn(vistoriaViaturaDTOBuilder);
        VistoriaViaturaDTO.VistoriaViaturaDTOBuilder dataVistoriaResult = vistoriaViaturaDTOBuilder2
                .dataVistoria(LocalDate.of(1970, 1, 1).atStartOfDay());

        TipoVistoriaEntity referenciaFinal = new TipoVistoriaEntity();
        referenciaFinal.setAtivo(true);
        referenciaFinal.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaFinal.setDescricao("Descricao");
        referenciaFinal.setId(1L);
        referenciaFinal.setNome("Nome");
        referenciaFinal.setStatusAnterior("Status Anterior");
        referenciaFinal.setStatusPosterior("Status Posterior");

        TipoVistoriaEntity referenciaInicial = new TipoVistoriaEntity();
        referenciaInicial.setAtivo(true);
        referenciaInicial.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaInicial.setDescricao("Descricao");
        referenciaInicial.setId(1L);
        referenciaInicial.setNome("Nome");
        referenciaInicial.setStatusAnterior("Status Anterior");
        referenciaInicial.setStatusPosterior("Status Posterior");

        DiferencaOdometroEntity diferencaOdometro = new DiferencaOdometroEntity();
        diferencaOdometro.setDataInclusao(LocalDate.of(1970, 1, 1));
        diferencaOdometro.setDataModificacao(LocalDate.of(1970, 1, 1));
        diferencaOdometro.setDiferencaOdometro(10.0d);
        diferencaOdometro.setId(1L);
        diferencaOdometro.setReferenciaFinal(referenciaFinal);
        diferencaOdometro.setReferenciaInicial(referenciaInicial);
        VistoriaViaturaDTO.VistoriaViaturaDTOBuilder statusResult = dataVistoriaResult.diferencaOdometro(diferencaOdometro)
                .status(VistoriaViaturaStatusEnum.DISPONIVEL);

        TipoVistoriaEntity tipoVistoria = new TipoVistoriaEntity();
        tipoVistoria.setAtivo(true);
        tipoVistoria.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoria.setDescricao("Descricao");
        tipoVistoria.setId(1L);
        tipoVistoria.setNome("Nome");
        tipoVistoria.setStatusAnterior("Status Anterior");
        tipoVistoria.setStatusPosterior("Status Posterior");
        VistoriaViaturaDTO.VistoriaViaturaDTOBuilder tipoVistoriaResult = statusResult.tipoVistoria(tipoVistoria);
        VistoriaViaturaDTO buildResult = tipoVistoriaResult.vistoriaViaturaHistorico(new ArrayList<>()).build();

        TipoVistoriaEntity referenciaFinal2 = new TipoVistoriaEntity();
        referenciaFinal2.setAtivo(true);
        referenciaFinal2.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaFinal2.setDescricao("Descricao");
        referenciaFinal2.setId(1L);
        referenciaFinal2.setNome("Nome");
        referenciaFinal2.setStatusAnterior("Status Anterior");
        referenciaFinal2.setStatusPosterior("Status Posterior");

        TipoVistoriaEntity referenciaInicial2 = new TipoVistoriaEntity();
        referenciaInicial2.setAtivo(true);
        referenciaInicial2.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaInicial2.setDescricao("Descricao");
        referenciaInicial2.setId(1L);
        referenciaInicial2.setNome("Nome");
        referenciaInicial2.setStatusAnterior("Status Anterior");
        referenciaInicial2.setStatusPosterior("Status Posterior");

        DiferencaOdometroEntity diferencaOdometro2 = new DiferencaOdometroEntity();
        diferencaOdometro2.setDataInclusao(LocalDate.of(1970, 1, 1));
        diferencaOdometro2.setDataModificacao(LocalDate.of(1970, 1, 1));
        diferencaOdometro2.setDiferencaOdometro(10.0d);
        diferencaOdometro2.setId(1L);
        diferencaOdometro2.setReferenciaFinal(referenciaFinal2);
        diferencaOdometro2.setReferenciaInicial(referenciaInicial2);
        VistoriaViaturaDTO.VistoriaViaturaDTOBuilder builderResult = VistoriaViaturaDTO.builder();
        VistoriaViaturaDTO.VistoriaViaturaDTOBuilder statusResult2 = builderResult
                .dataVistoria(LocalDate.of(1970, 1, 1).atStartOfDay())
                .diferencaOdometro(diferencaOdometro2)
                .status(VistoriaViaturaStatusEnum.DISPONIVEL);

        TipoVistoriaEntity tipoVistoria2 = new TipoVistoriaEntity();
        tipoVistoria2.setAtivo(true);
        tipoVistoria2.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoria2.setDescricao("Descricao");
        tipoVistoria2.setId(1L);
        tipoVistoria2.setNome("Nome");
        tipoVistoria2.setStatusAnterior("Status Anterior");
        tipoVistoria2.setStatusPosterior("Status Posterior");
        VistoriaViaturaDTO.VistoriaViaturaDTOBuilder tipoVistoriaResult2 = statusResult2.tipoVistoria(tipoVistoria2);
        VistoriaViaturaDTO buildResult2 = tipoVistoriaResult2.vistoriaViaturaHistorico(new ArrayList<>()).build();

        // Act and Assert
        assertNotEquals(buildResult, buildResult2);
    }

    /**
     * Method under test: {@link VistoriaViaturaDTO#equals(Object)}
     */
    @Test
    void testEquals5() {
        // Arrange
        VistoriaViaturaDTO.VistoriaViaturaDTOBuilder vistoriaViaturaDTOBuilder = mock(
                VistoriaViaturaDTO.VistoriaViaturaDTOBuilder.class);
        when(vistoriaViaturaDTOBuilder.diferencaOdometro(Mockito.<DiferencaOdometroEntity>any()))
                .thenReturn(VistoriaViaturaDTO.builder());
        VistoriaViaturaDTO.VistoriaViaturaDTOBuilder vistoriaViaturaDTOBuilder2 = mock(
                VistoriaViaturaDTO.VistoriaViaturaDTOBuilder.class);
        when(vistoriaViaturaDTOBuilder2.dataVistoria(Mockito.<LocalDateTime>any())).thenReturn(vistoriaViaturaDTOBuilder);
        VistoriaViaturaDTO.VistoriaViaturaDTOBuilder dataVistoriaResult = vistoriaViaturaDTOBuilder2
                .dataVistoria(LocalDate.of(1970, 1, 1).atStartOfDay());

        TipoVistoriaEntity referenciaFinal = new TipoVistoriaEntity();
        referenciaFinal.setAtivo(true);
        referenciaFinal.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaFinal.setDescricao("Descricao");
        referenciaFinal.setId(1L);
        referenciaFinal.setNome("Nome");
        referenciaFinal.setStatusAnterior("Status Anterior");
        referenciaFinal.setStatusPosterior("Status Posterior");

        TipoVistoriaEntity referenciaInicial = new TipoVistoriaEntity();
        referenciaInicial.setAtivo(true);
        referenciaInicial.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaInicial.setDescricao("Descricao");
        referenciaInicial.setId(1L);
        referenciaInicial.setNome("Nome");
        referenciaInicial.setStatusAnterior("Status Anterior");
        referenciaInicial.setStatusPosterior("Status Posterior");

        DiferencaOdometroEntity diferencaOdometro = new DiferencaOdometroEntity();
        diferencaOdometro.setDataInclusao(LocalDate.of(1970, 1, 1));
        diferencaOdometro.setDataModificacao(LocalDate.of(1970, 1, 1));
        diferencaOdometro.setDiferencaOdometro(10.0d);
        diferencaOdometro.setId(1L);
        diferencaOdometro.setReferenciaFinal(referenciaFinal);
        diferencaOdometro.setReferenciaInicial(referenciaInicial);
        VistoriaViaturaDTO.VistoriaViaturaDTOBuilder statusResult = dataVistoriaResult.diferencaOdometro(diferencaOdometro)
                .status(VistoriaViaturaStatusEnum.DISPONIVEL);
        TipoVistoriaEntity tipoVistoria = mock(TipoVistoriaEntity.class);
        doNothing().when(tipoVistoria).setAtivo(Mockito.<Boolean>any());
        doNothing().when(tipoVistoria).setDataInclusao(Mockito.<LocalDate>any());
        doNothing().when(tipoVistoria).setDescricao(Mockito.<String>any());
        doNothing().when(tipoVistoria).setId(Mockito.<Long>any());
        doNothing().when(tipoVistoria).setNome(Mockito.<String>any());
        doNothing().when(tipoVistoria).setStatusAnterior(Mockito.<String>any());
        doNothing().when(tipoVistoria).setStatusPosterior(Mockito.<String>any());
        tipoVistoria.setAtivo(true);
        tipoVistoria.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoria.setDescricao("Descricao");
        tipoVistoria.setId(1L);
        tipoVistoria.setNome("Nome");
        tipoVistoria.setStatusAnterior("Status Anterior");
        tipoVistoria.setStatusPosterior("Status Posterior");
        VistoriaViaturaDTO.VistoriaViaturaDTOBuilder tipoVistoriaResult = statusResult.tipoVistoria(tipoVistoria);
        VistoriaViaturaDTO buildResult = tipoVistoriaResult.vistoriaViaturaHistorico(new ArrayList<>()).build();

        TipoVistoriaEntity referenciaFinal2 = new TipoVistoriaEntity();
        referenciaFinal2.setAtivo(true);
        referenciaFinal2.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaFinal2.setDescricao("Descricao");
        referenciaFinal2.setId(1L);
        referenciaFinal2.setNome("Nome");
        referenciaFinal2.setStatusAnterior("Status Anterior");
        referenciaFinal2.setStatusPosterior("Status Posterior");

        TipoVistoriaEntity referenciaInicial2 = new TipoVistoriaEntity();
        referenciaInicial2.setAtivo(true);
        referenciaInicial2.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaInicial2.setDescricao("Descricao");
        referenciaInicial2.setId(1L);
        referenciaInicial2.setNome("Nome");
        referenciaInicial2.setStatusAnterior("Status Anterior");
        referenciaInicial2.setStatusPosterior("Status Posterior");

        DiferencaOdometroEntity diferencaOdometro2 = new DiferencaOdometroEntity();
        diferencaOdometro2.setDataInclusao(LocalDate.of(1970, 1, 1));
        diferencaOdometro2.setDataModificacao(LocalDate.of(1970, 1, 1));
        diferencaOdometro2.setDiferencaOdometro(10.0d);
        diferencaOdometro2.setId(1L);
        diferencaOdometro2.setReferenciaFinal(referenciaFinal2);
        diferencaOdometro2.setReferenciaInicial(referenciaInicial2);
        VistoriaViaturaDTO.VistoriaViaturaDTOBuilder builderResult = VistoriaViaturaDTO.builder();
        VistoriaViaturaDTO.VistoriaViaturaDTOBuilder statusResult2 = builderResult
                .dataVistoria(LocalDate.of(1970, 1, 1).atStartOfDay())
                .diferencaOdometro(diferencaOdometro2)
                .status(VistoriaViaturaStatusEnum.DISPONIVEL);

        TipoVistoriaEntity tipoVistoria2 = new TipoVistoriaEntity();
        tipoVistoria2.setAtivo(true);
        tipoVistoria2.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoria2.setDescricao("Descricao");
        tipoVistoria2.setId(1L);
        tipoVistoria2.setNome("Nome");
        tipoVistoria2.setStatusAnterior("Status Anterior");
        tipoVistoria2.setStatusPosterior("Status Posterior");
        VistoriaViaturaDTO.VistoriaViaturaDTOBuilder tipoVistoriaResult2 = statusResult2.tipoVistoria(tipoVistoria2);
        VistoriaViaturaDTO buildResult2 = tipoVistoriaResult2.vistoriaViaturaHistorico(new ArrayList<>()).build();

        // Act and Assert
        assertNotEquals(buildResult, buildResult2);
    }

    /**
     * Methods under test:
     * <ul>
     *   <li>{@link VistoriaViaturaDTO#equals(Object)}
     *   <li>{@link VistoriaViaturaDTO#hashCode()}
     * </ul>
     */
    @Test
    void testEqualsAndHashCode() {
        // Arrange
        TipoVistoriaEntity referenciaFinal = new TipoVistoriaEntity();
        referenciaFinal.setAtivo(true);
        referenciaFinal.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaFinal.setDescricao("Descricao");
        referenciaFinal.setId(1L);
        referenciaFinal.setNome("Nome");
        referenciaFinal.setStatusAnterior("Status Anterior");
        referenciaFinal.setStatusPosterior("Status Posterior");

        TipoVistoriaEntity referenciaInicial = new TipoVistoriaEntity();
        referenciaInicial.setAtivo(true);
        referenciaInicial.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaInicial.setDescricao("Descricao");
        referenciaInicial.setId(1L);
        referenciaInicial.setNome("Nome");
        referenciaInicial.setStatusAnterior("Status Anterior");
        referenciaInicial.setStatusPosterior("Status Posterior");

        DiferencaOdometroEntity diferencaOdometro = new DiferencaOdometroEntity();
        diferencaOdometro.setDataInclusao(LocalDate.of(1970, 1, 1));
        diferencaOdometro.setDataModificacao(LocalDate.of(1970, 1, 1));
        diferencaOdometro.setDiferencaOdometro(10.0d);
        diferencaOdometro.setId(1L);
        diferencaOdometro.setReferenciaFinal(referenciaFinal);
        diferencaOdometro.setReferenciaInicial(referenciaInicial);
        VistoriaViaturaDTO.VistoriaViaturaDTOBuilder builderResult = VistoriaViaturaDTO.builder();
        VistoriaViaturaDTO.VistoriaViaturaDTOBuilder statusResult = builderResult
                .dataVistoria(LocalDate.of(1970, 1, 1).atStartOfDay())
                .diferencaOdometro(diferencaOdometro)
                .status(VistoriaViaturaStatusEnum.DISPONIVEL);

        TipoVistoriaEntity tipoVistoria = new TipoVistoriaEntity();
        tipoVistoria.setAtivo(true);
        tipoVistoria.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoria.setDescricao("Descricao");
        tipoVistoria.setId(1L);
        tipoVistoria.setNome("Nome");
        tipoVistoria.setStatusAnterior("Status Anterior");
        tipoVistoria.setStatusPosterior("Status Posterior");
        VistoriaViaturaDTO.VistoriaViaturaDTOBuilder tipoVistoriaResult = statusResult.tipoVistoria(tipoVistoria);
        VistoriaViaturaDTO buildResult = tipoVistoriaResult.vistoriaViaturaHistorico(new ArrayList<>()).build();

        // Act and Assert
        assertEquals(buildResult, buildResult);
        int expectedHashCodeResult = buildResult.hashCode();
        assertEquals(expectedHashCodeResult, buildResult.hashCode());
    }

    /**
     * Methods under test:
     * <ul>
     *   <li>{@link VistoriaViaturaDTO#equals(Object)}
     *   <li>{@link VistoriaViaturaDTO#hashCode()}
     * </ul>
     */
    @Test
    void testEqualsAndHashCode2() {
        // Arrange
        TipoVistoriaEntity referenciaFinal = new TipoVistoriaEntity();
        referenciaFinal.setAtivo(true);
        referenciaFinal.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaFinal.setDescricao("Descricao");
        referenciaFinal.setId(1L);
        referenciaFinal.setNome("Nome");
        referenciaFinal.setStatusAnterior("Status Anterior");
        referenciaFinal.setStatusPosterior("Status Posterior");

        TipoVistoriaEntity referenciaInicial = new TipoVistoriaEntity();
        referenciaInicial.setAtivo(true);
        referenciaInicial.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaInicial.setDescricao("Descricao");
        referenciaInicial.setId(1L);
        referenciaInicial.setNome("Nome");
        referenciaInicial.setStatusAnterior("Status Anterior");
        referenciaInicial.setStatusPosterior("Status Posterior");

        DiferencaOdometroEntity diferencaOdometro = new DiferencaOdometroEntity();
        diferencaOdometro.setDataInclusao(LocalDate.of(1970, 1, 1));
        diferencaOdometro.setDataModificacao(LocalDate.of(1970, 1, 1));
        diferencaOdometro.setDiferencaOdometro(10.0d);
        diferencaOdometro.setId(1L);
        diferencaOdometro.setReferenciaFinal(referenciaFinal);
        diferencaOdometro.setReferenciaInicial(referenciaInicial);
        VistoriaViaturaDTO.VistoriaViaturaDTOBuilder builderResult = VistoriaViaturaDTO.builder();
        VistoriaViaturaDTO.VistoriaViaturaDTOBuilder statusResult = builderResult
                .dataVistoria(LocalDate.of(1970, 1, 1).atStartOfDay())
                .diferencaOdometro(diferencaOdometro)
                .status(VistoriaViaturaStatusEnum.DISPONIVEL);

        TipoVistoriaEntity tipoVistoria = new TipoVistoriaEntity();
        tipoVistoria.setAtivo(true);
        tipoVistoria.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoria.setDescricao("Descricao");
        tipoVistoria.setId(1L);
        tipoVistoria.setNome("Nome");
        tipoVistoria.setStatusAnterior("Status Anterior");
        tipoVistoria.setStatusPosterior("Status Posterior");
        VistoriaViaturaDTO.VistoriaViaturaDTOBuilder tipoVistoriaResult = statusResult.tipoVistoria(tipoVistoria);
        VistoriaViaturaDTO buildResult = tipoVistoriaResult.vistoriaViaturaHistorico(new ArrayList<>()).build();

        TipoVistoriaEntity referenciaFinal2 = new TipoVistoriaEntity();
        referenciaFinal2.setAtivo(true);
        referenciaFinal2.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaFinal2.setDescricao("Descricao");
        referenciaFinal2.setId(1L);
        referenciaFinal2.setNome("Nome");
        referenciaFinal2.setStatusAnterior("Status Anterior");
        referenciaFinal2.setStatusPosterior("Status Posterior");

        TipoVistoriaEntity referenciaInicial2 = new TipoVistoriaEntity();
        referenciaInicial2.setAtivo(true);
        referenciaInicial2.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaInicial2.setDescricao("Descricao");
        referenciaInicial2.setId(1L);
        referenciaInicial2.setNome("Nome");
        referenciaInicial2.setStatusAnterior("Status Anterior");
        referenciaInicial2.setStatusPosterior("Status Posterior");

        DiferencaOdometroEntity diferencaOdometro2 = new DiferencaOdometroEntity();
        diferencaOdometro2.setDataInclusao(LocalDate.of(1970, 1, 1));
        diferencaOdometro2.setDataModificacao(LocalDate.of(1970, 1, 1));
        diferencaOdometro2.setDiferencaOdometro(10.0d);
        diferencaOdometro2.setId(1L);
        diferencaOdometro2.setReferenciaFinal(referenciaFinal2);
        diferencaOdometro2.setReferenciaInicial(referenciaInicial2);
        VistoriaViaturaDTO.VistoriaViaturaDTOBuilder builderResult2 = VistoriaViaturaDTO.builder();
        VistoriaViaturaDTO.VistoriaViaturaDTOBuilder statusResult2 = builderResult2
                .dataVistoria(LocalDate.of(1970, 1, 1).atStartOfDay())
                .diferencaOdometro(diferencaOdometro2)
                .status(VistoriaViaturaStatusEnum.DISPONIVEL);

        TipoVistoriaEntity tipoVistoria2 = new TipoVistoriaEntity();
        tipoVistoria2.setAtivo(true);
        tipoVistoria2.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoria2.setDescricao("Descricao");
        tipoVistoria2.setId(1L);
        tipoVistoria2.setNome("Nome");
        tipoVistoria2.setStatusAnterior("Status Anterior");
        tipoVistoria2.setStatusPosterior("Status Posterior");
        VistoriaViaturaDTO.VistoriaViaturaDTOBuilder tipoVistoriaResult2 = statusResult2.tipoVistoria(tipoVistoria2);
        VistoriaViaturaDTO buildResult2 = tipoVistoriaResult2.vistoriaViaturaHistorico(new ArrayList<>()).build();

        // Act and Assert
        assertEquals(buildResult, buildResult2);
        int expectedHashCodeResult = buildResult.hashCode();
        assertEquals(expectedHashCodeResult, buildResult2.hashCode());
    }

    /**
     * Methods under test:
     * <ul>
     *   <li>
     * {@link VistoriaViaturaDTO#VistoriaViaturaDTO(TipoVistoriaEntity, List, DiferencaOdometroEntity, VistoriaViaturaStatusEnum, LocalDateTime)}
     *   <li>{@link VistoriaViaturaDTO#setDataVistoria(LocalDateTime)}
     *   <li>{@link VistoriaViaturaDTO#setDiferencaOdometro(DiferencaOdometroEntity)}
     *   <li>{@link VistoriaViaturaDTO#setStatus(VistoriaViaturaStatusEnum)}
     *   <li>{@link VistoriaViaturaDTO#setTipoVistoria(TipoVistoriaEntity)}
     *   <li>{@link VistoriaViaturaDTO#setVistoriaViaturaHistorico(List)}
     *   <li>{@link VistoriaViaturaDTO#toString()}
     *   <li>{@link VistoriaViaturaDTO#getDataVistoria()}
     *   <li>{@link VistoriaViaturaDTO#getDiferencaOdometro()}
     *   <li>{@link VistoriaViaturaDTO#getStatus()}
     *   <li>{@link VistoriaViaturaDTO#getTipoVistoria()}
     *   <li>{@link VistoriaViaturaDTO#getVistoriaViaturaHistorico()}
     * </ul>
     */
    @Test
    void testGettersAndSetters() {
        // Arrange
        TipoVistoriaEntity tipoVistoria = new TipoVistoriaEntity();
        tipoVistoria.setAtivo(true);
        tipoVistoria.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoria.setDescricao("Descricao");
        tipoVistoria.setId(1L);
        tipoVistoria.setNome("Nome");
        tipoVistoria.setStatusAnterior("Status Anterior");
        tipoVistoria.setStatusPosterior("Status Posterior");
        ArrayList<VistoriaViaturaHistoricoEntity> vistoriaViaturaHistorico = new ArrayList<>();

        TipoVistoriaEntity referenciaFinal = new TipoVistoriaEntity();
        referenciaFinal.setAtivo(true);
        referenciaFinal.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaFinal.setDescricao("Descricao");
        referenciaFinal.setId(1L);
        referenciaFinal.setNome("Nome");
        referenciaFinal.setStatusAnterior("Status Anterior");
        referenciaFinal.setStatusPosterior("Status Posterior");

        TipoVistoriaEntity referenciaInicial = new TipoVistoriaEntity();
        referenciaInicial.setAtivo(true);
        referenciaInicial.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaInicial.setDescricao("Descricao");
        referenciaInicial.setId(1L);
        referenciaInicial.setNome("Nome");
        referenciaInicial.setStatusAnterior("Status Anterior");
        referenciaInicial.setStatusPosterior("Status Posterior");

        DiferencaOdometroEntity diferencaOdometro = new DiferencaOdometroEntity();
        diferencaOdometro.setDataInclusao(LocalDate.of(1970, 1, 1));
        diferencaOdometro.setDataModificacao(LocalDate.of(1970, 1, 1));
        diferencaOdometro.setDiferencaOdometro(10.0d);
        diferencaOdometro.setId(1L);
        diferencaOdometro.setReferenciaFinal(referenciaFinal);
        diferencaOdometro.setReferenciaInicial(referenciaInicial);

        // Act
        VistoriaViaturaDTO actualVistoriaViaturaDTO = new VistoriaViaturaDTO(tipoVistoria, vistoriaViaturaHistorico,
                diferencaOdometro, VistoriaViaturaStatusEnum.DISPONIVEL, LocalDate.of(1970, 1, 1).atStartOfDay());
        LocalDateTime dataVistoria = LocalDate.of(1970, 1, 1).atStartOfDay();
        actualVistoriaViaturaDTO.setDataVistoria(dataVistoria);
        TipoVistoriaEntity referenciaFinal2 = new TipoVistoriaEntity();
        referenciaFinal2.setAtivo(true);
        referenciaFinal2.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaFinal2.setDescricao("Descricao");
        referenciaFinal2.setId(1L);
        referenciaFinal2.setNome("Nome");
        referenciaFinal2.setStatusAnterior("Status Anterior");
        referenciaFinal2.setStatusPosterior("Status Posterior");
        TipoVistoriaEntity referenciaInicial2 = new TipoVistoriaEntity();
        referenciaInicial2.setAtivo(true);
        referenciaInicial2.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaInicial2.setDescricao("Descricao");
        referenciaInicial2.setId(1L);
        referenciaInicial2.setNome("Nome");
        referenciaInicial2.setStatusAnterior("Status Anterior");
        referenciaInicial2.setStatusPosterior("Status Posterior");
        DiferencaOdometroEntity diferencaOdometro2 = new DiferencaOdometroEntity();
        diferencaOdometro2.setDataInclusao(LocalDate.of(1970, 1, 1));
        diferencaOdometro2.setDataModificacao(LocalDate.of(1970, 1, 1));
        diferencaOdometro2.setDiferencaOdometro(10.0d);
        diferencaOdometro2.setId(1L);
        diferencaOdometro2.setReferenciaFinal(referenciaFinal2);
        diferencaOdometro2.setReferenciaInicial(referenciaInicial2);
        actualVistoriaViaturaDTO.setDiferencaOdometro(diferencaOdometro2);
        actualVistoriaViaturaDTO.setStatus(VistoriaViaturaStatusEnum.DISPONIVEL);
        TipoVistoriaEntity tipoVistoria2 = new TipoVistoriaEntity();
        tipoVistoria2.setAtivo(true);
        tipoVistoria2.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoria2.setDescricao("Descricao");
        tipoVistoria2.setId(1L);
        tipoVistoria2.setNome("Nome");
        tipoVistoria2.setStatusAnterior("Status Anterior");
        tipoVistoria2.setStatusPosterior("Status Posterior");
        actualVistoriaViaturaDTO.setTipoVistoria(tipoVistoria2);
        ArrayList<VistoriaViaturaHistoricoEntity> vistoriaViaturaHistorico2 = new ArrayList<>();
        actualVistoriaViaturaDTO.setVistoriaViaturaHistorico(vistoriaViaturaHistorico2);
        actualVistoriaViaturaDTO.toString();
        LocalDateTime actualDataVistoria = actualVistoriaViaturaDTO.getDataVistoria();
        DiferencaOdometroEntity actualDiferencaOdometro = actualVistoriaViaturaDTO.getDiferencaOdometro();
        VistoriaViaturaStatusEnum actualStatus = actualVistoriaViaturaDTO.getStatus();
        TipoVistoriaEntity actualTipoVistoria = actualVistoriaViaturaDTO.getTipoVistoria();
        List<VistoriaViaturaHistoricoEntity> actualVistoriaViaturaHistorico = actualVistoriaViaturaDTO
                .getVistoriaViaturaHistorico();

        // Assert that nothing has changed
        assertEquals(VistoriaViaturaStatusEnum.DISPONIVEL, actualStatus);
        assertEquals(diferencaOdometro, actualDiferencaOdometro);
        assertEquals(tipoVistoria, actualTipoVistoria);
        assertEquals(vistoriaViaturaHistorico, actualVistoriaViaturaHistorico);
        assertSame(diferencaOdometro2, actualDiferencaOdometro);
        assertSame(tipoVistoria2, actualTipoVistoria);
        assertSame(vistoriaViaturaHistorico2, actualVistoriaViaturaHistorico);
        assertSame(dataVistoria, actualDataVistoria);
    }
}
