```java
package br.gov.df.pm.sgv.domain;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.time.LocalDate;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

class ItemVistoriaEntityDiffblueTest {

    @Test
    void testCanEqual() {
        assertFalse((new ItemVistoriaEntity()).canEqual("Other"));
    }

    @Test
    void testCanEqual2() {
        ItemVistoriaEntity itemVistoriaEntity = new ItemVistoriaEntity();
        itemVistoriaEntity.setAtivo(true);
        itemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity.setDescricao("Descricao");
        itemVistoriaEntity.setId(1L);
        itemVistoriaEntity.setNome("Nome");

        ItemVistoriaEntity itemVistoriaEntity2 = new ItemVistoriaEntity();
        itemVistoriaEntity2.setAtivo(true);
        itemVistoriaEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity2.setDescricao("Descricao");
        itemVistoriaEntity2.setId(1L);
        itemVistoriaEntity2.setNome("Nome");

        assertTrue(itemVistoriaEntity.canEqual(itemVistoriaEntity2));
    }

    @Test
    void testEquals() {
        ItemVistoriaEntity itemVistoriaEntity = new ItemVistoriaEntity();
        itemVistoriaEntity.setAtivo(true);
        itemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity.setDescricao("Descricao");
        itemVistoriaEntity.setId(1L);
        itemVistoriaEntity.setNome("Nome");

        assertNotEquals(itemVistoriaEntity, null);
    }

    @Test
    void testEquals2() {
        ItemVistoriaEntity itemVistoriaEntity = new ItemVistoriaEntity();
        itemVistoriaEntity.setAtivo(true);
        itemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity.setDescricao("Descricao");
        itemVistoriaEntity.setId(1L);
        itemVistoriaEntity.setNome("Nome");

        assertNotEquals(itemVistoriaEntity, "Different type to ItemVistoriaEntity");
    }

    @Test
    void testEquals3() {
        ItemVistoriaEntity itemVistoriaEntity = new ItemVistoriaEntity();
        itemVistoriaEntity.setAtivo(true);
        itemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity.setDescricao("Descricao");
        itemVistoriaEntity.setId(2L);
        itemVistoriaEntity.setNome("Nome");

        ItemVistoriaEntity itemVistoriaEntity2 = new ItemVistoriaEntity();
        itemVistoriaEntity2.setAtivo(true);
        itemVistoriaEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity2.setDescricao("Descricao");
        itemVistoriaEntity2.setId(1L);
        itemVistoriaEntity2.setNome("Nome");

        assertNotEquals(itemVistoriaEntity, itemVistoriaEntity2);
    }

    @Test
    void testEquals4() {
        ItemVistoriaEntity itemVistoriaEntity = new ItemVistoriaEntity();
        itemVistoriaEntity.setAtivo(true);
        itemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity.setDescricao("Descricao");
        itemVistoriaEntity.setId(null);
        itemVistoriaEntity.setNome("Nome");

        ItemVistoriaEntity itemVistoriaEntity2 = new ItemVistoriaEntity();
        itemVistoriaEntity2.setAtivo(true);
        itemVistoriaEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity2.setDescricao("Descricao");
        itemVistoriaEntity2.setId(1L);
        itemVistoriaEntity2.setNome("Nome");

        assertNotEquals(itemVistoriaEntity, itemVistoriaEntity2);
    }

    @Test
    void testEqualsAndHashCode() {
        ItemVistoriaEntity itemVistoriaEntity = new ItemVistoriaEntity();
        itemVistoriaEntity.setAtivo(true);
        itemVistoriaEntity.setDataInclusao(LocalDate.of