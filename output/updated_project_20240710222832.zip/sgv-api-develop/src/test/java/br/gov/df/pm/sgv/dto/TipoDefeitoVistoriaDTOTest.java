package br.gov.df.pm.sgv.dto;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

public class TipoDefeitoVistoriaDTOTest {
    private TipoDefeitoVistoriaDTO tipoDefeitoVistoria = new TipoDefeitoVistoriaDTO(null, "", "", null, null);
    private LocalDate diaAtual = LocalDate.now();


    @BeforeEach
    void setUp() {
        tipoDefeitoVistoria.setId(1L);
        tipoDefeitoVistoria.setNome("Vidro");
        tipoDefeitoVistoria.setDescricao("Vidro do Carro");
        tipoDefeitoVistoria.setDataInclusao(diaAtual);
        tipoDefeitoVistoria.setAtivo(true);
    }

    @Test
    void testEquals() {
        var tipoDefeitoVistoria1 = TipoDefeitoVistoriaDTO.builder()
                .id(1L)
                .nome("Vidro")
                .descricao("Vidro do Carro")
                .dataInclusao(diaAtual)
                .ativo(true)
                .build();
        assertEquals(tipoDefeitoVistoria, tipoDefeitoVistoria1);

        var tipoDefeitoVistoria2 = TipoDefeitoVistoriaDTO.builder().nome("Janela").build();
        assertNotEquals(tipoDefeitoVistoria, tipoDefeitoVistoria2);


    }

    @Test
    void testHashCode() {
        var tipoDefeitoVistoria1 = TipoDefeitoVistoriaDTO.builder()
                .id(1L)
                .nome("Vidro")
                .descricao("Vidro do Carro")
                .dataInclusao(diaAtual)
                .ativo(true)
                .build();
        assertEquals(tipoDefeitoVistoria.hashCode(), tipoDefeitoVistoria1.hashCode());

        var tipoDefeitoVistoria2 = TipoDefeitoVistoriaDTO.builder().build();
        assertNotEquals(tipoDefeitoVistoria.hashCode(), tipoDefeitoVistoria2.hashCode());
    }

    @Test
    void testToString() {
        assertNotNull(tipoDefeitoVistoria.toString());
    }
}
