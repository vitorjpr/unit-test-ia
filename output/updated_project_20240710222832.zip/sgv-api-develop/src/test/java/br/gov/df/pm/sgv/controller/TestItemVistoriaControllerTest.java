```java
import br.gov.df.pm.sgv.controller.ItemVistoriaController;
import br.gov.df.pm.sgv.domain.ItemVistoriaEntity;
import br.gov.df.pm.sgv.dto.EdicaoItemVistoriaDTO;
import br.gov.df.pm.sgv.dto.ItemVistoriaDTO;
import br.gov.df.pm.sgv.dto.SubitemVistoriaDTO;
import br.gov.df.pm.sgv.exceptions.VistoriaExceptions;
import br.gov.df.pm.sgv.repository.ItemVistoriaRepository;
import br.gov.df.pm.sgv.repository.ItensVistoriaRepository;
import br.gov.df.pm.sgv.repository.SubitemVistoriaRepository;
import br.gov.df.pm.sgv.repository.SubitensVistoriaRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.PagedModel;
import org.springframework.http.ResponseEntity;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class ItemVistoriaControllerTest {

    @MockBean
    ItemVistoriaRepository repository;
    @MockBean
    SubitemVistoriaRepository subitemRepository;
    @Autowired
    ItemVistoriaController controller;
    @MockBean
    SubitensVistoriaRepository subitensRepository;
    @MockBean
    ItensVistoriaRepository itensRepository;

    ItemVistoriaEntity itemMock;
    ItemVistoriaDTO itemMockDto;
    EdicaoItemVistoriaDTO edicaoItemVistoriaMockDto;
    SubitemVistoriaEntity subitemMock;
    SubitensVistoriaEntity subitensVistoriaEntity;

    @BeforeEach
    void setUp() {
        subitemMock = SubitemVistoriaEntity.builder()
                .id(1L)
                .nome("Vidro")
                .descricao("Vidro da Viatura")
                .ativo(true)
                .dataInclusao(LocalDate.now())
                .build();

        itemMock = ItemVistoriaEntity.builder()
                .id(1L)
                .nome("Vidro")
                .descricao("Vidro da Viatura")
                .ativo(true)
                .dataInclusao(LocalDate.now())
                .build();

        itemMockDto = ItemVistoriaDTO.builder()
                .nome("Vidro")
                .descricao("Vidro da Viatura")
                .ativo(true)
                .dataInclusao(LocalDate.now())
                .subitens(List.of(subitemMock))
                .build();

        edicaoItemVistoriaMockDto = EdicaoItemVistoriaDTO.builder()
                .nome("Vidro")
                .descricao("Vidro da Vistoria")
                .build();

        subitensVistoriaEntity = SubitensVistoriaEntity.builder()
                .id(1L)
                .codItem(new ItemVistoriaEntity())
                .codSubitem(new SubitemVistoriaEntity())
                .dataInclusao(LocalDate.now())
                .ativo(true)
                .build();

        Specification<ItemVistoriaEntity> spec = any();
        Pageable pageable = any();
        when(repository.findAll(spec, pageable)).thenAnswer(invocation -> {
            Specification<ItemVistoriaDTO> s = invocation.getArgument(0);
            CriteriaQuery<ItemVistoriaDTO> query = mock(CriteriaQuery.class);
            when(query.getResultType()).thenReturn(ItemVistoriaDTO.class);
            return new PageImpl<>(List.of(itemMock));
        });
    }

    @Test
    void buscarId() {
        when(repository.findById(1L)).thenReturn(Optional.of(itemMock));
        ResponseEntity<?> response = controller.buscarId(1L);
        assertNotNull(response);
    }

    @Test
    void buscar() {
        var pageable = PageRequest.of(0, 1);
        when(subitemRepository.findByNome("Vidro")).thenReturn(Optional.of(subitemMock));
        when(subitensRepository.findAllByCodSubitem(new SubitemVistoriaEntity())).thenReturn(List.of(subitensVistoriaEntity));
        PagedModel<EntityModel<ItemVistoriaDTO>> response = controller.buscar("Vidro", pageable);
        assertNotNull(response);
   