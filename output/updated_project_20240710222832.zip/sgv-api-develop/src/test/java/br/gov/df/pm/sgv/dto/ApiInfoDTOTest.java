package br.gov.df.pm.sgv.dto;

import br.gov.df.pm.sgv.domain.sgpol.Policial;
import br.gov.df.pm.sgv.dto.root.ApiInfoDTO;
import br.gov.df.pm.sgv.dto.root.PerfilDTO;
import nl.jqno.equalsverifier.EqualsVerifier;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

class ApiInfoDTOTest {

    @BeforeEach
    void setUp() {
        Policial policial = new Policial();
        PerfilDTO dto1 = new PerfilDTO("");
        dto1.setNome("nome");
        EqualsVerifier.simple().forClass(ApiInfoDTO.class).verify();
        ApiInfoDTO apiInfoDTO = new ApiInfoDTO("policial", policial, List.of(dto1));
        apiInfoDTO.toString();
        apiInfoDTO.getPolicial();
        apiInfoDTO.getPerfis();

    }

    @Test
    void testEquals() {
    }
}