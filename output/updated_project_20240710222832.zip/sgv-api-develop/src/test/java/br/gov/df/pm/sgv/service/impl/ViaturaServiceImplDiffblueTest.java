package br.gov.df.pm.sgv.service.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isA;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.Mockito.anyInt;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import br.gov.df.pm.sgv.domain.ChecklistVistoriaEntity;
import br.gov.df.pm.sgv.domain.DiferencaOdometroEntity;
import br.gov.df.pm.sgv.domain.TipoEmpregoViaturaEntity;
import br.gov.df.pm.sgv.domain.TipoVistoriaEntity;
import br.gov.df.pm.sgv.domain.ViaturaEntity;
import br.gov.df.pm.sgv.domain.VistoriaArquivo;
import br.gov.df.pm.sgv.domain.VistoriaViaturaEntity;
import br.gov.df.pm.sgv.domain.VistoriaViaturaHistoricoEntity;
import br.gov.df.pm.sgv.domain.enums.VistoriaViaturaStatusEnum;
import br.gov.df.pm.sgv.domain.sgpol.UnidadePolicialMilitar;
import br.gov.df.pm.sgv.dto.TipoEmpregoViaturaDto;
import br.gov.df.pm.sgv.dto.VistoriaViaturaDTO;
import br.gov.df.pm.sgv.exceptions.ViaturaException;
import br.gov.df.pm.sgv.repository.TipoEmpregoViaturaRepository;
import br.gov.df.pm.sgv.repository.app.ViaturaRepository;
import br.gov.df.pm.sgv.repository.app.VistoriaViaturaRepository;
import br.gov.df.pm.sgv.repository.sgpol.UnidadePolicialMilitarRepository;

import java.time.LocalDate;
import java.time.LocalDateTime;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ContextConfiguration(classes = {ViaturaServiceImpl.class})
@ExtendWith(SpringExtension.class)
class ViaturaServiceImplDiffblueTest {
    @MockBean
    private TipoEmpregoViaturaRepository tipoEmpregoViaturaRepository;

    @MockBean
    private UnidadePolicialMilitarRepository unidadePolicialMilitarRepository;

    @MockBean
    private ViaturaRepository viaturaRepository;

    @Autowired
    private ViaturaServiceImpl viaturaServiceImpl;

    @MockBean
    private VistoriaViaturaRepository vistoriaViaturaRepository;

    /**
     * Method under test:
     * {@link ViaturaServiceImpl#buscar(Integer, String, String, Pageable)}
     */
    @Test
    void testBuscar() {
        // Arrange
        PageImpl<ViaturaEntity> pageImpl = new PageImpl<>(new ArrayList<>());
        when(viaturaRepository.findAll(Mockito.<Specification<ViaturaEntity>>any(), Mockito.<Pageable>any()))
                .thenReturn(pageImpl);

        // Act
        Page<ViaturaEntity> actualBuscarResult = viaturaServiceImpl.buscar(1, "Prefixo", "Placa", null);

        // Assert
        verify(viaturaRepository).findAll(isA(Specification.class), (Pageable) isNull());
        assertTrue(actualBuscarResult.toList().isEmpty());
        assertSame(pageImpl, actualBuscarResult);
    }

    /**
     * Method under test:
     * {@link ViaturaServiceImpl#buscar(Integer, String, String, Pageable)}
     */
    @Test
    void testBuscar2() {
        // Arrange
        when(viaturaRepository.findAll(Mockito.<Specification<ViaturaEntity>>any(), Mockito.<Pageable>any()))
                .thenThrow(new ViaturaException("An error occurred"));

        // Act and Assert
        assertThrows(ViaturaException.class, () -> viaturaServiceImpl.buscar(1, "Prefixo", "Placa", null));
        verify(viaturaRepository).findAll(isA(Specification.class), (Pageable) isNull());
    }

    /**
     * Method under test:
     * {@link ViaturaServiceImpl#buscarViatura(Integer, String, String, Integer, Pageable)}
     */
    @Test
    void testBuscarViatura() {
        // Arrange
        when(viaturaRepository.findAll(Mockito.<Specification<ViaturaEntity>>any(), Mockito.<Pageable>any()))
                .thenReturn(new PageImpl<>(new ArrayList<>()));

        // Act and Assert
        assertThrows(ViaturaException.class, () -> viaturaServiceImpl.buscarViatura(1, "Prefixo", "Placa", 1, null));
        verify(viaturaRepository).findAll(isA(Specification.class), (Pageable) isNull());
    }

    /**
     * Method under test:
     * {@link ViaturaServiceImpl#buscarViatura(Integer, String, String, Integer, Pageable)}
     */
    @Test
    void testBuscarViatura2() {
        // Arrange
        when(viaturaRepository.findAll(Mockito.<Specification<ViaturaEntity>>any(), Mockito.<Pageable>any()))
                .thenReturn(null);

        // Act and Assert
        assertThrows(ViaturaException.class, () -> viaturaServiceImpl.buscarViatura(1, "Prefixo", "Placa", 1, null));
        verify(viaturaRepository).findAll(isA(Specification.class), (Pageable) isNull());
    }

    /**
     * Method under test:
     * {@link ViaturaServiceImpl#buscarViatura(Integer, String, String, Integer, Pageable)}
     */
    @Test
    void testBuscarViatura3() {
        // Arrange
        when(viaturaRepository.findAll(Mockito.<Specification<ViaturaEntity>>any(), Mockito.<Pageable>any()))
                .thenThrow(new ViaturaException("An error occurred"));

        // Act and Assert
        assertThrows(ViaturaException.class, () -> viaturaServiceImpl.buscarViatura(1, "Prefixo", "Placa", 1, null));
        verify(viaturaRepository).findAll(isA(Specification.class), (Pageable) isNull());
    }

    /**
     * Method under test: {@link ViaturaServiceImpl#findPaginado(Pageable)}
     */
    @Test
    void testFindPaginado() {
        // Arrange
        PageImpl<ViaturaEntity> pageImpl = new PageImpl<>(new ArrayList<>());
        when(viaturaRepository.findAll(Mockito.<Pageable>any())).thenReturn(pageImpl);

        // Act
        Page<ViaturaEntity> actualFindPaginadoResult = viaturaServiceImpl.findPaginado(null);

        // Assert
        verify(viaturaRepository).findAll((Pageable) isNull());
        assertTrue(actualFindPaginadoResult.toList().isEmpty());
        assertSame(pageImpl, actualFindPaginadoResult);
    }

    /**
     * Method under test: {@link ViaturaServiceImpl#findPaginado(Pageable)}
     */
    @Test
    void testFindPaginado2() {
        // Arrange
        when(viaturaRepository.findAll(Mockito.<Pageable>any())).thenThrow(new ViaturaException("An error occurred"));

        // Act and Assert
        assertThrows(ViaturaException.class, () -> viaturaServiceImpl.findPaginado(null));
        verify(viaturaRepository).findAll((Pageable) isNull());
    }

    /**
     * Method under test:
     * {@link ViaturaServiceImpl#getUltimoOdometroByViatura(Long)}
     */
    @Test
    void testGetUltimoOdometroByViatura() {
        // Arrange
        when(vistoriaViaturaRepository.findAllByViaturaId(Mockito.<Long>any())).thenReturn(new ArrayList<>());

        // Act
        Double actualUltimoOdometroByViatura = viaturaServiceImpl.getUltimoOdometroByViatura(1L);

        // Assert
        verify(vistoriaViaturaRepository).findAllByViaturaId(eq(1L));
        assertEquals(0.0d, actualUltimoOdometroByViatura.doubleValue());
    }

    /**
     * Method under test:
     * {@link ViaturaServiceImpl#getUltimoOdometroByViatura(Long)}
     */
    @Test
    void testGetUltimoOdometroByViatura2() {
        // Arrange
        TipoVistoriaEntity referenciaFinal = new TipoVistoriaEntity();
        referenciaFinal.setAtivo(true);
        referenciaFinal.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaFinal.setDescricao("Descricao");
        referenciaFinal.setId(1L);
        referenciaFinal.setNome("Nome");
        referenciaFinal.setStatusAnterior("Status Anterior");
        referenciaFinal.setStatusPosterior("Status Posterior");

        TipoVistoriaEntity referenciaInicial = new TipoVistoriaEntity();
        referenciaInicial.setAtivo(true);
        referenciaInicial.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaInicial.setDescricao("Descricao");
        referenciaInicial.setId(1L);
        referenciaInicial.setNome("Nome");
        referenciaInicial.setStatusAnterior("Status Anterior");
        referenciaInicial.setStatusPosterior("Status Posterior");

        DiferencaOdometroEntity diferencaOdometro = new DiferencaOdometroEntity();
        diferencaOdometro.setDataInclusao(LocalDate.of(1970, 1, 1));
        diferencaOdometro.setDataModificacao(LocalDate.of(1970, 1, 1));
        diferencaOdometro.setDiferencaOdometro(10.0d);
        diferencaOdometro.setId(1L);
        diferencaOdometro.setReferenciaFinal(referenciaFinal);
        diferencaOdometro.setReferenciaInicial(referenciaInicial);

        TipoVistoriaEntity tipoVistoria = new TipoVistoriaEntity();
        tipoVistoria.setAtivo(true);
        tipoVistoria.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoria.setDescricao("Descricao");
        tipoVistoria.setId(1L);
        tipoVistoria.setNome("Nome");
        tipoVistoria.setStatusAnterior("Status Anterior");
        tipoVistoria.setStatusPosterior("Status Posterior");

        TipoEmpregoViaturaEntity tipoEmpregoViatura = new TipoEmpregoViaturaEntity();
        tipoEmpregoViatura.setAtivo(1);
        tipoEmpregoViatura.setId(1);
        tipoEmpregoViatura.setNome("Nome");

        ViaturaEntity viatura = new ViaturaEntity();
        viatura.setAtivo(true);
        viatura.setDataAtualizacao(LocalDate.of(1970, 1, 1));
        viatura.setDataInclusao(LocalDate.of(1970, 1, 1));
        viatura.setId(1L);
        viatura.setListaUpm(new ArrayList<>());
        viatura.setMarcaModelo("Marca Modelo");
        viatura.setNrSei("Nr Sei");
        viatura.setPlaca("Placa");
        viatura.setPrefixo("Prefixo");
        viatura.setRenavam("Renavam");
        viatura.setStatus("Status");
        viatura.setTipoEmpregoViatura(tipoEmpregoViatura);
        viatura.setTombamento("alice.liddell@example.org");

        VistoriaViaturaEntity vistoriaViaturaEntity = new VistoriaViaturaEntity();
        vistoriaViaturaEntity.setCheckLists(new ArrayList<>());
        vistoriaViaturaEntity.setDataVistoria(LocalDate.of(1970, 1, 1).atStartOfDay());
        vistoriaViaturaEntity.setDiferencaOdometro(diferencaOdometro);
        vistoriaViaturaEntity.setDiferencaVistoria(true);
        vistoriaViaturaEntity.setId(1L);
        vistoriaViaturaEntity.setIdPolicial(1);
        vistoriaViaturaEntity.setIdUpm(1);
        vistoriaViaturaEntity.setOdometroFinal(10.0f);
        vistoriaViaturaEntity.setOdometroInicial(10.0f);
        vistoriaViaturaEntity.setStatus(VistoriaViaturaStatusEnum.DISPONIVEL);
        vistoriaViaturaEntity.setTipoVistoria(tipoVistoria);
        vistoriaViaturaEntity.setViatura(viatura);
        vistoriaViaturaEntity.setVistoriaArquivoList(new ArrayList<>());
        vistoriaViaturaEntity.setVistoriaViaturaHistorico(new ArrayList<>());

        ArrayList<VistoriaViaturaEntity> vistoriaViaturaEntityList = new ArrayList<>();
        vistoriaViaturaEntityList.add(vistoriaViaturaEntity);
        when(vistoriaViaturaRepository.findAllByViaturaId(Mockito.<Long>any())).thenReturn(vistoriaViaturaEntityList);

        // Act
        Double actualUltimoOdometroByViatura = viaturaServiceImpl.getUltimoOdometroByViatura(1L);

        // Assert
        verify(vistoriaViaturaRepository).findAllByViaturaId(eq(1L));
        assertEquals(10.0d, actualUltimoOdometroByViatura.doubleValue());
    }

    /**
     * Method under test:
     * {@link ViaturaServiceImpl#getUltimoOdometroByViatura(Long)}
     */
    @Test
    void testGetUltimoOdometroByViatura3() {
        // Arrange
        when(vistoriaViaturaRepository.findAllByViaturaId(Mockito.<Long>any()))
                .thenThrow(new ViaturaException("An error occurred"));

        // Act and Assert
        assertThrows(ViaturaException.class, () -> viaturaServiceImpl.getUltimoOdometroByViatura(1L));
        verify(vistoriaViaturaRepository).findAllByViaturaId(eq(1L));
    }

    /**
     * Method under test:
     * {@link ViaturaServiceImpl#getUltimoOdometroByViatura(Long)}
     */
    @Test
    void testGetUltimoOdometroByViatura4() {
        // Arrange
        TipoVistoriaEntity referenciaFinal = new TipoVistoriaEntity();
        referenciaFinal.setAtivo(true);
        referenciaFinal.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaFinal.setDescricao("Descricao");
        referenciaFinal.setId(1L);
        referenciaFinal.setNome("Nome");
        referenciaFinal.setStatusAnterior("Status Anterior");
        referenciaFinal.setStatusPosterior("Status Posterior");

        TipoVistoriaEntity referenciaInicial = new TipoVistoriaEntity();
        referenciaInicial.setAtivo(true);
        referenciaInicial.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaInicial.setDescricao("Descricao");
        referenciaInicial.setId(1L);
        referenciaInicial.setNome("Nome");
        referenciaInicial.setStatusAnterior("Status Anterior");
        referenciaInicial.setStatusPosterior("Status Posterior");

        DiferencaOdometroEntity diferencaOdometro = new DiferencaOdometroEntity();
        diferencaOdometro.setDataInclusao(LocalDate.of(1970, 1, 1));
        diferencaOdometro.setDataModificacao(LocalDate.of(1970, 1, 1));
        diferencaOdometro.setDiferencaOdometro(10.0d);
        diferencaOdometro.setId(1L);
        diferencaOdometro.setReferenciaFinal(referenciaFinal);
        diferencaOdometro.setReferenciaInicial(referenciaInicial);

        TipoVistoriaEntity tipoVistoria = new TipoVistoriaEntity();
        tipoVistoria.setAtivo(true);
        tipoVistoria.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoria.setDescricao("Descricao");
        tipoVistoria.setId(1L);
        tipoVistoria.setNome("Nome");
        tipoVistoria.setStatusAnterior("Status Anterior");
        tipoVistoria.setStatusPosterior("Status Posterior");

        TipoEmpregoViaturaEntity tipoEmpregoViatura = new TipoEmpregoViaturaEntity();
        tipoEmpregoViatura.setAtivo(1);
        tipoEmpregoViatura.setId(1);
        tipoEmpregoViatura.setNome("Nome");

        ViaturaEntity viatura = new ViaturaEntity();
        viatura.setAtivo(true);
        viatura.setDataAtualizacao(LocalDate.of(1970, 1, 1));
        viatura.setDataInclusao(LocalDate.of(1970, 1, 1));
        viatura.setId(1L);
        viatura.setListaUpm(new ArrayList<>());
        viatura.setMarcaModelo("Marca Modelo");
        viatura.setNrSei("Nr Sei");
        viatura.setPlaca("Placa");
        viatura.setPrefixo("Prefixo");
        viatura.setRenavam("Renavam");
        viatura.setStatus("Status");
        viatura.setTipoEmpregoViatura(tipoEmpregoViatura);
        viatura.setTombamento("alice.liddell@example.org");

        TipoVistoriaEntity referenciaFinal2 = new TipoVistoriaEntity();
        referenciaFinal2.setAtivo(true);
        referenciaFinal2.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaFinal2.setDescricao("Descricao");
        referenciaFinal2.setId(1L);
        referenciaFinal2.setNome("Nome");
        referenciaFinal2.setStatusAnterior("Status Anterior");
        referenciaFinal2.setStatusPosterior("Status Posterior");

        TipoVistoriaEntity referenciaInicial2 = new TipoVistoriaEntity();
        referenciaInicial2.setAtivo(true);
        referenciaInicial2.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaInicial2.setDescricao("Descricao");
        referenciaInicial2.setId(1L);
        referenciaInicial2.setNome("Nome");
        referenciaInicial2.setStatusAnterior("Status Anterior");
        referenciaInicial2.setStatusPosterior("Status Posterior");

        DiferencaOdometroEntity diferencaOdometroEntity = new DiferencaOdometroEntity();
        diferencaOdometroEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        diferencaOdometroEntity.setDataModificacao(LocalDate.of(1970, 1, 1));
        diferencaOdometroEntity.setDiferencaOdometro(10.0d);
        diferencaOdometroEntity.setId(1L);
        diferencaOdometroEntity.setReferenciaFinal(referenciaFinal2);
        diferencaOdometroEntity.setReferenciaInicial(referenciaInicial2);
        VistoriaViaturaEntity vistoriaViaturaEntity = mock(VistoriaViaturaEntity.class);
        when(vistoriaViaturaEntity.getDiferencaOdometro()).thenReturn(diferencaOdometroEntity);
        doNothing().when(vistoriaViaturaEntity).setCheckLists(Mockito.<List<ChecklistVistoriaEntity>>any());
        doNothing().when(vistoriaViaturaEntity).setDataVistoria(Mockito.<LocalDateTime>any());
        doNothing().when(vistoriaViaturaEntity).setDiferencaOdometro(Mockito.<DiferencaOdometroEntity>any());
        doNothing().when(vistoriaViaturaEntity).setDiferencaVistoria(Mockito.<Boolean>any());
        doNothing().when(vistoriaViaturaEntity).setId(Mockito.<Long>any());
        doNothing().when(vistoriaViaturaEntity).setIdPolicial(Mockito.<Integer>any());
        doNothing().when(vistoriaViaturaEntity).setIdUpm(Mockito.<Integer>any());
        doNothing().when(vistoriaViaturaEntity).setOdometroFinal(Mockito.<Float>any());
        doNothing().when(vistoriaViaturaEntity).setOdometroInicial(Mockito.<Float>any());
        doNothing().when(vistoriaViaturaEntity).setStatus(Mockito.<VistoriaViaturaStatusEnum>any());
        doNothing().when(vistoriaViaturaEntity).setTipoVistoria(Mockito.<TipoVistoriaEntity>any());
        doNothing().when(vistoriaViaturaEntity).setViatura(Mockito.<ViaturaEntity>any());
        doNothing().when(vistoriaViaturaEntity).setVistoriaArquivoList(Mockito.<List<VistoriaArquivo>>any());
        doNothing().when(vistoriaViaturaEntity)
                .setVistoriaViaturaHistorico(Mockito.<List<VistoriaViaturaHistoricoEntity>>any());
        vistoriaViaturaEntity.setCheckLists(new ArrayList<>());
        vistoriaViaturaEntity.setDataVistoria(LocalDate.of(1970, 1, 1).atStartOfDay());
        vistoriaViaturaEntity.setDiferencaOdometro(diferencaOdometro);
        vistoriaViaturaEntity.setDiferencaVistoria(true);
        vistoriaViaturaEntity.setId(1L);
        vistoriaViaturaEntity.setIdPolicial(1);
        vistoriaViaturaEntity.setIdUpm(1);
        vistoriaViaturaEntity.setOdometroFinal(10.0f);
        vistoriaViaturaEntity.setOdometroInicial(10.0f);
        vistoriaViaturaEntity.setStatus(VistoriaViaturaStatusEnum.DISPONIVEL);
        vistoriaViaturaEntity.setTipoVistoria(tipoVistoria);
        vistoriaViaturaEntity.setViatura(viatura);
        vistoriaViaturaEntity.setVistoriaArquivoList(new ArrayList<>());
        vistoriaViaturaEntity.setVistoriaViaturaHistorico(new ArrayList<>());

        TipoVistoriaEntity referenciaFinal3 = new TipoVistoriaEntity();
        referenciaFinal3.setAtivo(true);
        referenciaFinal3.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaFinal3.setDescricao("42");
        referenciaFinal3.setId(3L);
        referenciaFinal3.setNome("42");
        referenciaFinal3.setStatusAnterior("42");
        referenciaFinal3.setStatusPosterior("42");

        TipoVistoriaEntity referenciaInicial3 = new TipoVistoriaEntity();
        referenciaInicial3.setAtivo(true);
        referenciaInicial3.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaInicial3.setDescricao("42");
        referenciaInicial3.setId(3L);
        referenciaInicial3.setNome("42");
        referenciaInicial3.setStatusAnterior("42");
        referenciaInicial3.setStatusPosterior("42");

        DiferencaOdometroEntity diferencaOdometro2 = new DiferencaOdometroEntity();
        diferencaOdometro2.setDataInclusao(LocalDate.of(1970, 1, 1));
        diferencaOdometro2.setDataModificacao(LocalDate.of(1970, 1, 1));
        diferencaOdometro2.setDiferencaOdometro(-0.5d);
        diferencaOdometro2.setId(3L);
        diferencaOdometro2.setReferenciaFinal(referenciaFinal3);
        diferencaOdometro2.setReferenciaInicial(referenciaInicial3);

        TipoVistoriaEntity tipoVistoria2 = new TipoVistoriaEntity();
        tipoVistoria2.setAtivo(true);
        tipoVistoria2.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoria2.setDescricao("42");
        tipoVistoria2.setId(3L);
        tipoVistoria2.setNome("42");
        tipoVistoria2.setStatusAnterior("42");
        tipoVistoria2.setStatusPosterior("42");

        TipoEmpregoViaturaEntity tipoEmpregoViatura2 = new TipoEmpregoViaturaEntity();
        tipoEmpregoViatura2.setAtivo(Integer.MIN_VALUE);
        tipoEmpregoViatura2.setId(3);
        tipoEmpregoViatura2.setNome("42");

        ViaturaEntity viatura2 = new ViaturaEntity();
        viatura2.setAtivo(true);
        viatura2.setDataAtualizacao(LocalDate.of(1970, 1, 1));
        viatura2.setDataInclusao(LocalDate.of(1970, 1, 1));
        viatura2.setId(3L);
        viatura2.setListaUpm(new ArrayList<>());
        viatura2.setMarcaModelo("42");
        viatura2.setNrSei("42");
        viatura2.setPlaca("42");
        viatura2.setPrefixo("42");
        viatura2.setRenavam("42");
        viatura2.setStatus("42");
        viatura2.setTipoEmpregoViatura(tipoEmpregoViatura2);
        viatura2.setTombamento("br.gov.df.pm.sgv.domain.ViaturaEntity");

        VistoriaViaturaEntity vistoriaViaturaEntity2 = new VistoriaViaturaEntity();
        vistoriaViaturaEntity2.setCheckLists(new ArrayList<>());
        vistoriaViaturaEntity2.setDataVistoria(LocalDate.of(1970, 1, 1).atStartOfDay());
        vistoriaViaturaEntity2.setDiferencaOdometro(diferencaOdometro2);
        vistoriaViaturaEntity2.setDiferencaVistoria(true);
        vistoriaViaturaEntity2.setId(3L);
        vistoriaViaturaEntity2.setIdPolicial(3);
        vistoriaViaturaEntity2.setIdUpm(3);
        vistoriaViaturaEntity2.setOdometroFinal(-0.5f);
        vistoriaViaturaEntity2.setOdometroInicial(-0.5f);
        vistoriaViaturaEntity2.setStatus(VistoriaViaturaStatusEnum.EM_USO);
        vistoriaViaturaEntity2.setTipoVistoria(tipoVistoria2);
        vistoriaViaturaEntity2.setViatura(viatura2);
        vistoriaViaturaEntity2.setVistoriaArquivoList(new ArrayList<>());
        vistoriaViaturaEntity2.setVistoriaViaturaHistorico(new ArrayList<>());

        ArrayList<VistoriaViaturaEntity> vistoriaViaturaEntityList = new ArrayList<>();
        vistoriaViaturaEntityList.add(vistoriaViaturaEntity2);
        vistoriaViaturaEntityList.add(vistoriaViaturaEntity);
        when(vistoriaViaturaRepository.findAllByViaturaId(Mockito.<Long>any())).thenReturn(vistoriaViaturaEntityList);

        // Act
        Double actualUltimoOdometroByViatura = viaturaServiceImpl.getUltimoOdometroByViatura(1L);

        // Assert
        verify(vistoriaViaturaEntity, atLeast(1)).getDiferencaOdometro();
        verify(vistoriaViaturaEntity).setCheckLists(isA(List.class));
        verify(vistoriaViaturaEntity).setDataVistoria(isA(LocalDateTime.class));
        verify(vistoriaViaturaEntity).setDiferencaOdometro(isA(DiferencaOdometroEntity.class));
        verify(vistoriaViaturaEntity).setDiferencaVistoria(eq(true));
        verify(vistoriaViaturaEntity).setId(eq(1L));
        verify(vistoriaViaturaEntity).setIdPolicial(eq(1));
        verify(vistoriaViaturaEntity).setIdUpm(eq(1));
        verify(vistoriaViaturaEntity).setOdometroFinal(eq(10.0f));
        verify(vistoriaViaturaEntity).setOdometroInicial(eq(10.0f));
        verify(vistoriaViaturaEntity).setStatus(eq(VistoriaViaturaStatusEnum.DISPONIVEL));
        verify(vistoriaViaturaEntity).setTipoVistoria(isA(TipoVistoriaEntity.class));
        verify(vistoriaViaturaEntity).setViatura(isA(ViaturaEntity.class));
        verify(vistoriaViaturaEntity).setVistoriaArquivoList(isA(List.class));
        verify(vistoriaViaturaEntity).setVistoriaViaturaHistorico(isA(List.class));
        verify(vistoriaViaturaRepository).findAllByViaturaId(eq(1L));
        assertEquals(10.0d, actualUltimoOdometroByViatura.doubleValue());
    }

    /**
     * Method under test:
     * {@link ViaturaServiceImpl#getVistoriaViaturaByViatura(Long)}
     */
    @Test
    void testGetVistoriaViaturaByViatura() {
        // Arrange
        when(vistoriaViaturaRepository.findAllByViaturaId(Mockito.<Long>any())).thenReturn(new ArrayList<>());

        // Act
        List<VistoriaViaturaDTO> actualVistoriaViaturaByViatura = viaturaServiceImpl.getVistoriaViaturaByViatura(1L);

        // Assert
        verify(vistoriaViaturaRepository).findAllByViaturaId(eq(1L));
        assertTrue(actualVistoriaViaturaByViatura.isEmpty());
    }

    /**
     * Method under test:
     * {@link ViaturaServiceImpl#getVistoriaViaturaByViatura(Long)}
     */
    @Test
    void testGetVistoriaViaturaByViatura2() {
        // Arrange
        TipoVistoriaEntity referenciaFinal = new TipoVistoriaEntity();
        referenciaFinal.setAtivo(true);
        referenciaFinal.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaFinal.setDescricao("Descricao");
        referenciaFinal.setId(1L);
        referenciaFinal.setNome("Nome");
        referenciaFinal.setStatusAnterior("Status Anterior");
        referenciaFinal.setStatusPosterior("Status Posterior");

        TipoVistoriaEntity referenciaInicial = new TipoVistoriaEntity();
        referenciaInicial.setAtivo(true);
        referenciaInicial.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaInicial.setDescricao("Descricao");
        referenciaInicial.setId(1L);
        referenciaInicial.setNome("Nome");
        referenciaInicial.setStatusAnterior("Status Anterior");
        referenciaInicial.setStatusPosterior("Status Posterior");

        DiferencaOdometroEntity diferencaOdometro = new DiferencaOdometroEntity();
        diferencaOdometro.setDataInclusao(LocalDate.of(1970, 1, 1));
        diferencaOdometro.setDataModificacao(LocalDate.of(1970, 1, 1));
        diferencaOdometro.setDiferencaOdometro(10.0d);
        diferencaOdometro.setId(1L);
        diferencaOdometro.setReferenciaFinal(referenciaFinal);
        diferencaOdometro.setReferenciaInicial(referenciaInicial);

        TipoVistoriaEntity tipoVistoria = new TipoVistoriaEntity();
        tipoVistoria.setAtivo(true);
        tipoVistoria.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoria.setDescricao("Descricao");
        tipoVistoria.setId(1L);
        tipoVistoria.setNome("Nome");
        tipoVistoria.setStatusAnterior("Status Anterior");
        tipoVistoria.setStatusPosterior("Status Posterior");

        TipoEmpregoViaturaEntity tipoEmpregoViatura = new TipoEmpregoViaturaEntity();
        tipoEmpregoViatura.setAtivo(1);
        tipoEmpregoViatura.setId(1);
        tipoEmpregoViatura.setNome("Nome");

        ViaturaEntity viatura = new ViaturaEntity();
        viatura.setAtivo(true);
        viatura.setDataAtualizacao(LocalDate.of(1970, 1, 1));
        viatura.setDataInclusao(LocalDate.of(1970, 1, 1));
        viatura.setId(1L);
        viatura.setListaUpm(new ArrayList<>());
        viatura.setMarcaModelo("Marca Modelo");
        viatura.setNrSei("Nr Sei");
        viatura.setPlaca("Placa");
        viatura.setPrefixo("Prefixo");
        viatura.setRenavam("Renavam");
        viatura.setStatus("Status");
        viatura.setTipoEmpregoViatura(tipoEmpregoViatura);
        viatura.setTombamento("alice.liddell@example.org");

        VistoriaViaturaEntity vistoriaViaturaEntity = new VistoriaViaturaEntity();
        ArrayList<ChecklistVistoriaEntity> checkLists = new ArrayList<>();
        vistoriaViaturaEntity.setCheckLists(checkLists);
        vistoriaViaturaEntity.setDataVistoria(LocalDate.of(1970, 1, 1).atStartOfDay());
        vistoriaViaturaEntity.setDiferencaOdometro(diferencaOdometro);
        vistoriaViaturaEntity.setDiferencaVistoria(true);
        vistoriaViaturaEntity.setId(1L);
        vistoriaViaturaEntity.setIdPolicial(1);
        vistoriaViaturaEntity.setIdUpm(1);
        vistoriaViaturaEntity.setOdometroFinal(10.0f);
        vistoriaViaturaEntity.setOdometroInicial(10.0f);
        vistoriaViaturaEntity.setStatus(VistoriaViaturaStatusEnum.DISPONIVEL);
        vistoriaViaturaEntity.setTipoVistoria(tipoVistoria);
        vistoriaViaturaEntity.setViatura(viatura);
        vistoriaViaturaEntity.setVistoriaArquivoList(new ArrayList<>());
        vistoriaViaturaEntity.setVistoriaViaturaHistorico(new ArrayList<>());

        ArrayList<VistoriaViaturaEntity> vistoriaViaturaEntityList = new ArrayList<>();
        vistoriaViaturaEntityList.add(vistoriaViaturaEntity);
        when(vistoriaViaturaRepository.findAllByViaturaId(Mockito.<Long>any())).thenReturn(vistoriaViaturaEntityList);

        // Act
        List<VistoriaViaturaDTO> actualVistoriaViaturaByViatura = viaturaServiceImpl.getVistoriaViaturaByViatura(1L);

        // Assert
        verify(vistoriaViaturaRepository).findAllByViaturaId(eq(1L));
        assertEquals(1, actualVistoriaViaturaByViatura.size());
        VistoriaViaturaDTO getResult = actualVistoriaViaturaByViatura.get(0);
        assertEquals("1970-01-01", getResult.getDiferencaOdometro().getDataInclusao().toString());
        assertNull(getResult.getDataVistoria());
        assertEquals(VistoriaViaturaStatusEnum.DISPONIVEL, getResult.getStatus());
        assertEquals(referenciaFinal, getResult.getTipoVistoria());
        assertEquals(checkLists, getResult.getVistoriaViaturaHistorico());
    }

    /**
     * Method under test:
     * {@link ViaturaServiceImpl#getVistoriaViaturaByViatura(Long)}
     */
    @Test
    void testGetVistoriaViaturaByViatura3() {
        // Arrange
        when(vistoriaViaturaRepository.findAllByViaturaId(Mockito.<Long>any()))
                .thenThrow(new ViaturaException("An error occurred"));

        // Act and Assert
        assertThrows(ViaturaException.class, () -> viaturaServiceImpl.getVistoriaViaturaByViatura(1L));
        verify(vistoriaViaturaRepository).findAllByViaturaId(eq(1L));
    }

    /**
     * Method under test: {@link ViaturaServiceImpl#listarUpm()}
     */
    @Test
    void testListarUpm() {
        // Arrange
        when(unidadePolicialMilitarRepository.findAllByAtivoOrderBySigla(anyInt())).thenReturn(new ArrayList<>());

        // Act
        ResponseEntity<List<UnidadePolicialMilitar>> actualListarUpmResult = viaturaServiceImpl.listarUpm();

        // Assert
        verify(unidadePolicialMilitarRepository).findAllByAtivoOrderBySigla(eq(1));
        assertEquals(HttpStatus.OK, actualListarUpmResult.getStatusCode());
        assertTrue(actualListarUpmResult.hasBody());
        assertTrue(actualListarUpmResult.getHeaders().isEmpty());
    }

    /**
     * Method under test: {@link ViaturaServiceImpl#listarUpm()}
     */
    @Test
    void testListarUpm2() {
        // Arrange
        when(unidadePolicialMilitarRepository.findAllByAtivoOrderBySigla(anyInt()))
                .thenThrow(new ViaturaException("An error occurred"));

        // Act and Assert
        assertThrows(ViaturaException.class, () -> viaturaServiceImpl.listarUpm());
        verify(unidadePolicialMilitarRepository).findAllByAtivoOrderBySigla(eq(1));
    }

    /**
     * Method under test: {@link ViaturaServiceImpl#listar()}
     */
    @Test
    void testListar() {
        // Arrange
        ArrayList<TipoEmpregoViaturaEntity> tipoEmpregoViaturaEntityList = new ArrayList<>();
        when(tipoEmpregoViaturaRepository.findAll()).thenReturn(tipoEmpregoViaturaEntityList);

        // Act
        ResponseEntity<List<TipoEmpregoViaturaDto>> actualListarResult = viaturaServiceImpl.listar();

        // Assert
        verify(tipoEmpregoViaturaRepository).findAll();
        assertEquals(HttpStatus.OK, actualListarResult.getStatusCode());
        assertTrue(actualListarResult.getHeaders().isEmpty());
        assertEquals(tipoEmpregoViaturaEntityList, actualListarResult.getBody());
    }

    /**
     * Method under test: {@link ViaturaServiceImpl#listar()}
     */
    @Test
    void testListar2() {
        // Arrange
        TipoEmpregoViaturaEntity tipoEmpregoViaturaEntity = new TipoEmpregoViaturaEntity();
        tipoEmpregoViaturaEntity.setAtivo(1);
        tipoEmpregoViaturaEntity.setId(1);
        tipoEmpregoViaturaEntity.setNome("Nome");

        ArrayList<TipoEmpregoViaturaEntity> tipoEmpregoViaturaEntityList = new ArrayList<>();
        tipoEmpregoViaturaEntityList.add(tipoEmpregoViaturaEntity);
        when(tipoEmpregoViaturaRepository.findAll()).thenReturn(tipoEmpregoViaturaEntityList);

        // Act
        ResponseEntity<List<TipoEmpregoViaturaDto>> actualListarResult = viaturaServiceImpl.listar();

        // Assert
        verify(tipoEmpregoViaturaRepository).findAll();
        List<TipoEmpregoViaturaDto> body = actualListarResult.getBody();
        assertEquals(1, body.size());
        TipoEmpregoViaturaDto getResult = body.get(0);
        assertEquals("Nome", getResult.getNome());
        assertEquals(1, getResult.getAtivo().intValue());
        assertEquals(1, getResult.getId().intValue());
        assertEquals(HttpStatus.OK, actualListarResult.getStatusCode());
        assertTrue(actualListarResult.hasBody());
        assertTrue(actualListarResult.getHeaders().isEmpty());
    }

    /**
     * Method under test: {@link ViaturaServiceImpl#listar()}
     */
    @Test
    void testListar3() {
        // Arrange
        TipoEmpregoViaturaEntity tipoEmpregoViaturaEntity = new TipoEmpregoViaturaEntity();
        tipoEmpregoViaturaEntity.setAtivo(1);
        tipoEmpregoViaturaEntity.setId(1);
        tipoEmpregoViaturaEntity.setNome("Nome");

        TipoEmpregoViaturaEntity tipoEmpregoViaturaEntity2 = new TipoEmpregoViaturaEntity();
        tipoEmpregoViaturaEntity2.setAtivo(0);
        tipoEmpregoViaturaEntity2.setId(2);
        tipoEmpregoViaturaEntity2.setNome("br.gov.df.pm.sgv.domain.TipoEmpregoViaturaEntity");

        ArrayList<TipoEmpregoViaturaEntity> tipoEmpregoViaturaEntityList = new ArrayList<>();
        tipoEmpregoViaturaEntityList.add(tipoEmpregoViaturaEntity2);
        tipoEmpregoViaturaEntityList.add(tipoEmpregoViaturaEntity);
        when(tipoEmpregoViaturaRepository.findAll()).thenReturn(tipoEmpregoViaturaEntityList);

        // Act
        ResponseEntity<List<TipoEmpregoViaturaDto>> actualListarResult = viaturaServiceImpl.listar();

        // Assert
        verify(tipoEmpregoViaturaRepository).findAll();
        List<TipoEmpregoViaturaDto> body = actualListarResult.getBody();
        assertEquals(2, body.size());
        TipoEmpregoViaturaDto getResult = body.get(1);
        assertEquals("Nome", getResult.getNome());
        TipoEmpregoViaturaDto getResult2 = body.get(0);
        assertEquals("br.gov.df.pm.sgv.domain.TipoEmpregoViaturaEntity", getResult2.getNome());
        assertEquals(0, getResult2.getAtivo().intValue());
        assertEquals(1, getResult.getAtivo().intValue());
        assertEquals(1, getResult.getId().intValue());
        assertEquals(2, getResult2.getId().intValue());
        assertEquals(HttpStatus.OK, actualListarResult.getStatusCode());
        assertTrue(actualListarResult.hasBody());
        assertTrue(actualListarResult.getHeaders().isEmpty());
    }

    /**
     * Method under test: {@link ViaturaServiceImpl#listar()}
     */
    @Test
    void testListar4() {
        // Arrange
        when(tipoEmpregoViaturaRepository.findAll()).thenThrow(new ViaturaException("An error occurred"));

        // Act and Assert
        assertThrows(ViaturaException.class, () -> viaturaServiceImpl.listar());
        verify(tipoEmpregoViaturaRepository).findAll();
    }

    /**
     * Method under test: {@link ViaturaServiceImpl#listar()}
     */
    @Test
    void testListar5() {
        // Arrange
        TipoEmpregoViaturaEntity tipoEmpregoViaturaEntity = mock(TipoEmpregoViaturaEntity.class);
        when(tipoEmpregoViaturaEntity.getAtivo()).thenReturn(1);
        when(tipoEmpregoViaturaEntity.getId()).thenReturn(1);
        when(tipoEmpregoViaturaEntity.getNome()).thenReturn("Nome");
        doNothing().when(tipoEmpregoViaturaEntity).setAtivo(Mockito.<Integer>any());
        doNothing().when(tipoEmpregoViaturaEntity).setId(Mockito.<Integer>any());
        doNothing().when(tipoEmpregoViaturaEntity).setNome(Mockito.<String>any());
        tipoEmpregoViaturaEntity.setAtivo(1);
        tipoEmpregoViaturaEntity.setId(1);
        tipoEmpregoViaturaEntity.setNome("Nome");

        ArrayList<TipoEmpregoViaturaEntity> tipoEmpregoViaturaEntityList = new ArrayList<>();
        tipoEmpregoViaturaEntityList.add(tipoEmpregoViaturaEntity);
        when(tipoEmpregoViaturaRepository.findAll()).thenReturn(tipoEmpregoViaturaEntityList);

        // Act
        ResponseEntity<List<TipoEmpregoViaturaDto>> actualListarResult = viaturaServiceImpl.listar();

        // Assert
        verify(tipoEmpregoViaturaEntity).getAtivo();
        verify(tipoEmpregoViaturaEntity).getId();
        verify(tipoEmpregoViaturaEntity).getNome();
        verify(tipoEmpregoViaturaEntity).setAtivo(eq(1));
        verify(tipoEmpregoViaturaEntity).setId(eq(1));
        verify(tipoEmpregoViaturaEntity).setNome(eq("Nome"));
        verify(tipoEmpregoViaturaRepository).findAll();
        List<TipoEmpregoViaturaDto> body = actualListarResult.getBody();
        assertEquals(1, body.size());
        TipoEmpregoViaturaDto getResult = body.get(0);
        assertEquals("Nome", getResult.getNome());
        assertEquals(1, getResult.getAtivo().intValue());
        assertEquals(1, getResult.getId().intValue());
        assertEquals(HttpStatus.OK, actualListarResult.getStatusCode());
        assertTrue(actualListarResult.hasBody());
        assertTrue(actualListarResult.getHeaders().isEmpty());
    }

    /**
     * Method under test: {@link ViaturaServiceImpl#buscarViaturasAtivas(Pageable)}
     */
    @Test
    void testBuscarViaturasAtivas() {
        // Arrange
        when(viaturaRepository.findAll(Mockito.<Pageable>any())).thenReturn(new PageImpl<>(new ArrayList<>()));

        // Act and Assert
        assertThrows(ViaturaException.class, () -> viaturaServiceImpl.buscarViaturasAtivas(null));
        verify(viaturaRepository).findAll((Pageable) isNull());
    }

    /**
     * Method under test: {@link ViaturaServiceImpl#buscarViaturasAtivas(Pageable)}
     */
    @Test
    void testBuscarViaturasAtivas2() {
        // Arrange
        when(viaturaRepository.findAll(Mockito.<Pageable>any())).thenThrow(new ViaturaException("An error occurred"));

        // Act and Assert
        assertThrows(ViaturaException.class, () -> viaturaServiceImpl.buscarViaturasAtivas(null));
        verify(viaturaRepository).findAll((Pageable) isNull());
    }
}
