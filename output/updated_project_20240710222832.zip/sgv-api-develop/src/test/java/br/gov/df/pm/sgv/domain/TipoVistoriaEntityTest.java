package br.gov.df.pm.sgv.domain;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

public class TipoVistoriaEntityTest {
    private TipoVistoriaEntity tipoVistoria = new TipoVistoriaEntity(null, "", "", "", "",null, null);
    private LocalDate diaAtual = LocalDate.now();

    @BeforeEach
    void setUp() {
        tipoVistoria.setId(1L);
        tipoVistoria.setNome("Vidro");
        tipoVistoria.setDescricao("Vidro do Carro");
        tipoVistoria.setStatusAnterior("EM USO");
        tipoVistoria.setStatusPosterior("DISPONÍVEL");
        tipoVistoria.setDataInclusao(diaAtual);
        tipoVistoria.setAtivo(true);
    }

    @Test
    void testEquals() {
        var tipoVistoria1 = TipoVistoriaEntity.builder()
                .id(1L)
                .nome("Vidro")
                .descricao("Vidro do Carro")
                .statusAnterior("EM USO")
                .statusPosterior("DISPONIVEL")
                .dataInclusao(diaAtual)
                .ativo(true)
                .build();
        assertEquals(tipoVistoria, tipoVistoria1);

        var tipoVistoria2 = TipoVistoriaEntity.builder().nome("Janela").build();
        assertNotEquals(tipoVistoria, tipoVistoria2);
    }

    @Test
    void testHashCode() {
        var tipoVistoria1 = TipoVistoriaEntity.builder()
                .id(1L)
                .nome("Vidro")
                .descricao("Vidro do Carro")
                .statusAnterior("EM USO")
                .statusPosterior("DISPONIVEL")
                .dataInclusao(diaAtual)
                .ativo(true)
                .build();
        assertEquals(tipoVistoria.hashCode(), tipoVistoria1.hashCode());

        var tipoVistoria2 = TipoVistoriaEntity.builder().build();
        assertNotEquals(tipoVistoria.hashCode(), tipoVistoria2.hashCode());
    }

    @Test
    void testToString() {
        assertNotNull(tipoVistoria.toString());
    }

}
