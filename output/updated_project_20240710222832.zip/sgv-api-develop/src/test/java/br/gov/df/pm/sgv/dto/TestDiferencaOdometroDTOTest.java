```java
package br.gov.df.pm.sgv.dto;

import br.gov.df.pm.sgv.domain.TipoVistoriaEntity;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

class DiferencaOdometroDTOTest {

    private DiferencaOdometroDTO diferencaOdometroDTO;

    @BeforeEach
    void setUp() {
        diferencaOdometroDTO = new DiferencaOdometroDTO(
                new TipoVistoriaEntity(),
                new TipoVistoriaEntity(),
                1.0,
                LocalDate.MIN,
                LocalDate.MAX,
                true);
        diferencaOdometroDTO.setDataModificacao(LocalDate.now());
        diferencaOdometroDTO.setReferenciaInicial(100.0);
        diferencaOdometroDTO.setReferenciaFinal(200.0);
        diferencaOdometroDTO.setDiferencaOdometro(100.0);
        diferencaOdometroDTO.setDataInclusao(LocalDate.now());
        diferencaOdometroDTO.setDiferencaPermitido(50.0);
    }

    @Test
    void getReferenciaInicial() {
        assertEquals(100.0, diferencaOdometroDTO.getReferenciaInicial());
    }

    @Test
    void getReferenciaFinal() {
        assertEquals(200.0, diferencaOdometroDTO.getReferenciaFinal());
    }

    @Test
    void getDiferencaOdometro() {
        assertEquals(100.0, diferencaOdometroDTO.getDiferencaOdometro());
    }

    @Test
    void getDataInclusao() {
        assertNotNull(diferencaOdometroDTO.getDataInclusao());
    }

    @Test
    void getDataModificacao() {
        assertNotNull(diferencaOdometroDTO.getDataModificacao());
    }

    @Test
    void getDiferencaPermitido() {
        assertEquals(50.0, diferencaOdometroDTO.getDiferencaPermitido());
    }

    @Test
    void setReferenciaInicial() {
        diferencaOdometroDTO.setReferenciaInicial(150.0);
        assertEquals(150.0, diferencaOdometroDTO.getReferenciaInicial());
    }

    @Test
    void setReferenciaFinal() {
        diferencaOdometroDTO.setReferenciaFinal(250.0);
        assertEquals(250.0, diferencaOdometroDTO.getReferenciaFinal());
    }

    @Test
    void setDiferencaOdometro() {
        diferencaOdometroDTO.setDiferencaOdometro(120.0);
        assertEquals(120.0, diferencaOdometroDTO.getDiferencaOdometro());
    }

    @Test
    void setDataInclusao() {
        LocalDate dataInclusao = LocalDate.of(2022, 1, 1);
        diferencaOdometroDTO.setDataInclusao(dataInclusao);
        assertEquals(dataInclusao, diferencaOdometroDTO.getDataInclusao());
    }

    @Test
    void setDataModificacao() {
        LocalDate dataModificacao = LocalDate.of(2022, 2, 1);
        diferencaOdometroDTO.setDataModificacao(dataModificacao);
        assertEquals(dataModificacao, diferencaOdometroDTO.getDataModificacao());
    }

    @Test
    void setDiferencaPermitido() {
        diferencaOdometroDTO.setDiferencaPermitido(60.0);
        assertEquals(60.0, diferencaOdometroDTO.getDiferencaPermitido());
    }

    @Test
    void testEquals() {
        DiferencaOdometroDTO diferencaOdometroDTO2 = new DiferencaOdometroDTO(
                new TipoVistoriaEntity(),
                new TipoVistoriaEntity(),
                1.0,
                LocalDate.MIN,
                LocalDate.MAX,
                true);
        assertEquals(diferencaOdometroDTO, diferencaOdometroDTO2);
    }

    @Test
    void canEqual() {
        DiferencaOdometroDTO diferencaOdometroDTO2 = new DiferencaOdometroDTO(
                new TipoVistoriaEntity(),
                new TipoVistoriaEntity(),
                1.0,
                LocalDate.MIN,
                LocalDate.MAX,
                true);
        assertTrue(diferencaOdometroDTO.canEqual(diferencaOdometroDTO2));
    }

    @Test
    void testHashCode() {
        DiferencaOdometroDTO