```java
package br.gov.df.pm.sgv.dto;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class TipoEmpregoViaturaDtoTest {

    private TipoEmpregoViaturaDto tipoEmpregoViaturaDto;

    @BeforeEach
    void setUp() {
        tipoEmpregoViaturaDto = new TipoEmpregoViaturaDto(1, "nome", 1);
    }

    @Test
    void getId() {
        assertEquals(1, tipoEmpregoViaturaDto.getId());
    }

    @Test
    void getNome() {
        assertEquals("nome", tipoEmpregoViaturaDto.getNome());
    }

    @Test
    void getAtivo() {
        assertEquals(1, tipoEmpregoViaturaDto.getAtivo());
    }

    @Test
    void testEquals() {
        TipoEmpregoViaturaDto tipoEmpregoViaturaDto1 = new TipoEmpregoViaturaDto(1, "nome", 1);

        assertTrue(tipoEmpregoViaturaDto.equals(tipoEmpregoViaturaDto));
        assertTrue(tipoEmpregoViaturaDto.equals(tipoEmpregoViaturaDto1));
    }

    @Test
    void testHashCode() {
        TipoEmpregoViaturaDto tipoEmpregoViaturaDto1 = new TipoEmpregoViaturaDto(1, "nome", 1);

        assertEquals(tipoEmpregoViaturaDto.hashCode(), tipoEmpregoViaturaDto1.hashCode());
    }

    @Test
    void testToString() {
        assertNotNull(tipoEmpregoViaturaDto.toString());
    }

    @Test
    void builder() {
        TipoEmpregoViaturaDto tipoEmpregoViaturaDtoBuilder = TipoEmpregoViaturaDto.builder()
                .id(1)
                .nome("nome")
                .ativo(1)
                .build();

        assertNotNull(tipoEmpregoViaturaDtoBuilder);
        assertEquals(1, tipoEmpregoViaturaDtoBuilder.getId());
        assertEquals("nome", tipoEmpregoViaturaDtoBuilder.getNome());
        assertEquals(1, tipoEmpregoViaturaDtoBuilder.getAtivo());
    }
}
```