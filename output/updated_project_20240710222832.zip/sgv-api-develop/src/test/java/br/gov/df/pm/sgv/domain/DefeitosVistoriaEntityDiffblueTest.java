package br.gov.df.pm.sgv.domain;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;

import java.time.LocalDate;
import java.time.ZoneOffset;
import java.util.Date;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

class DefeitosVistoriaEntityDiffblueTest {
    /**
     * Method under test: {@link DefeitosVistoriaEntity#canEqual(Object)}
     */
    @Test
    void testCanEqual() {
        // Arrange, Act and Assert
        assertFalse((new DefeitosVistoriaEntity()).canEqual("Other"));
    }

    /**
     * Method under test: {@link DefeitosVistoriaEntity#canEqual(Object)}
     */
    @Test
    void testCanEqual2() {
        // Arrange
        SubitemVistoriaEntity codSubitem = new SubitemVistoriaEntity();
        codSubitem.setAtivo(true);
        codSubitem.setDataInclusao(LocalDate.of(1970, 1, 1));
        codSubitem.setDescricao("Descricao");
        codSubitem.setId(1L);
        codSubitem.setNome("Nome");

        TipoDefeitoVistoriaEntity codTipoDefeito = new TipoDefeitoVistoriaEntity();
        codTipoDefeito.setAtivo(true);
        codTipoDefeito.setDataInclusao(LocalDate.of(1970, 1, 1));
        codTipoDefeito.setDescricao("Descricao");
        codTipoDefeito.setId(1L);
        codTipoDefeito.setNome("Nome");

        DefeitosVistoriaEntity defeitosVistoriaEntity = new DefeitosVistoriaEntity();
        defeitosVistoriaEntity.setAtivo(true);
        defeitosVistoriaEntity.setCodSubitem(codSubitem);
        defeitosVistoriaEntity.setCodTipoDefeito(codTipoDefeito);
        defeitosVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        defeitosVistoriaEntity.setId(1L);

        SubitemVistoriaEntity codSubitem2 = new SubitemVistoriaEntity();
        codSubitem2.setAtivo(true);
        codSubitem2.setDataInclusao(LocalDate.of(1970, 1, 1));
        codSubitem2.setDescricao("Descricao");
        codSubitem2.setId(1L);
        codSubitem2.setNome("Nome");

        TipoDefeitoVistoriaEntity codTipoDefeito2 = new TipoDefeitoVistoriaEntity();
        codTipoDefeito2.setAtivo(true);
        codTipoDefeito2.setDataInclusao(LocalDate.of(1970, 1, 1));
        codTipoDefeito2.setDescricao("Descricao");
        codTipoDefeito2.setId(1L);
        codTipoDefeito2.setNome("Nome");

        DefeitosVistoriaEntity defeitosVistoriaEntity2 = new DefeitosVistoriaEntity();
        defeitosVistoriaEntity2.setAtivo(true);
        defeitosVistoriaEntity2.setCodSubitem(codSubitem2);
        defeitosVistoriaEntity2.setCodTipoDefeito(codTipoDefeito2);
        defeitosVistoriaEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        defeitosVistoriaEntity2.setId(1L);

        // Act and Assert
        assertTrue(defeitosVistoriaEntity.canEqual(defeitosVistoriaEntity2));
    }

    /**
     * Method under test: {@link DefeitosVistoriaEntity#equals(Object)}
     */
    @Test
    void testEquals() {
        // Arrange
        SubitemVistoriaEntity codSubitem = new SubitemVistoriaEntity();
        codSubitem.setAtivo(true);
        codSubitem.setDataInclusao(LocalDate.of(1970, 1, 1));
        codSubitem.setDescricao("Descricao");
        codSubitem.setId(1L);
        codSubitem.setNome("Nome");

        TipoDefeitoVistoriaEntity codTipoDefeito = new TipoDefeitoVistoriaEntity();
        codTipoDefeito.setAtivo(true);
        codTipoDefeito.setDataInclusao(LocalDate.of(1970, 1, 1));
        codTipoDefeito.setDescricao("Descricao");
        codTipoDefeito.setId(1L);
        codTipoDefeito.setNome("Nome");

        DefeitosVistoriaEntity defeitosVistoriaEntity = new DefeitosVistoriaEntity();
        defeitosVistoriaEntity.setAtivo(true);
        defeitosVistoriaEntity.setCodSubitem(codSubitem);
        defeitosVistoriaEntity.setCodTipoDefeito(codTipoDefeito);
        defeitosVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        defeitosVistoriaEntity.setId(1L);

        // Act and Assert
        assertNotEquals(defeitosVistoriaEntity, null);
    }

    /**
     * Method under test: {@link DefeitosVistoriaEntity#equals(Object)}
     */
    @Test
    void testEquals2() {
        // Arrange
        SubitemVistoriaEntity codSubitem = new SubitemVistoriaEntity();
        codSubitem.setAtivo(true);
        codSubitem.setDataInclusao(LocalDate.of(1970, 1, 1));
        codSubitem.setDescricao("Descricao");
        codSubitem.setId(1L);
        codSubitem.setNome("Nome");

        TipoDefeitoVistoriaEntity codTipoDefeito = new TipoDefeitoVistoriaEntity();
        codTipoDefeito.setAtivo(true);
        codTipoDefeito.setDataInclusao(LocalDate.of(1970, 1, 1));
        codTipoDefeito.setDescricao("Descricao");
        codTipoDefeito.setId(1L);
        codTipoDefeito.setNome("Nome");

        DefeitosVistoriaEntity defeitosVistoriaEntity = new DefeitosVistoriaEntity();
        defeitosVistoriaEntity.setAtivo(true);
        defeitosVistoriaEntity.setCodSubitem(codSubitem);
        defeitosVistoriaEntity.setCodTipoDefeito(codTipoDefeito);
        defeitosVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        defeitosVistoriaEntity.setId(1L);

        // Act and Assert
        assertNotEquals(defeitosVistoriaEntity, "Different type to DefeitosVistoriaEntity");
    }

    /**
     * Method under test: {@link DefeitosVistoriaEntity#equals(Object)}
     */
    @Test
    void testEquals3() {
        // Arrange
        SubitemVistoriaEntity codSubitem = mock(SubitemVistoriaEntity.class);
        doNothing().when(codSubitem).setAtivo(Mockito.<Boolean>any());
        doNothing().when(codSubitem).setDataInclusao(Mockito.<LocalDate>any());
        doNothing().when(codSubitem).setDescricao(Mockito.<String>any());
        doNothing().when(codSubitem).setId(Mockito.<Long>any());
        doNothing().when(codSubitem).setNome(Mockito.<String>any());
        codSubitem.setAtivo(true);
        codSubitem.setDataInclusao(LocalDate.of(1970, 1, 1));
        codSubitem.setDescricao("Descricao");
        codSubitem.setId(1L);
        codSubitem.setNome("Nome");

        TipoDefeitoVistoriaEntity codTipoDefeito = new TipoDefeitoVistoriaEntity();
        codTipoDefeito.setAtivo(true);
        codTipoDefeito.setDataInclusao(LocalDate.of(1970, 1, 1));
        codTipoDefeito.setDescricao("Descricao");
        codTipoDefeito.setId(1L);
        codTipoDefeito.setNome("Nome");

        DefeitosVistoriaEntity defeitosVistoriaEntity = new DefeitosVistoriaEntity();
        defeitosVistoriaEntity.setAtivo(true);
        defeitosVistoriaEntity.setCodSubitem(codSubitem);
        defeitosVistoriaEntity.setCodTipoDefeito(codTipoDefeito);
        defeitosVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        defeitosVistoriaEntity.setId(2L);

        SubitemVistoriaEntity codSubitem2 = new SubitemVistoriaEntity();
        codSubitem2.setAtivo(true);
        codSubitem2.setDataInclusao(LocalDate.of(1970, 1, 1));
        codSubitem2.setDescricao("Descricao");
        codSubitem2.setId(1L);
        codSubitem2.setNome("Nome");

        TipoDefeitoVistoriaEntity codTipoDefeito2 = new TipoDefeitoVistoriaEntity();
        codTipoDefeito2.setAtivo(true);
        codTipoDefeito2.setDataInclusao(LocalDate.of(1970, 1, 1));
        codTipoDefeito2.setDescricao("Descricao");
        codTipoDefeito2.setId(1L);
        codTipoDefeito2.setNome("Nome");

        DefeitosVistoriaEntity defeitosVistoriaEntity2 = new DefeitosVistoriaEntity();
        defeitosVistoriaEntity2.setAtivo(true);
        defeitosVistoriaEntity2.setCodSubitem(codSubitem2);
        defeitosVistoriaEntity2.setCodTipoDefeito(codTipoDefeito2);
        defeitosVistoriaEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        defeitosVistoriaEntity2.setId(1L);

        // Act and Assert
        assertNotEquals(defeitosVistoriaEntity, defeitosVistoriaEntity2);
    }

    /**
     * Method under test: {@link DefeitosVistoriaEntity#equals(Object)}
     */
    @Test
    void testEquals4() {
        // Arrange
        SubitemVistoriaEntity codSubitem = mock(SubitemVistoriaEntity.class);
        doNothing().when(codSubitem).setAtivo(Mockito.<Boolean>any());
        doNothing().when(codSubitem).setDataInclusao(Mockito.<LocalDate>any());
        doNothing().when(codSubitem).setDescricao(Mockito.<String>any());
        doNothing().when(codSubitem).setId(Mockito.<Long>any());
        doNothing().when(codSubitem).setNome(Mockito.<String>any());
        codSubitem.setAtivo(true);
        codSubitem.setDataInclusao(LocalDate.of(1970, 1, 1));
        codSubitem.setDescricao("Descricao");
        codSubitem.setId(1L);
        codSubitem.setNome("Nome");

        TipoDefeitoVistoriaEntity codTipoDefeito = new TipoDefeitoVistoriaEntity();
        codTipoDefeito.setAtivo(true);
        codTipoDefeito.setDataInclusao(LocalDate.of(1970, 1, 1));
        codTipoDefeito.setDescricao("Descricao");
        codTipoDefeito.setId(1L);
        codTipoDefeito.setNome("Nome");

        DefeitosVistoriaEntity defeitosVistoriaEntity = new DefeitosVistoriaEntity();
        defeitosVistoriaEntity.setAtivo(true);
        defeitosVistoriaEntity.setCodSubitem(codSubitem);
        defeitosVistoriaEntity.setCodTipoDefeito(codTipoDefeito);
        defeitosVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        defeitosVistoriaEntity.setId(null);

        SubitemVistoriaEntity codSubitem2 = new SubitemVistoriaEntity();
        codSubitem2.setAtivo(true);
        codSubitem2.setDataInclusao(LocalDate.of(1970, 1, 1));
        codSubitem2.setDescricao("Descricao");
        codSubitem2.setId(1L);
        codSubitem2.setNome("Nome");

        TipoDefeitoVistoriaEntity codTipoDefeito2 = new TipoDefeitoVistoriaEntity();
        codTipoDefeito2.setAtivo(true);
        codTipoDefeito2.setDataInclusao(LocalDate.of(1970, 1, 1));
        codTipoDefeito2.setDescricao("Descricao");
        codTipoDefeito2.setId(1L);
        codTipoDefeito2.setNome("Nome");

        DefeitosVistoriaEntity defeitosVistoriaEntity2 = new DefeitosVistoriaEntity();
        defeitosVistoriaEntity2.setAtivo(true);
        defeitosVistoriaEntity2.setCodSubitem(codSubitem2);
        defeitosVistoriaEntity2.setCodTipoDefeito(codTipoDefeito2);
        defeitosVistoriaEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        defeitosVistoriaEntity2.setId(1L);

        // Act and Assert
        assertNotEquals(defeitosVistoriaEntity, defeitosVistoriaEntity2);
    }

    /**
     * Methods under test:
     * <ul>
     *   <li>{@link DefeitosVistoriaEntity#equals(Object)}
     *   <li>{@link DefeitosVistoriaEntity#hashCode()}
     * </ul>
     */
    @Test
    void testEqualsAndHashCode() {
        // Arrange
        SubitemVistoriaEntity codSubitem = new SubitemVistoriaEntity();
        codSubitem.setAtivo(true);
        codSubitem.setDataInclusao(LocalDate.of(1970, 1, 1));
        codSubitem.setDescricao("Descricao");
        codSubitem.setId(1L);
        codSubitem.setNome("Nome");

        TipoDefeitoVistoriaEntity codTipoDefeito = new TipoDefeitoVistoriaEntity();
        codTipoDefeito.setAtivo(true);
        codTipoDefeito.setDataInclusao(LocalDate.of(1970, 1, 1));
        codTipoDefeito.setDescricao("Descricao");
        codTipoDefeito.setId(1L);
        codTipoDefeito.setNome("Nome");

        DefeitosVistoriaEntity defeitosVistoriaEntity = new DefeitosVistoriaEntity();
        defeitosVistoriaEntity.setAtivo(true);
        defeitosVistoriaEntity.setCodSubitem(codSubitem);
        defeitosVistoriaEntity.setCodTipoDefeito(codTipoDefeito);
        defeitosVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        defeitosVistoriaEntity.setId(1L);

        // Act and Assert
        assertEquals(defeitosVistoriaEntity, defeitosVistoriaEntity);
        int expectedHashCodeResult = defeitosVistoriaEntity.hashCode();
        assertEquals(expectedHashCodeResult, defeitosVistoriaEntity.hashCode());
    }

    /**
     * Methods under test:
     * <ul>
     *   <li>{@link DefeitosVistoriaEntity#equals(Object)}
     *   <li>{@link DefeitosVistoriaEntity#hashCode()}
     * </ul>
     */
    @Test
    void testEqualsAndHashCode2() {
        // Arrange
        SubitemVistoriaEntity codSubitem = new SubitemVistoriaEntity();
        codSubitem.setAtivo(true);
        codSubitem.setDataInclusao(LocalDate.of(1970, 1, 1));
        codSubitem.setDescricao("Descricao");
        codSubitem.setId(1L);
        codSubitem.setNome("Nome");

        TipoDefeitoVistoriaEntity codTipoDefeito = new TipoDefeitoVistoriaEntity();
        codTipoDefeito.setAtivo(true);
        codTipoDefeito.setDataInclusao(LocalDate.of(1970, 1, 1));
        codTipoDefeito.setDescricao("Descricao");
        codTipoDefeito.setId(1L);
        codTipoDefeito.setNome("Nome");

        DefeitosVistoriaEntity defeitosVistoriaEntity = new DefeitosVistoriaEntity();
        defeitosVistoriaEntity.setAtivo(true);
        defeitosVistoriaEntity.setCodSubitem(codSubitem);
        defeitosVistoriaEntity.setCodTipoDefeito(codTipoDefeito);
        defeitosVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        defeitosVistoriaEntity.setId(1L);

        SubitemVistoriaEntity codSubitem2 = new SubitemVistoriaEntity();
        codSubitem2.setAtivo(true);
        codSubitem2.setDataInclusao(LocalDate.of(1970, 1, 1));
        codSubitem2.setDescricao("Descricao");
        codSubitem2.setId(1L);
        codSubitem2.setNome("Nome");

        TipoDefeitoVistoriaEntity codTipoDefeito2 = new TipoDefeitoVistoriaEntity();
        codTipoDefeito2.setAtivo(true);
        codTipoDefeito2.setDataInclusao(LocalDate.of(1970, 1, 1));
        codTipoDefeito2.setDescricao("Descricao");
        codTipoDefeito2.setId(1L);
        codTipoDefeito2.setNome("Nome");

        DefeitosVistoriaEntity defeitosVistoriaEntity2 = new DefeitosVistoriaEntity();
        defeitosVistoriaEntity2.setAtivo(true);
        defeitosVistoriaEntity2.setCodSubitem(codSubitem2);
        defeitosVistoriaEntity2.setCodTipoDefeito(codTipoDefeito2);
        defeitosVistoriaEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        defeitosVistoriaEntity2.setId(1L);

        // Act and Assert
        assertEquals(defeitosVistoriaEntity, defeitosVistoriaEntity2);
        int expectedHashCodeResult = defeitosVistoriaEntity.hashCode();
        assertEquals(expectedHashCodeResult, defeitosVistoriaEntity2.hashCode());
    }

    /**
     * Methods under test:
     * <ul>
     *   <li>{@link DefeitosVistoriaEntity#equals(Object)}
     *   <li>{@link DefeitosVistoriaEntity#hashCode()}
     * </ul>
     */
    @Test
    void testEqualsAndHashCode3() {
        // Arrange
        SubitemVistoriaEntity codSubitem = mock(SubitemVistoriaEntity.class);
        doNothing().when(codSubitem).setAtivo(Mockito.<Boolean>any());
        doNothing().when(codSubitem).setDataInclusao(Mockito.<LocalDate>any());
        doNothing().when(codSubitem).setDescricao(Mockito.<String>any());
        doNothing().when(codSubitem).setId(Mockito.<Long>any());
        doNothing().when(codSubitem).setNome(Mockito.<String>any());
        codSubitem.setAtivo(true);
        codSubitem.setDataInclusao(LocalDate.of(1970, 1, 1));
        codSubitem.setDescricao("Descricao");
        codSubitem.setId(1L);
        codSubitem.setNome("Nome");

        TipoDefeitoVistoriaEntity codTipoDefeito = new TipoDefeitoVistoriaEntity();
        codTipoDefeito.setAtivo(true);
        codTipoDefeito.setDataInclusao(LocalDate.of(1970, 1, 1));
        codTipoDefeito.setDescricao("Descricao");
        codTipoDefeito.setId(1L);
        codTipoDefeito.setNome("Nome");

        DefeitosVistoriaEntity defeitosVistoriaEntity = new DefeitosVistoriaEntity();
        defeitosVistoriaEntity.setAtivo(true);
        defeitosVistoriaEntity.setCodSubitem(codSubitem);
        defeitosVistoriaEntity.setCodTipoDefeito(codTipoDefeito);
        defeitosVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        defeitosVistoriaEntity.setId(1L);

        SubitemVistoriaEntity codSubitem2 = new SubitemVistoriaEntity();
        codSubitem2.setAtivo(true);
        codSubitem2.setDataInclusao(LocalDate.of(1970, 1, 1));
        codSubitem2.setDescricao("Descricao");
        codSubitem2.setId(1L);
        codSubitem2.setNome("Nome");

        TipoDefeitoVistoriaEntity codTipoDefeito2 = new TipoDefeitoVistoriaEntity();
        codTipoDefeito2.setAtivo(true);
        codTipoDefeito2.setDataInclusao(LocalDate.of(1970, 1, 1));
        codTipoDefeito2.setDescricao("Descricao");
        codTipoDefeito2.setId(1L);
        codTipoDefeito2.setNome("Nome");

        DefeitosVistoriaEntity defeitosVistoriaEntity2 = new DefeitosVistoriaEntity();
        defeitosVistoriaEntity2.setAtivo(true);
        defeitosVistoriaEntity2.setCodSubitem(codSubitem2);
        defeitosVistoriaEntity2.setCodTipoDefeito(codTipoDefeito2);
        defeitosVistoriaEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        defeitosVistoriaEntity2.setId(1L);

        // Act and Assert
        assertEquals(defeitosVistoriaEntity, defeitosVistoriaEntity2);
        int expectedHashCodeResult = defeitosVistoriaEntity.hashCode();
        assertEquals(expectedHashCodeResult, defeitosVistoriaEntity2.hashCode());
    }

    /**
     * Methods under test:
     * <ul>
     *   <li>{@link DefeitosVistoriaEntity#DefeitosVistoriaEntity()}
     *   <li>{@link DefeitosVistoriaEntity#setAtivo(Boolean)}
     *   <li>{@link DefeitosVistoriaEntity#setCodSubitem(SubitemVistoriaEntity)}
     *   <li>
     * {@link DefeitosVistoriaEntity#setCodTipoDefeito(TipoDefeitoVistoriaEntity)}
     *   <li>{@link DefeitosVistoriaEntity#setDataInclusao(LocalDate)}
     *   <li>{@link DefeitosVistoriaEntity#setId(Long)}
     *   <li>{@link DefeitosVistoriaEntity#getAtivo()}
     *   <li>{@link DefeitosVistoriaEntity#getCodSubitem()}
     *   <li>{@link DefeitosVistoriaEntity#getCodTipoDefeito()}
     *   <li>{@link DefeitosVistoriaEntity#getDataInclusao()}
     *   <li>{@link DefeitosVistoriaEntity#getId()}
     * </ul>
     */
    @Test
    void testGettersAndSetters() {
        // Arrange and Act
        DefeitosVistoriaEntity actualDefeitosVistoriaEntity = new DefeitosVistoriaEntity();
        actualDefeitosVistoriaEntity.setAtivo(true);
        SubitemVistoriaEntity codSubitem = new SubitemVistoriaEntity();
        codSubitem.setAtivo(true);
        codSubitem.setDataInclusao(LocalDate.of(1970, 1, 1));
        codSubitem.setDescricao("Descricao");
        codSubitem.setId(1L);
        codSubitem.setNome("Nome");
        actualDefeitosVistoriaEntity.setCodSubitem(codSubitem);
        TipoDefeitoVistoriaEntity codTipoDefeito = new TipoDefeitoVistoriaEntity();
        codTipoDefeito.setAtivo(true);
        codTipoDefeito.setDataInclusao(LocalDate.of(1970, 1, 1));
        codTipoDefeito.setDescricao("Descricao");
        codTipoDefeito.setId(1L);
        codTipoDefeito.setNome("Nome");
        actualDefeitosVistoriaEntity.setCodTipoDefeito(codTipoDefeito);
        LocalDate dataInclusao = LocalDate.of(1970, 1, 1);
        actualDefeitosVistoriaEntity.setDataInclusao(dataInclusao);
        actualDefeitosVistoriaEntity.setId(1L);
        Boolean actualAtivo = actualDefeitosVistoriaEntity.getAtivo();
        SubitemVistoriaEntity actualCodSubitem = actualDefeitosVistoriaEntity.getCodSubitem();
        TipoDefeitoVistoriaEntity actualCodTipoDefeito = actualDefeitosVistoriaEntity.getCodTipoDefeito();
        LocalDate actualDataInclusao = actualDefeitosVistoriaEntity.getDataInclusao();

        // Assert that nothing has changed
        assertEquals(1L, actualDefeitosVistoriaEntity.getId().longValue());
        assertTrue(actualAtivo);
        assertSame(codSubitem, actualCodSubitem);
        assertSame(codTipoDefeito, actualCodTipoDefeito);
        assertSame(dataInclusao, actualDataInclusao);
    }

    /**
     * Methods under test:
     * <ul>
     *   <li>
     * {@link DefeitosVistoriaEntity#DefeitosVistoriaEntity(Long, SubitemVistoriaEntity, TipoDefeitoVistoriaEntity, Boolean, LocalDate)}
     *   <li>{@link DefeitosVistoriaEntity#setAtivo(Boolean)}
     *   <li>{@link DefeitosVistoriaEntity#setCodSubitem(SubitemVistoriaEntity)}
     *   <li>
     * {@link DefeitosVistoriaEntity#setCodTipoDefeito(TipoDefeitoVistoriaEntity)}
     *   <li>{@link DefeitosVistoriaEntity#setDataInclusao(LocalDate)}
     *   <li>{@link DefeitosVistoriaEntity#setId(Long)}
     *   <li>{@link DefeitosVistoriaEntity#getAtivo()}
     *   <li>{@link DefeitosVistoriaEntity#getCodSubitem()}
     *   <li>{@link DefeitosVistoriaEntity#getCodTipoDefeito()}
     *   <li>{@link DefeitosVistoriaEntity#getDataInclusao()}
     *   <li>{@link DefeitosVistoriaEntity#getId()}
     * </ul>
     */
    @Test
    void testGettersAndSetters2() {
        // Arrange
        SubitemVistoriaEntity codSubitem = new SubitemVistoriaEntity();
        codSubitem.setAtivo(true);
        codSubitem.setDataInclusao(LocalDate.of(1970, 1, 1));
        codSubitem.setDescricao("Descricao");
        codSubitem.setId(1L);
        codSubitem.setNome("Nome");

        TipoDefeitoVistoriaEntity codTipoDefeito = new TipoDefeitoVistoriaEntity();
        codTipoDefeito.setAtivo(true);
        codTipoDefeito.setDataInclusao(LocalDate.of(1970, 1, 1));
        codTipoDefeito.setDescricao("Descricao");
        codTipoDefeito.setId(1L);
        codTipoDefeito.setNome("Nome");

        // Act
        DefeitosVistoriaEntity actualDefeitosVistoriaEntity = new DefeitosVistoriaEntity(1L, codSubitem, codTipoDefeito,
                true, LocalDate.of(1970, 1, 1));
        actualDefeitosVistoriaEntity.setAtivo(true);
        SubitemVistoriaEntity codSubitem2 = new SubitemVistoriaEntity();
        codSubitem2.setAtivo(true);
        codSubitem2.setDataInclusao(LocalDate.of(1970, 1, 1));
        codSubitem2.setDescricao("Descricao");
        codSubitem2.setId(1L);
        codSubitem2.setNome("Nome");
        actualDefeitosVistoriaEntity.setCodSubitem(codSubitem2);
        TipoDefeitoVistoriaEntity codTipoDefeito2 = new TipoDefeitoVistoriaEntity();
        codTipoDefeito2.setAtivo(true);
        codTipoDefeito2.setDataInclusao(LocalDate.of(1970, 1, 1));
        codTipoDefeito2.setDescricao("Descricao");
        codTipoDefeito2.setId(1L);
        codTipoDefeito2.setNome("Nome");
        actualDefeitosVistoriaEntity.setCodTipoDefeito(codTipoDefeito2);
        LocalDate dataInclusao = LocalDate.of(1970, 1, 1);
        actualDefeitosVistoriaEntity.setDataInclusao(dataInclusao);
        actualDefeitosVistoriaEntity.setId(1L);
        Boolean actualAtivo = actualDefeitosVistoriaEntity.getAtivo();
        SubitemVistoriaEntity actualCodSubitem = actualDefeitosVistoriaEntity.getCodSubitem();
        TipoDefeitoVistoriaEntity actualCodTipoDefeito = actualDefeitosVistoriaEntity.getCodTipoDefeito();
        LocalDate actualDataInclusao = actualDefeitosVistoriaEntity.getDataInclusao();

        // Assert that nothing has changed
        assertEquals(1L, actualDefeitosVistoriaEntity.getId().longValue());
        assertTrue(actualAtivo);
        assertEquals(codSubitem, actualCodSubitem);
        assertEquals(codTipoDefeito, actualCodTipoDefeito);
        assertSame(codSubitem2, actualCodSubitem);
        assertSame(codTipoDefeito2, actualCodTipoDefeito);
        assertSame(dataInclusao, actualDataInclusao);
    }

    @Test
    void builder() {
        DefeitosVistoriaEntity defeitosVistoriaEntity = DefeitosVistoriaEntity.builder()
                .id(1L)
                .dataInclusao(LocalDate.MIN)
                .ativo(true)
                .codTipoDefeito(new TipoDefeitoVistoriaEntity())
                .codSubitem(new SubitemVistoriaEntity())
                .build();

        assertNotNull(defeitosVistoriaEntity);
    }

}
