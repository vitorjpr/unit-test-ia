```java
package br.gov.df.pm.sgv.dto;

import br.gov.df.pm.sgv.domain.SubitemVistoriaEntity;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class ItemVistoriaDTOTest {
    private ItemVistoriaDTO itemVistoria;
    private LocalDate diaAtual;
    private SubitemVistoriaEntity subitens;

    @BeforeEach
    void setUp() {
        itemVistoria = new ItemVistoriaDTO(null, "", "", null, null, null);
        diaAtual = LocalDate.now();
        subitens = SubitemVistoriaEntity.builder().build();

        itemVistoria.setId(1L);
        itemVistoria.setNome("Vidro");
        itemVistoria.setDescricao("Vidro do Carro");
        itemVistoria.setDataInclusao(diaAtual);
        itemVistoria.setAtivo(true);
        itemVistoria.setSubitens(List.of(subitens));
    }

    @Test
    void testEquals() {
        var itemVistoria1 = ItemVistoriaDTO.builder()
                .id(1L)
                .nome("Vidro")
                .descricao("Vidro do Carro")
                .dataInclusao(diaAtual)
                .ativo(true)
                .subitens(List.of(subitens))
                .build();
        assertEquals(itemVistoria, itemVistoria1);

        var itemVistoria2 = ItemVistoriaDTO.builder().nome("Janela").build();
        assertNotEquals(itemVistoria, itemVistoria2);
    }

    @Test
    void testHashCode() {
        var itemVistoria1 = ItemVistoriaDTO.builder()
                .id(1L)
                .nome("Vidro")
                .descricao("Vidro do Carro")
                .dataInclusao(diaAtual)
                .ativo(true)
                .subitens(List.of(subitens))
                .build();
        assertEquals(itemVistoria.hashCode(), itemVistoria1.hashCode());

        var itemVistoria2 = ItemVistoriaDTO.builder().build();
        assertNotEquals(itemVistoria.hashCode(), itemVistoria2.hashCode());
    }

    @Test
    void testToString() {
        assertNotNull(itemVistoria.toString());
    }

    @Test
    void testGetters() {
        assertEquals(1L, itemVistoria.getId());
        assertEquals("Vidro", itemVistoria.getNome());
        assertEquals("Vidro do Carro", itemVistoria.getDescricao());
        assertEquals(diaAtual, itemVistoria.getDataInclusao());
        assertTrue(itemVistoria.isAtivo());
        assertEquals(List.of(subitens), itemVistoria.getSubitens());
    }

    @Test
    void testSetters() {
        ItemVistoriaDTO newItemVistoria = new ItemVistoriaDTO(null, "", "", null, null, null);
        newItemVistoria.setId(2L);
        newItemVistoria.setNome("Pneu");
        newItemVistoria.setDescricao("Pneu do Carro");
        LocalDate newDate = LocalDate.now().minusDays(1);
        newItemVistoria.setDataInclusao(newDate);
        newItemVistoria.setAtivo(false);
        SubitemVistoriaEntity newSubitem = SubitemVistoriaEntity.builder().build();
        newItemVistoria.setSubitens(List.of(newSubitem));

        assertEquals(2L, newItemVistoria.getId());
        assertEquals("Pneu", newItemVistoria.getNome());
        assertEquals("Pneu do Carro", newItemVistoria.getDescricao());
        assertEquals(newDate, newItemVistoria.getDataInclusao());
        assertFalse(newItemVistoria.isAtivo());
        assertEquals(List.of(newSubitem), newItemVistoria.getSubitens());
    }
}
```