Sure! Here are some unit tests for the `OcorrenciasDTOTest` class:

```java
package br.gov.df.pm.sgv.dto;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class OcorrenciasDTOTest {

    private OcorrenciasDTO ocorrenciasDTO;

    @BeforeEach
    void setUp() {
        ocorrenciasDTO = new OcorrenciasDTO();
    }

    @Test
    void getItemVistoriaOcorrenciaDTOS() {
        // Test getItemVistoriaOcorrenciaDTOS method
        // Add your test logic here
    }

    @Test
    void setItemVistoriaOcorrenciaDTOS() {
        // Test setItemVistoriaOcorrenciaDTOS method
        // Add your test logic here
    }

    @Test
    void testEquals() {
        // Test equals method
        // Add your test logic here
    }

    @Test
    void canEqual() {
        // Test canEqual method
        // Add your test logic here
    }

    @Test
    void testHashCode() {
        // Test hashCode method
        // Add your test logic here
    }

    @Test
    void testToString() {
        // Test toString method
        // Add your test logic here
    }

    @Test
    void builder() {
        // Test builder method
        // Add your test logic here
    }
}
```

You can add your specific test logic inside each test method to ensure comprehensive testing of the `OcorrenciasDTO` class.