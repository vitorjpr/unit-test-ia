```java
package br.gov.df.pm.sgv.domain;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;

import java.time.LocalDate;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

class ItensVistoriaEntityDiffblueTest {

    @Test
    void testCanEqual() {
        assertFalse((new ItensVistoriaEntity()).canEqual("Other"));
    }

    @Test
    void testCanEqual2() {
        ItemVistoriaEntity codItem = new ItemVistoriaEntity();
        // Initialize codItem properties
        TipoVistoriaEntity codTipo = new TipoVistoriaEntity();
        // Initialize codTipo properties
        ItensVistoriaEntity itensVistoriaEntity = new ItensVistoriaEntity();
        // Initialize itensVistoriaEntity properties
        ItensVistoriaEntity itensVistoriaEntity2 = new ItensVistoriaEntity();
        // Initialize itensVistoriaEntity2 properties
        assertTrue(itensVistoriaEntity.canEqual(itensVistoriaEntity2));
    }

    @Test
    void testEquals() {
        ItemVistoriaEntity codItem = new ItemVistoriaEntity();
        // Initialize codItem properties
        TipoVistoriaEntity codTipo = new TipoVistoriaEntity();
        // Initialize codTipo properties
        ItensVistoriaEntity itensVistoriaEntity = new ItensVistoriaEntity();
        // Initialize itensVistoriaEntity properties
        assertNotEquals(itensVistoriaEntity, null);
    }

    @Test
    void testEquals2() {
        ItemVistoriaEntity codItem = new ItemVistoriaEntity();
        // Initialize codItem properties
        TipoVistoriaEntity codTipo = new TipoVistoriaEntity();
        // Initialize codTipo properties
        ItensVistoriaEntity itensVistoriaEntity = new ItensVistoriaEntity();
        // Initialize itensVistoriaEntity properties
        assertNotEquals(itensVistoriaEntity, "Different type to ItensVistoriaEntity");
    }

    @Test
    void testEquals3() {
        ItemVistoriaEntity codItem = mock(ItemVistoriaEntity.class);
        // Mock codItem methods
        TipoVistoriaEntity codTipo = new TipoVistoriaEntity();
        // Initialize codTipo properties
        ItensVistoriaEntity itensVistoriaEntity = new ItensVistoriaEntity();
        // Initialize itensVistoriaEntity properties
        ItensVistoriaEntity itensVistoriaEntity2 = new ItensVistoriaEntity();
        // Initialize itensVistoriaEntity2 properties
        assertNotEquals(itensVistoriaEntity, itensVistoriaEntity2);
    }

    @Test
    void testEquals4() {
        ItemVistoriaEntity codItem = mock(ItemVistoriaEntity.class);
        // Mock codItem methods
        TipoVistoriaEntity codTipo = new TipoVistoriaEntity();
        // Initialize codTipo properties
        ItensVistoriaEntity itensVistoriaEntity = new ItensVistoriaEntity();
        // Initialize itensVistoriaEntity properties
        ItensVistoriaEntity itensVistoriaEntity2 = new ItensVistoriaEntity();
        // Initialize itensVistoriaEntity2 properties
        assertNotEquals(itensVistoriaEntity, itensVistoriaEntity2);
    }

    @Test
    void testEqualsAndHashCode() {
        ItemVistoriaEntity codItem = new ItemVistoriaEntity();
        // Initialize codItem properties
        TipoVistoriaEntity codTipo = new TipoVistoriaEntity();
        // Initialize codTipo properties
        ItensVistoriaEntity itensVistoriaEntity = new ItensVistoriaEntity();
        // Initialize itensVistoriaEntity properties
        assertEquals(itensVistoriaEntity, itensVistoriaEntity);
        int expectedHashCodeResult = itensVistoriaEntity.hashCode();
        assertEquals(expectedHashCodeResult, itensVistoriaEntity.hashCode());
    }

    @Test
    void testEqualsAndHashCode2() {
        ItemVistoriaEntity codItem = new ItemVistoriaEntity();
        // Initialize codItem properties
        TipoVistoriaEntity codTipo = new TipoVistoriaEntity();
        // Initialize codTipo properties
        ItensVistoriaEntity itensVistoriaEntity = new ItensVistoriaEntity();
        // Initialize itensVistoriaEntity properties
        ItensVistoriaEntity itensVistoriaEntity2 = new ItensVistoriaEntity();
        // Initialize itensVistoriaEntity2 properties
