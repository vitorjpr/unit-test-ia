package br.gov.df.pm.sgv.dto;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

class ItemVistoriaOcorrenciaDTODiffblueTest {
    /**
     * Method under test: {@link ItemVistoriaOcorrenciaDTO#canEqual(Object)}
     */
    @Test
    void testCanEqual() {
        // Arrange, Act and Assert
        assertFalse((new ItemVistoriaOcorrenciaDTO()).canEqual("Other"));
    }

    /**
     * Method under test: {@link ItemVistoriaOcorrenciaDTO#canEqual(Object)}
     */
    @Test
    void testCanEqual2() {
        // Arrange
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder ativoResult = ItemVistoriaOcorrenciaDTO.builder()
                .ativo(true);
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder nomeResult = ativoResult
                .dataInclusao(LocalDate.of(1970, 1, 1))
                .descricao("Descricao")
                .id(1L)
                .nome("Nome");
        ItemVistoriaOcorrenciaDTO buildResult = nomeResult.subitemVistoriaDTOS(new ArrayList<>()).build();
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder ativoResult2 = ItemVistoriaOcorrenciaDTO.builder()
                .ativo(true);
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder nomeResult2 = ativoResult2
                .dataInclusao(LocalDate.of(1970, 1, 1))
                .descricao("Descricao")
                .id(1L)
                .nome("Nome");
        ItemVistoriaOcorrenciaDTO buildResult2 = nomeResult2.subitemVistoriaDTOS(new ArrayList<>()).build();

        // Act and Assert
        assertTrue(buildResult.canEqual(buildResult2));
    }

    /**
     * Method under test: {@link ItemVistoriaOcorrenciaDTO#equals(Object)}
     */
    @Test
    void testEquals() {
        // Arrange
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder ativoResult = ItemVistoriaOcorrenciaDTO.builder()
                .ativo(true);
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder nomeResult = ativoResult
                .dataInclusao(LocalDate.of(1970, 1, 1))
                .descricao("Descricao")
                .id(1L)
                .nome("Nome");
        ItemVistoriaOcorrenciaDTO buildResult = nomeResult.subitemVistoriaDTOS(new ArrayList<>()).build();

        // Act and Assert
        assertNotEquals(buildResult, null);
    }

    /**
     * Method under test: {@link ItemVistoriaOcorrenciaDTO#equals(Object)}
     */
    @Test
    void testEquals2() {
        // Arrange
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder ativoResult = ItemVistoriaOcorrenciaDTO.builder()
                .ativo(true);
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder nomeResult = ativoResult
                .dataInclusao(LocalDate.of(1970, 1, 1))
                .descricao("Descricao")
                .id(1L)
                .nome("Nome");
        ItemVistoriaOcorrenciaDTO buildResult = nomeResult.subitemVistoriaDTOS(new ArrayList<>()).build();

        // Act and Assert
        assertNotEquals(buildResult, "Different type to ItemVistoriaOcorrenciaDTO");
    }

    /**
     * Method under test: {@link ItemVistoriaOcorrenciaDTO#equals(Object)}
     */
    @Test
    void testEquals3() {
        // Arrange
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder itemVistoriaOcorrenciaDTOBuilder = mock(
                ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder.class);
        when(itemVistoriaOcorrenciaDTOBuilder.ativo(Mockito.<Boolean>any()))
                .thenReturn(ItemVistoriaOcorrenciaDTO.builder());
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder ativoResult = itemVistoriaOcorrenciaDTOBuilder
                .ativo(true);
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder nomeResult = ativoResult
                .dataInclusao(LocalDate.of(1970, 1, 1))
                .descricao("Descricao")
                .id(1L)
                .nome("Nome");
        ItemVistoriaOcorrenciaDTO buildResult = nomeResult.subitemVistoriaDTOS(new ArrayList<>()).build();
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder ativoResult2 = ItemVistoriaOcorrenciaDTO.builder()
                .ativo(true);
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder nomeResult2 = ativoResult2
                .dataInclusao(LocalDate.of(1970, 1, 1))
                .descricao("Descricao")
                .id(1L)
                .nome("Nome");
        ItemVistoriaOcorrenciaDTO buildResult2 = nomeResult2.subitemVistoriaDTOS(new ArrayList<>()).build();

        // Act and Assert
        assertNotEquals(buildResult, buildResult2);
    }

    /**
     * Method under test: {@link ItemVistoriaOcorrenciaDTO#equals(Object)}
     */
    @Test
    void testEquals4() {
        // Arrange
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder itemVistoriaOcorrenciaDTOBuilder = mock(
                ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder.class);
        when(itemVistoriaOcorrenciaDTOBuilder.ativo(Mockito.<Boolean>any()))
                .thenReturn(ItemVistoriaOcorrenciaDTO.builder());
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder ativoResult = itemVistoriaOcorrenciaDTOBuilder
                .ativo(true);
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder nomeResult = ativoResult
                .dataInclusao(LocalDate.of(1970, 1, 1))
                .descricao("Descricao")
                .id(2L)
                .nome("Nome");
        ItemVistoriaOcorrenciaDTO buildResult = nomeResult.subitemVistoriaDTOS(new ArrayList<>()).build();
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder ativoResult2 = ItemVistoriaOcorrenciaDTO.builder()
                .ativo(true);
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder nomeResult2 = ativoResult2
                .dataInclusao(LocalDate.of(1970, 1, 1))
                .descricao("Descricao")
                .id(1L)
                .nome("Nome");
        ItemVistoriaOcorrenciaDTO buildResult2 = nomeResult2.subitemVistoriaDTOS(new ArrayList<>()).build();

        // Act and Assert
        assertNotEquals(buildResult, buildResult2);
    }

    /**
     * Method under test: {@link ItemVistoriaOcorrenciaDTO#equals(Object)}
     */
    @Test
    void testEquals5() {
        // Arrange
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder itemVistoriaOcorrenciaDTOBuilder = mock(
                ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder.class);
        when(itemVistoriaOcorrenciaDTOBuilder.ativo(Mockito.<Boolean>any()))
                .thenReturn(ItemVistoriaOcorrenciaDTO.builder());
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder ativoResult = itemVistoriaOcorrenciaDTOBuilder
                .ativo(true);
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder nomeResult = ativoResult
                .dataInclusao(LocalDate.of(1970, 1, 1))
                .descricao("Descricao")
                .id(null)
                .nome("Nome");
        ItemVistoriaOcorrenciaDTO buildResult = nomeResult.subitemVistoriaDTOS(new ArrayList<>()).build();
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder ativoResult2 = ItemVistoriaOcorrenciaDTO.builder()
                .ativo(true);
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder nomeResult2 = ativoResult2
                .dataInclusao(LocalDate.of(1970, 1, 1))
                .descricao("Descricao")
                .id(1L)
                .nome("Nome");
        ItemVistoriaOcorrenciaDTO buildResult2 = nomeResult2.subitemVistoriaDTOS(new ArrayList<>()).build();

        // Act and Assert
        assertNotEquals(buildResult, buildResult2);
    }

    /**
     * Method under test: {@link ItemVistoriaOcorrenciaDTO#equals(Object)}
     */
    @Test
    void testEquals6() {
        // Arrange
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder itemVistoriaOcorrenciaDTOBuilder = mock(
                ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder.class);
        when(itemVistoriaOcorrenciaDTOBuilder.dataInclusao(Mockito.<LocalDate>any()))
                .thenReturn(ItemVistoriaOcorrenciaDTO.builder());
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder itemVistoriaOcorrenciaDTOBuilder2 = mock(
                ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder.class);
        when(itemVistoriaOcorrenciaDTOBuilder2.ativo(Mockito.<Boolean>any())).thenReturn(itemVistoriaOcorrenciaDTOBuilder);
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder ativoResult = itemVistoriaOcorrenciaDTOBuilder2
                .ativo(true);
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder nomeResult = ativoResult
                .dataInclusao(LocalDate.of(1970, 1, 1))
                .descricao("Descricao")
                .id(1L)
                .nome("Nome");
        ItemVistoriaOcorrenciaDTO buildResult = nomeResult.subitemVistoriaDTOS(new ArrayList<>()).build();
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder itemVistoriaOcorrenciaDTOBuilder3 = mock(
                ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder.class);
        when(itemVistoriaOcorrenciaDTOBuilder3.ativo(Mockito.<Boolean>any()))
                .thenReturn(ItemVistoriaOcorrenciaDTO.builder());
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder ativoResult2 = itemVistoriaOcorrenciaDTOBuilder3
                .ativo(true);
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder nomeResult2 = ativoResult2
                .dataInclusao(LocalDate.of(1970, 1, 1))
                .descricao("Descricao")
                .id(1L)
                .nome("Nome");
        ItemVistoriaOcorrenciaDTO buildResult2 = nomeResult2.subitemVistoriaDTOS(new ArrayList<>()).build();

        // Act and Assert
        assertNotEquals(buildResult, buildResult2);
    }

    /**
     * Method under test: {@link ItemVistoriaOcorrenciaDTO#equals(Object)}
     */
    @Test
    void testEquals7() {
        // Arrange
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder itemVistoriaOcorrenciaDTOBuilder = mock(
                ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder.class);
        when(itemVistoriaOcorrenciaDTOBuilder.descricao(Mockito.<String>any()))
                .thenReturn(ItemVistoriaOcorrenciaDTO.builder());
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder itemVistoriaOcorrenciaDTOBuilder2 = mock(
                ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder.class);
        when(itemVistoriaOcorrenciaDTOBuilder2.dataInclusao(Mockito.<LocalDate>any()))
                .thenReturn(itemVistoriaOcorrenciaDTOBuilder);
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder itemVistoriaOcorrenciaDTOBuilder3 = mock(
                ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder.class);
        when(itemVistoriaOcorrenciaDTOBuilder3.ativo(Mockito.<Boolean>any())).thenReturn(itemVistoriaOcorrenciaDTOBuilder2);
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder ativoResult = itemVistoriaOcorrenciaDTOBuilder3
                .ativo(true);
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder nomeResult = ativoResult
                .dataInclusao(LocalDate.of(1970, 1, 1))
                .descricao("Descricao")
                .id(1L)
                .nome("Nome");
        ItemVistoriaOcorrenciaDTO buildResult = nomeResult.subitemVistoriaDTOS(new ArrayList<>()).build();
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder itemVistoriaOcorrenciaDTOBuilder4 = mock(
                ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder.class);
        when(itemVistoriaOcorrenciaDTOBuilder4.ativo(Mockito.<Boolean>any()))
                .thenReturn(ItemVistoriaOcorrenciaDTO.builder());
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder ativoResult2 = itemVistoriaOcorrenciaDTOBuilder4
                .ativo(true);
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder nomeResult2 = ativoResult2
                .dataInclusao(LocalDate.of(1970, 1, 1))
                .descricao("Descricao")
                .id(1L)
                .nome("Nome");
        ItemVistoriaOcorrenciaDTO buildResult2 = nomeResult2.subitemVistoriaDTOS(new ArrayList<>()).build();

        // Act and Assert
        assertNotEquals(buildResult, buildResult2);
    }

    /**
     * Method under test: {@link ItemVistoriaOcorrenciaDTO#equals(Object)}
     */
    @Test
    void testEquals8() {
        // Arrange
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder itemVistoriaOcorrenciaDTOBuilder = mock(
                ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder.class);
        when(itemVistoriaOcorrenciaDTOBuilder.descricao(Mockito.<String>any()))
                .thenReturn(ItemVistoriaOcorrenciaDTO.builder());
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder itemVistoriaOcorrenciaDTOBuilder2 = mock(
                ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder.class);
        when(itemVistoriaOcorrenciaDTOBuilder2.dataInclusao(Mockito.<LocalDate>any()))
                .thenReturn(itemVistoriaOcorrenciaDTOBuilder);
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder itemVistoriaOcorrenciaDTOBuilder3 = mock(
                ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder.class);
        when(itemVistoriaOcorrenciaDTOBuilder3.ativo(Mockito.<Boolean>any())).thenReturn(itemVistoriaOcorrenciaDTOBuilder2);
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder ativoResult = itemVistoriaOcorrenciaDTOBuilder3
                .ativo(true);
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder nomeResult = ativoResult
                .dataInclusao(LocalDate.of(1970, 1, 1))
                .descricao("Descricao")
                .id(1L)
                .nome(null);
        ItemVistoriaOcorrenciaDTO buildResult = nomeResult.subitemVistoriaDTOS(new ArrayList<>()).build();
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder itemVistoriaOcorrenciaDTOBuilder4 = mock(
                ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder.class);
        when(itemVistoriaOcorrenciaDTOBuilder4.ativo(Mockito.<Boolean>any()))
                .thenReturn(ItemVistoriaOcorrenciaDTO.builder());
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder ativoResult2 = itemVistoriaOcorrenciaDTOBuilder4
                .ativo(true);
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder nomeResult2 = ativoResult2
                .dataInclusao(LocalDate.of(1970, 1, 1))
                .descricao("Descricao")
                .id(1L)
                .nome("Nome");
        ItemVistoriaOcorrenciaDTO buildResult2 = nomeResult2.subitemVistoriaDTOS(new ArrayList<>()).build();

        // Act and Assert
        assertNotEquals(buildResult, buildResult2);
    }

    /**
     * Method under test: {@link ItemVistoriaOcorrenciaDTO#equals(Object)}
     */
    @Test
    void testEquals9() {
        // Arrange
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder itemVistoriaOcorrenciaDTOBuilder = mock(
                ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder.class);
        when(itemVistoriaOcorrenciaDTOBuilder.descricao(Mockito.<String>any()))
                .thenReturn(ItemVistoriaOcorrenciaDTO.builder());
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder itemVistoriaOcorrenciaDTOBuilder2 = mock(
                ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder.class);
        when(itemVistoriaOcorrenciaDTOBuilder2.dataInclusao(Mockito.<LocalDate>any()))
                .thenReturn(itemVistoriaOcorrenciaDTOBuilder);
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder itemVistoriaOcorrenciaDTOBuilder3 = mock(
                ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder.class);
        when(itemVistoriaOcorrenciaDTOBuilder3.ativo(Mockito.<Boolean>any())).thenReturn(itemVistoriaOcorrenciaDTOBuilder2);
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder ativoResult = itemVistoriaOcorrenciaDTOBuilder3
                .ativo(true);
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder nomeResult = ativoResult
                .dataInclusao(LocalDate.of(1970, 1, 1))
                .descricao("Descricao")
                .id(1L)
                .nome("42");
        ItemVistoriaOcorrenciaDTO buildResult = nomeResult.subitemVistoriaDTOS(new ArrayList<>()).build();
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder itemVistoriaOcorrenciaDTOBuilder4 = mock(
                ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder.class);
        when(itemVistoriaOcorrenciaDTOBuilder4.ativo(Mockito.<Boolean>any()))
                .thenReturn(ItemVistoriaOcorrenciaDTO.builder());
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder ativoResult2 = itemVistoriaOcorrenciaDTOBuilder4
                .ativo(true);
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder nomeResult2 = ativoResult2
                .dataInclusao(LocalDate.of(1970, 1, 1))
                .descricao("Descricao")
                .id(1L)
                .nome("Nome");
        ItemVistoriaOcorrenciaDTO buildResult2 = nomeResult2.subitemVistoriaDTOS(new ArrayList<>()).build();

        // Act and Assert
        assertNotEquals(buildResult, buildResult2);
    }

    /**
     * Method under test: {@link ItemVistoriaOcorrenciaDTO#equals(Object)}
     */
    @Test
    void testEquals10() {
        // Arrange
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder itemVistoriaOcorrenciaDTOBuilder = mock(
                ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder.class);
        when(itemVistoriaOcorrenciaDTOBuilder.descricao(Mockito.<String>any()))
                .thenReturn(ItemVistoriaOcorrenciaDTO.builder());
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder itemVistoriaOcorrenciaDTOBuilder2 = mock(
                ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder.class);
        when(itemVistoriaOcorrenciaDTOBuilder2.dataInclusao(Mockito.<LocalDate>any()))
                .thenReturn(itemVistoriaOcorrenciaDTOBuilder);
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder itemVistoriaOcorrenciaDTOBuilder3 = mock(
                ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder.class);
        when(itemVistoriaOcorrenciaDTOBuilder3.ativo(Mockito.<Boolean>any())).thenReturn(itemVistoriaOcorrenciaDTOBuilder2);
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder ativoResult = itemVistoriaOcorrenciaDTOBuilder3
                .ativo(true);
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder nomeResult = ativoResult
                .dataInclusao(LocalDate.of(1970, 1, 1))
                .descricao("Descricao")
                .id(1L)
                .nome("Nome");
        ItemVistoriaOcorrenciaDTO buildResult = nomeResult.subitemVistoriaDTOS(new ArrayList<>()).build();
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder itemVistoriaOcorrenciaDTOBuilder4 = mock(
                ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder.class);
        when(itemVistoriaOcorrenciaDTOBuilder4.ativo(Mockito.<Boolean>any()))
                .thenReturn(ItemVistoriaOcorrenciaDTO.builder());
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder ativoResult2 = itemVistoriaOcorrenciaDTOBuilder4
                .ativo(true);
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder nomeResult2 = ativoResult2
                .dataInclusao(LocalDate.of(1970, 1, 1))
                .descricao(null)
                .id(1L)
                .nome("Nome");
        ItemVistoriaOcorrenciaDTO buildResult2 = nomeResult2.subitemVistoriaDTOS(new ArrayList<>()).build();

        // Act and Assert
        assertNotEquals(buildResult, buildResult2);
    }

    /**
     * Method under test: {@link ItemVistoriaOcorrenciaDTO#equals(Object)}
     */
    @Test
    void testEquals11() {
        // Arrange
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder builderResult = ItemVistoriaOcorrenciaDTO.builder();
        builderResult.descricao("Nome");
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder itemVistoriaOcorrenciaDTOBuilder = mock(
                ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder.class);
        when(itemVistoriaOcorrenciaDTOBuilder.descricao(Mockito.<String>any())).thenReturn(builderResult);
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder itemVistoriaOcorrenciaDTOBuilder2 = mock(
                ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder.class);
        when(itemVistoriaOcorrenciaDTOBuilder2.dataInclusao(Mockito.<LocalDate>any()))
                .thenReturn(itemVistoriaOcorrenciaDTOBuilder);
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder itemVistoriaOcorrenciaDTOBuilder3 = mock(
                ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder.class);
        when(itemVistoriaOcorrenciaDTOBuilder3.ativo(Mockito.<Boolean>any())).thenReturn(itemVistoriaOcorrenciaDTOBuilder2);
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder ativoResult = itemVistoriaOcorrenciaDTOBuilder3
                .ativo(true);
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder nomeResult = ativoResult
                .dataInclusao(LocalDate.of(1970, 1, 1))
                .descricao("Descricao")
                .id(1L)
                .nome("Nome");
        ItemVistoriaOcorrenciaDTO buildResult = nomeResult.subitemVistoriaDTOS(new ArrayList<>()).build();
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder itemVistoriaOcorrenciaDTOBuilder4 = mock(
                ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder.class);
        when(itemVistoriaOcorrenciaDTOBuilder4.ativo(Mockito.<Boolean>any()))
                .thenReturn(ItemVistoriaOcorrenciaDTO.builder());
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder ativoResult2 = itemVistoriaOcorrenciaDTOBuilder4
                .ativo(true);
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder nomeResult2 = ativoResult2
                .dataInclusao(LocalDate.of(1970, 1, 1))
                .descricao("Descricao")
                .id(1L)
                .nome("Nome");
        ItemVistoriaOcorrenciaDTO buildResult2 = nomeResult2.subitemVistoriaDTOS(new ArrayList<>()).build();

        // Act and Assert
        assertNotEquals(buildResult, buildResult2);
    }

    /**
     * Method under test: {@link ItemVistoriaOcorrenciaDTO#equals(Object)}
     */
    @Test
    void testEquals12() {
        // Arrange
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder builderResult = ItemVistoriaOcorrenciaDTO.builder();
        builderResult.ativo(true);
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder itemVistoriaOcorrenciaDTOBuilder = mock(
                ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder.class);
        when(itemVistoriaOcorrenciaDTOBuilder.descricao(Mockito.<String>any())).thenReturn(builderResult);
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder itemVistoriaOcorrenciaDTOBuilder2 = mock(
                ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder.class);
        when(itemVistoriaOcorrenciaDTOBuilder2.dataInclusao(Mockito.<LocalDate>any()))
                .thenReturn(itemVistoriaOcorrenciaDTOBuilder);
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder itemVistoriaOcorrenciaDTOBuilder3 = mock(
                ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder.class);
        when(itemVistoriaOcorrenciaDTOBuilder3.ativo(Mockito.<Boolean>any())).thenReturn(itemVistoriaOcorrenciaDTOBuilder2);
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder ativoResult = itemVistoriaOcorrenciaDTOBuilder3
                .ativo(true);
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder nomeResult = ativoResult
                .dataInclusao(LocalDate.of(1970, 1, 1))
                .descricao("Descricao")
                .id(1L)
                .nome("Nome");
        ItemVistoriaOcorrenciaDTO buildResult = nomeResult.subitemVistoriaDTOS(new ArrayList<>()).build();
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder itemVistoriaOcorrenciaDTOBuilder4 = mock(
                ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder.class);
        when(itemVistoriaOcorrenciaDTOBuilder4.ativo(Mockito.<Boolean>any()))
                .thenReturn(ItemVistoriaOcorrenciaDTO.builder());
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder ativoResult2 = itemVistoriaOcorrenciaDTOBuilder4
                .ativo(true);
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder nomeResult2 = ativoResult2
                .dataInclusao(LocalDate.of(1970, 1, 1))
                .descricao("Descricao")
                .id(1L)
                .nome("Nome");
        ItemVistoriaOcorrenciaDTO buildResult2 = nomeResult2.subitemVistoriaDTOS(new ArrayList<>()).build();

        // Act and Assert
        assertNotEquals(buildResult, buildResult2);
    }

    /**
     * Method under test: {@link ItemVistoriaOcorrenciaDTO#equals(Object)}
     */
    @Test
    void testEquals13() {
        // Arrange
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder itemVistoriaOcorrenciaDTOBuilder = mock(
                ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder.class);
        when(itemVistoriaOcorrenciaDTOBuilder.descricao(Mockito.<String>any()))
                .thenReturn(ItemVistoriaOcorrenciaDTO.builder());
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder itemVistoriaOcorrenciaDTOBuilder2 = mock(
                ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder.class);
        when(itemVistoriaOcorrenciaDTOBuilder2.dataInclusao(Mockito.<LocalDate>any()))
                .thenReturn(itemVistoriaOcorrenciaDTOBuilder);
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder itemVistoriaOcorrenciaDTOBuilder3 = mock(
                ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder.class);
        when(itemVistoriaOcorrenciaDTOBuilder3.ativo(Mockito.<Boolean>any())).thenReturn(itemVistoriaOcorrenciaDTOBuilder2);
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder ativoResult = itemVistoriaOcorrenciaDTOBuilder3
                .ativo(true);
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder nomeResult = ativoResult
                .dataInclusao(LocalDate.of(1970, 1, 1))
                .descricao("Descricao")
                .id(1L)
                .nome(null);
        ItemVistoriaOcorrenciaDTO buildResult = nomeResult.subitemVistoriaDTOS(new ArrayList<>()).build();
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder itemVistoriaOcorrenciaDTOBuilder4 = mock(
                ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder.class);
        when(itemVistoriaOcorrenciaDTOBuilder4.ativo(Mockito.<Boolean>any()))
                .thenReturn(ItemVistoriaOcorrenciaDTO.builder());
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder ativoResult2 = itemVistoriaOcorrenciaDTOBuilder4
                .ativo(true);
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder nomeResult2 = ativoResult2
                .dataInclusao(LocalDate.of(1970, 1, 1))
                .descricao("Descricao")
                .id(1L)
                .nome(null);
        ItemVistoriaOcorrenciaDTO buildResult2 = nomeResult2.subitemVistoriaDTOS(new ArrayList<>()).build();

        // Act and Assert
        assertNotEquals(buildResult, buildResult2);
    }

    /**
     * Method under test: {@link ItemVistoriaOcorrenciaDTO#equals(Object)}
     */
    @Test
    void testEquals14() {
        // Arrange
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder itemVistoriaOcorrenciaDTOBuilder = mock(
                ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder.class);
        when(itemVistoriaOcorrenciaDTOBuilder.descricao(Mockito.<String>any()))
                .thenReturn(ItemVistoriaOcorrenciaDTO.builder());
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder itemVistoriaOcorrenciaDTOBuilder2 = mock(
                ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder.class);
        when(itemVistoriaOcorrenciaDTOBuilder2.dataInclusao(Mockito.<LocalDate>any()))
                .thenReturn(itemVistoriaOcorrenciaDTOBuilder);
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder itemVistoriaOcorrenciaDTOBuilder3 = mock(
                ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder.class);
        when(itemVistoriaOcorrenciaDTOBuilder3.ativo(Mockito.<Boolean>any())).thenReturn(itemVistoriaOcorrenciaDTOBuilder2);
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder ativoResult = itemVistoriaOcorrenciaDTOBuilder3
                .ativo(true);
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder nomeResult = ativoResult
                .dataInclusao(LocalDate.of(1970, 1, 1))
                .descricao("Descricao")
                .id(1L)
                .nome("Nome");

        ArrayList<SubitemVistoriaDTO> subitemVistoriaDTOS = new ArrayList<>();
        SubitemVistoriaDTO.SubitemVistoriaDTOBuilder ativoResult2 = SubitemVistoriaDTO.builder().ativo(true);
        SubitemVistoriaDTO.SubitemVistoriaDTOBuilder dataInclusaoResult = ativoResult2
                .dataInclusao(LocalDate.of(1970, 1, 1));
        SubitemVistoriaDTO buildResult = dataInclusaoResult.defeitos(new ArrayList<>())
                .descricao("Descricao")
                .id(1L)
                .nome("Nome")
                .build();
        subitemVistoriaDTOS.add(buildResult);
        ItemVistoriaOcorrenciaDTO buildResult2 = nomeResult.subitemVistoriaDTOS(subitemVistoriaDTOS).build();
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder itemVistoriaOcorrenciaDTOBuilder4 = mock(
                ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder.class);
        when(itemVistoriaOcorrenciaDTOBuilder4.dataInclusao(Mockito.<LocalDate>any()))
                .thenReturn(ItemVistoriaOcorrenciaDTO.builder());
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder itemVistoriaOcorrenciaDTOBuilder5 = mock(
                ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder.class);
        when(itemVistoriaOcorrenciaDTOBuilder5.ativo(Mockito.<Boolean>any())).thenReturn(itemVistoriaOcorrenciaDTOBuilder4);
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder ativoResult3 = itemVistoriaOcorrenciaDTOBuilder5
                .ativo(true);
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder nomeResult2 = ativoResult3
                .dataInclusao(LocalDate.of(1970, 1, 1))
                .descricao(null)
                .id(1L)
                .nome("Nome");
        ItemVistoriaOcorrenciaDTO buildResult3 = nomeResult2.subitemVistoriaDTOS(new ArrayList<>()).build();

        // Act and Assert
        assertNotEquals(buildResult2, buildResult3);
    }

    /**
     * Method under test: {@link ItemVistoriaOcorrenciaDTO#equals(Object)}
     */
    @Test
    void testEquals15() {
        // Arrange
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder builderResult = ItemVistoriaOcorrenciaDTO.builder();
        builderResult.dataInclusao(LocalDate.of(1970, 1, 1));
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder itemVistoriaOcorrenciaDTOBuilder = mock(
                ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder.class);
        when(itemVistoriaOcorrenciaDTOBuilder.descricao(Mockito.<String>any())).thenReturn(builderResult);
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder itemVistoriaOcorrenciaDTOBuilder2 = mock(
                ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder.class);
        when(itemVistoriaOcorrenciaDTOBuilder2.dataInclusao(Mockito.<LocalDate>any()))
                .thenReturn(itemVistoriaOcorrenciaDTOBuilder);
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder itemVistoriaOcorrenciaDTOBuilder3 = mock(
                ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder.class);
        when(itemVistoriaOcorrenciaDTOBuilder3.ativo(Mockito.<Boolean>any())).thenReturn(itemVistoriaOcorrenciaDTOBuilder2);
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder ativoResult = itemVistoriaOcorrenciaDTOBuilder3
                .ativo(true);
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder nomeResult = ativoResult
                .dataInclusao(LocalDate.of(1970, 1, 1))
                .descricao("Descricao")
                .id(1L)
                .nome("Nome");
        ItemVistoriaOcorrenciaDTO buildResult = nomeResult.subitemVistoriaDTOS(new ArrayList<>()).build();
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder itemVistoriaOcorrenciaDTOBuilder4 = mock(
                ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder.class);
        when(itemVistoriaOcorrenciaDTOBuilder4.dataInclusao(Mockito.<LocalDate>any()))
                .thenReturn(ItemVistoriaOcorrenciaDTO.builder());
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder itemVistoriaOcorrenciaDTOBuilder5 = mock(
                ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder.class);
        when(itemVistoriaOcorrenciaDTOBuilder5.ativo(Mockito.<Boolean>any())).thenReturn(itemVistoriaOcorrenciaDTOBuilder4);
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder ativoResult2 = itemVistoriaOcorrenciaDTOBuilder5
                .ativo(true);
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder nomeResult2 = ativoResult2
                .dataInclusao(LocalDate.of(1970, 1, 1))
                .descricao(null)
                .id(1L)
                .nome("Nome");
        ItemVistoriaOcorrenciaDTO buildResult2 = nomeResult2.subitemVistoriaDTOS(new ArrayList<>()).build();

        // Act and Assert
        assertNotEquals(buildResult, buildResult2);
    }

    /**
     * Methods under test:
     * <ul>
     *   <li>{@link ItemVistoriaOcorrenciaDTO#equals(Object)}
     *   <li>{@link ItemVistoriaOcorrenciaDTO#hashCode()}
     * </ul>
     */
    @Test
    void testEqualsAndHashCode() {
        // Arrange
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder ativoResult = ItemVistoriaOcorrenciaDTO.builder()
                .ativo(true);
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder nomeResult = ativoResult
                .dataInclusao(LocalDate.of(1970, 1, 1))
                .descricao("Descricao")
                .id(1L)
                .nome("Nome");
        ItemVistoriaOcorrenciaDTO buildResult = nomeResult.subitemVistoriaDTOS(new ArrayList<>()).build();

        // Act and Assert
        assertEquals(buildResult, buildResult);
        int expectedHashCodeResult = buildResult.hashCode();
        assertEquals(expectedHashCodeResult, buildResult.hashCode());
    }

    /**
     * Methods under test:
     * <ul>
     *   <li>{@link ItemVistoriaOcorrenciaDTO#equals(Object)}
     *   <li>{@link ItemVistoriaOcorrenciaDTO#hashCode()}
     * </ul>
     */
    @Test
    void testEqualsAndHashCode2() {
        // Arrange
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder ativoResult = ItemVistoriaOcorrenciaDTO.builder()
                .ativo(true);
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder nomeResult = ativoResult
                .dataInclusao(LocalDate.of(1970, 1, 1))
                .descricao("Descricao")
                .id(1L)
                .nome("Nome");
        ItemVistoriaOcorrenciaDTO buildResult = nomeResult.subitemVistoriaDTOS(new ArrayList<>()).build();
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder ativoResult2 = ItemVistoriaOcorrenciaDTO.builder()
                .ativo(true);
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder nomeResult2 = ativoResult2
                .dataInclusao(LocalDate.of(1970, 1, 1))
                .descricao("Descricao")
                .id(1L)
                .nome("Nome");
        ItemVistoriaOcorrenciaDTO buildResult2 = nomeResult2.subitemVistoriaDTOS(new ArrayList<>()).build();

        // Act and Assert
        assertEquals(buildResult, buildResult2);
        int expectedHashCodeResult = buildResult.hashCode();
        assertEquals(expectedHashCodeResult, buildResult2.hashCode());
    }

    /**
     * Methods under test:
     * <ul>
     *   <li>{@link ItemVistoriaOcorrenciaDTO#equals(Object)}
     *   <li>{@link ItemVistoriaOcorrenciaDTO#hashCode()}
     * </ul>
     */
    @Test
    void testEqualsAndHashCode3() {
        // Arrange
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder itemVistoriaOcorrenciaDTOBuilder = mock(
                ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder.class);
        when(itemVistoriaOcorrenciaDTOBuilder.ativo(Mockito.<Boolean>any()))
                .thenReturn(ItemVistoriaOcorrenciaDTO.builder());
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder ativoResult = itemVistoriaOcorrenciaDTOBuilder
                .ativo(true);
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder nomeResult = ativoResult
                .dataInclusao(LocalDate.of(1970, 1, 1))
                .descricao("Descricao")
                .id(1L)
                .nome("Nome");
        ItemVistoriaOcorrenciaDTO buildResult = nomeResult.subitemVistoriaDTOS(new ArrayList<>()).build();
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder itemVistoriaOcorrenciaDTOBuilder2 = mock(
                ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder.class);
        when(itemVistoriaOcorrenciaDTOBuilder2.ativo(Mockito.<Boolean>any()))
                .thenReturn(ItemVistoriaOcorrenciaDTO.builder());
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder ativoResult2 = itemVistoriaOcorrenciaDTOBuilder2
                .ativo(true);
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder nomeResult2 = ativoResult2
                .dataInclusao(LocalDate.of(1970, 1, 1))
                .descricao("Descricao")
                .id(1L)
                .nome("Nome");
        ItemVistoriaOcorrenciaDTO buildResult2 = nomeResult2.subitemVistoriaDTOS(new ArrayList<>()).build();

        // Act and Assert
        assertEquals(buildResult, buildResult2);
        int expectedHashCodeResult = buildResult.hashCode();
        assertEquals(expectedHashCodeResult, buildResult2.hashCode());
    }

    /**
     * Methods under test:
     * <ul>
     *   <li>{@link ItemVistoriaOcorrenciaDTO#equals(Object)}
     *   <li>{@link ItemVistoriaOcorrenciaDTO#hashCode()}
     * </ul>
     */
    @Test
    void testEqualsAndHashCode4() {
        // Arrange
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder itemVistoriaOcorrenciaDTOBuilder = mock(
                ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder.class);
        when(itemVistoriaOcorrenciaDTOBuilder.descricao(Mockito.<String>any()))
                .thenReturn(ItemVistoriaOcorrenciaDTO.builder());
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder itemVistoriaOcorrenciaDTOBuilder2 = mock(
                ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder.class);
        when(itemVistoriaOcorrenciaDTOBuilder2.dataInclusao(Mockito.<LocalDate>any()))
                .thenReturn(itemVistoriaOcorrenciaDTOBuilder);
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder itemVistoriaOcorrenciaDTOBuilder3 = mock(
                ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder.class);
        when(itemVistoriaOcorrenciaDTOBuilder3.ativo(Mockito.<Boolean>any())).thenReturn(itemVistoriaOcorrenciaDTOBuilder2);
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder ativoResult = itemVistoriaOcorrenciaDTOBuilder3
                .ativo(true);
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder nomeResult = ativoResult
                .dataInclusao(LocalDate.of(1970, 1, 1))
                .descricao("Descricao")
                .id(1L)
                .nome("Nome");
        ItemVistoriaOcorrenciaDTO buildResult = nomeResult.subitemVistoriaDTOS(new ArrayList<>()).build();
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder itemVistoriaOcorrenciaDTOBuilder4 = mock(
                ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder.class);
        when(itemVistoriaOcorrenciaDTOBuilder4.dataInclusao(Mockito.<LocalDate>any()))
                .thenReturn(ItemVistoriaOcorrenciaDTO.builder());
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder itemVistoriaOcorrenciaDTOBuilder5 = mock(
                ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder.class);
        when(itemVistoriaOcorrenciaDTOBuilder5.ativo(Mockito.<Boolean>any())).thenReturn(itemVistoriaOcorrenciaDTOBuilder4);
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder ativoResult2 = itemVistoriaOcorrenciaDTOBuilder5
                .ativo(true);
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder nomeResult2 = ativoResult2
                .dataInclusao(LocalDate.of(1970, 1, 1))
                .descricao(null)
                .id(1L)
                .nome("Nome");
        ItemVistoriaOcorrenciaDTO buildResult2 = nomeResult2.subitemVistoriaDTOS(new ArrayList<>()).build();

        // Act and Assert
        assertEquals(buildResult, buildResult2);
        int expectedHashCodeResult = buildResult.hashCode();
        assertEquals(expectedHashCodeResult, buildResult2.hashCode());
    }

    /**
     * Methods under test:
     * <ul>
     *   <li>{@link ItemVistoriaOcorrenciaDTO#ItemVistoriaOcorrenciaDTO()}
     *   <li>{@link ItemVistoriaOcorrenciaDTO#setAtivo(Boolean)}
     *   <li>{@link ItemVistoriaOcorrenciaDTO#setDataInclusao(LocalDate)}
     *   <li>{@link ItemVistoriaOcorrenciaDTO#setDescricao(String)}
     *   <li>{@link ItemVistoriaOcorrenciaDTO#setId(Long)}
     *   <li>{@link ItemVistoriaOcorrenciaDTO#setNome(String)}
     *   <li>{@link ItemVistoriaOcorrenciaDTO#setSubitemVistoriaDTOS(List)}
     *   <li>{@link ItemVistoriaOcorrenciaDTO#toString()}
     *   <li>{@link ItemVistoriaOcorrenciaDTO#getAtivo()}
     *   <li>{@link ItemVistoriaOcorrenciaDTO#getDataInclusao()}
     *   <li>{@link ItemVistoriaOcorrenciaDTO#getDescricao()}
     *   <li>{@link ItemVistoriaOcorrenciaDTO#getId()}
     *   <li>{@link ItemVistoriaOcorrenciaDTO#getNome()}
     *   <li>{@link ItemVistoriaOcorrenciaDTO#getSubitemVistoriaDTOS()}
     * </ul>
     */
    @Test
    void testGettersAndSetters() {
        // Arrange and Act
        ItemVistoriaOcorrenciaDTO actualItemVistoriaOcorrenciaDTO = new ItemVistoriaOcorrenciaDTO();
        actualItemVistoriaOcorrenciaDTO.setAtivo(true);
        LocalDate dataInclusao = LocalDate.of(1970, 1, 1);
        actualItemVistoriaOcorrenciaDTO.setDataInclusao(dataInclusao);
        actualItemVistoriaOcorrenciaDTO.setDescricao("Descricao");
        actualItemVistoriaOcorrenciaDTO.setId(1L);
        actualItemVistoriaOcorrenciaDTO.setNome("Nome");
        ArrayList<SubitemVistoriaDTO> subitemVistoriaDTOS = new ArrayList<>();
        actualItemVistoriaOcorrenciaDTO.setSubitemVistoriaDTOS(subitemVistoriaDTOS);
        String actualToStringResult = actualItemVistoriaOcorrenciaDTO.toString();
        Boolean actualAtivo = actualItemVistoriaOcorrenciaDTO.getAtivo();
        LocalDate actualDataInclusao = actualItemVistoriaOcorrenciaDTO.getDataInclusao();
        String actualDescricao = actualItemVistoriaOcorrenciaDTO.getDescricao();
        Long actualId = actualItemVistoriaOcorrenciaDTO.getId();
        String actualNome = actualItemVistoriaOcorrenciaDTO.getNome();
        List<SubitemVistoriaDTO> actualSubitemVistoriaDTOS = actualItemVistoriaOcorrenciaDTO.getSubitemVistoriaDTOS();

        // Assert that nothing has changed
        assertEquals("Descricao", actualDescricao);
        assertEquals("ItemVistoriaOcorrenciaDTO(id=1, nome=Nome, descricao=Descricao, dataInclusao=1970-01-01, ativo=true,"
                + " subitemVistoriaDTOS=[])", actualToStringResult);
        assertEquals("Nome", actualNome);
        assertEquals(1L, actualId.longValue());
        assertTrue(actualAtivo);
        assertSame(subitemVistoriaDTOS, actualSubitemVistoriaDTOS);
        assertSame(dataInclusao, actualDataInclusao);
    }

    /**
     * Methods under test:
     * <ul>
     *   <li>
     * {@link ItemVistoriaOcorrenciaDTO#ItemVistoriaOcorrenciaDTO(Long, String, String, LocalDate, Boolean, List)}
     *   <li>{@link ItemVistoriaOcorrenciaDTO#setAtivo(Boolean)}
     *   <li>{@link ItemVistoriaOcorrenciaDTO#setDataInclusao(LocalDate)}
     *   <li>{@link ItemVistoriaOcorrenciaDTO#setDescricao(String)}
     *   <li>{@link ItemVistoriaOcorrenciaDTO#setId(Long)}
     *   <li>{@link ItemVistoriaOcorrenciaDTO#setNome(String)}
     *   <li>{@link ItemVistoriaOcorrenciaDTO#setSubitemVistoriaDTOS(List)}
     *   <li>{@link ItemVistoriaOcorrenciaDTO#toString()}
     *   <li>{@link ItemVistoriaOcorrenciaDTO#getAtivo()}
     *   <li>{@link ItemVistoriaOcorrenciaDTO#getDataInclusao()}
     *   <li>{@link ItemVistoriaOcorrenciaDTO#getDescricao()}
     *   <li>{@link ItemVistoriaOcorrenciaDTO#getId()}
     *   <li>{@link ItemVistoriaOcorrenciaDTO#getNome()}
     *   <li>{@link ItemVistoriaOcorrenciaDTO#getSubitemVistoriaDTOS()}
     * </ul>
     */
    @Test
    void testGettersAndSetters2() {
        // Arrange
        LocalDate dataInclusao = LocalDate.of(1970, 1, 1);
        ArrayList<SubitemVistoriaDTO> subitemVistoriaDTOS = new ArrayList<>();

        // Act
        ItemVistoriaOcorrenciaDTO actualItemVistoriaOcorrenciaDTO = new ItemVistoriaOcorrenciaDTO(1L, "Nome", "Descricao",
                dataInclusao, true, subitemVistoriaDTOS);
        actualItemVistoriaOcorrenciaDTO.setAtivo(true);
        LocalDate dataInclusao2 = LocalDate.of(1970, 1, 1);
        actualItemVistoriaOcorrenciaDTO.setDataInclusao(dataInclusao2);
        actualItemVistoriaOcorrenciaDTO.setDescricao("Descricao");
        actualItemVistoriaOcorrenciaDTO.setId(1L);
        actualItemVistoriaOcorrenciaDTO.setNome("Nome");
        ArrayList<SubitemVistoriaDTO> subitemVistoriaDTOS2 = new ArrayList<>();
        actualItemVistoriaOcorrenciaDTO.setSubitemVistoriaDTOS(subitemVistoriaDTOS2);
        String actualToStringResult = actualItemVistoriaOcorrenciaDTO.toString();
        Boolean actualAtivo = actualItemVistoriaOcorrenciaDTO.getAtivo();
        LocalDate actualDataInclusao = actualItemVistoriaOcorrenciaDTO.getDataInclusao();
        String actualDescricao = actualItemVistoriaOcorrenciaDTO.getDescricao();
        Long actualId = actualItemVistoriaOcorrenciaDTO.getId();
        String actualNome = actualItemVistoriaOcorrenciaDTO.getNome();
        List<SubitemVistoriaDTO> actualSubitemVistoriaDTOS = actualItemVistoriaOcorrenciaDTO.getSubitemVistoriaDTOS();

        // Assert that nothing has changed
        assertEquals("Descricao", actualDescricao);
        assertEquals("ItemVistoriaOcorrenciaDTO(id=1, nome=Nome, descricao=Descricao, dataInclusao=1970-01-01, ativo=true,"
                + " subitemVistoriaDTOS=[])", actualToStringResult);
        assertEquals("Nome", actualNome);
        assertEquals(1L, actualId.longValue());
        assertTrue(actualAtivo);
        assertEquals(subitemVistoriaDTOS, actualSubitemVistoriaDTOS);
        assertSame(subitemVistoriaDTOS2, actualSubitemVistoriaDTOS);
        assertSame(dataInclusao2, actualDataInclusao);
    }
}
