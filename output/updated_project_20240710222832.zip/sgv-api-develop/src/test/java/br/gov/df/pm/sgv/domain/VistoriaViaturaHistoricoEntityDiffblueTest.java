package br.gov.df.pm.sgv.domain;

import br.gov.df.pm.sgv.domain.enums.VistoriaViaturaStatusEnum;
import br.gov.df.pm.sgv.domain.sgpol.Pessoa;
import br.gov.df.pm.sgv.domain.sgpol.Policial;
import br.gov.df.pm.sgv.domain.sgpol.UnidadePolicialMilitar;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Date;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class VistoriaViaturaHistoricoEntityDiffblueTest {
    /**
     * Methods under test:
     * <ul>
     *   <li>{@link VistoriaViaturaHistoricoEntity#VistoriaViaturaHistoricoEntity()}
     *   <li>{@link VistoriaViaturaHistoricoEntity#setData(Date)}
     *   <li>{@link VistoriaViaturaHistoricoEntity#setId(Long)}
     *   <li>{@link VistoriaViaturaHistoricoEntity#setPolicial(Policial)}
     *   <li>
     * {@link VistoriaViaturaHistoricoEntity#setStatus(VistoriaViaturaStatusEnum)}
     *   <li>
     * {@link VistoriaViaturaHistoricoEntity#setUnidadePolicialMilitar(UnidadePolicialMilitar)}
     *   <li>
     * {@link VistoriaViaturaHistoricoEntity#setVistoriaViatura(VistoriaViaturaEntity)}
     *   <li>{@link VistoriaViaturaHistoricoEntity#getData()}
     *   <li>{@link VistoriaViaturaHistoricoEntity#getId()}
     *   <li>{@link VistoriaViaturaHistoricoEntity#getPolicial()}
     *   <li>{@link VistoriaViaturaHistoricoEntity#getStatus()}
     *   <li>{@link VistoriaViaturaHistoricoEntity#getUnidadePolicialMilitar()}
     *   <li>{@link VistoriaViaturaHistoricoEntity#getVistoriaViatura()}
     * </ul>
     */
    @Test
    void testGettersAndSetters() {
        // Arrange and Act
        VistoriaViaturaHistoricoEntity actualVistoriaViaturaHistoricoEntity = new VistoriaViaturaHistoricoEntity();
        Date data = Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant());
        actualVistoriaViaturaHistoricoEntity.setData(data);
        actualVistoriaViaturaHistoricoEntity.setId(1L);
        Pessoa idPessoa = new Pessoa();
        idPessoa.setAcessoRestrito(true);
        idPessoa.setBloqueado(true);
        idPessoa.setCertidaocivil(1);
        idPessoa.setCnhDataEmissao(LocalDate.of(1970, 1, 1));
        idPessoa.setCnhDataPrimeira(LocalDate.of(1970, 1, 1));
        idPessoa.setCnhDataValidade(LocalDate.of(1970, 1, 1));
        idPessoa.setCnhRegistro("Cnh Registro");
        idPessoa.setCpf("Cpf");
        idPessoa.setDataAtualizacao(LocalDate.of(1970, 1, 1).atStartOfDay());
        idPessoa.setDataNascimento(LocalDate.of(1970, 1, 1));
        idPessoa.setDataPisPasep(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
        idPessoa.setId(1);
        idPessoa.setIdUsuario(1);
        idPessoa.setListPessoaRecurso(new ArrayList<>());
        idPessoa.setMensagemAlerta(true);
        idPessoa.setMensagemTela(true);
        idPessoa.setNome("Nome");
        idPessoa.setNomeAnterior("Nome Anterior");
        idPessoa.setNomeMae("Nome Mae");
        idPessoa.setNomePai("Nome Pai");
        idPessoa.setNomecurto("alice.liddell@example.org");
        idPessoa.setPerfis(new ArrayList<>());
        idPessoa.setPessoaPerfil(new ArrayList<>());
        idPessoa.setPisPasep("Pis Pasep");
        idPessoa.setProvaVidaValida(true);
        idPessoa.setRg("Rg");
        idPessoa.setRgDataEmissao(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
        idPessoa.setRgOrgaoExpedidor("Rg Orgao Expedidor");
        idPessoa.setStatusProvaVida(1);
        idPessoa.setTituloEleitorNumero("Titulo Eleitor Numero");
        idPessoa.setTituloEleitorSecao(1);
        idPessoa.setTituloEleitorZona(1);
        idPessoa.setTransacaoEgov("Transacao Egov");
        UnidadePolicialMilitar upm = new UnidadePolicialMilitar();
        upm.setAtivo(1);
        upm.setComandoRegional(true);
        upm.setId(1);
        upm.setNome("Nome");
        upm.setNomeHistorico("Nome Historico");
        upm.setSigla("Sigla");
        UnidadePolicialMilitar upmCodigoPolicialCedido = new UnidadePolicialMilitar();
        upmCodigoPolicialCedido.setAtivo(1);
        upmCodigoPolicialCedido.setComandoRegional(true);
        upmCodigoPolicialCedido.setId(1);
        upmCodigoPolicialCedido.setNome("Nome");
        upmCodigoPolicialCedido.setNomeHistorico("Nome Historico");
        upmCodigoPolicialCedido.setSigla("Sigla");
        Policial policial = new Policial();
        policial.setAlmanaque(1);
        policial.setAssistenciaMedica(true);
        policial.setCn("Cn");
        policial.setCtgrafiSuspenso(true);
        policial.setDataAdmissao(LocalDate.of(1970, 1, 1));
        policial.setDataPrevisaoFimAssistenciaMedica(LocalDate.of(1970, 1, 1));
        policial.setDataSuspensaoAssistenciaMedica(LocalDate.of(1970, 1, 1));
        policial.setGraduacaoAtual("Graduacao Atual");
        policial.setId(1);
        policial.setIdPessoa(idPessoa);
        policial.setIdentificacaoUnica("Identificacao Unica");
        policial.setLogin("Login");
        policial.setMatricula("Matricula");
        policial.setNomeGuerra("Nome Guerra");
        policial.setPorteSuspenso(true);
        policial.setRestrito(true);
        policial.setSiape("Siape");
        policial.setSirgh("Sirgh");
        policial.setUpm(upm);
        policial.setUpmCodigoPolicialCedido(upmCodigoPolicialCedido);
        actualVistoriaViaturaHistoricoEntity.setPolicial(policial);
        actualVistoriaViaturaHistoricoEntity.setStatus(VistoriaViaturaStatusEnum.DISPONIVEL);
        UnidadePolicialMilitar unidadePolicialMilitar = new UnidadePolicialMilitar();
        unidadePolicialMilitar.setAtivo(1);
        unidadePolicialMilitar.setComandoRegional(true);
        unidadePolicialMilitar.setId(1);
        unidadePolicialMilitar.setNome("Nome");
        unidadePolicialMilitar.setNomeHistorico("Nome Historico");
        unidadePolicialMilitar.setSigla("Sigla");
        actualVistoriaViaturaHistoricoEntity.setUnidadePolicialMilitar(unidadePolicialMilitar);
        TipoVistoriaEntity referenciaFinal = new TipoVistoriaEntity();
        referenciaFinal.setAtivo(true);
        referenciaFinal.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaFinal.setDescricao("Descricao");
        referenciaFinal.setId(1L);
        referenciaFinal.setNome("Nome");
        referenciaFinal.setStatusAnterior("Status Anterior");
        referenciaFinal.setStatusPosterior("Status Posterior");
        TipoVistoriaEntity referenciaInicial = new TipoVistoriaEntity();
        referenciaInicial.setAtivo(true);
        referenciaInicial.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaInicial.setDescricao("Descricao");
        referenciaInicial.setId(1L);
        referenciaInicial.setNome("Nome");
        referenciaInicial.setStatusAnterior("Status Anterior");
        referenciaInicial.setStatusPosterior("Status Posterior");
        DiferencaOdometroEntity diferencaOdometro = new DiferencaOdometroEntity();
        diferencaOdometro.setDataInclusao(LocalDate.of(1970, 1, 1));
        diferencaOdometro.setDataModificacao(LocalDate.of(1970, 1, 1));
        diferencaOdometro.setDiferencaOdometro(10.0d);
        diferencaOdometro.setId(1L);
        diferencaOdometro.setReferenciaFinal(referenciaFinal);
        diferencaOdometro.setReferenciaInicial(referenciaInicial);
        TipoVistoriaEntity tipoVistoria = new TipoVistoriaEntity();
        tipoVistoria.setAtivo(true);
        tipoVistoria.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoria.setDescricao("Descricao");
        tipoVistoria.setId(1L);
        tipoVistoria.setNome("Nome");
        tipoVistoria.setStatusAnterior("Status Anterior");
        tipoVistoria.setStatusPosterior("Status Posterior");
        TipoEmpregoViaturaEntity tipoEmpregoViatura = new TipoEmpregoViaturaEntity();
        tipoEmpregoViatura.setAtivo(1);
        tipoEmpregoViatura.setId(1);
        tipoEmpregoViatura.setNome("Nome");
        ViaturaEntity viatura = new ViaturaEntity();
        viatura.setAtivo(true);
        viatura.setDataAtualizacao(LocalDate.of(1970, 1, 1));
        viatura.setDataInclusao(LocalDate.of(1970, 1, 1));
        viatura.setId(1L);
        viatura.setListaUpm(new ArrayList<>());
        viatura.setMarcaModelo("Marca Modelo");
        viatura.setNrSei("Nr Sei");
        viatura.setPlaca("Placa");
        viatura.setPrefixo("Prefixo");
        viatura.setRenavam("Renavam");
        viatura.setStatus("Status");
        viatura.setTipoEmpregoViatura(tipoEmpregoViatura);
        viatura.setTombamento("alice.liddell@example.org");
        VistoriaViaturaEntity vistoriaViatura = new VistoriaViaturaEntity();
        vistoriaViatura.setCheckLists(new ArrayList<>());
        vistoriaViatura.setDataVistoria(LocalDate.of(1970, 1, 1).atStartOfDay());
        vistoriaViatura.setDiferencaOdometro(diferencaOdometro);
        vistoriaViatura.setDiferencaVistoria(true);
        vistoriaViatura.setId(1L);
        vistoriaViatura.setIdPolicial(1);
        vistoriaViatura.setIdUpm(1);
        vistoriaViatura.setOdometroFinal(10.0f);
        vistoriaViatura.setOdometroInicial(10.0f);
        vistoriaViatura.setStatus(VistoriaViaturaStatusEnum.DISPONIVEL);
        vistoriaViatura.setTipoVistoria(tipoVistoria);
        vistoriaViatura.setViatura(viatura);
        vistoriaViatura.setVistoriaArquivoList(new ArrayList<>());
        vistoriaViatura.setVistoriaViaturaHistorico(new ArrayList<>());
        actualVistoriaViaturaHistoricoEntity.setVistoriaViatura(vistoriaViatura);
        Date actualData = actualVistoriaViaturaHistoricoEntity.getData();
        Long actualId = actualVistoriaViaturaHistoricoEntity.getId();
        Policial actualPolicial = actualVistoriaViaturaHistoricoEntity.getPolicial();
        VistoriaViaturaStatusEnum actualStatus = actualVistoriaViaturaHistoricoEntity.getStatus();
        UnidadePolicialMilitar actualUnidadePolicialMilitar = actualVistoriaViaturaHistoricoEntity
                .getUnidadePolicialMilitar();
        VistoriaViaturaEntity actualVistoriaViatura = actualVistoriaViaturaHistoricoEntity.getVistoriaViatura();

        // Assert that nothing has changed
        assertEquals(1L, actualId.longValue());
        assertEquals(VistoriaViaturaStatusEnum.DISPONIVEL, actualStatus);
        assertSame(vistoriaViatura, actualVistoriaViatura);
        assertSame(policial, actualPolicial);
        assertSame(unidadePolicialMilitar, actualUnidadePolicialMilitar);
        assertSame(data, actualData);
    }

    /**
     * Methods under test:
     * <ul>
     *   <li>
     * {@link VistoriaViaturaHistoricoEntity#VistoriaViaturaHistoricoEntity(Long, UnidadePolicialMilitar, Policial, Date, VistoriaViaturaStatusEnum, VistoriaViaturaEntity)}
     *   <li>{@link VistoriaViaturaHistoricoEntity#setData(Date)}
     *   <li>{@link VistoriaViaturaHistoricoEntity#setId(Long)}
     *   <li>{@link VistoriaViaturaHistoricoEntity#setPolicial(Policial)}
     *   <li>
     * {@link VistoriaViaturaHistoricoEntity#setStatus(VistoriaViaturaStatusEnum)}
     *   <li>
     * {@link VistoriaViaturaHistoricoEntity#setUnidadePolicialMilitar(UnidadePolicialMilitar)}
     *   <li>
     * {@link VistoriaViaturaHistoricoEntity#setVistoriaViatura(VistoriaViaturaEntity)}
     *   <li>{@link VistoriaViaturaHistoricoEntity#getData()}
     *   <li>{@link VistoriaViaturaHistoricoEntity#getId()}
     *   <li>{@link VistoriaViaturaHistoricoEntity#getPolicial()}
     *   <li>{@link VistoriaViaturaHistoricoEntity#getStatus()}
     *   <li>{@link VistoriaViaturaHistoricoEntity#getUnidadePolicialMilitar()}
     *   <li>{@link VistoriaViaturaHistoricoEntity#getVistoriaViatura()}
     * </ul>
     */
    @Test
    void testGettersAndSetters2() {
        // Arrange
        UnidadePolicialMilitar unidadePolicialMilitar = new UnidadePolicialMilitar();
        unidadePolicialMilitar.setAtivo(1);
        unidadePolicialMilitar.setComandoRegional(true);
        unidadePolicialMilitar.setId(1);
        unidadePolicialMilitar.setNome("Nome");
        unidadePolicialMilitar.setNomeHistorico("Nome Historico");
        unidadePolicialMilitar.setSigla("Sigla");

        Pessoa idPessoa = new Pessoa();
        idPessoa.setAcessoRestrito(true);
        idPessoa.setBloqueado(true);
        idPessoa.setCertidaocivil(1);
        idPessoa.setCnhDataEmissao(LocalDate.of(1970, 1, 1));
        idPessoa.setCnhDataPrimeira(LocalDate.of(1970, 1, 1));
        idPessoa.setCnhDataValidade(LocalDate.of(1970, 1, 1));
        idPessoa.setCnhRegistro("Cnh Registro");
        idPessoa.setCpf("Cpf");
        idPessoa.setDataAtualizacao(LocalDate.of(1970, 1, 1).atStartOfDay());
        idPessoa.setDataNascimento(LocalDate.of(1970, 1, 1));
        idPessoa.setDataPisPasep(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
        idPessoa.setId(1);
        idPessoa.setIdUsuario(1);
        idPessoa.setListPessoaRecurso(new ArrayList<>());
        idPessoa.setMensagemAlerta(true);
        idPessoa.setMensagemTela(true);
        idPessoa.setNome("Nome");
        idPessoa.setNomeAnterior("Nome Anterior");
        idPessoa.setNomeMae("Nome Mae");
        idPessoa.setNomePai("Nome Pai");
        idPessoa.setNomecurto("alice.liddell@example.org");
        idPessoa.setPerfis(new ArrayList<>());
        idPessoa.setPessoaPerfil(new ArrayList<>());
        idPessoa.setPisPasep("Pis Pasep");
        idPessoa.setProvaVidaValida(true);
        idPessoa.setRg("Rg");
        idPessoa.setRgDataEmissao(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
        idPessoa.setRgOrgaoExpedidor("Rg Orgao Expedidor");
        idPessoa.setStatusProvaVida(1);
        idPessoa.setTituloEleitorNumero("Titulo Eleitor Numero");
        idPessoa.setTituloEleitorSecao(1);
        idPessoa.setTituloEleitorZona(1);
        idPessoa.setTransacaoEgov("Transacao Egov");

        UnidadePolicialMilitar upm = new UnidadePolicialMilitar();
        upm.setAtivo(1);
        upm.setComandoRegional(true);
        upm.setId(1);
        upm.setNome("Nome");
        upm.setNomeHistorico("Nome Historico");
        upm.setSigla("Sigla");

        UnidadePolicialMilitar upmCodigoPolicialCedido = new UnidadePolicialMilitar();
        upmCodigoPolicialCedido.setAtivo(1);
        upmCodigoPolicialCedido.setComandoRegional(true);
        upmCodigoPolicialCedido.setId(1);
        upmCodigoPolicialCedido.setNome("Nome");
        upmCodigoPolicialCedido.setNomeHistorico("Nome Historico");
        upmCodigoPolicialCedido.setSigla("Sigla");

        Policial policial = new Policial();
        policial.setAlmanaque(1);
        policial.setAssistenciaMedica(true);
        policial.setCn("Cn");
        policial.setCtgrafiSuspenso(true);
        policial.setDataAdmissao(LocalDate.of(1970, 1, 1));
        policial.setDataPrevisaoFimAssistenciaMedica(LocalDate.of(1970, 1, 1));
        policial.setDataSuspensaoAssistenciaMedica(LocalDate.of(1970, 1, 1));
        policial.setGraduacaoAtual("Graduacao Atual");
        policial.setId(1);
        policial.setIdPessoa(idPessoa);
        policial.setIdentificacaoUnica("Identificacao Unica");
        policial.setLogin("Login");
        policial.setMatricula("Matricula");
        policial.setNomeGuerra("Nome Guerra");
        policial.setPorteSuspenso(true);
        policial.setRestrito(true);
        policial.setSiape("Siape");
        policial.setSirgh("Sirgh");
        policial.setUpm(upm);
        policial.setUpmCodigoPolicialCedido(upmCodigoPolicialCedido);
        Date data = Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant());

        TipoVistoriaEntity referenciaFinal = new TipoVistoriaEntity();
        referenciaFinal.setAtivo(true);
        referenciaFinal.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaFinal.setDescricao("Descricao");
        referenciaFinal.setId(1L);
        referenciaFinal.setNome("Nome");
        referenciaFinal.setStatusAnterior("Status Anterior");
        referenciaFinal.setStatusPosterior("Status Posterior");

        TipoVistoriaEntity referenciaInicial = new TipoVistoriaEntity();
        referenciaInicial.setAtivo(true);
        referenciaInicial.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaInicial.setDescricao("Descricao");
        referenciaInicial.setId(1L);
        referenciaInicial.setNome("Nome");
        referenciaInicial.setStatusAnterior("Status Anterior");
        referenciaInicial.setStatusPosterior("Status Posterior");

        DiferencaOdometroEntity diferencaOdometro = new DiferencaOdometroEntity();
        diferencaOdometro.setDataInclusao(LocalDate.of(1970, 1, 1));
        diferencaOdometro.setDataModificacao(LocalDate.of(1970, 1, 1));
        diferencaOdometro.setDiferencaOdometro(10.0d);
        diferencaOdometro.setId(1L);
        diferencaOdometro.setReferenciaFinal(referenciaFinal);
        diferencaOdometro.setReferenciaInicial(referenciaInicial);

        TipoVistoriaEntity tipoVistoria = new TipoVistoriaEntity();
        tipoVistoria.setAtivo(true);
        tipoVistoria.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoria.setDescricao("Descricao");
        tipoVistoria.setId(1L);
        tipoVistoria.setNome("Nome");
        tipoVistoria.setStatusAnterior("Status Anterior");
        tipoVistoria.setStatusPosterior("Status Posterior");

        TipoEmpregoViaturaEntity tipoEmpregoViatura = new TipoEmpregoViaturaEntity();
        tipoEmpregoViatura.setAtivo(1);
        tipoEmpregoViatura.setId(1);
        tipoEmpregoViatura.setNome("Nome");

        ViaturaEntity viatura = new ViaturaEntity();
        viatura.setAtivo(true);
        viatura.setDataAtualizacao(LocalDate.of(1970, 1, 1));
        viatura.setDataInclusao(LocalDate.of(1970, 1, 1));
        viatura.setId(1L);
        viatura.setListaUpm(new ArrayList<>());
        viatura.setMarcaModelo("Marca Modelo");
        viatura.setNrSei("Nr Sei");
        viatura.setPlaca("Placa");
        viatura.setPrefixo("Prefixo");
        viatura.setRenavam("Renavam");
        viatura.setStatus("Status");
        viatura.setTipoEmpregoViatura(tipoEmpregoViatura);
        viatura.setTombamento("alice.liddell@example.org");

        VistoriaViaturaEntity vistoriaViatura = new VistoriaViaturaEntity();
        vistoriaViatura.setCheckLists(new ArrayList<>());
        vistoriaViatura.setDataVistoria(LocalDate.of(1970, 1, 1).atStartOfDay());
        vistoriaViatura.setDiferencaOdometro(diferencaOdometro);
        vistoriaViatura.setDiferencaVistoria(true);
        vistoriaViatura.setId(1L);
        vistoriaViatura.setIdPolicial(1);
        vistoriaViatura.setIdUpm(1);
        vistoriaViatura.setOdometroFinal(10.0f);
        vistoriaViatura.setOdometroInicial(10.0f);
        vistoriaViatura.setStatus(VistoriaViaturaStatusEnum.DISPONIVEL);
        vistoriaViatura.setTipoVistoria(tipoVistoria);
        vistoriaViatura.setViatura(viatura);
        vistoriaViatura.setVistoriaArquivoList(new ArrayList<>());
        vistoriaViatura.setVistoriaViaturaHistorico(new ArrayList<>());

        // Act
        VistoriaViaturaHistoricoEntity actualVistoriaViaturaHistoricoEntity = new VistoriaViaturaHistoricoEntity(1L,
                unidadePolicialMilitar, policial, data, VistoriaViaturaStatusEnum.DISPONIVEL, vistoriaViatura);
        Date data2 = Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant());
        actualVistoriaViaturaHistoricoEntity.setData(data2);
        actualVistoriaViaturaHistoricoEntity.setId(1L);
        Pessoa idPessoa2 = new Pessoa();
        idPessoa2.setAcessoRestrito(true);
        idPessoa2.setBloqueado(true);
        idPessoa2.setCertidaocivil(1);
        idPessoa2.setCnhDataEmissao(LocalDate.of(1970, 1, 1));
        idPessoa2.setCnhDataPrimeira(LocalDate.of(1970, 1, 1));
        idPessoa2.setCnhDataValidade(LocalDate.of(1970, 1, 1));
        idPessoa2.setCnhRegistro("Cnh Registro");
        idPessoa2.setCpf("Cpf");
        idPessoa2.setDataAtualizacao(LocalDate.of(1970, 1, 1).atStartOfDay());
        idPessoa2.setDataNascimento(LocalDate.of(1970, 1, 1));
        idPessoa2.setDataPisPasep(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
        idPessoa2.setId(1);
        idPessoa2.setIdUsuario(1);
        idPessoa2.setListPessoaRecurso(new ArrayList<>());
        idPessoa2.setMensagemAlerta(true);
        idPessoa2.setMensagemTela(true);
        idPessoa2.setNome("Nome");
        idPessoa2.setNomeAnterior("Nome Anterior");
        idPessoa2.setNomeMae("Nome Mae");
        idPessoa2.setNomePai("Nome Pai");
        idPessoa2.setNomecurto("alice.liddell@example.org");
        idPessoa2.setPerfis(new ArrayList<>());
        idPessoa2.setPessoaPerfil(new ArrayList<>());
        idPessoa2.setPisPasep("Pis Pasep");
        idPessoa2.setProvaVidaValida(true);
        idPessoa2.setRg("Rg");
        idPessoa2.setRgDataEmissao(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
        idPessoa2.setRgOrgaoExpedidor("Rg Orgao Expedidor");
        idPessoa2.setStatusProvaVida(1);
        idPessoa2.setTituloEleitorNumero("Titulo Eleitor Numero");
        idPessoa2.setTituloEleitorSecao(1);
        idPessoa2.setTituloEleitorZona(1);
        idPessoa2.setTransacaoEgov("Transacao Egov");
        UnidadePolicialMilitar upm2 = new UnidadePolicialMilitar();
        upm2.setAtivo(1);
        upm2.setComandoRegional(true);
        upm2.setId(1);
        upm2.setNome("Nome");
        upm2.setNomeHistorico("Nome Historico");
        upm2.setSigla("Sigla");
        UnidadePolicialMilitar upmCodigoPolicialCedido2 = new UnidadePolicialMilitar();
        upmCodigoPolicialCedido2.setAtivo(1);
        upmCodigoPolicialCedido2.setComandoRegional(true);
        upmCodigoPolicialCedido2.setId(1);
        upmCodigoPolicialCedido2.setNome("Nome");
        upmCodigoPolicialCedido2.setNomeHistorico("Nome Historico");
        upmCodigoPolicialCedido2.setSigla("Sigla");
        Policial policial2 = new Policial();
        policial2.setAlmanaque(1);
        policial2.setAssistenciaMedica(true);
        policial2.setCn("Cn");
        policial2.setCtgrafiSuspenso(true);
        policial2.setDataAdmissao(LocalDate.of(1970, 1, 1));
        policial2.setDataPrevisaoFimAssistenciaMedica(LocalDate.of(1970, 1, 1));
        policial2.setDataSuspensaoAssistenciaMedica(LocalDate.of(1970, 1, 1));
        policial2.setGraduacaoAtual("Graduacao Atual");
        policial2.setId(1);
        policial2.setIdPessoa(idPessoa2);
        policial2.setIdentificacaoUnica("Identificacao Unica");
        policial2.setLogin("Login");
        policial2.setMatricula("Matricula");
        policial2.setNomeGuerra("Nome Guerra");
        policial2.setPorteSuspenso(true);
        policial2.setRestrito(true);
        policial2.setSiape("Siape");
        policial2.setSirgh("Sirgh");
        policial2.setUpm(upm2);
        policial2.setUpmCodigoPolicialCedido(upmCodigoPolicialCedido2);
        actualVistoriaViaturaHistoricoEntity.setPolicial(policial2);
        actualVistoriaViaturaHistoricoEntity.setStatus(VistoriaViaturaStatusEnum.DISPONIVEL);
        UnidadePolicialMilitar unidadePolicialMilitar2 = new UnidadePolicialMilitar();
        unidadePolicialMilitar2.setAtivo(1);
        unidadePolicialMilitar2.setComandoRegional(true);
        unidadePolicialMilitar2.setId(1);
        unidadePolicialMilitar2.setNome("Nome");
        unidadePolicialMilitar2.setNomeHistorico("Nome Historico");
        unidadePolicialMilitar2.setSigla("Sigla");
        actualVistoriaViaturaHistoricoEntity.setUnidadePolicialMilitar(unidadePolicialMilitar2);
        TipoVistoriaEntity referenciaFinal2 = new TipoVistoriaEntity();
        referenciaFinal2.setAtivo(true);
        referenciaFinal2.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaFinal2.setDescricao("Descricao");
        referenciaFinal2.setId(1L);
        referenciaFinal2.setNome("Nome");
        referenciaFinal2.setStatusAnterior("Status Anterior");
        referenciaFinal2.setStatusPosterior("Status Posterior");
        TipoVistoriaEntity referenciaInicial2 = new TipoVistoriaEntity();
        referenciaInicial2.setAtivo(true);
        referenciaInicial2.setDataInclusao(LocalDate.of(1970, 1, 1));
        referenciaInicial2.setDescricao("Descricao");
        referenciaInicial2.setId(1L);
        referenciaInicial2.setNome("Nome");
        referenciaInicial2.setStatusAnterior("Status Anterior");
        referenciaInicial2.setStatusPosterior("Status Posterior");
        DiferencaOdometroEntity diferencaOdometro2 = new DiferencaOdometroEntity();
        diferencaOdometro2.setDataInclusao(LocalDate.of(1970, 1, 1));
        diferencaOdometro2.setDataModificacao(LocalDate.of(1970, 1, 1));
        diferencaOdometro2.setDiferencaOdometro(10.0d);
        diferencaOdometro2.setId(1L);
        diferencaOdometro2.setReferenciaFinal(referenciaFinal2);
        diferencaOdometro2.setReferenciaInicial(referenciaInicial2);
        TipoVistoriaEntity tipoVistoria2 = new TipoVistoriaEntity();
        tipoVistoria2.setAtivo(true);
        tipoVistoria2.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoria2.setDescricao("Descricao");
        tipoVistoria2.setId(1L);
        tipoVistoria2.setNome("Nome");
        tipoVistoria2.setStatusAnterior("Status Anterior");
        tipoVistoria2.setStatusPosterior("Status Posterior");
        TipoEmpregoViaturaEntity tipoEmpregoViatura2 = new TipoEmpregoViaturaEntity();
        tipoEmpregoViatura2.setAtivo(1);
        tipoEmpregoViatura2.setId(1);
        tipoEmpregoViatura2.setNome("Nome");
        ViaturaEntity viatura2 = new ViaturaEntity();
        viatura2.setAtivo(true);
        viatura2.setDataAtualizacao(LocalDate.of(1970, 1, 1));
        viatura2.setDataInclusao(LocalDate.of(1970, 1, 1));
        viatura2.setId(1L);
        viatura2.setListaUpm(new ArrayList<>());
        viatura2.setMarcaModelo("Marca Modelo");
        viatura2.setNrSei("Nr Sei");
        viatura2.setPlaca("Placa");
        viatura2.setPrefixo("Prefixo");
        viatura2.setRenavam("Renavam");
        viatura2.setStatus("Status");
        viatura2.setTipoEmpregoViatura(tipoEmpregoViatura2);
        viatura2.setTombamento("alice.liddell@example.org");
        VistoriaViaturaEntity vistoriaViatura2 = new VistoriaViaturaEntity();
        vistoriaViatura2.setCheckLists(new ArrayList<>());
        vistoriaViatura2.setDataVistoria(LocalDate.of(1970, 1, 1).atStartOfDay());
        vistoriaViatura2.setDiferencaOdometro(diferencaOdometro2);
        vistoriaViatura2.setDiferencaVistoria(true);
        vistoriaViatura2.setId(1L);
        vistoriaViatura2.setIdPolicial(1);
        vistoriaViatura2.setIdUpm(1);
        vistoriaViatura2.setOdometroFinal(10.0f);
        vistoriaViatura2.setOdometroInicial(10.0f);
        vistoriaViatura2.setStatus(VistoriaViaturaStatusEnum.DISPONIVEL);
        vistoriaViatura2.setTipoVistoria(tipoVistoria2);
        vistoriaViatura2.setViatura(viatura2);
        vistoriaViatura2.setVistoriaArquivoList(new ArrayList<>());
        vistoriaViatura2.setVistoriaViaturaHistorico(new ArrayList<>());
        actualVistoriaViaturaHistoricoEntity.setVistoriaViatura(vistoriaViatura2);
        Date actualData = actualVistoriaViaturaHistoricoEntity.getData();
        Long actualId = actualVistoriaViaturaHistoricoEntity.getId();
        Policial actualPolicial = actualVistoriaViaturaHistoricoEntity.getPolicial();
        VistoriaViaturaStatusEnum actualStatus = actualVistoriaViaturaHistoricoEntity.getStatus();
        UnidadePolicialMilitar actualUnidadePolicialMilitar = actualVistoriaViaturaHistoricoEntity
                .getUnidadePolicialMilitar();
        VistoriaViaturaEntity actualVistoriaViatura = actualVistoriaViaturaHistoricoEntity.getVistoriaViatura();

        // Assert that nothing has changed
        assertEquals(1L, actualId.longValue());
        assertEquals(VistoriaViaturaStatusEnum.DISPONIVEL, actualStatus);
        assertSame(vistoriaViatura2, actualVistoriaViatura);
        assertSame(policial2, actualPolicial);
        assertSame(unidadePolicialMilitar2, actualUnidadePolicialMilitar);
        assertSame(data2, actualData);
        assertNotNull(actualVistoriaViaturaHistoricoEntity.toString());
    }

    @Test
    void builder() {
        VistoriaViaturaHistoricoEntity vistoriaViaturaHistoricoEntity = VistoriaViaturaHistoricoEntity.builder()
                .id(1L)
                .unidadePolicialMilitar(new UnidadePolicialMilitar())
                .data(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()))
                .policial(new Policial())
                .status(VistoriaViaturaStatusEnum.DISPONIVEL)
                .vistoriaViatura(new VistoriaViaturaEntity())
                .build();

        assertNotNull(vistoriaViaturaHistoricoEntity);
    }


}
