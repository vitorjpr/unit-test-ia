package br.gov.df.pm.sgv.dto;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

public class EdicaoSubitemVistoriaDTOTest {
    private EdicaoSubitemVistoriaDTO edicaoSubitemVistoria = new EdicaoSubitemVistoriaDTO("", "", null);

    @BeforeEach
    void setUp() {
        edicaoSubitemVistoria.setNome("Vidro");
        edicaoSubitemVistoria.setDescricao("Vidro do Carro");
        edicaoSubitemVistoria.setDefeitos(new ArrayList<>());
    }

    @Test
    void testEquals() {
        var edicaoSubitemVistoria1 = EdicaoSubitemVistoriaDTO.builder()
                .nome("Vidro")
                .descricao("Vidro do Carro")
                .defeitos(new ArrayList<>())
                .build();
        assertEquals(edicaoSubitemVistoria, edicaoSubitemVistoria1);

        var edicaoItemVistoria2 = EdicaoSubitemVistoriaDTO.builder().nome("Janela").build();
        assertNotEquals(edicaoSubitemVistoria, edicaoItemVistoria2);


    }

    @Test
    void testHashCode() {
        var edicaoSubitemVistoria1 = EdicaoSubitemVistoriaDTO.builder()
                .nome("Vidro")
                .descricao("Vidro do Carro")
                .defeitos(new ArrayList<>())
                .build();
        assertEquals(edicaoSubitemVistoria.hashCode(), edicaoSubitemVistoria1.hashCode());

        var edicaoSubitemVistoria2 = EdicaoSubitemVistoriaDTO.builder().build();
        assertNotEquals(edicaoSubitemVistoria.hashCode(), edicaoSubitemVistoria2.hashCode());
    }

    @Test
    void testToString() {
        assertNotNull(edicaoSubitemVistoria.toString());
    }
}
