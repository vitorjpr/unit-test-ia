package br.gov.df.pm.sgv.domain.app;

import br.gov.df.pm.sgv.domain.TipoVistoriaEntity;
import br.gov.df.pm.sgv.domain.ViaturaEntity;
import br.gov.df.pm.sgv.domain.VistoriaViaturaEntity;
import br.gov.df.pm.sgv.domain.VistoriaViaturaHistoricoEntity;
import br.gov.df.pm.sgv.domain.enums.VistoriaViaturaStatusEnum;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class VistoriaViaturaEntityTest {
    private VistoriaViaturaEntity vistoria = new VistoriaViaturaEntity();

    @BeforeEach
    void setUp() {
        List<VistoriaViaturaHistoricoEntity> vistoriaViaturaHistoricoEntities = new ArrayList<>();
        vistoriaViaturaHistoricoEntities.add(VistoriaViaturaHistoricoEntity.builder().id(1L).build());
        vistoria.setId(1L);
        vistoria.setTipoVistoria(TipoVistoriaEntity.builder().id(1L).build());
        vistoria.setViatura(ViaturaEntity.builder().id(1L).build());
        vistoria.setVistoriaViaturaHistorico(vistoriaViaturaHistoricoEntities);
        vistoria.setStatus(VistoriaViaturaStatusEnum.EM_VISTORIA);
    }

//    @Test
//    void testEquals() {
//        List<VistoriaViaturaHistoricoEntity> vistoriaViaturaHistoricoEntities = new ArrayList<>();
//        vistoriaViaturaHistoricoEntities.add(VistoriaViaturaHistoricoEntity.builder().id(1L).build());
//        var vistoria1 = VistoriaViaturaEntity.builder()
//                .id(1L)
//                .tipoVistoria(TipoVistoriaEntity.builder().id(1L).build())
//                .viatura(ViaturaEntity.builder().id(1L).build())
//                .vistoriaViaturaHistorico(vistoriaViaturaHistoricoEntities)
//                .status(VistoriaViaturaStatusEnum.EM_VISTORIA)
//                .build();
//        assertEquals(vistoria, vistoria1);
//
//        var vistoria2 = VistoriaViaturaEntity.builder().id(2L).build();
//        assertNotEquals(vistoria, vistoria2);
//    }

//    @Test
//    void testHashCode() {
//        List<VistoriaViaturaHistoricoEntity> vistoriaViaturaHistoricoEntities = new ArrayList<>();
//        vistoriaViaturaHistoricoEntities.add(VistoriaViaturaHistoricoEntity.builder().id(1L).build());
//        var vistoria1 = VistoriaViaturaEntity.builder()
//                .id(1L)
//                .tipoVistoria(TipoVistoriaEntity.builder().id(1 L).build())
//                .viatura(ViaturaEntity.builder().id(1L).build())
//                .vistoriaViaturaHistorico(vistoriaViaturaHistoricoEntities)
//                .status(VistoriaViaturaStatusEnum.EM_VISTORIA)
//                .build();
//        assertEquals(vistoria.hashCode(), vistoria1.hashCode());
//
//        var vistoria2 = VistoriaViaturaEntity.builder().id(2L).build();
//        assertNotEquals(vistoria.hashCode(), vistoria2.hashCode());
//    }

    @Test
    void testToString() {
        assertNotNull(vistoria.toString());
    }
}
