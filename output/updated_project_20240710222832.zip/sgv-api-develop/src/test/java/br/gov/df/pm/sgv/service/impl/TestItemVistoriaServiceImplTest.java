```java
package br.gov.df.pm.sgv.service.impl;

import br.gov.df.pm.sgv.domain.ItemVistoriaEntity;
import br.gov.df.pm.sgv.domain.SubitemVistoriaEntity;
import br.gov.df.pm.sgv.domain.SubitensVistoriaEntity;
import br.gov.df.pm.sgv.dto.ItemVistoriaDTO;
import br.gov.df.pm.sgv.exceptions.VistoriaExceptions;
import br.gov.df.pm.sgv.repository.ItemVistoriaRepository;
import br.gov.df.pm.sgv.repository.SubitemVistoriaRepository;
import br.gov.df.pm.sgv.repository.SubitensVistoriaRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ItemVistoriaServiceImplTest {

    @Mock
    private ItemVistoriaRepository itemVistoriaRepository;
    @Mock
    private SubitemVistoriaRepository subitemVistoriaRepository;
    @Mock
    private SubitensVistoriaRepository subitensVistoriaRepository;
    @InjectMocks
    private ItemVistoriaServiceImpl itemVistoriaService;

    private ItemVistoriaEntity itemVistoria;
    private SubitemVistoriaEntity subitemVistoria;
    private List<SubitemVistoriaEntity> subitemVistoriaList;
    private SubitensVistoriaEntity subitensVistoria;
    private List<SubitensVistoriaEntity> subitensVistoriaList;

    @BeforeEach
    void setUp() {
        itemVistoria = new ItemVistoriaEntity();
        itemVistoria.setId(1L);
        itemVistoria.setNome("nome");
        itemVistoria.setDescricao("descricao");
        itemVistoria.setAtivo(true);
        itemVistoria.setDataInclusao(LocalDate.MIN);

        subitemVistoria = new SubitemVistoriaEntity();
        subitemVistoria.setId(1L);
        subitemVistoria.setNome("nome");
        subitemVistoria.setDescricao("descricao");
        subitemVistoria.setAtivo(true);
        subitemVistoria.setDataInclusao(LocalDate.MIN);

        subitemVistoriaList = new ArrayList<>();
        subitemVistoriaList.add(subitemVistoria);

        subitensVistoria = new SubitensVistoriaEntity();
        subitensVistoria.setId(1L);
        subitensVistoria.setCodItem(itemVistoria);
        subitensVistoria.setCodSubitem(subitemVistoria);
        subitensVistoria.setAtivo(true);
        subitensVistoria.setDataInclusao(LocalDate.MIN);

        subitensVistoriaList = new ArrayList<>();
        subitensVistoriaList.add(subitensVistoria);

        when(itemVistoriaRepository.findByNome(itemVistoria.getNome())).thenReturn(Optional.of(itemVistoria));
    }

    @Test
    void salvar() {
        when(itemVistoriaRepository.save(itemVistoria)).thenReturn(itemVistoria);

        ItemVistoriaDTO itemVistoriaDTO = new ItemVistoriaDTO();
        itemVistoriaDTO.setId(1L);
        itemVistoriaDTO.setNome("nome");
        itemVistoriaDTO.setDescricao("descricao");
        itemVistoriaDTO.setAtivo(true);
        itemVistoriaDTO.setDataInclusao(LocalDate.MIN);
        itemVistoriaDTO.setSubitens(subitemVistoriaList);

        assertThrows(VistoriaExceptions.class, () -> itemVistoriaService.salvar(itemVistoriaDTO));
    }

    @Test
    void salvar2() {
        ItemVistoriaEntity itemVistoria2Entity = new ItemVistoriaEntity();
        itemVistoria2Entity.setId(2L);
        itemVistoria2Entity.setNome("nome2");
        itemVistoria2Entity.setDescricao("descricao2");
        itemVistoria2Entity.setAtivo(true);
        itemVistoria2Entity.setDataInclusao(LocalDate.MIN);

        ItemVistoriaDTO itemVistoria2DTO = new ItemVistoriaDTO();
        itemVistoria2DTO.setId(2L);
        itemVistoria2DTO.setNome("nome2");
        itemVistoria2DTO.setDescricao("descricao2");
        itemVistoria2DTO.setAtivo(true);
        itemVistoria2DTO.setDataInclusao(LocalDate.MIN);
       