```java
package br.gov.df.pm.sgv.dto;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

class ItemVistoriaOcorrenciaDTODiffblueTest {

    @Test
    void testCanEqual() {
        assertFalse((new ItemVistoriaOcorrenciaDTO()).canEqual("Other"));
    }

    @Test
    void testCanEqual2() {
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder ativoResult = ItemVistoriaOcorrenciaDTO.builder()
                .ativo(true);
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder nomeResult = ativoResult
                .dataInclusao(LocalDate.of(1970, 1, 1))
                .descricao("Descricao")
                .id(1L)
                .nome("Nome");
        ItemVistoriaOcorrenciaDTO buildResult = nomeResult.subitemVistoriaDTOS(new ArrayList<>()).build();
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder ativoResult2 = ItemVistoriaOcorrenciaDTO.builder()
                .ativo(true);
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder nomeResult2 = ativoResult2
                .dataInclusao(LocalDate.of(1970, 1, 1))
                .descricao("Descricao")
                .id(1L)
                .nome("Nome");
        ItemVistoriaOcorrenciaDTO buildResult2 = nomeResult2.subitemVistoriaDTOS(new ArrayList<>()).build();

        assertTrue(buildResult.canEqual(buildResult2));
    }

    @Test
    void testEquals() {
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder ativoResult = ItemVistoriaOcorrenciaDTO.builder()
                .ativo(true);
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder nomeResult = ativoResult
                .dataInclusao(LocalDate.of(1970, 1, 1))
                .descricao("Descricao")
                .id(1L)
                .nome("Nome");
        ItemVistoriaOcorrenciaDTO buildResult = nomeResult.subitemVistoriaDTOS(new ArrayList<>()).build();

        assertNotEquals(buildResult, null);
    }

    @Test
    void testEquals2() {
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder ativoResult = ItemVistoriaOcorrenciaDTO.builder()
                .ativo(true);
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder nomeResult = ativoResult
                .dataInclusao(LocalDate.of(1970, 1, 1))
                .descricao("Descricao")
                .id(1L)
                .nome("Nome");
        ItemVistoriaOcorrenciaDTO buildResult = nomeResult.subitemVistoriaDTOS(new ArrayList<>()).build();

        assertNotEquals(buildResult, "Different type to ItemVistoriaOcorrenciaDTO");
    }

    @Test
    void testEquals3() {
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder itemVistoriaOcorrenciaDTOBuilder = mock(
                ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder.class);
        when(itemVistoriaOcorrenciaDTOBuilder.ativo(Mockito.<Boolean>any()))
                .thenReturn(ItemVistoriaOcorrenciaDTO.builder());
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder ativoResult = itemVistoriaOcorrenciaDTOBuilder
                .ativo(true);
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder nomeResult = ativoResult
                .dataInclusao(LocalDate.of(1970, 1, 1))
                .descricao("Descricao")
                .id(1L)
                .nome("Nome");
        ItemVistoriaOcorrenciaDTO buildResult = nomeResult.subitemVistoriaDTOS(new ArrayList<>()).build();
        ItemVistoriaOcorrenciaDTO.ItemVistoriaOcorrenciaDTOBuilder ativoResult2 = ItemVistoriaOcorrenciaDTO.builder()
                .ativo(true);
       