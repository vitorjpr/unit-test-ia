```java
package br.gov.df.pm.sgv.domain;

import br.gov.df.pm.sgv.domain.enums.VistoriaViaturaStatusEnum;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Date;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ChecklistVistoriaSubItemEntityDiffblueTest {

    @Test
    void testGettersAndSetters() {
        // Arrange
        ChecklistVistoriaSubItemEntity actualChecklistVistoriaSubItemEntity = new ChecklistVistoriaSubItemEntity();
        // Set up entities
        // ...
        
        // Act
        // Set actual values
        // ...
        
        // Assert
        assertEquals(1L, actualChecklistVistoriaSubItemEntity.getId());
        assertTrue(actualChecklistVistoriaSubItemEntity.getSelecionado());
        assertSame(checklistItemVistoria, actualChecklistVistoriaSubItemEntity.getChecklistItemVistoria());
        assertSame(tipoDefeitoVistoria, actualChecklistVistoriaSubItemEntity.getTipoDefeitoVistoria());
        assertSame(dataCriacao, actualChecklistVistoriaSubItemEntity.getDataCriacao());
    }

    @Test
    void testGettersAndSetters2() {
        // Arrange
        // Set up entities
        // ...
        
        // Act
        // Set actual values
        // ...
        
        // Assert
        assertEquals(1L, actualChecklistVistoriaSubItemEntity.getId());
        assertTrue(actualChecklistVistoriaSubItemEntity.getSelecionado());
        assertEquals(checklistItemVistoria2, actualChecklistVistoriaSubItemEntity.getChecklistItemVistoria());
        assertEquals(tipoDefeitoVistoria2, actualChecklistVistoriaSubItemEntity.getTipoDefeitoVistoria());
        assertSame(dataCriacao2, actualChecklistVistoriaSubItemEntity.getDataCriacao());
    }

    @Test
    void builder() {
        // Act
        ChecklistVistoriaSubItemEntity checklistVistoriaSubItemEntity = ChecklistVistoriaSubItemEntity.builder()
                .id(1L)
                .dataCriacao(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()))
                .checklistItemVistoria(new ChecklistItemVistoriaEntity())
                .selecionado(true)
                .tipoDefeitoVistoria(new TipoDefeitoVistoriaEntity())
                .build();

        // Assert
        assertNotNull(checklistVistoriaSubItemEntity);
    }

}
```