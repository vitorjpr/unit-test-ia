```java
package br.gov.df.pm.sgv.domain;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

class ViaturaEntityDiffblueTest {

    @Test
    void testGettersAndSetters() {
        ViaturaEntity actualViaturaEntity = new ViaturaEntity();
        actualViaturaEntity.setAtivo(true);
        LocalDate dataAtualizacao = LocalDate.of(1970, 1, 1);
        actualViaturaEntity.setDataAtualizacao(dataAtualizacao);
        LocalDate dataInclusao = LocalDate.of(1970, 1, 1);
        actualViaturaEntity.setDataInclusao(dataInclusao);
        actualViaturaEntity.setId(1L);
        List<ViaturaUpmEntity> listaUpm = new ArrayList<>();
        actualViaturaEntity.setListaUpm(listaUpm);
        actualViaturaEntity.setMarcaModelo("Marca Modelo");
        actualViaturaEntity.setNrSei("Nr Sei");
        actualViaturaEntity.setPlaca("Placa");
        actualViaturaEntity.setPrefixo("Prefixo");
        actualViaturaEntity.setRenavam("Renavam");
        actualViaturaEntity.setStatus("Status");
        TipoEmpregoViaturaEntity tipoEmpregoViatura = new TipoEmpregoViaturaEntity();
        tipoEmpregoViatura.setAtivo(1);
        tipoEmpregoViatura.setId(1);
        tipoEmpregoViatura.setNome("Nome");
        actualViaturaEntity.setTipoEmpregoViatura(tipoEmpregoViatura);
        actualViaturaEntity.setTombamento("alice.liddell@example.org");

        assertEquals("Marca Modelo", actualViaturaEntity.getMarcaModelo());
        assertEquals("Nr Sei", actualViaturaEntity.getNrSei());
        assertEquals("Placa", actualViaturaEntity.getPlaca());
        assertEquals("Prefixo", actualViaturaEntity.getPrefixo());
        assertEquals("Renavam", actualViaturaEntity.getRenavam());
        assertEquals("Status", actualViaturaEntity.getStatus());
        assertEquals("alice.liddell@example.org", actualViaturaEntity.getTombamento());
        assertEquals(1L, actualViaturaEntity.getId());
        assertTrue(actualViaturaEntity.getAtivo());
        assertSame(tipoEmpregoViatura, actualViaturaEntity.getTipoEmpregoViatura());
        assertSame(listaUpm, actualViaturaEntity.getListaUpm());
        assertSame(dataAtualizacao, actualViaturaEntity.getDataAtualizacao());
        assertSame(dataInclusao, actualViaturaEntity.getDataInclusao());
    }

    @Test
    void testGettersAndSetters2() {
        LocalDate dataInclusao = LocalDate.of(1970, 1, 1);
        LocalDate dataAtualizacao = LocalDate.of(1970, 1, 1);

        TipoEmpregoViaturaEntity tipoEmpregoViatura = new TipoEmpregoViaturaEntity();
        tipoEmpregoViatura.setAtivo(1);
        tipoEmpregoViatura.setId(1);
        tipoEmpregoViatura.setNome("Nome");
        List<ViaturaUpmEntity> listaUpm = new ArrayList<>();

        ViaturaEntity actualViaturaEntity = new ViaturaEntity(1L, "Prefixo", "Nr Sei", "Placa", "Status",
                "alice.liddell@example.org", "Renavam", dataInclusao, dataAtualizacao, true, tipoEmpregoViatura, listaUpm,
                "Marca Modelo");
        actualViaturaEntity.setAtivo(true);
        LocalDate dataAtualizacao2 = LocalDate.of(1970, 1, 1);
        actualViaturaEntity.setDataAtualizacao(dataAtualizacao2);
        LocalDate dataInclusao2 = LocalDate.of(1970, 1, 1);
        actualViaturaEntity.setDataInclusao(dataInclusao2);
        actualViaturaEntity.setId(1L);
        List<ViaturaUpmEntity> listaUpm2 = new ArrayList<>();
        actualViaturaEntity.setListaUpm(listaUpm2);
        actualViaturaEntity.setMarcaModelo("Marca Modelo");
        actualViaturaEntity.setNrSei("Nr Sei");
        actualViaturaEntity.setPlaca("Placa");
        actualViaturaEntity.setPrefixo("Prefixo");
        actualViaturaEntity.setRenavam("Renavam");
        actualViaturaEntity.setStatus("Status");
        TipoEmpregoViaturaEntity tipoEmpregoViatura2 = new TipoEmpregoViaturaEntity();
        tipoEmpregoViatura2.setAtivo(1);
        tipoEmpregoViatura2.setId(1);
        tipoEmpregoViatura2.setNome("Nome");
        actualViaturaEntity.setTipoEmp