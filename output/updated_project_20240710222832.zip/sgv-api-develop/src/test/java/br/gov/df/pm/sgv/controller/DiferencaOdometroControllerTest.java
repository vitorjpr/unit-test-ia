//package br.gov.df.pm.sgv.controller;
//
//import br.gov.df.pm.sgv.domain.*;
//import br.gov.df.pm.sgv.dto.DiferencaOdometroDTO;
//import br.gov.df.pm.sgv.dto.EdicaoItemVistoriaDTO;
//import br.gov.df.pm.sgv.dto.ItemVistoriaDTO;
//import br.gov.df.pm.sgv.repository.DiferencaOdometroRepository;
//import br.gov.df.pm.sgv.repository.TipoVistoriaRepository;
//import br.gov.df.pm.sgv.util.TestUtils;
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.boot.test.mock.mockito.MockBean;
//import org.springframework.data.domain.PageImpl;
//import org.springframework.data.domain.PageRequest;
//import org.springframework.data.domain.Pageable;
//import org.springframework.data.jpa.domain.Specification;
//import org.springframework.hateoas.EntityModel;
//import org.springframework.hateoas.PagedModel;
//import org.springframework.http.ResponseEntity;
//import org.springframework.mock.web.MockHttpServletRequest;
//import org.springframework.web.context.request.RequestContextHolder;
//import org.springframework.web.context.request.ServletRequestAttributes;
//
//import javax.persistence.criteria.CriteriaBuilder;
//import javax.persistence.criteria.CriteriaQuery;
//import javax.persistence.criteria.Root;
//import java.util.List;
//import java.util.Optional;
//
//import static org.junit.jupiter.api.Assertions.assertNotNull;
//import static org.junit.jupiter.api.Assertions.assertNull;
//import static org.mockito.ArgumentMatchers.any;
//import static org.mockito.Mockito.*;
//
//@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
//public class DiferencaOdometroControllerTest {
//
//    @Autowired
//    DiferencaOdometroController diferencaOdometroController;
//
//    @MockBean
//    DiferencaOdometroRepository diferencaOdometroRepository;
//
//    @MockBean
//    TipoVistoriaRepository tipoVistoriaRepository;
//
//    TipoVistoriaEntity tipoVistoriaMock;
//
//    DiferencaOdometroEntity diferencaOdometroMock;
//
//    @BeforeEach
//    void setUp() {
//        var request = new MockHttpServletRequest();
//        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(request));
//
//        tipoVistoriaMock = TipoVistoriaEntity.builder().build();
//
//        diferencaOdometroMock = DiferencaOdometroEntity.builder()
//                .id(1L)
//                .referenciaInicial(tipoVistoriaMock)
//                .referenciaFinal(tipoVistoriaMock)
//                .diferencaOdometro(100.0)
//                .build();
//
//        Specification<DiferencaOdometroEntity> spec = any();
//        Pageable pageable = any();
//        when(diferencaOdometroRepository.findAll(spec, pageable)).then(TestUtils.callableAnswer(invocation -> {
//            Specification<DiferencaOdometroEntity> s = invocation.getArgument(0);
//            Root<DiferencaOdometroEntity> root = mock(Root.class, withSettings().defaultAnswer(RETURNS_MOCKS));
//            CriteriaQuery<DiferencaOdometroEntity> query = mock(CriteriaQuery.class, withSettings().defaultAnswer(RETURNS_MOCKS));
//            when(query.getResultType()).thenReturn(DiferencaOdometroEntity.class);
//            CriteriaBuilder builder = mock(CriteriaBuilder.class, withSettings().defaultAnswer(RETURNS_MOCKS));
//            s.toPredicate(root, query, builder);
//            return new PageImpl<>(List.of(diferencaOdometroMock));
//        }));
//    }
//
//    @Test
//    void buscarId() {
//        when(diferencaOdometroRepository.findById(1L)).thenReturn(Optional.of(diferencaOdometroMock));
//        ResponseEntity<?> response = diferencaOdometroController.buscarId(1L);
//        assertNotNull(response);
//    }
//
//    @Test
//    void buscar() {
//        var pageable = PageRequest.of(0, 1);
//        PagedModel<EntityModel<DiferencaOdometroEntity>> response = diferencaOdometroController.buscar("100", pageable);
//        assertNotNull(response);
//    }
//
//    @Test
//    void salvar() {
//        when(diferencaOdometroRepository.findByReferenciaInicialAndReferenciaFinal(any(), any())).thenReturn(Optional.ofNullable(null));
//        when(diferencaOdometroRepository.save(any(DiferencaOdometroEntity.class))).thenReturn(diferencaOdometroMock);
//        assertNotNull(diferencaOdometroController.salvar(DiferencaOdometroDTO.builder().diferencaOdometro(100.0).build()));
//    }
//
//    @Test
//    void excluir() {
//        when(diferencaOdometroRepository.findById(1L)).thenReturn(Optional.of(diferencaOdometroMock));
//        assertNull(diferencaOdometroController.excluir(1L));
//    }
//}
