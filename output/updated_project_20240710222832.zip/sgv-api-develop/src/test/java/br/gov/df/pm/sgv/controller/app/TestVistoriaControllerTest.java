```java
package br.gov.df.pm.sgv.controller.app;

import br.gov.df.pm.sgv.controller.VistoriaController;
import br.gov.df.pm.sgv.domain.TipoVistoriaEntity;
import br.gov.df.pm.sgv.domain.ViaturaEntity;
import br.gov.df.pm.sgv.domain.VistoriaViaturaEntity;
import br.gov.df.pm.sgv.dto.VistoriaDTO;
import br.gov.df.pm.sgv.repository.app.ViaturaRepository;
import br.gov.df.pm.sgv.repository.app.VistoriaViaturaRepository;
import br.gov.df.pm.sgv.security.UserProvider;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.mock.mockito.SpyBean;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class VistoriaControllerTest {

    @Autowired
    VistoriaController vistoriaController;

    @MockBean
    private VistoriaViaturaRepository vistoriaRepository;

    @MockBean
    private ViaturaRepository viaturaRepository;

    @SpyBean
    UserProvider userProvider;

    @MockBean
    RestTemplate restTemplate;

    VistoriaViaturaEntity vistoriaMock;
    VistoriaDTO vistoriaDTOMock;
    ViaturaEntity viaturaMock;

    @BeforeEach
    void setUp() {
        var request = new MockHttpServletRequest();
        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(request));

        String url = any();
        Object reqObj = any();
        Class<UUID> clazz = any();
        Object[] params = any();
        when(restTemplate.postForEntity(url, reqObj, clazz, params)).thenReturn(ResponseEntity.of(Optional.of(UUID.randomUUID()));
        var resource = new ByteArrayResource(new byte[] {});
        RequestEntity<?> req = any();
        Class<Resource> resourceClass = any();
        when(restTemplate.exchange(req, resourceClass)).thenReturn(ResponseEntity.of(Optional.of(resource));

        vistoriaMock = VistoriaViaturaEntity.builder()
                .id(1L)
                .viatura(ViaturaEntity.builder().id(1L).build())
                .tipoVistoria(TipoVistoriaEntity.builder().id(1L).build())
                .build();

        vistoriaDTOMock = VistoriaDTO.builder()
                .viatura(ViaturaEntity.builder().id(1L).build())
                .tipoVistoria(TipoVistoriaEntity.builder().id(1L).build())
                .build();

        viaturaMock = ViaturaEntity.builder()
                .id(1L)
                .ativo(1)
                .build();
    }

    @Test
    void buscarId() {
        when(viaturaRepository.findById(1L)).thenReturn(Optional.of(viaturaMock));
        when(vistoriaRepository.findByViatura(any(ViaturaEntity.class))).thenReturn(Optional.of(vistoriaMock));
        ResponseEntity<?> response = vistoriaController.vistoriaByViatura(1L);
        assertNotNull(response);
    }

    @Test
    void salvar() {
        when(vistoriaRepository.save(any(VistoriaViaturaEntity.class))).thenReturn(vistoriaMock);
        assertNotNull(vistoriaController.salvar(vistoriaDTOMock));
    }
}
```