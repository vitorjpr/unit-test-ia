```java
package br.gov.df.pm.sgv.domain.app;

import br.gov.df.pm.sgv.domain.TipoVistoriaEntity;
import br.gov.df.pm.sgv.domain.ViaturaEntity;
import br.gov.df.pm.sgv.domain.VistoriaViaturaEntity;
import br.gov.df.pm.sgv.domain.VistoriaViaturaHistoricoEntity;
import br.gov.df.pm.sgv.domain.enums.VistoriaViaturaStatusEnum;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class VistoriaViaturaEntityTest {
    private VistoriaViaturaEntity vistoria;

    @BeforeEach
    void setUp() {
        vistoria = new VistoriaViaturaEntity();
        List<VistoriaViaturaHistoricoEntity> vistoriaViaturaHistoricoEntities = new ArrayList<>();
        vistoriaViaturaHistoricoEntities.add(VistoriaViaturaHistoricoEntity.builder().id(1L).build());
        vistoria.setId(1L);
        vistoria.setTipoVistoria(TipoVistoriaEntity.builder().id(1L).build());
        vistoria.setViatura(ViaturaEntity.builder().id(1L).build());
        vistoria.setVistoriaViaturaHistorico(vistoriaViaturaHistoricoEntities);
        vistoria.setStatus(VistoriaViaturaStatusEnum.EM_VISTORIA);
    }

    @Test
    void testGetId() {
        assertEquals(1L, vistoria.getId());
    }

    @Test
    void testGetTipoVistoria() {
        assertNotNull(vistoria.getTipoVistoria());
    }

    @Test
    void testGetViatura() {
        assertNotNull(vistoria.getViatura());
    }

    @Test
    void testGetVistoriaViaturaHistorico() {
        assertFalse(vistoria.getVistoriaViaturaHistorico().isEmpty());
    }

    @Test
    void testGetStatus() {
        assertEquals(VistoriaViaturaStatusEnum.EM_VISTORIA, vistoria.getStatus());
    }

    @Test
    void testToString() {
        assertNotNull(vistoria.toString());
    }
}
``` 

Este é um exemplo de testes unitários para a classe `VistoriaViaturaEntity`. Os testes cobrem os métodos `getId`, `getTipoVistoria`, `getViatura`, `getVistoriaViaturaHistorico`, `getStatus` e `toString`. Certifique-se de ajustar os testes de acordo com a lógica de negócio da sua aplicação e adicionar mais testes conforme necessário.