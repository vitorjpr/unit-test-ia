```java
package br.gov.df.pm.sgv.domain.app;

import br.gov.df.pm.sgv.domain.ViaturaEntity;
import br.gov.df.pm.sgv.domain.ViaturaUpmEntity;
import br.gov.df.pm.sgv.domain.sgpol.UnidadePolicialMilitar;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

public class ViaturaUpmEntityTest {
    private ViaturaUpmEntity viaturaUpm;

    @BeforeEach
    void setUp() {
        viaturaUpm = ViaturaUpmEntity.builder()
                .id(1)
                .viatura(ViaturaEntity.builder().id(1L).build())
                .upmCodigo(new UnidadePolicialMilitar())
                .ativo(1)
                .dtSaida(new Date())
                .nrSei("XXXX")
                .build();
    }

    @Test
    void testEquals() {
        var viaturaUpm1 = ViaturaUpmEntity.builder()
                .id(1)
                .viatura(ViaturaEntity.builder().id(1L).build())
                .upmCodigo(new UnidadePolicialMilitar())
                .ativo(1)
                .dtSaida(new Date())
                .nrSei("XXXX")
                .build();
        assertEquals(viaturaUpm, viaturaUpm1);

        var viaturaUpm2 = ViaturaUpmEntity.builder().id(2).build();
        assertNotEquals(viaturaUpm, viaturaUpm2);
    }

    @Test
    void testHashCode() {
        var viaturaUpm1 = ViaturaUpmEntity.builder()
                .id(1)
                .viatura(ViaturaEntity.builder().id(1L).build())
                .upmCodigo(new UnidadePolicialMilitar())
                .ativo(1)
                .dtSaida(new Date())
                .nrSei("XXXX")
                .build();
        assertEquals(viaturaUpm.hashCode(), viaturaUpm1.hashCode());

        var viaturaUpm2 = ViaturaUpmEntity.builder().id(2).build();
        assertNotEquals(viaturaUpm.hashCode(), viaturaUpm2.hashCode());
    }

    @Test
    void testToString() {
        assertNotNull(viaturaUpm.toString());
    }
}
```