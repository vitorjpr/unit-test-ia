```java
package br.gov.df.pm.sgv.domain;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

public class TipoVistoriaEntityTest {
    private TipoVistoriaEntity tipoVistoria;

    @BeforeEach
    void setUp() {
        tipoVistoria = new TipoVistoriaEntity(1L, "Vidro", "Vidro do Carro", "EM USO", "DISPONÍVEL", LocalDate.now(), true);
    }

    @Test
    void testEquals() {
        var tipoVistoria1 = new TipoVistoriaEntity(1L, "Vidro", "Vidro do Carro", "EM USO", "DISPONÍVEL", LocalDate.now(), true);
        assertEquals(tipoVistoria, tipoVistoria1);

        var tipoVistoria2 = new TipoVistoriaEntity(null, "Janela", null, null, null, null, false);
        assertNotEquals(tipoVistoria, tipoVistoria2);
    }

    @Test
    void testHashCode() {
        var tipoVistoria1 = new TipoVistoriaEntity(1L, "Vidro", "Vidro do Carro", "EM USO", "DISPONÍVEL", LocalDate.now(), true);
        assertEquals(tipoVistoria.hashCode(), tipoVistoria1.hashCode());

        var tipoVistoria2 = new TipoVistoriaEntity(null, null, null, null, null, null, false);
        assertNotEquals(tipoVistoria.hashCode(), tipoVistoria2.hashCode());
    }

    @Test
    void testToString() {
        assertNotNull(tipoVistoria.toString());
    }

    @Test
    void testGetters() {
        assertEquals(1L, tipoVistoria.getId());
        assertEquals("Vidro", tipoVistoria.getNome());
        assertEquals("Vidro do Carro", tipoVistoria.getDescricao());
        assertEquals("EM USO", tipoVistoria.getStatusAnterior());
        assertEquals("DISPONÍVEL", tipoVistoria.getStatusPosterior());
        assertEquals(LocalDate.now(), tipoVistoria.getDataInclusao());
        assertTrue(tipoVistoria.isAtivo());
    }

    @Test
    void testSetters() {
        tipoVistoria.setId(2L);
        tipoVistoria.setNome("Pneu");
        tipoVistoria.setDescricao("Pneu do Carro");
        tipoVistoria.setStatusAnterior("EM USO");
        tipoVistoria.setStatusPosterior("DISPONÍVEL");
        tipoVistoria.setDataInclusao(LocalDate.now());
        tipoVistoria.setAtivo(false);

        assertEquals(2L, tipoVistoria.getId());
        assertEquals("Pneu", tipoVistoria.getNome());
        assertEquals("Pneu do Carro", tipoVistoria.getDescricao());
        assertEquals("EM USO", tipoVistoria.getStatusAnterior());
        assertEquals("DISPONÍVEL", tipoVistoria.getStatusPosterior());
        assertEquals(LocalDate.now(), tipoVistoria.getDataInclusao());
        assertFalse(tipoVistoria.isAtivo());
    }
}
``` 

Esses são testes unitários abrangentes para a classe `TipoVistoriaEntity`. Eles cobrem os métodos `equals()`, `hashCode()`, `toString()`, getters e setters. Certifique-se de ajustar os testes conforme necessário para refletir a lógica e os requisitos específicos do seu código.