package br.gov.df.pm.sgv.service.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isA;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import br.gov.df.pm.sgv.domain.ItemVistoriaEntity;
import br.gov.df.pm.sgv.domain.ItensVistoriaEntity;
import br.gov.df.pm.sgv.domain.TipoVistoriaEntity;
import br.gov.df.pm.sgv.dto.EdicaoTipoVistoriaDTO;
import br.gov.df.pm.sgv.dto.TipoVistoriaDTO;
import br.gov.df.pm.sgv.exceptions.TipoVistoriaException;
import br.gov.df.pm.sgv.exceptions.VistoriaExceptions;
import br.gov.df.pm.sgv.repository.ItemVistoriaRepository;
import br.gov.df.pm.sgv.repository.ItensVistoriaRepository;
import br.gov.df.pm.sgv.repository.TipoVistoriaRepository;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ContextConfiguration(classes = {TipoVistoriaServiceImpl.class})
@ExtendWith(SpringExtension.class)
class TipoVistoriaServiceImplDiffblueTest {
    @MockBean
    private ItemVistoriaRepository itemVistoriaRepository;

    @MockBean
    private ItensVistoriaRepository itensVistoriaRepository;

    @MockBean
    private TipoVistoriaRepository tipoVistoriaRepository;

    @Autowired
    private TipoVistoriaServiceImpl tipoVistoriaServiceImpl;

    /**
     * Method under test: {@link TipoVistoriaServiceImpl#buscarId(Long)}
     */
    @Test
    void testBuscarId() {
        // Arrange
        TipoVistoriaEntity tipoVistoriaEntity = new TipoVistoriaEntity();
        tipoVistoriaEntity.setAtivo(true);
        tipoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoriaEntity.setDescricao("Descricao");
        tipoVistoriaEntity.setId(1L);
        tipoVistoriaEntity.setNome("Nome");
        tipoVistoriaEntity.setStatusAnterior("Status Anterior");
        tipoVistoriaEntity.setStatusPosterior("Status Posterior");
        Optional<TipoVistoriaEntity> ofResult = Optional.of(tipoVistoriaEntity);
        when(tipoVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        // Act
        ResponseEntity<?> actualBuscarIdResult = tipoVistoriaServiceImpl.buscarId(1L);

        // Assert
        verify(tipoVistoriaRepository).findById(eq(1L));
        assertEquals("1970-01-01", ((TipoVistoriaDTO) actualBuscarIdResult.getBody()).getDataInclusao().toString());
        assertEquals("Descricao", ((TipoVistoriaDTO) actualBuscarIdResult.getBody()).getDescricao());
        assertEquals("Nome", ((TipoVistoriaDTO) actualBuscarIdResult.getBody()).getNome());
        assertEquals("Status Anterior", ((TipoVistoriaDTO) actualBuscarIdResult.getBody()).getStatusAnterior());
        assertEquals("Status Posterior", ((TipoVistoriaDTO) actualBuscarIdResult.getBody()).getStatusPosterior());
        assertNull(((TipoVistoriaDTO) actualBuscarIdResult.getBody()).getItens());
        assertEquals(1L, ((TipoVistoriaDTO) actualBuscarIdResult.getBody()).getId().longValue());
        assertEquals(HttpStatus.OK, actualBuscarIdResult.getStatusCode());
        assertTrue(((TipoVistoriaDTO) actualBuscarIdResult.getBody()).getAtivo());
        assertTrue(actualBuscarIdResult.hasBody());
        assertTrue(actualBuscarIdResult.getHeaders().isEmpty());
    }

    /**
     * Method under test: {@link TipoVistoriaServiceImpl#buscarId(Long)}
     */
    @Test
    void testBuscarId2() {
        // Arrange
        TipoVistoriaEntity tipoVistoriaEntity = mock(TipoVistoriaEntity.class);
        when(tipoVistoriaEntity.getAtivo()).thenReturn(true);
        when(tipoVistoriaEntity.getId()).thenReturn(1L);
        when(tipoVistoriaEntity.getDescricao()).thenReturn("Descricao");
        when(tipoVistoriaEntity.getNome()).thenReturn("Nome");
        when(tipoVistoriaEntity.getStatusAnterior()).thenReturn("Status Anterior");
        when(tipoVistoriaEntity.getStatusPosterior()).thenReturn("Status Posterior");
        when(tipoVistoriaEntity.getDataInclusao()).thenReturn(LocalDate.of(1970, 1, 1));
        doNothing().when(tipoVistoriaEntity).setAtivo(Mockito.<Boolean>any());
        doNothing().when(tipoVistoriaEntity).setDataInclusao(Mockito.<LocalDate>any());
        doNothing().when(tipoVistoriaEntity).setDescricao(Mockito.<String>any());
        doNothing().when(tipoVistoriaEntity).setId(Mockito.<Long>any());
        doNothing().when(tipoVistoriaEntity).setNome(Mockito.<String>any());
        doNothing().when(tipoVistoriaEntity).setStatusAnterior(Mockito.<String>any());
        doNothing().when(tipoVistoriaEntity).setStatusPosterior(Mockito.<String>any());
        tipoVistoriaEntity.setAtivo(true);
        tipoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoriaEntity.setDescricao("Descricao");
        tipoVistoriaEntity.setId(1L);
        tipoVistoriaEntity.setNome("Nome");
        tipoVistoriaEntity.setStatusAnterior("Status Anterior");
        tipoVistoriaEntity.setStatusPosterior("Status Posterior");
        Optional<TipoVistoriaEntity> ofResult = Optional.of(tipoVistoriaEntity);
        when(tipoVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        // Act
        ResponseEntity<?> actualBuscarIdResult = tipoVistoriaServiceImpl.buscarId(1L);

        // Assert
        verify(tipoVistoriaEntity).getAtivo();
        verify(tipoVistoriaEntity).getDataInclusao();
        verify(tipoVistoriaEntity).getDescricao();
        verify(tipoVistoriaEntity).getId();
        verify(tipoVistoriaEntity).getNome();
        verify(tipoVistoriaEntity).getStatusAnterior();
        verify(tipoVistoriaEntity).getStatusPosterior();
        verify(tipoVistoriaEntity).setAtivo(eq(true));
        verify(tipoVistoriaEntity).setDataInclusao(isA(LocalDate.class));
        verify(tipoVistoriaEntity).setDescricao(eq("Descricao"));
        verify(tipoVistoriaEntity).setId(eq(1L));
        verify(tipoVistoriaEntity).setNome(eq("Nome"));
        verify(tipoVistoriaEntity).setStatusAnterior(eq("Status Anterior"));
        verify(tipoVistoriaEntity).setStatusPosterior(eq("Status Posterior"));
        verify(tipoVistoriaRepository).findById(eq(1L));
        assertEquals("1970-01-01", ((TipoVistoriaDTO) actualBuscarIdResult.getBody()).getDataInclusao().toString());
        assertEquals("Descricao", ((TipoVistoriaDTO) actualBuscarIdResult.getBody()).getDescricao());
        assertEquals("Nome", ((TipoVistoriaDTO) actualBuscarIdResult.getBody()).getNome());
        assertEquals("Status Anterior", ((TipoVistoriaDTO) actualBuscarIdResult.getBody()).getStatusAnterior());
        assertEquals("Status Posterior", ((TipoVistoriaDTO) actualBuscarIdResult.getBody()).getStatusPosterior());
        assertNull(((TipoVistoriaDTO) actualBuscarIdResult.getBody()).getItens());
        assertEquals(1L, ((TipoVistoriaDTO) actualBuscarIdResult.getBody()).getId().longValue());
        assertEquals(HttpStatus.OK, actualBuscarIdResult.getStatusCode());
        assertTrue(((TipoVistoriaDTO) actualBuscarIdResult.getBody()).getAtivo());
        assertTrue(actualBuscarIdResult.hasBody());
        assertTrue(actualBuscarIdResult.getHeaders().isEmpty());
    }

    /**
     * Method under test: {@link TipoVistoriaServiceImpl#buscar(String, Pageable)}
     */
    @Test
    void testBuscar() {
        // Arrange
        ItemVistoriaEntity itemVistoriaEntity = new ItemVistoriaEntity();
        itemVistoriaEntity.setAtivo(true);
        itemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity.setDescricao("Descricao");
        itemVistoriaEntity.setId(1L);
        itemVistoriaEntity.setNome("Nome");
        Optional<ItemVistoriaEntity> ofResult = Optional.of(itemVistoriaEntity);
        when(itemVistoriaRepository.findByNome(Mockito.<String>any())).thenReturn(ofResult);
        when(itensVistoriaRepository.findAllByCodItem(Mockito.<ItemVistoriaEntity>any())).thenReturn(new ArrayList<>());
        PageImpl<TipoVistoriaEntity> pageImpl = new PageImpl<>(new ArrayList<>());
        when(tipoVistoriaRepository.findAll(Mockito.<Specification<TipoVistoriaEntity>>any(), Mockito.<Pageable>any()))
                .thenReturn(pageImpl);

        // Act
        Page<TipoVistoriaEntity> actualBuscarResult = tipoVistoriaServiceImpl.buscar("Filter", null);

        // Assert
        verify(itemVistoriaRepository).findByNome(eq("Filter"));
        verify(itensVistoriaRepository).findAllByCodItem(isA(ItemVistoriaEntity.class));
        verify(tipoVistoriaRepository).findAll(isA(Specification.class), (Pageable) isNull());
        assertTrue(actualBuscarResult.toList().isEmpty());
        assertSame(pageImpl, actualBuscarResult);
    }

    /**
     * Method under test: {@link TipoVistoriaServiceImpl#buscar(String, Pageable)}
     */
    @Test
    void testBuscar2() {
        // Arrange
        ItemVistoriaEntity itemVistoriaEntity = new ItemVistoriaEntity();
        itemVistoriaEntity.setAtivo(true);
        itemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity.setDescricao("Descricao");
        itemVistoriaEntity.setId(1L);
        itemVistoriaEntity.setNome("Nome");
        Optional<ItemVistoriaEntity> ofResult = Optional.of(itemVistoriaEntity);
        when(itemVistoriaRepository.findByNome(Mockito.<String>any())).thenReturn(ofResult);
        when(itensVistoriaRepository.findAllByCodItem(Mockito.<ItemVistoriaEntity>any())).thenReturn(new ArrayList<>());
        when(tipoVistoriaRepository.findAll(Mockito.<Specification<TipoVistoriaEntity>>any(), Mockito.<Pageable>any()))
                .thenThrow(new VistoriaExceptions("An error occurred"));

        // Act and Assert
        assertThrows(VistoriaExceptions.class, () -> tipoVistoriaServiceImpl.buscar("Filter", null));
        verify(itemVistoriaRepository).findByNome(eq("Filter"));
        verify(itensVistoriaRepository).findAllByCodItem(isA(ItemVistoriaEntity.class));
        verify(tipoVistoriaRepository).findAll(isA(Specification.class), (Pageable) isNull());
    }

    /**
     * Method under test: {@link TipoVistoriaServiceImpl#buscar(String, Pageable)}
     */
    @Test
    void testBuscar3() {
        // Arrange
        Optional<ItemVistoriaEntity> emptyResult = Optional.empty();
        when(itemVistoriaRepository.findByNome(Mockito.<String>any())).thenReturn(emptyResult);
        PageImpl<TipoVistoriaEntity> pageImpl = new PageImpl<>(new ArrayList<>());
        when(tipoVistoriaRepository.findAll(Mockito.<Specification<TipoVistoriaEntity>>any(), Mockito.<Pageable>any()))
                .thenReturn(pageImpl);

        // Act
        Page<TipoVistoriaEntity> actualBuscarResult = tipoVistoriaServiceImpl.buscar("Filter", null);

        // Assert
        verify(itemVistoriaRepository).findByNome(eq("Filter"));
        verify(tipoVistoriaRepository).findAll(isA(Specification.class), (Pageable) isNull());
        assertTrue(actualBuscarResult.toList().isEmpty());
        assertSame(pageImpl, actualBuscarResult);
    }

    /**
     * Method under test: {@link TipoVistoriaServiceImpl#salvar(TipoVistoriaDTO)}
     */
    @Test
    void testSalvar() {
        // Arrange
        TipoVistoriaEntity tipoVistoriaEntity = new TipoVistoriaEntity();
        tipoVistoriaEntity.setAtivo(true);
        tipoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoriaEntity.setDescricao("Descricao");
        tipoVistoriaEntity.setId(1L);
        tipoVistoriaEntity.setNome("Nome");
        tipoVistoriaEntity.setStatusAnterior("Status Anterior");
        tipoVistoriaEntity.setStatusPosterior("Status Posterior");
        Optional<TipoVistoriaEntity> ofResult = Optional.of(tipoVistoriaEntity);
        when(tipoVistoriaRepository.findByNome(Mockito.<String>any())).thenReturn(ofResult);
        TipoVistoriaDTO.TipoVistoriaDTOBuilder ativoResult = TipoVistoriaDTO.builder().ativo(true);
        TipoVistoriaDTO.TipoVistoriaDTOBuilder idResult = ativoResult.dataInclusao(LocalDate.of(1970, 1, 1))
                .descricao("Descricao")
                .id(1L);
        TipoVistoriaDTO tipoVistoria = idResult.itens(new ArrayList<>())
                .nome("Nome")
                .statusAnterior("Status Anterior")
                .statusPosterior("Status Posterior")
                .build();

        // Act and Assert
        assertThrows(VistoriaExceptions.class, () -> tipoVistoriaServiceImpl.salvar(tipoVistoria));
        verify(tipoVistoriaRepository).findByNome(eq("Nome"));
    }

    /**
     * Method under test: {@link TipoVistoriaServiceImpl#salvar(TipoVistoriaDTO)}
     */
    @Test
    void testSalvar2() {
        // Arrange
        when(tipoVistoriaRepository.findByNome(Mockito.<String>any())).thenThrow(new IllegalArgumentException("foo"));
        TipoVistoriaDTO.TipoVistoriaDTOBuilder ativoResult = TipoVistoriaDTO.builder().ativo(true);
        TipoVistoriaDTO.TipoVistoriaDTOBuilder idResult = ativoResult.dataInclusao(LocalDate.of(1970, 1, 1))
                .descricao("Descricao")
                .id(1L);
        TipoVistoriaDTO tipoVistoria = idResult.itens(new ArrayList<>())
                .nome("Nome")
                .statusAnterior("Status Anterior")
                .statusPosterior("Status Posterior")
                .build();

        // Act and Assert
        assertThrows(IllegalArgumentException.class, () -> tipoVistoriaServiceImpl.salvar(tipoVistoria));
        verify(tipoVistoriaRepository).findByNome(eq("Nome"));
    }

    /**
     * Method under test: {@link TipoVistoriaServiceImpl#salvar(TipoVistoriaDTO)}
     */
    @Test
    void testSalvar3() {
        // Arrange
        when(itensVistoriaRepository.saveAll(Mockito.<Iterable<ItensVistoriaEntity>>any())).thenReturn(new ArrayList<>());

        TipoVistoriaEntity tipoVistoriaEntity = new TipoVistoriaEntity();
        tipoVistoriaEntity.setAtivo(true);
        tipoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoriaEntity.setDescricao("Descricao");
        tipoVistoriaEntity.setId(1L);
        tipoVistoriaEntity.setNome("Nome");
        tipoVistoriaEntity.setStatusAnterior("Status Anterior");
        tipoVistoriaEntity.setStatusPosterior("Status Posterior");
        when(tipoVistoriaRepository.save(Mockito.<TipoVistoriaEntity>any())).thenReturn(tipoVistoriaEntity);
        Optional<TipoVistoriaEntity> emptyResult = Optional.empty();
        when(tipoVistoriaRepository.findByNome(Mockito.<String>any())).thenReturn(emptyResult);
        TipoVistoriaDTO.TipoVistoriaDTOBuilder ativoResult = TipoVistoriaDTO.builder().ativo(true);
        TipoVistoriaDTO.TipoVistoriaDTOBuilder idResult = ativoResult.dataInclusao(LocalDate.of(1970, 1, 1))
                .descricao("Descricao")
                .id(1L);
        TipoVistoriaDTO tipoVistoria = idResult.itens(new ArrayList<>())
                .nome("Nome")
                .statusAnterior("Status Anterior")
                .statusPosterior("Status Posterior")
                .build();

        // Act
        ResponseEntity<?> actualSalvarResult = tipoVistoriaServiceImpl.salvar(tipoVistoria);

        // Assert
        verify(tipoVistoriaRepository).findByNome(eq("Nome"));
        verify(itensVistoriaRepository).saveAll(isA(Iterable.class));
        verify(tipoVistoriaRepository).save(isA(TipoVistoriaEntity.class));
        assertEquals(HttpStatus.OK, actualSalvarResult.getStatusCode());
        assertTrue(actualSalvarResult.hasBody());
        assertTrue(actualSalvarResult.getHeaders().isEmpty());
    }

    /**
     * Method under test: {@link TipoVistoriaServiceImpl#salvar(TipoVistoriaDTO)}
     */
    @Test
    void testSalvar4() {
        // Arrange
        TipoVistoriaDTO.TipoVistoriaDTOBuilder ativoResult = TipoVistoriaDTO.builder().ativo(true);
        TipoVistoriaDTO.TipoVistoriaDTOBuilder idResult = ativoResult.dataInclusao(LocalDate.of(1970, 1, 1))
                .descricao("Descricao")
                .id(1L);
        TipoVistoriaDTO tipoVistoria = idResult.itens(new ArrayList<>())
                .nome("")
                .statusAnterior("Status Anterior")
                .statusPosterior("Status Posterior")
                .build();

        // Act and Assert
        assertThrows(VistoriaExceptions.class, () -> tipoVistoriaServiceImpl.salvar(tipoVistoria));
    }

    /**
     * Method under test:
     * {@link TipoVistoriaServiceImpl#editar(Long, EdicaoTipoVistoriaDTO)}
     */
    @Test
    void testEditar() {
        // Arrange
        TipoVistoriaEntity tipoVistoriaEntity = new TipoVistoriaEntity();
        tipoVistoriaEntity.setAtivo(true);
        tipoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoriaEntity.setDescricao("Descricao");
        tipoVistoriaEntity.setId(1L);
        tipoVistoriaEntity.setNome("Nome");
        tipoVistoriaEntity.setStatusAnterior("Status Anterior");
        tipoVistoriaEntity.setStatusPosterior("Status Posterior");
        Optional<TipoVistoriaEntity> ofResult = Optional.of(tipoVistoriaEntity);
        when(tipoVistoriaRepository.findByNome(Mockito.<String>any())).thenReturn(ofResult);
        EdicaoTipoVistoriaDTO.EdicaoTipoVistoriaDTOBuilder descricaoResult = EdicaoTipoVistoriaDTO.builder()
                .descricao("Descricao");
        EdicaoTipoVistoriaDTO edicao = descricaoResult.itens(new ArrayList<>())
                .nome("Nome")
                .statusAnterior("Status Anterior")
                .statusPosterior("Status Posterior")
                .build();

        // Act and Assert
        assertThrows(VistoriaExceptions.class, () -> tipoVistoriaServiceImpl.editar(1L, edicao));
        verify(tipoVistoriaRepository).findByNome(eq("Nome"));
    }

    /**
     * Method under test:
     * {@link TipoVistoriaServiceImpl#editar(Long, EdicaoTipoVistoriaDTO)}
     */
    @Test
    void testEditar2() {
        // Arrange
        when(itensVistoriaRepository.findAllByCodTipo(Mockito.<TipoVistoriaEntity>any())).thenReturn(new ArrayList<>());

        TipoVistoriaEntity tipoVistoriaEntity = new TipoVistoriaEntity();
        tipoVistoriaEntity.setAtivo(true);
        tipoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoriaEntity.setDescricao("Descricao");
        tipoVistoriaEntity.setId(1L);
        tipoVistoriaEntity.setNome("Nome");
        tipoVistoriaEntity.setStatusAnterior("Status Anterior");
        tipoVistoriaEntity.setStatusPosterior("Status Posterior");
        Optional<TipoVistoriaEntity> ofResult = Optional.of(tipoVistoriaEntity);

        TipoVistoriaEntity tipoVistoriaEntity2 = new TipoVistoriaEntity();
        tipoVistoriaEntity2.setAtivo(true);
        tipoVistoriaEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoriaEntity2.setDescricao("Descricao");
        tipoVistoriaEntity2.setId(1L);
        tipoVistoriaEntity2.setNome("Nome");
        tipoVistoriaEntity2.setStatusAnterior("Status Anterior");
        tipoVistoriaEntity2.setStatusPosterior("Status Posterior");
        when(tipoVistoriaRepository.save(Mockito.<TipoVistoriaEntity>any())).thenReturn(tipoVistoriaEntity2);
        Optional<TipoVistoriaEntity> emptyResult = Optional.empty();
        when(tipoVistoriaRepository.findByNome(Mockito.<String>any())).thenReturn(emptyResult);
        when(tipoVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);
        EdicaoTipoVistoriaDTO.EdicaoTipoVistoriaDTOBuilder descricaoResult = EdicaoTipoVistoriaDTO.builder()
                .descricao("Descricao");
        EdicaoTipoVistoriaDTO edicao = descricaoResult.itens(new ArrayList<>())
                .nome("Nome")
                .statusAnterior("Status Anterior")
                .statusPosterior("Status Posterior")
                .build();

        // Act
        ResponseEntity<?> actualEditarResult = tipoVistoriaServiceImpl.editar(1L, edicao);

        // Assert
        verify(itensVistoriaRepository).findAllByCodTipo(isA(TipoVistoriaEntity.class));
        verify(tipoVistoriaRepository).findByNome(eq("Nome"));
        verify(tipoVistoriaRepository).findById(eq(1L));
        verify(tipoVistoriaRepository).save(isA(TipoVistoriaEntity.class));
        assertEquals(HttpStatus.OK, actualEditarResult.getStatusCode());
        assertTrue(actualEditarResult.hasBody());
        assertTrue(actualEditarResult.getHeaders().isEmpty());
    }

    /**
     * Method under test:
     * {@link TipoVistoriaServiceImpl#editar(Long, EdicaoTipoVistoriaDTO)}
     */
    @Test
    void testEditar3() {
        // Arrange
        when(itensVistoriaRepository.findAllByCodTipo(Mockito.<TipoVistoriaEntity>any())).thenReturn(new ArrayList<>());

        TipoVistoriaEntity tipoVistoriaEntity = new TipoVistoriaEntity();
        tipoVistoriaEntity.setAtivo(true);
        tipoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoriaEntity.setDescricao("Descricao");
        tipoVistoriaEntity.setId(1L);
        tipoVistoriaEntity.setNome("Nome");
        tipoVistoriaEntity.setStatusAnterior("Status Anterior");
        tipoVistoriaEntity.setStatusPosterior("Status Posterior");
        Optional<TipoVistoriaEntity> ofResult = Optional.of(tipoVistoriaEntity);
        when(tipoVistoriaRepository.save(Mockito.<TipoVistoriaEntity>any()))
                .thenThrow(new VistoriaExceptions("An error occurred"));
        Optional<TipoVistoriaEntity> emptyResult = Optional.empty();
        when(tipoVistoriaRepository.findByNome(Mockito.<String>any())).thenReturn(emptyResult);
        when(tipoVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);
        EdicaoTipoVistoriaDTO.EdicaoTipoVistoriaDTOBuilder descricaoResult = EdicaoTipoVistoriaDTO.builder()
                .descricao("Descricao");
        EdicaoTipoVistoriaDTO edicao = descricaoResult.itens(new ArrayList<>())
                .nome("Nome")
                .statusAnterior("Status Anterior")
                .statusPosterior("Status Posterior")
                .build();

        // Act and Assert
        assertThrows(VistoriaExceptions.class, () -> tipoVistoriaServiceImpl.editar(1L, edicao));
        verify(itensVistoriaRepository).findAllByCodTipo(isA(TipoVistoriaEntity.class));
        verify(tipoVistoriaRepository).findByNome(eq("Nome"));
        verify(tipoVistoriaRepository).findById(eq(1L));
        verify(tipoVistoriaRepository).save(isA(TipoVistoriaEntity.class));
    }

    /**
     * Method under test:
     * {@link TipoVistoriaServiceImpl#editar(Long, EdicaoTipoVistoriaDTO)}
     */
    @Test
    void testEditar4() {
        // Arrange
        ItemVistoriaEntity codItem = new ItemVistoriaEntity();
        codItem.setAtivo(true);
        codItem.setDataInclusao(LocalDate.of(1970, 1, 1));
        codItem.setDescricao("Descricao");
        codItem.setId(1L);
        codItem.setNome("Nome");

        TipoVistoriaEntity codTipo = new TipoVistoriaEntity();
        codTipo.setAtivo(true);
        codTipo.setDataInclusao(LocalDate.of(1970, 1, 1));
        codTipo.setDescricao("Descricao");
        codTipo.setId(1L);
        codTipo.setNome("Nome");
        codTipo.setStatusAnterior("Status Anterior");
        codTipo.setStatusPosterior("Status Posterior");

        ItensVistoriaEntity itensVistoriaEntity = new ItensVistoriaEntity();
        itensVistoriaEntity.setAtivo(true);
        itensVistoriaEntity.setCodItem(codItem);
        itensVistoriaEntity.setCodTipo(codTipo);
        itensVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itensVistoriaEntity.setId(1L);

        ArrayList<ItensVistoriaEntity> itensVistoriaEntityList = new ArrayList<>();
        itensVistoriaEntityList.add(itensVistoriaEntity);
        doNothing().when(itensVistoriaRepository).deleteAll(Mockito.<Iterable<ItensVistoriaEntity>>any());
        when(itensVistoriaRepository.findAllByCodTipo(Mockito.<TipoVistoriaEntity>any()))
                .thenReturn(itensVistoriaEntityList);

        TipoVistoriaEntity tipoVistoriaEntity = new TipoVistoriaEntity();
        tipoVistoriaEntity.setAtivo(true);
        tipoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoriaEntity.setDescricao("Descricao");
        tipoVistoriaEntity.setId(1L);
        tipoVistoriaEntity.setNome("Nome");
        tipoVistoriaEntity.setStatusAnterior("Status Anterior");
        tipoVistoriaEntity.setStatusPosterior("Status Posterior");
        Optional<TipoVistoriaEntity> ofResult = Optional.of(tipoVistoriaEntity);

        TipoVistoriaEntity tipoVistoriaEntity2 = new TipoVistoriaEntity();
        tipoVistoriaEntity2.setAtivo(true);
        tipoVistoriaEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoriaEntity2.setDescricao("Descricao");
        tipoVistoriaEntity2.setId(1L);
        tipoVistoriaEntity2.setNome("Nome");
        tipoVistoriaEntity2.setStatusAnterior("Status Anterior");
        tipoVistoriaEntity2.setStatusPosterior("Status Posterior");
        when(tipoVistoriaRepository.save(Mockito.<TipoVistoriaEntity>any())).thenReturn(tipoVistoriaEntity2);
        Optional<TipoVistoriaEntity> emptyResult = Optional.empty();
        when(tipoVistoriaRepository.findByNome(Mockito.<String>any())).thenReturn(emptyResult);
        when(tipoVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);
        EdicaoTipoVistoriaDTO.EdicaoTipoVistoriaDTOBuilder descricaoResult = EdicaoTipoVistoriaDTO.builder()
                .descricao("Descricao");
        EdicaoTipoVistoriaDTO edicao = descricaoResult.itens(new ArrayList<>())
                .nome("Nome")
                .statusAnterior("Status Anterior")
                .statusPosterior("Status Posterior")
                .build();

        // Act
        ResponseEntity<?> actualEditarResult = tipoVistoriaServiceImpl.editar(1L, edicao);

        // Assert
        verify(itensVistoriaRepository).findAllByCodTipo(isA(TipoVistoriaEntity.class));
        verify(tipoVistoriaRepository).findByNome(eq("Nome"));
        verify(itensVistoriaRepository).deleteAll(isA(Iterable.class));
        verify(tipoVistoriaRepository).findById(eq(1L));
        verify(tipoVistoriaRepository).save(isA(TipoVistoriaEntity.class));
        assertEquals(HttpStatus.OK, actualEditarResult.getStatusCode());
        assertTrue(actualEditarResult.hasBody());
        assertTrue(actualEditarResult.getHeaders().isEmpty());
    }

    /**
     * Method under test:
     * {@link TipoVistoriaServiceImpl#editar(Long, EdicaoTipoVistoriaDTO)}
     */
    @Test
    void testEditar5() {
        // Arrange
        ItemVistoriaEntity codItem = new ItemVistoriaEntity();
        codItem.setAtivo(true);
        codItem.setDataInclusao(LocalDate.of(1970, 1, 1));
        codItem.setDescricao("Descricao");
        codItem.setId(1L);
        codItem.setNome("Nome");

        TipoVistoriaEntity codTipo = new TipoVistoriaEntity();
        codTipo.setAtivo(true);
        codTipo.setDataInclusao(LocalDate.of(1970, 1, 1));
        codTipo.setDescricao("Descricao");
        codTipo.setId(1L);
        codTipo.setNome("Nome");
        codTipo.setStatusAnterior("Status Anterior");
        codTipo.setStatusPosterior("Status Posterior");

        ItensVistoriaEntity itensVistoriaEntity = new ItensVistoriaEntity();
        itensVistoriaEntity.setAtivo(true);
        itensVistoriaEntity.setCodItem(codItem);
        itensVistoriaEntity.setCodTipo(codTipo);
        itensVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itensVistoriaEntity.setId(1L);

        ArrayList<ItensVistoriaEntity> itensVistoriaEntityList = new ArrayList<>();
        itensVistoriaEntityList.add(itensVistoriaEntity);
        doNothing().when(itensVistoriaRepository).deleteAll(Mockito.<Iterable<ItensVistoriaEntity>>any());
        when(itensVistoriaRepository.findAllByCodTipo(Mockito.<TipoVistoriaEntity>any()))
                .thenReturn(itensVistoriaEntityList);
        TipoVistoriaEntity tipoVistoriaEntity = mock(TipoVistoriaEntity.class);
        doNothing().when(tipoVistoriaEntity).setAtivo(Mockito.<Boolean>any());
        doNothing().when(tipoVistoriaEntity).setDataInclusao(Mockito.<LocalDate>any());
        doNothing().when(tipoVistoriaEntity).setDescricao(Mockito.<String>any());
        doNothing().when(tipoVistoriaEntity).setId(Mockito.<Long>any());
        doNothing().when(tipoVistoriaEntity).setNome(Mockito.<String>any());
        doNothing().when(tipoVistoriaEntity).setStatusAnterior(Mockito.<String>any());
        doNothing().when(tipoVistoriaEntity).setStatusPosterior(Mockito.<String>any());
        tipoVistoriaEntity.setAtivo(true);
        tipoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoriaEntity.setDescricao("Descricao");
        tipoVistoriaEntity.setId(1L);
        tipoVistoriaEntity.setNome("Nome");
        tipoVistoriaEntity.setStatusAnterior("Status Anterior");
        tipoVistoriaEntity.setStatusPosterior("Status Posterior");
        Optional<TipoVistoriaEntity> ofResult = Optional.of(tipoVistoriaEntity);

        TipoVistoriaEntity tipoVistoriaEntity2 = new TipoVistoriaEntity();
        tipoVistoriaEntity2.setAtivo(true);
        tipoVistoriaEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoriaEntity2.setDescricao("Descricao");
        tipoVistoriaEntity2.setId(1L);
        tipoVistoriaEntity2.setNome("Nome");
        tipoVistoriaEntity2.setStatusAnterior("Status Anterior");
        tipoVistoriaEntity2.setStatusPosterior("Status Posterior");
        when(tipoVistoriaRepository.save(Mockito.<TipoVistoriaEntity>any())).thenReturn(tipoVistoriaEntity2);
        Optional<TipoVistoriaEntity> emptyResult = Optional.empty();
        when(tipoVistoriaRepository.findByNome(Mockito.<String>any())).thenReturn(emptyResult);
        when(tipoVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);
        EdicaoTipoVistoriaDTO.EdicaoTipoVistoriaDTOBuilder descricaoResult = EdicaoTipoVistoriaDTO.builder()
                .descricao("Descricao");
        EdicaoTipoVistoriaDTO edicao = descricaoResult.itens(new ArrayList<>())
                .nome("Nome")
                .statusAnterior("Status Anterior")
                .statusPosterior("Status Posterior")
                .build();

        // Act
        ResponseEntity<?> actualEditarResult = tipoVistoriaServiceImpl.editar(1L, edicao);

        // Assert
        verify(tipoVistoriaEntity).setAtivo(eq(true));
        verify(tipoVistoriaEntity).setDataInclusao(isA(LocalDate.class));
        verify(tipoVistoriaEntity, atLeast(1)).setDescricao(eq("Descricao"));
        verify(tipoVistoriaEntity).setId(eq(1L));
        verify(tipoVistoriaEntity, atLeast(1)).setNome(eq("Nome"));
        verify(tipoVistoriaEntity, atLeast(1)).setStatusAnterior(eq("Status Anterior"));
        verify(tipoVistoriaEntity, atLeast(1)).setStatusPosterior(eq("Status Posterior"));
        verify(itensVistoriaRepository).findAllByCodTipo(isA(TipoVistoriaEntity.class));
        verify(tipoVistoriaRepository).findByNome(eq("Nome"));
        verify(itensVistoriaRepository).deleteAll(isA(Iterable.class));
        verify(tipoVistoriaRepository).findById(eq(1L));
        verify(tipoVistoriaRepository).save(isA(TipoVistoriaEntity.class));
        assertEquals(HttpStatus.OK, actualEditarResult.getStatusCode());
        assertTrue(actualEditarResult.hasBody());
        assertTrue(actualEditarResult.getHeaders().isEmpty());
    }

    /**
     * Method under test: {@link TipoVistoriaServiceImpl#desativar(Long)}
     */
    @Test
    void testDesativar() {
        // Arrange
        TipoVistoriaEntity tipoVistoriaEntity = new TipoVistoriaEntity();
        tipoVistoriaEntity.setAtivo(true);
        tipoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoriaEntity.setDescricao("Descricao");
        tipoVistoriaEntity.setId(1L);
        tipoVistoriaEntity.setNome("Nome");
        tipoVistoriaEntity.setStatusAnterior("Status Anterior");
        tipoVistoriaEntity.setStatusPosterior("Status Posterior");
        Optional<TipoVistoriaEntity> ofResult = Optional.of(tipoVistoriaEntity);

        TipoVistoriaEntity tipoVistoriaEntity2 = new TipoVistoriaEntity();
        tipoVistoriaEntity2.setAtivo(true);
        tipoVistoriaEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoriaEntity2.setDescricao("Descricao");
        tipoVistoriaEntity2.setId(1L);
        tipoVistoriaEntity2.setNome("Nome");
        tipoVistoriaEntity2.setStatusAnterior("Status Anterior");
        tipoVistoriaEntity2.setStatusPosterior("Status Posterior");
        when(tipoVistoriaRepository.save(Mockito.<TipoVistoriaEntity>any())).thenReturn(tipoVistoriaEntity2);
        when(tipoVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        // Act
        ResponseEntity<?> actualDesativarResult = tipoVistoriaServiceImpl.desativar(1L);

        // Assert
        verify(tipoVistoriaRepository).findById(eq(1L));
        verify(tipoVistoriaRepository).save(isA(TipoVistoriaEntity.class));
        assertNull(actualDesativarResult.getBody());
        assertEquals(HttpStatus.OK, actualDesativarResult.getStatusCode());
        assertTrue(actualDesativarResult.getHeaders().isEmpty());
    }

    /**
     * Method under test: {@link TipoVistoriaServiceImpl#desativar(Long)}
     */
    @Test
    void testDesativar2() {
        // Arrange
        TipoVistoriaEntity tipoVistoriaEntity = new TipoVistoriaEntity();
        tipoVistoriaEntity.setAtivo(true);
        tipoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoriaEntity.setDescricao("Descricao");
        tipoVistoriaEntity.setId(1L);
        tipoVistoriaEntity.setNome("Nome");
        tipoVistoriaEntity.setStatusAnterior("Status Anterior");
        tipoVistoriaEntity.setStatusPosterior("Status Posterior");
        Optional<TipoVistoriaEntity> ofResult = Optional.of(tipoVistoriaEntity);
        when(tipoVistoriaRepository.save(Mockito.<TipoVistoriaEntity>any()))
                .thenThrow(new VistoriaExceptions("An error occurred"));
        when(tipoVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        // Act and Assert
        assertThrows(VistoriaExceptions.class, () -> tipoVistoriaServiceImpl.desativar(1L));
        verify(tipoVistoriaRepository).findById(eq(1L));
        verify(tipoVistoriaRepository).save(isA(TipoVistoriaEntity.class));
    }

    /**
     * Method under test: {@link TipoVistoriaServiceImpl#desativar(Long)}
     */
    @Test
    void testDesativar3() {
        // Arrange
        TipoVistoriaEntity tipoVistoriaEntity = mock(TipoVistoriaEntity.class);
        doNothing().when(tipoVistoriaEntity).setAtivo(Mockito.<Boolean>any());
        doNothing().when(tipoVistoriaEntity).setDataInclusao(Mockito.<LocalDate>any());
        doNothing().when(tipoVistoriaEntity).setDescricao(Mockito.<String>any());
        doNothing().when(tipoVistoriaEntity).setId(Mockito.<Long>any());
        doNothing().when(tipoVistoriaEntity).setNome(Mockito.<String>any());
        doNothing().when(tipoVistoriaEntity).setStatusAnterior(Mockito.<String>any());
        doNothing().when(tipoVistoriaEntity).setStatusPosterior(Mockito.<String>any());
        tipoVistoriaEntity.setAtivo(true);
        tipoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoriaEntity.setDescricao("Descricao");
        tipoVistoriaEntity.setId(1L);
        tipoVistoriaEntity.setNome("Nome");
        tipoVistoriaEntity.setStatusAnterior("Status Anterior");
        tipoVistoriaEntity.setStatusPosterior("Status Posterior");
        Optional<TipoVistoriaEntity> ofResult = Optional.of(tipoVistoriaEntity);

        TipoVistoriaEntity tipoVistoriaEntity2 = new TipoVistoriaEntity();
        tipoVistoriaEntity2.setAtivo(true);
        tipoVistoriaEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoriaEntity2.setDescricao("Descricao");
        tipoVistoriaEntity2.setId(1L);
        tipoVistoriaEntity2.setNome("Nome");
        tipoVistoriaEntity2.setStatusAnterior("Status Anterior");
        tipoVistoriaEntity2.setStatusPosterior("Status Posterior");
        when(tipoVistoriaRepository.save(Mockito.<TipoVistoriaEntity>any())).thenReturn(tipoVistoriaEntity2);
        when(tipoVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        // Act
        ResponseEntity<?> actualDesativarResult = tipoVistoriaServiceImpl.desativar(1L);

        // Assert
        verify(tipoVistoriaEntity, atLeast(1)).setAtivo(Mockito.<Boolean>any());
        verify(tipoVistoriaEntity).setDataInclusao(isA(LocalDate.class));
        verify(tipoVistoriaEntity).setDescricao(eq("Descricao"));
        verify(tipoVistoriaEntity).setId(eq(1L));
        verify(tipoVistoriaEntity).setNome(eq("Nome"));
        verify(tipoVistoriaEntity).setStatusAnterior(eq("Status Anterior"));
        verify(tipoVistoriaEntity).setStatusPosterior(eq("Status Posterior"));
        verify(tipoVistoriaRepository).findById(eq(1L));
        verify(tipoVistoriaRepository).save(isA(TipoVistoriaEntity.class));
        assertNull(actualDesativarResult.getBody());
        assertEquals(HttpStatus.OK, actualDesativarResult.getStatusCode());
        assertTrue(actualDesativarResult.getHeaders().isEmpty());
    }

    /**
     * Method under test: {@link TipoVistoriaServiceImpl#excluir(Long)}
     */
    @Test
    void testExcluir() {
        // Arrange
        TipoVistoriaEntity tipoVistoriaEntity = new TipoVistoriaEntity();
        tipoVistoriaEntity.setAtivo(true);
        tipoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoriaEntity.setDescricao("Descricao");
        tipoVistoriaEntity.setId(1L);
        tipoVistoriaEntity.setNome("Nome");
        tipoVistoriaEntity.setStatusAnterior("Status Anterior");
        tipoVistoriaEntity.setStatusPosterior("Status Posterior");
        Optional<TipoVistoriaEntity> ofResult = Optional.of(tipoVistoriaEntity);
        doNothing().when(tipoVistoriaRepository).delete(Mockito.<TipoVistoriaEntity>any());
        when(tipoVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        // Act
        ResponseEntity<?> actualExcluirResult = tipoVistoriaServiceImpl.excluir(1L);

        // Assert
        verify(tipoVistoriaRepository).delete(isA(TipoVistoriaEntity.class));
        verify(tipoVistoriaRepository).findById(eq(1L));
        assertNull(actualExcluirResult.getBody());
        assertEquals(HttpStatus.OK, actualExcluirResult.getStatusCode());
        assertTrue(actualExcluirResult.getHeaders().isEmpty());
    }

    /**
     * Method under test: {@link TipoVistoriaServiceImpl#excluir(Long)}
     */
    @Test
    void testExcluir2() {
        // Arrange
        TipoVistoriaEntity tipoVistoriaEntity = new TipoVistoriaEntity();
        tipoVistoriaEntity.setAtivo(true);
        tipoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoriaEntity.setDescricao("Descricao");
        tipoVistoriaEntity.setId(1L);
        tipoVistoriaEntity.setNome("Nome");
        tipoVistoriaEntity.setStatusAnterior("Status Anterior");
        tipoVistoriaEntity.setStatusPosterior("Status Posterior");
        Optional<TipoVistoriaEntity> ofResult = Optional.of(tipoVistoriaEntity);
        doThrow(new VistoriaExceptions("An error occurred")).when(tipoVistoriaRepository)
                .delete(Mockito.<TipoVistoriaEntity>any());
        when(tipoVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        // Act and Assert
        assertThrows(VistoriaExceptions.class, () -> tipoVistoriaServiceImpl.excluir(1L));
        verify(tipoVistoriaRepository).delete(isA(TipoVistoriaEntity.class));
        verify(tipoVistoriaRepository).findById(eq(1L));
    }

    /**
     * Method under test: {@link TipoVistoriaServiceImpl#ativar(Long)}
     */
    @Test
    void testAtivar() {
        // Arrange
        TipoVistoriaEntity tipoVistoriaEntity = new TipoVistoriaEntity();
        tipoVistoriaEntity.setAtivo(true);
        tipoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoriaEntity.setDescricao("Descricao");
        tipoVistoriaEntity.setId(1L);
        tipoVistoriaEntity.setNome("Nome");
        tipoVistoriaEntity.setStatusAnterior("Status Anterior");
        tipoVistoriaEntity.setStatusPosterior("Status Posterior");
        Optional<TipoVistoriaEntity> ofResult = Optional.of(tipoVistoriaEntity);

        TipoVistoriaEntity tipoVistoriaEntity2 = new TipoVistoriaEntity();
        tipoVistoriaEntity2.setAtivo(true);
        tipoVistoriaEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoriaEntity2.setDescricao("Descricao");
        tipoVistoriaEntity2.setId(1L);
        tipoVistoriaEntity2.setNome("Nome");
        tipoVistoriaEntity2.setStatusAnterior("Status Anterior");
        tipoVistoriaEntity2.setStatusPosterior("Status Posterior");
        when(tipoVistoriaRepository.save(Mockito.<TipoVistoriaEntity>any())).thenReturn(tipoVistoriaEntity2);
        when(tipoVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        // Act
        ResponseEntity<?> actualAtivarResult = tipoVistoriaServiceImpl.ativar(1L);

        // Assert
        verify(tipoVistoriaRepository).findById(eq(1L));
        verify(tipoVistoriaRepository).save(isA(TipoVistoriaEntity.class));
        assertNull(actualAtivarResult.getBody());
        assertEquals(HttpStatus.OK, actualAtivarResult.getStatusCode());
        assertTrue(actualAtivarResult.getHeaders().isEmpty());
    }

    /**
     * Method under test: {@link TipoVistoriaServiceImpl#ativar(Long)}
     */
    @Test
    void testAtivar2() {
        // Arrange
        TipoVistoriaEntity tipoVistoriaEntity = new TipoVistoriaEntity();
        tipoVistoriaEntity.setAtivo(true);
        tipoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoriaEntity.setDescricao("Descricao");
        tipoVistoriaEntity.setId(1L);
        tipoVistoriaEntity.setNome("Nome");
        tipoVistoriaEntity.setStatusAnterior("Status Anterior");
        tipoVistoriaEntity.setStatusPosterior("Status Posterior");
        Optional<TipoVistoriaEntity> ofResult = Optional.of(tipoVistoriaEntity);
        when(tipoVistoriaRepository.save(Mockito.<TipoVistoriaEntity>any()))
                .thenThrow(new VistoriaExceptions("An error occurred"));
        when(tipoVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        // Act and Assert
        assertThrows(VistoriaExceptions.class, () -> tipoVistoriaServiceImpl.ativar(1L));
        verify(tipoVistoriaRepository).findById(eq(1L));
        verify(tipoVistoriaRepository).save(isA(TipoVistoriaEntity.class));
    }

    /**
     * Method under test: {@link TipoVistoriaServiceImpl#ativar(Long)}
     */
    @Test
    void testAtivar3() {
        // Arrange
        TipoVistoriaEntity tipoVistoriaEntity = mock(TipoVistoriaEntity.class);
        doNothing().when(tipoVistoriaEntity).setAtivo(Mockito.<Boolean>any());
        doNothing().when(tipoVistoriaEntity).setDataInclusao(Mockito.<LocalDate>any());
        doNothing().when(tipoVistoriaEntity).setDescricao(Mockito.<String>any());
        doNothing().when(tipoVistoriaEntity).setId(Mockito.<Long>any());
        doNothing().when(tipoVistoriaEntity).setNome(Mockito.<String>any());
        doNothing().when(tipoVistoriaEntity).setStatusAnterior(Mockito.<String>any());
        doNothing().when(tipoVistoriaEntity).setStatusPosterior(Mockito.<String>any());
        tipoVistoriaEntity.setAtivo(true);
        tipoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoriaEntity.setDescricao("Descricao");
        tipoVistoriaEntity.setId(1L);
        tipoVistoriaEntity.setNome("Nome");
        tipoVistoriaEntity.setStatusAnterior("Status Anterior");
        tipoVistoriaEntity.setStatusPosterior("Status Posterior");
        Optional<TipoVistoriaEntity> ofResult = Optional.of(tipoVistoriaEntity);

        TipoVistoriaEntity tipoVistoriaEntity2 = new TipoVistoriaEntity();
        tipoVistoriaEntity2.setAtivo(true);
        tipoVistoriaEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoriaEntity2.setDescricao("Descricao");
        tipoVistoriaEntity2.setId(1L);
        tipoVistoriaEntity2.setNome("Nome");
        tipoVistoriaEntity2.setStatusAnterior("Status Anterior");
        tipoVistoriaEntity2.setStatusPosterior("Status Posterior");
        when(tipoVistoriaRepository.save(Mockito.<TipoVistoriaEntity>any())).thenReturn(tipoVistoriaEntity2);
        when(tipoVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        // Act
        ResponseEntity<?> actualAtivarResult = tipoVistoriaServiceImpl.ativar(1L);

        // Assert
        verify(tipoVistoriaEntity, atLeast(1)).setAtivo(eq(true));
        verify(tipoVistoriaEntity).setDataInclusao(isA(LocalDate.class));
        verify(tipoVistoriaEntity).setDescricao(eq("Descricao"));
        verify(tipoVistoriaEntity).setId(eq(1L));
        verify(tipoVistoriaEntity).setNome(eq("Nome"));
        verify(tipoVistoriaEntity).setStatusAnterior(eq("Status Anterior"));
        verify(tipoVistoriaEntity).setStatusPosterior(eq("Status Posterior"));
        verify(tipoVistoriaRepository).findById(eq(1L));
        verify(tipoVistoriaRepository).save(isA(TipoVistoriaEntity.class));
        assertNull(actualAtivarResult.getBody());
        assertEquals(HttpStatus.OK, actualAtivarResult.getStatusCode());
        assertTrue(actualAtivarResult.getHeaders().isEmpty());
    }

    /**
     * Method under test: {@link TipoVistoriaServiceImpl#findAllItensVistoria()}
     */
    @Test
    void testFindAllItensVistoria() {
        // Arrange
        when(itensVistoriaRepository.findAll()).thenReturn(new ArrayList<>());

        // Act
        ResponseEntity<List<ItensVistoriaEntity>> actualFindAllItensVistoriaResult = tipoVistoriaServiceImpl
                .findAllItensVistoria();

        // Assert
        verify(itensVistoriaRepository).findAll();
        assertEquals(HttpStatus.OK, actualFindAllItensVistoriaResult.getStatusCode());
        assertTrue(actualFindAllItensVistoriaResult.hasBody());
        assertTrue(actualFindAllItensVistoriaResult.getHeaders().isEmpty());
    }

    /**
     * Method under test: {@link TipoVistoriaServiceImpl#findAllItensVistoria()}
     */
    @Test
    void testFindAllItensVistoria2() {
        // Arrange
        when(itensVistoriaRepository.findAll()).thenThrow(new VistoriaExceptions("An error occurred"));

        // Act and Assert
        assertThrows(VistoriaExceptions.class, () -> tipoVistoriaServiceImpl.findAllItensVistoria());
        verify(itensVistoriaRepository).findAll();
    }

    /**
     * Method under test:
     * {@link TipoVistoriaServiceImpl#findAllItemVistoriaById(String)}
     */
    @Test
    void testFindAllItemVistoriaById() {
        // Arrange
        ArrayList<ItensVistoriaEntity> itensVistoriaEntityList = new ArrayList<>();
        when(itensVistoriaRepository.findAllByCodTipo(Mockito.<TipoVistoriaEntity>any()))
                .thenReturn(itensVistoriaEntityList);

        TipoVistoriaEntity tipoVistoriaEntity = new TipoVistoriaEntity();
        tipoVistoriaEntity.setAtivo(true);
        tipoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoriaEntity.setDescricao("Descricao");
        tipoVistoriaEntity.setId(1L);
        tipoVistoriaEntity.setNome("Nome");
        tipoVistoriaEntity.setStatusAnterior("Status Anterior");
        tipoVistoriaEntity.setStatusPosterior("Status Posterior");
        Optional<TipoVistoriaEntity> ofResult = Optional.of(tipoVistoriaEntity);
        when(tipoVistoriaRepository.findByNome(Mockito.<String>any())).thenReturn(ofResult);

        // Act
        ResponseEntity<List<ItemVistoriaEntity>> actualFindAllItemVistoriaByIdResult = tipoVistoriaServiceImpl
                .findAllItemVistoriaById("Nome");

        // Assert
        verify(itensVistoriaRepository).findAllByCodTipo(isA(TipoVistoriaEntity.class));
        verify(tipoVistoriaRepository).findByNome(eq("Nome"));
        assertEquals(HttpStatus.OK, actualFindAllItemVistoriaByIdResult.getStatusCode());
        assertTrue(actualFindAllItemVistoriaByIdResult.getHeaders().isEmpty());
        assertEquals(itensVistoriaEntityList, actualFindAllItemVistoriaByIdResult.getBody());
    }

    /**
     * Method under test:
     * {@link TipoVistoriaServiceImpl#findAllItemVistoriaById(String)}
     */
    @Test
    void testFindAllItemVistoriaById2() {
        // Arrange
        when(itensVistoriaRepository.findAllByCodTipo(Mockito.<TipoVistoriaEntity>any()))
                .thenThrow(new VistoriaExceptions("An error occurred"));

        TipoVistoriaEntity tipoVistoriaEntity = new TipoVistoriaEntity();
        tipoVistoriaEntity.setAtivo(true);
        tipoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoriaEntity.setDescricao("Descricao");
        tipoVistoriaEntity.setId(1L);
        tipoVistoriaEntity.setNome("Nome");
        tipoVistoriaEntity.setStatusAnterior("Status Anterior");
        tipoVistoriaEntity.setStatusPosterior("Status Posterior");
        Optional<TipoVistoriaEntity> ofResult = Optional.of(tipoVistoriaEntity);
        when(tipoVistoriaRepository.findByNome(Mockito.<String>any())).thenReturn(ofResult);

        // Act and Assert
        assertThrows(VistoriaExceptions.class, () -> tipoVistoriaServiceImpl.findAllItemVistoriaById("Nome"));
        verify(itensVistoriaRepository).findAllByCodTipo(isA(TipoVistoriaEntity.class));
        verify(tipoVistoriaRepository).findByNome(eq("Nome"));
    }

    /**
     * Method under test:
     * {@link TipoVistoriaServiceImpl#findAllItemVistoriaById(String)}
     */
    @Test
    void testFindAllItemVistoriaById3() {
        // Arrange
        ItemVistoriaEntity itemVistoriaEntity = new ItemVistoriaEntity();
        itemVistoriaEntity.setAtivo(true);
        itemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity.setDescricao("Descricao");
        itemVistoriaEntity.setId(1L);
        itemVistoriaEntity.setNome("Nome");
        Optional<ItemVistoriaEntity> ofResult = Optional.of(itemVistoriaEntity);
        when(itemVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        ItemVistoriaEntity codItem = new ItemVistoriaEntity();
        codItem.setAtivo(true);
        codItem.setDataInclusao(LocalDate.of(1970, 1, 1));
        codItem.setDescricao("Descricao");
        codItem.setId(1L);
        codItem.setNome("Nome");

        TipoVistoriaEntity codTipo = new TipoVistoriaEntity();
        codTipo.setAtivo(true);
        codTipo.setDataInclusao(LocalDate.of(1970, 1, 1));
        codTipo.setDescricao("Descricao");
        codTipo.setId(1L);
        codTipo.setNome("Nome");
        codTipo.setStatusAnterior("Status Anterior");
        codTipo.setStatusPosterior("Status Posterior");

        ItensVistoriaEntity itensVistoriaEntity = new ItensVistoriaEntity();
        itensVistoriaEntity.setAtivo(true);
        itensVistoriaEntity.setCodItem(codItem);
        itensVistoriaEntity.setCodTipo(codTipo);
        itensVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itensVistoriaEntity.setId(1L);

        ArrayList<ItensVistoriaEntity> itensVistoriaEntityList = new ArrayList<>();
        itensVistoriaEntityList.add(itensVistoriaEntity);
        when(itensVistoriaRepository.findAllByCodTipo(Mockito.<TipoVistoriaEntity>any()))
                .thenReturn(itensVistoriaEntityList);

        TipoVistoriaEntity tipoVistoriaEntity = new TipoVistoriaEntity();
        tipoVistoriaEntity.setAtivo(true);
        tipoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoriaEntity.setDescricao("Descricao");
        tipoVistoriaEntity.setId(1L);
        tipoVistoriaEntity.setNome("Nome");
        tipoVistoriaEntity.setStatusAnterior("Status Anterior");
        tipoVistoriaEntity.setStatusPosterior("Status Posterior");
        Optional<TipoVistoriaEntity> ofResult2 = Optional.of(tipoVistoriaEntity);
        when(tipoVistoriaRepository.findByNome(Mockito.<String>any())).thenReturn(ofResult2);

        // Act
        ResponseEntity<List<ItemVistoriaEntity>> actualFindAllItemVistoriaByIdResult = tipoVistoriaServiceImpl
                .findAllItemVistoriaById("Nome");

        // Assert
        verify(itensVistoriaRepository).findAllByCodTipo(isA(TipoVistoriaEntity.class));
        verify(tipoVistoriaRepository).findByNome(eq("Nome"));
        verify(itemVistoriaRepository).findById(eq(1L));
        assertEquals(1, actualFindAllItemVistoriaByIdResult.getBody().size());
        assertEquals(HttpStatus.OK, actualFindAllItemVistoriaByIdResult.getStatusCode());
        assertTrue(actualFindAllItemVistoriaByIdResult.hasBody());
        assertTrue(actualFindAllItemVistoriaByIdResult.getHeaders().isEmpty());
    }

    /**
     * Method under test:
     * {@link TipoVistoriaServiceImpl#findAllItemVistoriaById(String)}
     */
    @Test
    void testFindAllItemVistoriaById4() {
        // Arrange
        ItemVistoriaEntity itemVistoriaEntity = new ItemVistoriaEntity();
        itemVistoriaEntity.setAtivo(true);
        itemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity.setDescricao("Descricao");
        itemVistoriaEntity.setId(1L);
        itemVistoriaEntity.setNome("Nome");
        Optional<ItemVistoriaEntity> ofResult = Optional.of(itemVistoriaEntity);
        when(itemVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        ItemVistoriaEntity codItem = new ItemVistoriaEntity();
        codItem.setAtivo(true);
        codItem.setDataInclusao(LocalDate.of(1970, 1, 1));
        codItem.setDescricao("Descricao");
        codItem.setId(1L);
        codItem.setNome("Nome");

        TipoVistoriaEntity codTipo = new TipoVistoriaEntity();
        codTipo.setAtivo(true);
        codTipo.setDataInclusao(LocalDate.of(1970, 1, 1));
        codTipo.setDescricao("Descricao");
        codTipo.setId(1L);
        codTipo.setNome("Nome");
        codTipo.setStatusAnterior("Status Anterior");
        codTipo.setStatusPosterior("Status Posterior");

        ItemVistoriaEntity itemVistoriaEntity2 = new ItemVistoriaEntity();
        itemVistoriaEntity2.setAtivo(true);
        itemVistoriaEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity2.setDescricao("Descricao");
        itemVistoriaEntity2.setId(1L);
        itemVistoriaEntity2.setNome("Nome");
        ItensVistoriaEntity itensVistoriaEntity = mock(ItensVistoriaEntity.class);
        when(itensVistoriaEntity.getCodItem()).thenReturn(itemVistoriaEntity2);
        doNothing().when(itensVistoriaEntity).setAtivo(Mockito.<Boolean>any());
        doNothing().when(itensVistoriaEntity).setCodItem(Mockito.<ItemVistoriaEntity>any());
        doNothing().when(itensVistoriaEntity).setCodTipo(Mockito.<TipoVistoriaEntity>any());
        doNothing().when(itensVistoriaEntity).setDataInclusao(Mockito.<LocalDate>any());
        doNothing().when(itensVistoriaEntity).setId(Mockito.<Long>any());
        itensVistoriaEntity.setAtivo(true);
        itensVistoriaEntity.setCodItem(codItem);
        itensVistoriaEntity.setCodTipo(codTipo);
        itensVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itensVistoriaEntity.setId(1L);

        ArrayList<ItensVistoriaEntity> itensVistoriaEntityList = new ArrayList<>();
        itensVistoriaEntityList.add(itensVistoriaEntity);
        when(itensVistoriaRepository.findAllByCodTipo(Mockito.<TipoVistoriaEntity>any()))
                .thenReturn(itensVistoriaEntityList);

        TipoVistoriaEntity tipoVistoriaEntity = new TipoVistoriaEntity();
        tipoVistoriaEntity.setAtivo(true);
        tipoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoriaEntity.setDescricao("Descricao");
        tipoVistoriaEntity.setId(1L);
        tipoVistoriaEntity.setNome("Nome");
        tipoVistoriaEntity.setStatusAnterior("Status Anterior");
        tipoVistoriaEntity.setStatusPosterior("Status Posterior");
        Optional<TipoVistoriaEntity> ofResult2 = Optional.of(tipoVistoriaEntity);
        when(tipoVistoriaRepository.findByNome(Mockito.<String>any())).thenReturn(ofResult2);

        // Act
        ResponseEntity<List<ItemVistoriaEntity>> actualFindAllItemVistoriaByIdResult = tipoVistoriaServiceImpl
                .findAllItemVistoriaById("Nome");

        // Assert
        verify(itensVistoriaEntity).getCodItem();
        verify(itensVistoriaEntity).setAtivo(eq(true));
        verify(itensVistoriaEntity).setCodItem(isA(ItemVistoriaEntity.class));
        verify(itensVistoriaEntity).setCodTipo(isA(TipoVistoriaEntity.class));
        verify(itensVistoriaEntity).setDataInclusao(isA(LocalDate.class));
        verify(itensVistoriaEntity).setId(eq(1L));
        verify(itensVistoriaRepository).findAllByCodTipo(isA(TipoVistoriaEntity.class));
        verify(tipoVistoriaRepository).findByNome(eq("Nome"));
        verify(itemVistoriaRepository).findById(eq(1L));
        assertEquals(1, actualFindAllItemVistoriaByIdResult.getBody().size());
        assertEquals(HttpStatus.OK, actualFindAllItemVistoriaByIdResult.getStatusCode());
        assertTrue(actualFindAllItemVistoriaByIdResult.hasBody());
        assertTrue(actualFindAllItemVistoriaByIdResult.getHeaders().isEmpty());
    }

    /**
     * Method under test: {@link TipoVistoriaServiceImpl#findAllItemVistoria()}
     */
    @Test
    void testFindAllItemVistoria() {
        // Arrange
        when(itemVistoriaRepository.findAll(Mockito.<Sort>any())).thenReturn(new ArrayList<>());

        // Act
        ResponseEntity<List<ItemVistoriaEntity>> actualFindAllItemVistoriaResult = tipoVistoriaServiceImpl
                .findAllItemVistoria();

        // Assert
        verify(itemVistoriaRepository).findAll(isA(Sort.class));
        assertEquals(HttpStatus.OK, actualFindAllItemVistoriaResult.getStatusCode());
        assertTrue(actualFindAllItemVistoriaResult.getBody().isEmpty());
        assertTrue(actualFindAllItemVistoriaResult.hasBody());
        assertTrue(actualFindAllItemVistoriaResult.getHeaders().isEmpty());
    }

    /**
     * Method under test: {@link TipoVistoriaServiceImpl#findAllItemVistoria()}
     */
    @Test
    void testFindAllItemVistoria2() {
        // Arrange
        ItemVistoriaEntity itemVistoriaEntity = new ItemVistoriaEntity();
        itemVistoriaEntity.setAtivo(true);
        itemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity.setDescricao("nome");
        itemVistoriaEntity.setId(1L);
        itemVistoriaEntity.setNome("nome");

        ArrayList<ItemVistoriaEntity> itemVistoriaEntityList = new ArrayList<>();
        itemVistoriaEntityList.add(itemVistoriaEntity);
        when(itemVistoriaRepository.findAll(Mockito.<Sort>any())).thenReturn(itemVistoriaEntityList);

        // Act
        ResponseEntity<List<ItemVistoriaEntity>> actualFindAllItemVistoriaResult = tipoVistoriaServiceImpl
                .findAllItemVistoria();

        // Assert
        verify(itemVistoriaRepository).findAll(isA(Sort.class));
        assertEquals(1, actualFindAllItemVistoriaResult.getBody().size());
        assertEquals(HttpStatus.OK, actualFindAllItemVistoriaResult.getStatusCode());
        assertTrue(actualFindAllItemVistoriaResult.hasBody());
        assertTrue(actualFindAllItemVistoriaResult.getHeaders().isEmpty());
    }

    /**
     * Method under test: {@link TipoVistoriaServiceImpl#findAllItemVistoria()}
     */
    @Test
    void testFindAllItemVistoria3() {
        // Arrange
        ItemVistoriaEntity itemVistoriaEntity = new ItemVistoriaEntity();
        itemVistoriaEntity.setAtivo(true);
        itemVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity.setDescricao("nome");
        itemVistoriaEntity.setId(1L);
        itemVistoriaEntity.setNome("nome");

        ItemVistoriaEntity itemVistoriaEntity2 = new ItemVistoriaEntity();
        itemVistoriaEntity2.setAtivo(false);
        itemVistoriaEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        itemVistoriaEntity2.setDescricao("Descricao");
        itemVistoriaEntity2.setId(2L);
        itemVistoriaEntity2.setNome("Nome");

        ArrayList<ItemVistoriaEntity> itemVistoriaEntityList = new ArrayList<>();
        itemVistoriaEntityList.add(itemVistoriaEntity2);
        itemVistoriaEntityList.add(itemVistoriaEntity);
        when(itemVistoriaRepository.findAll(Mockito.<Sort>any())).thenReturn(itemVistoriaEntityList);

        // Act
        ResponseEntity<List<ItemVistoriaEntity>> actualFindAllItemVistoriaResult = tipoVistoriaServiceImpl
                .findAllItemVistoria();

        // Assert
        verify(itemVistoriaRepository).findAll(isA(Sort.class));
        assertEquals(1, actualFindAllItemVistoriaResult.getBody().size());
        assertEquals(HttpStatus.OK, actualFindAllItemVistoriaResult.getStatusCode());
        assertTrue(actualFindAllItemVistoriaResult.hasBody());
        assertTrue(actualFindAllItemVistoriaResult.getHeaders().isEmpty());
    }

    /**
     * Method under test: {@link TipoVistoriaServiceImpl#findAllItemVistoria()}
     */
    @Test
    void testFindAllItemVistoria4() {
        // Arrange
        when(itemVistoriaRepository.findAll(Mockito.<Sort>any())).thenThrow(new VistoriaExceptions("An error occurred"));

        // Act and Assert
        assertThrows(VistoriaExceptions.class, () -> tipoVistoriaServiceImpl.findAllItemVistoria());
        verify(itemVistoriaRepository).findAll(isA(Sort.class));
    }

    /**
     * Method under test:
     * {@link TipoVistoriaServiceImpl#listAllTipoVistoriaAtivos()}
     */
    @Test
    void testListAllTipoVistoriaAtivos() {
        // Arrange
        when(tipoVistoriaRepository.findAllByAtivo(Mockito.<Boolean>any())).thenReturn(new ArrayList<>());

        // Act and Assert
        assertThrows(TipoVistoriaException.class, () -> tipoVistoriaServiceImpl.listAllTipoVistoriaAtivos());
        verify(tipoVistoriaRepository).findAllByAtivo(eq(true));
    }

    /**
     * Method under test:
     * {@link TipoVistoriaServiceImpl#listAllTipoVistoriaAtivos()}
     */
    @Test
    void testListAllTipoVistoriaAtivos2() {
        // Arrange
        TipoVistoriaEntity tipoVistoriaEntity = new TipoVistoriaEntity();
        tipoVistoriaEntity.setAtivo(true);
        tipoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoriaEntity.setDescricao("Não encontrada nenhum tipo de vistoria ativo.");
        tipoVistoriaEntity.setId(1L);
        tipoVistoriaEntity.setNome("Não encontrada nenhum tipo de vistoria ativo.");
        tipoVistoriaEntity.setStatusAnterior("Não encontrada nenhum tipo de vistoria ativo.");
        tipoVistoriaEntity.setStatusPosterior("Não encontrada nenhum tipo de vistoria ativo.");

        ArrayList<TipoVistoriaEntity> tipoVistoriaEntityList = new ArrayList<>();
        tipoVistoriaEntityList.add(tipoVistoriaEntity);
        when(tipoVistoriaRepository.findAllByAtivo(Mockito.<Boolean>any())).thenReturn(tipoVistoriaEntityList);

        // Act
        List<TipoVistoriaDTO> actualListAllTipoVistoriaAtivosResult = tipoVistoriaServiceImpl.listAllTipoVistoriaAtivos();

        // Assert
        verify(tipoVistoriaRepository).findAllByAtivo(eq(true));
        assertEquals(1, actualListAllTipoVistoriaAtivosResult.size());
    }

    /**
     * Method under test:
     * {@link TipoVistoriaServiceImpl#listAllTipoVistoriaAtivos()}
     */
    @Test
    void testListAllTipoVistoriaAtivos3() {
        // Arrange
        TipoVistoriaEntity tipoVistoriaEntity = new TipoVistoriaEntity();
        tipoVistoriaEntity.setAtivo(true);
        tipoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoriaEntity.setDescricao("Não encontrada nenhum tipo de vistoria ativo.");
        tipoVistoriaEntity.setId(1L);
        tipoVistoriaEntity.setNome("Não encontrada nenhum tipo de vistoria ativo.");
        tipoVistoriaEntity.setStatusAnterior("Não encontrada nenhum tipo de vistoria ativo.");
        tipoVistoriaEntity.setStatusPosterior("Não encontrada nenhum tipo de vistoria ativo.");

        TipoVistoriaEntity tipoVistoriaEntity2 = new TipoVistoriaEntity();
        tipoVistoriaEntity2.setAtivo(false);
        tipoVistoriaEntity2.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoriaEntity2.setDescricao("br.gov.df.pm.sgv.domain.TipoVistoriaEntity");
        tipoVistoriaEntity2.setId(2L);
        tipoVistoriaEntity2.setNome("br.gov.df.pm.sgv.domain.TipoVistoriaEntity");
        tipoVistoriaEntity2.setStatusAnterior("br.gov.df.pm.sgv.domain.TipoVistoriaEntity");
        tipoVistoriaEntity2.setStatusPosterior("br.gov.df.pm.sgv.domain.TipoVistoriaEntity");

        ArrayList<TipoVistoriaEntity> tipoVistoriaEntityList = new ArrayList<>();
        tipoVistoriaEntityList.add(tipoVistoriaEntity2);
        tipoVistoriaEntityList.add(tipoVistoriaEntity);
        when(tipoVistoriaRepository.findAllByAtivo(Mockito.<Boolean>any())).thenReturn(tipoVistoriaEntityList);

        // Act
        List<TipoVistoriaDTO> actualListAllTipoVistoriaAtivosResult = tipoVistoriaServiceImpl.listAllTipoVistoriaAtivos();

        // Assert
        verify(tipoVistoriaRepository).findAllByAtivo(eq(true));
        assertEquals(2, actualListAllTipoVistoriaAtivosResult.size());
    }

    /**
     * Method under test:
     * {@link TipoVistoriaServiceImpl#listAllTipoVistoriaAtivos()}
     */
    @Test
    void testListAllTipoVistoriaAtivos4() {
        // Arrange
        when(tipoVistoriaRepository.findAllByAtivo(Mockito.<Boolean>any()))
                .thenThrow(new VistoriaExceptions("An error occurred"));

        // Act and Assert
        assertThrows(VistoriaExceptions.class, () -> tipoVistoriaServiceImpl.listAllTipoVistoriaAtivos());
        verify(tipoVistoriaRepository).findAllByAtivo(eq(true));
    }

    /**
     * Method under test:
     * {@link TipoVistoriaServiceImpl#listAllTipoVistoriaAtivos()}
     */
    @Test
    void testListAllTipoVistoriaAtivos5() {
        // Arrange
        TipoVistoriaEntity tipoVistoriaEntity = mock(TipoVistoriaEntity.class);
        when(tipoVistoriaEntity.getAtivo()).thenReturn(true);
        when(tipoVistoriaEntity.getId()).thenReturn(1L);
        when(tipoVistoriaEntity.getDescricao()).thenReturn("Descricao");
        when(tipoVistoriaEntity.getNome()).thenReturn("Nome");
        when(tipoVistoriaEntity.getStatusAnterior()).thenReturn("Status Anterior");
        when(tipoVistoriaEntity.getStatusPosterior()).thenReturn("Status Posterior");
        when(tipoVistoriaEntity.getDataInclusao()).thenReturn(LocalDate.of(1970, 1, 1));
        doNothing().when(tipoVistoriaEntity).setAtivo(Mockito.<Boolean>any());
        doNothing().when(tipoVistoriaEntity).setDataInclusao(Mockito.<LocalDate>any());
        doNothing().when(tipoVistoriaEntity).setDescricao(Mockito.<String>any());
        doNothing().when(tipoVistoriaEntity).setId(Mockito.<Long>any());
        doNothing().when(tipoVistoriaEntity).setNome(Mockito.<String>any());
        doNothing().when(tipoVistoriaEntity).setStatusAnterior(Mockito.<String>any());
        doNothing().when(tipoVistoriaEntity).setStatusPosterior(Mockito.<String>any());
        tipoVistoriaEntity.setAtivo(true);
        tipoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoriaEntity.setDescricao("Não encontrada nenhum tipo de vistoria ativo.");
        tipoVistoriaEntity.setId(1L);
        tipoVistoriaEntity.setNome("Não encontrada nenhum tipo de vistoria ativo.");
        tipoVistoriaEntity.setStatusAnterior("Não encontrada nenhum tipo de vistoria ativo.");
        tipoVistoriaEntity.setStatusPosterior("Não encontrada nenhum tipo de vistoria ativo.");

        ArrayList<TipoVistoriaEntity> tipoVistoriaEntityList = new ArrayList<>();
        tipoVistoriaEntityList.add(tipoVistoriaEntity);
        when(tipoVistoriaRepository.findAllByAtivo(Mockito.<Boolean>any())).thenReturn(tipoVistoriaEntityList);

        // Act
        List<TipoVistoriaDTO> actualListAllTipoVistoriaAtivosResult = tipoVistoriaServiceImpl.listAllTipoVistoriaAtivos();

        // Assert
        verify(tipoVistoriaEntity).getAtivo();
        verify(tipoVistoriaEntity).getDataInclusao();
        verify(tipoVistoriaEntity).getDescricao();
        verify(tipoVistoriaEntity).getId();
        verify(tipoVistoriaEntity).getNome();
        verify(tipoVistoriaEntity).getStatusAnterior();
        verify(tipoVistoriaEntity).getStatusPosterior();
        verify(tipoVistoriaEntity).setAtivo(eq(true));
        verify(tipoVistoriaEntity).setDataInclusao(isA(LocalDate.class));
        verify(tipoVistoriaEntity).setDescricao(eq("Não encontrada nenhum tipo de vistoria ativo."));
        verify(tipoVistoriaEntity).setId(eq(1L));
        verify(tipoVistoriaEntity).setNome(eq("Não encontrada nenhum tipo de vistoria ativo."));
        verify(tipoVistoriaEntity).setStatusAnterior(eq("Não encontrada nenhum tipo de vistoria ativo."));
        verify(tipoVistoriaEntity).setStatusPosterior(eq("Não encontrada nenhum tipo de vistoria ativo."));
        verify(tipoVistoriaRepository).findAllByAtivo(eq(true));
        assertEquals(1, actualListAllTipoVistoriaAtivosResult.size());
    }

    /**
     * Method under test: {@link TipoVistoriaServiceImpl#findByIdTipoVistoria(Long)}
     */
    @Test
    void testFindByIdTipoVistoria() {
        // Arrange
        TipoVistoriaEntity tipoVistoriaEntity = new TipoVistoriaEntity();
        tipoVistoriaEntity.setAtivo(true);
        tipoVistoriaEntity.setDataInclusao(LocalDate.of(1970, 1, 1));
        tipoVistoriaEntity.setDescricao("Descricao");
        tipoVistoriaEntity.setId(1L);
        tipoVistoriaEntity.setNome("Nome");
        tipoVistoriaEntity.setStatusAnterior("Status Anterior");
        tipoVistoriaEntity.setStatusPosterior("Status Posterior");
        Optional<TipoVistoriaEntity> ofResult = Optional.of(tipoVistoriaEntity);
        when(tipoVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(ofResult);

        // Act
        TipoVistoriaEntity actualFindByIdTipoVistoriaResult = tipoVistoriaServiceImpl.findByIdTipoVistoria(1L);

        // Assert
        verify(tipoVistoriaRepository).findById(eq(1L));
        assertSame(tipoVistoriaEntity, actualFindByIdTipoVistoriaResult);
    }

    /**
     * Method under test: {@link TipoVistoriaServiceImpl#findByIdTipoVistoria(Long)}
     */
    @Test
    void testFindByIdTipoVistoria2() {
        // Arrange
        Optional<TipoVistoriaEntity> emptyResult = Optional.empty();
        when(tipoVistoriaRepository.findById(Mockito.<Long>any())).thenReturn(emptyResult);

        // Act and Assert
        assertThrows(TipoVistoriaException.class, () -> tipoVistoriaServiceImpl.findByIdTipoVistoria(1L));
        verify(tipoVistoriaRepository).findById(eq(1L));
    }

    /**
     * Method under test: {@link TipoVistoriaServiceImpl#findByIdTipoVistoria(Long)}
     */
    @Test
    void testFindByIdTipoVistoria3() {
        // Arrange
        when(tipoVistoriaRepository.findById(Mockito.<Long>any())).thenThrow(new VistoriaExceptions("An error occurred"));

        // Act and Assert
        assertThrows(VistoriaExceptions.class, () -> tipoVistoriaServiceImpl.findByIdTipoVistoria(1L));
        verify(tipoVistoriaRepository).findById(eq(1L));
    }
}
