package br.gov.df.pm.sgv.domain.app;

import br.gov.df.pm.sgv.domain.TipoEmpregoViaturaEntity;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class TipoEmpregoViaturaEntityTest {
    private TipoEmpregoViaturaEntity tipoEmprego = new TipoEmpregoViaturaEntity(null, null, null);

    @BeforeEach
    void setUp() {
        tipoEmprego.setId(1);
        tipoEmprego.setNome("Vidro");
        tipoEmprego.setAtivo(1);
    }

    @Test
    void testEquals() {
        var tipoEmprego1 = TipoEmpregoViaturaEntity.builder()
                .id(1)
                .nome("Vidro")
                .ativo(1)
                .build();
        assertEquals(tipoEmprego, tipoEmprego1);

        var tipoEmprego2 = TipoEmpregoViaturaEntity.builder().nome("Janela").build();
        assertNotEquals(tipoEmprego, tipoEmprego2);
    }

    @Test
    void testHashCode() {
        var tipoEmprego1 = TipoEmpregoViaturaEntity.builder()
                .id(1)
                .nome("Vidro")
                .ativo(1)
                .build();
        assertEquals(tipoEmprego.hashCode(), tipoEmprego1.hashCode());

        var tipoEmprego2 = TipoEmpregoViaturaEntity.builder().nome("Janela").build();
        assertNotEquals(tipoEmprego.hashCode(), tipoEmprego2.hashCode());
    }

    @Test
    void testToString() {
        assertNotNull(tipoEmprego.toString());
    }
}
