Here is an example of how you might write unit tests for the `Application` class using Mockito and JUnit. Note that it's not possible to test the `main` method in a reasonable way, so we're focusing on the `run` method and the `restTemplate` and `run` beans.

```java
package hello;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.times;

import java.util.Arrays;
import java.util.List;

import hello.model.Customer;
import hello.model.Quote;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.Logger;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.client.RestTemplate;

@ExtendWith(MockitoExtension.class)
public class ApplicationTest {

    @Mock
    private RestTemplateBuilder builder;

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private JdbcTemplate jdbcTemplate;

    @Mock
    private Logger log;

    @InjectMocks
    private Application application;

    @BeforeEach
    public void setUp() {
        when(builder.build()).thenReturn(restTemplate);
        doNothing().when(jdbcTemplate).execute(anyString());
    }

    @Test
    public void testRestTemplate() {
        RestTemplate result = application.restTemplate(builder);
        verify(builder, times(1)).build();
    }

    @Test
    public void testRun() throws Exception {
        Quote quote = new Quote();
        when(restTemplate.getForObject(anyString(), Quote.class)).thenReturn(quote);
        application.run("test");
        verify(log, times(1)).info("Creating tables");
        verify(jdbcTemplate, times(2)).execute(anyString());
        verify(jdbcTemplate, times(1)).batchUpdate(anyString(), anyList());
        verify(jdbcTemplate, times(1)).query(anyString(), any(Object[].class), any(RowMapper.class));
    }
}
```

This is a simple test and does not cover every possible scenario. In a real-world application, you would want to write more comprehensive tests, including negative tests and edge cases.