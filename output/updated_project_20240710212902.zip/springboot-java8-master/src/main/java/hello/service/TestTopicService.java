Sure, here is a set of unit tests for the provided Java code:

```java
package hello.service;

import hello.declaration.CustomPredicate;
import hello.model.Topic;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
public class TopicServiceTest {

    private TopicService topicService;

    @BeforeEach
    public void setup() {
        topicService = new TopicService();
    }

    @Test
    public void testGetAllTopics() {
        List<Topic> topics = topicService.getAllTopics();
        assertEquals(3, topics.size());
    }

    @Test
    public void testGetTopicWithId() {
        Topic topic = topicService.getTopicWithId("java");
        assertEquals("Core Java", topic.getName());
        assertEquals("Java Description", topic.getDescription());
    }

    @Test
    public void testAddTopic() {
        Topic newTopic = new Topic("python", "Python", "Python Description");
        topicService.addTopic(newTopic);
        assertEquals(4, topicService.getAllTopics().size());
    }

    @Test
    public void testUpdateTopic() {
        Topic updatedTopic = new Topic("java", "Updated Java", "Updated Description");
        topicService.updateTopic("java", updatedTopic);
        Topic topic = topicService.getTopicWithId("java");
        assertEquals("Updated Java", topic.getName());
        assertEquals("Updated Description", topic.getDescription());
    }

    @Test
    public void testDeleteTopic() {
        topicService.deleteTopic("java");
        assertEquals(2, topicService.getAllTopics().size());
    }

    @Test
    public void testFilterMinimumLengthForId() {
        List<Topic> filteredTopics = topicService.filterMinimumLengthForId(5);
        assertEquals(2, filteredTopics.size());
    }

    @Test
    public void testSortTopicsWithID() {
        List<Topic> sortedTopics = topicService.sortTopicsWithID();
        assertEquals("java", sortedTopics.get(0).getId());
    }

    // Add more tests as needed for the remaining methods.
}
```

Please note that some of the methods in your `TopicService` class interact with the file system. Testing these methods could be more complex and could require the use of mocking frameworks like Mockito to avoid actual file system interactions during testing.

You should also consider handling exceptions in a more robust way, rather than returning string error messages. This would make your code easier to test and more predictable.