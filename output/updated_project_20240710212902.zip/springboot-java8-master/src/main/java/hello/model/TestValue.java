Sure, here is a comprehensive JUnit test class for the above Value class:

```java
package hello.model;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class ValueTest {
    private Value value;

    @Before
    public void setUp() {
        value = new Value();
    }

    @Test
    public void testId() {
        Long id = 5L;
        value.setId(id);
        assertEquals(id, value.getId());
    }

    @Test
    public void testQuote() {
        String quote = "Test quote";
        value.setQuote(quote);
        assertEquals(quote, value.getQuote());
    }

    @Test
    public void testToString() {
        Long id = 10L;
        String quote = "Another test quote";
        value.setId(id);
        value.setQuote(quote);

        String expected = "Value{" +
                "id=" + id +
                ", quote='" + quote + '\'' +
                '}';
        assertEquals(expected, value.toString());
    }
}
```
This test class has three tests: `testId()`, `testQuote()`, and `testToString()`. Each test sets a value for the corresponding property, then asserts that the getter method returns the correct value. The `testToString()` method tests the `toString()` method by asserting that the returned string matches the expected format. 

The `@Before` annotation is used to specify that the `setUp()` method should be run before each test. This method initializes the `value` object that is used in the tests.

The `assertEquals()` method is used to assert that two values are equal. If they are not, the test fails.

Remember to add JUnit to your project's dependencies to use `@Test`, `@Before` and `assertEquals()`.