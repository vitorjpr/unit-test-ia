The unit test for the Greeting class using JUnit and Mockito could look like this:

```java
package hello.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class GreetingTest {
    private Greeting greeting;

    @BeforeEach
    public void setUp() {
        greeting = new Greeting(1L, "Hello, World!");
    }

    @Test
    public void testGetId() {
        assertEquals(1L, greeting.getId());
    }

    @Test
    public void testGetContent() {
        assertEquals("Hello, World!", greeting.getContent());
    }
}
```

This test class includes two test cases. The first one tests the getId method and the second one tests the getContent method. The setUp method is annotated with @BeforeEach to indicate that it should be run before each test. It initializes the greeting object that is used in the test cases. The assertEquals method is used to check that the method under test returns the expected result. If it does not, the test fails.