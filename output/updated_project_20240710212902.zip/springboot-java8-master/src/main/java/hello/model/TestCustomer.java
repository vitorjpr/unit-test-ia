Sure, here is a simple example of a unit test for the `Customer` class using JUnit:

```java
package hello.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class CustomerTest {
    private Customer customer;

    @BeforeEach
    public void setUp() {
        customer = new Customer(1L, "John", "Doe");
    }

    @Test
    public void testToString() {
        String expected = "Customer{id=1, firstName='John', lastName='Doe'}";
        assertEquals(expected, customer.toString());
    }

    @Test
    public void testGetId() {
        assertEquals(1L, customer.getId());
    }

    @Test
    public void testSetId() {
        customer.setId(2L);
        assertEquals(2L, customer.getId());
    }

    @Test
    public void testGetFirstName() {
        assertEquals("John", customer.getFirstName());
    }

    @Test
    public void testSetFirstName() {
        customer.setFirstName("Jane");
        assertEquals("Jane", customer.getFirstName());
    }

    @Test
    public void testGetLastName() {
        assertEquals("Doe", customer.getLastName());
    }

    @Test
    public void testSetLastName() {
        customer.setLastName("Smith");
        assertEquals("Smith", customer.getLastName());
    }
}
```

This test class covers all the getter and setter methods in the `Customer` class, as well as the `toString()` method. The `setUp()` method is used to initialize a `Customer` object before each test.