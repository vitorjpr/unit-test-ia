Here's a set of unit tests for the SimpleTimeClient class using JUnit and Mockito:

```java
package hello.model;

import hello.declaration.TimeClient;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class SimpleTimeClientTest {
    private SimpleTimeClient simpleTimeClient;

    @BeforeEach
    public void setUp() {
        simpleTimeClient = new SimpleTimeClient();
    }

    @Test
    public void testSetTime() {
        int hour = 10;
        int minute = 30;
        int second = 45;
        simpleTimeClient.setTime(hour, minute, second);

        LocalDateTime dateTime = simpleTimeClient.getLocalDateTime();

        assertEquals(hour, dateTime.getHour());
        assertEquals(minute, dateTime.getMinute());
        assertEquals(second, dateTime.getSecond());
    }

    @Test
    public void testSetDate() {
        int day = 15;
        int month = 8;
        int year = 2022;
        simpleTimeClient.setDate(day, month, year);

        LocalDateTime dateTime = simpleTimeClient.getLocalDateTime();

        assertEquals(day, dateTime.getDayOfMonth());
        assertEquals(month, dateTime.getMonthValue());
        assertEquals(year, dateTime.getYear());
    }

    @Test
    public void testSetDateAndTime() {
        int day = 15;
        int month = 8;
        int year = 2022;
        int hour = 10;
        int minute = 30;
        int second = 45;
        simpleTimeClient.setDateAndTime(day, month, year, hour, minute, second);

        LocalDateTime dateTime = simpleTimeClient.getLocalDateTime();

        assertEquals(day, dateTime.getDayOfMonth());
        assertEquals(month, dateTime.getMonthValue());
        assertEquals(year, dateTime.getYear());
        assertEquals(hour, dateTime.getHour());
        assertEquals(minute, dateTime.getMinute());
        assertEquals(second, dateTime.getSecond());
    }

    @Test
    public void testToString() {
        int day = 15;
        int month = 8;
        int year = 2022;
        int hour = 10;
        int minute = 30;
        int second = 45;
        simpleTimeClient.setDateAndTime(day, month, year, hour, minute, second);

        String expected = "2022-08-15T10:30:45";
        assertEquals(expected, simpleTimeClient.toString());
    }
}
```

This set of tests covers all the public methods in the SimpleTimeClient class. It checks that the setTime, setDate, and setDateAndTime methods correctly update the dateAndTime field, and that the toString method correctly formats the date and time.