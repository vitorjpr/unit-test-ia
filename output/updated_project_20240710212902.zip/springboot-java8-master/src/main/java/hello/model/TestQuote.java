Sure, here is a basic set of unit tests for your `Quote` class using JUnit and Mockito. This test will cover the basic getters and setters, as well as the `toString` method.

```java
package hello.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class QuoteTest {
    private Quote quote;
    private Value mockValue;

    @BeforeEach
    public void setUp() {
        quote = new Quote();
        mockValue = mock(Value.class);
    }

    @Test
    public void testGetType() {
        String type = "testType";
        quote.setType(type);
        assertEquals(type, quote.getType());
    }

    @Test
    public void testSetValue() {
        quote.setValue(mockValue);
        assertEquals(mockValue, quote.getValue());
    }

    @Test
    public void testToString() {
        String type = "testType";
        quote.setType(type);
        quote.setValue(mockValue);
        String expectedString = "Quote{" +
                "type='" + type + '\'' +
                ", value=" + mockValue.toString() +
                '}';
        assertEquals(expectedString, quote.toString());
    }
}
```

Please note that these tests are quite basic and do not cover edge cases or error conditions. Depending on the implementation of the `Value` class, you may want to add additional tests to ensure that the `Quote` class behaves as expected when interacting with the `Value` class.