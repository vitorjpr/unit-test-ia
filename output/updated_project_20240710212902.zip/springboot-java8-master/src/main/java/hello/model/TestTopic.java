Here is a JUnit test class for your Topic class:

```java
package hello.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class TopicTest {
    private Topic topic;

    @BeforeEach
    public void setUp() {
        topic = new Topic();
    }

    @Test
    public void testId() {
        String id = "123";
        topic.setId(id);
        assertEquals(id, topic.getId(), "Incorrect Id");
    }

    @Test
    public void testSubjectName() {
        String subjectName = "Math";
        topic.setSubjectName(subjectName);
        assertEquals(subjectName, topic.getSubjectName(), "Incorrect Subject Name");
    }

    @Test
    public void testSubjectDescription() {
        String subjectDescription = "Algebra";
        topic.setSubjectDescription(subjectDescription);
        assertEquals(subjectDescription, topic.getSubjectDescription(), "Incorrect Subject Description");
    }

    @Test
    public void testConstructor() {
        String id = "123";
        String subjectName = "Math";
        String subjectDescription = "Algebra";
        Topic topic = new Topic(id, subjectName, subjectDescription);
        assertEquals(id, topic.getId(), "Incorrect Id");
        assertEquals(subjectName, topic.getSubjectName(), "Incorrect Subject Name");
        assertEquals(subjectDescription, topic.getSubjectDescription(), "Incorrect Subject Description");
    }
}
```

This test class includes four test methods. Each method tests a specific part of the Topic class:

- `testId()` tests the getter and setter for the id.
- `testSubjectName()` tests the getter and setter for the subjectName.
- `testSubjectDescription()` tests the getter and setter for the subjectDescription.
- `testConstructor()` tests the constructor with parameters.

The `setUp()` method is annotated with `@BeforeEach`, which means it will be run before each test. It initializes a new Topic object for each test. 

The `assertEquals()` method is used to check if the expected value equals the actual value. If not, it will throw an AssertionFailedError with a specified message.