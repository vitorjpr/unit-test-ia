Here is a unit test for your GreetingController using JUnit and Mockito:

```java
package hello.controller;

import hello.model.Greeting;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.concurrent.atomic.AtomicLong;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

public class GreetingControllerTest {

    @InjectMocks
    GreetingController greetingController;

    @Mock
    AtomicLong counter;

    @BeforeEach
    public void init() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void greetingTestWithName() {
        String name = "John";
        when(counter.incrementAndGet()).thenReturn(1L);
        Greeting result = greetingController.greeting(name);
        assertEquals("Hello, John!", result.getContent());
        assertEquals(1, result.getId());
    }

    @Test
    public void greetingTestWithDefaultName() {
        String name = "World";
        when(counter.incrementAndGet()).thenReturn(1L);
        Greeting result = greetingController.greeting(name);
        assertEquals("Hello, World!", result.getContent());
        assertEquals(1, result.getId());
    }

    @Test
    public void greetingTestWithIncrement() {
        String name = "John";
        when(counter.incrementAndGet()).thenReturn(1L, 2L);
        Greeting result = greetingController.greeting(name);
        assertEquals("Hello, John!", result.getContent());
        assertEquals(1, result.getId());
        result = greetingController.greeting(name);
        assertEquals("Hello, John!", result.getContent());
        assertEquals(2, result.getId());
    }
}
```

Please note that this is a basic unit test. Depending on your requirements, you might need to add more test cases. For example, you might want to add a test case to check what happens if the `AtomicLong` `incrementAndGet` method throws an exception. Also, you might want to add a test case to check the behavior of the `greeting` method when it is called concurrently from multiple threads.