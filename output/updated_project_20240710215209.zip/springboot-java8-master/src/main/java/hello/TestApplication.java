Here is a simple example of how you can write unit tests for the above code using Mockito and JUnit. This example covers the `run` method and the `restTemplate` bean method.

```java
package hello;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.client.RestTemplate;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class ApplicationTest {

    @Mock
    private RestTemplateBuilder restTemplateBuilder;

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private JdbcTemplate jdbcTemplate;

    @InjectMocks
    private Application application;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testRestTemplateBean() {
        when(restTemplateBuilder.build()).thenReturn(restTemplate);

        RestTemplate result = application.restTemplate(restTemplateBuilder);

        verify(restTemplateBuilder, times(1)).build();
        assertNotNull(result);
    }

    @Test
    public void testRunMethod() throws Exception {
        when(jdbcTemplate.execute(anyString())).thenReturn(null);
        when(jdbcTemplate.batchUpdate(anyString(), anyList())).thenReturn(new int[]{1, 1, 1, 1});

        application.run();

        verify(jdbcTemplate, times(2)).execute(anyString());
        verify(jdbcTemplate, times(1)).batchUpdate(anyString(), anyList());
    }

    @Test
    public void testCommandLineRunnerBean() throws Exception {
        when(restTemplateBuilder.build()).thenReturn(restTemplate);
        when(restTemplate.getForObject(anyString(), eq(Quote.class))).thenReturn(new Quote());

        CommandLineRunner result = application.run(restTemplate);

        assertNotNull(result);
    }
}
```

Please note that this is a simple example and might not cover all edge cases. Depending on the complexity of your application and the logic in your methods, you might need to write more comprehensive tests.