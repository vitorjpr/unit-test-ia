Here's an example of how you can write unit tests for your `TopicController` class using Mockito and JUnit. This is not a comprehensive set of tests, but it should give you a good starting point.

```java
package hello.controller;

import hello.model.Topic;
import hello.service.TopicService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.Arrays;
import java.util.List;

import static org.hamcrest.Matchers.hasSize;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

public class TopicControllerTest {

    private MockMvc mockMvc;

    @Mock
    private TopicService topicService;

    @InjectMocks
    private TopicController topicController;

    @BeforeEach
    public void init(){
        MockitoAnnotations.initMocks(this);
        mockMvc = MockMvcBuilders
                .standaloneSetup(topicController)
                .build();
    }

    @Test
    public void testGetAllTopics() throws Exception {
        List<Topic> topics = Arrays.asList(
                new Topic("id1", "name1", "desc1"),
                new Topic("id2", "name2", "desc2"));
        when(topicService.getAllTopics()).thenReturn(topics);

        mockMvc.perform(get("/topic"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$", hasSize(2)));
    }

    @Test
    public void testGetTopicWithID() throws Exception {
        Topic topic = new Topic("id1", "name1", "desc1");
        when(topicService.getTopicWithId("id1")).thenReturn(topic);

        mockMvc.perform(get("/topic/id1"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.id").value("id1"))
                .andExpect(jsonPath("$.name").value("name1"))
                .andExpect(jsonPath("$.description").value("desc1"));
    }

    //...similar tests for addTopic, updateTopic, deleteTopic, filterMinimumLengthForId, sortTopicsWithID...
}
```

This test class uses Mockito to create a mock `TopicService` that the `TopicController` under test will use. We then define the behavior of this mock for the test cases.

The `testGetAllTopics` method tests the `getAllTopics` method of the `TopicController`. It does this by performing a GET request to the "/topic" endpoint, then asserts that the response status is OK, the content type is JSON, and that the JSON array has the correct size.

The `testGetTopicWithID` method tests the `getTopicWithID` method in a similar way. It also checks that the fields in the returned JSON object have the correct values.
  
You can create similar tests for the other methods in the `TopicController`.