Here is a simple unit test for your `GreetingController` class:

```java
package hello.controller;

import hello.model.Greeting;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

@SpringBootTest
@AutoConfigureMockMvc
public class GreetingControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Test
    public void greetingDefaultTest() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.content").value("Hello, World!"));
    }

    @Test
    public void greetingCustomNameTest() throws Exception {
        String customName = "John";
        mockMvc.perform(MockMvcRequestBuilders.get("/").param("name", customName))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.content").value("Hello, " + customName + "!"));
    }
}
```

This test class includes two tests:

1. `greetingDefaultTest()`: This test checks if the default greeting ("Hello, World!") is returned when no name parameter is provided in the request.

2. `greetingCustomNameTest()`: This test checks if a custom greeting is returned when a name parameter ("John") is provided in the request.

Both tests use `MockMvc` to perform HTTP GET requests to the `/` endpoint, and they both expect a 200 OK status in the response. They also check the content of the response using `jsonPath()`.