Here are the unit tests for the above Java code:

```java
package hello.controller;

import hello.declaration.TimeClient;
import hello.model.SimpleTimeClient;
import hello.service.TopicService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(MockitoJUnitRunner.class)
public class HelloControllerTest {

    @InjectMocks
    private HelloController helloController;

    @Mock
    private TopicService topicService;

    private MockMvc mockMvc;

    @Before
    public void setup() {
        mockMvc = MockMvcBuilders.standaloneSetup(helloController).build();
    }

    @Test
    public void testIndex() throws Exception {
        TimeClient myTimeClient = new SimpleTimeClient();
        Mockito.when(topicService.returnAllTopicIDWithStringSlicing()).thenReturn("Mocked String");
        mockMvc.perform(get("/datetime"))
                .andExpect(status().isOk());
    }

    @Test
    public void testShowStringOperation() throws Exception {
        Mockito.when(topicService.returnAllTopicIDWithStringSlicing()).thenReturn("Mocked String");
        Mockito.when(topicService.makeDistinctAndSortCharacters(Mockito.anyString())).thenReturn("Mocked String");
        Mockito.when(topicService.splitAllIdWithColonSelectIDWithJavaKeywordThenSortThenJoin(Mockito.anyString())).thenReturn("Mocked String");
        Mockito.when(topicService.findIdHavingCharacter()).thenReturn("Mocked String");
        mockMvc.perform(get("/topic/string/operation"))
                .andExpect(status().isOk());
    }

    @Test
    public void testShowFileOperation() throws Exception {
        Mockito.when(topicService.findAllFilesInPathAndSort()).thenReturn("Mocked String");
        Mockito.when(topicService.findParticularFileInPathAndSort()).thenReturn("Mocked String");
        Mockito.when(topicService.findParticularFileInPathAndSortWithWalkFunction()).thenReturn("Mocked String");
        Mockito.when(topicService.readFileWithStreamFunction()).thenReturn("Mocked String");
        mockMvc.perform(get("/topic/file/operation"))
                .andExpect(status().isOk());
    }
}
```

In this test, we use Mockito to mock the `TopicService` and its methods. We then use the `MockMvc` to perform GET requests to the endpoints and verify that the status of the response is OK (HTTP 200). 

Please note that these are very basic tests and only check the status of the response. For comprehensive tests, you would need to check the content of the response, handle exceptions, and add more test cases.