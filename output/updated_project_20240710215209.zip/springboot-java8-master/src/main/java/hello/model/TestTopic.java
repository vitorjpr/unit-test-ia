Here is a comprehensive unit test for the Topic class:

```java
package hello.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TopicTest {
    private Topic topic;

    @BeforeEach
    public void setUp() {
        topic = new Topic();
    }

    @Test
    public void testGetId() {
        String id = "123";
        topic.setId(id);
        assertEquals(id, topic.getId());
    }

    @Test
    public void testSetId() {
        String id = "456";
        topic.setId(id);
        assertEquals(id, topic.getId());
    }

    @Test
    public void testGetSubjectName() {
        String subjectName = "Math";
        topic.setSubjectName(subjectName);
        assertEquals(subjectName, topic.getSubjectName());
    }

    @Test
    public void testSetSubjectName() {
        String subjectName = "Science";
        topic.setSubjectName(subjectName);
        assertEquals(subjectName, topic.getSubjectName());
    }

    @Test
    public void testGetSubjectDescription() {
        String subjectDescription = "Algebra";
        topic.setSubjectDescription(subjectDescription);
        assertEquals(subjectDescription, topic.getSubjectDescription());
    }

    @Test
    public void testSetSubjectDescription() {
        String subjectDescription = "Physics";
        topic.setSubjectDescription(subjectDescription);
        assertEquals(subjectDescription, topic.getSubjectDescription());
    }

    @Test
    public void testConstructor() {
        String id = "789";
        String subjectName = "English";
        String subjectDescription = "Literature";
        Topic newTopic = new Topic(id, subjectName, subjectDescription);
        assertEquals(id, newTopic.getId());
        assertEquals(subjectName, newTopic.getSubjectName());
        assertEquals(subjectDescription, newTopic.getSubjectDescription());
    }
}
```

This test class tests all the getter and setter methods of the Topic class and also checks the constructor. The `setUp` method is used to initialize the `Topic` object before each test. The `assertEquals` method is used to check if the expected and actual values are the same. If they are not, the test fails.