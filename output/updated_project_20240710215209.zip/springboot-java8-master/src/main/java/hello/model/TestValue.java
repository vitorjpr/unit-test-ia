Here is a unit test for your `Value` class using JUnit and Mockito:

```java
package hello.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class ValueTest {

    private Value value;

    @BeforeEach
    public void setUp() {
        value = new Value();
    }

    @Test
    public void testGetId() {
        Long id = 123L;
        value.setId(id);
        assertEquals(id, value.getId());
    }

    @Test
    public void testSetId() {
        Long id = 123L;
        value.setId(id);
        assertEquals(id, value.getId());
    }

    @Test
    public void testGetQuote() {
        String quote = "Hello, World!";
        value.setQuote(quote);
        assertEquals(quote, value.getQuote());
    }

    @Test
    public void testSetQuote() {
        String quote = "Hello, World!";
        value.setQuote(quote);
        assertEquals(quote, value.getQuote());
    }

    @Test
    public void testToString() {
        Long id = 123L;
        String quote = "Hello, World!";
        value.setId(id);
        value.setQuote(quote);
        String expected = "Value{id=" + id + ", quote='" + quote + '\'' + '}';
        assertEquals(expected, value.toString());
    }
}
```

This unit test covers all the getter and setter methods of the `Value` class, as well as the `toString()` method. The `setUp()` method is annotated with `@BeforeEach`, which means it will be run before each test case, ensuring that each test starts with a fresh `Value` object. Each test case sets a value, then checks that the correct value is returned. The `testToString()` method also checks that the `toString()` method is formatting the string correctly.