Here is a comprehensive unit test for the above `Customer` class using JUnit:

```java
package hello.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class CustomerTest {
    private Customer customer;

    @BeforeEach
    public void setUp() {
        customer = new Customer(1L, "John", "Doe");
    }

    @Test
    public void testGetId() {
        assertEquals(1L, customer.getId());
    }

    @Test
    public void testSetId() {
        customer.setId(2L);
        assertEquals(2L, customer.getId());
    }

    @Test
    public void testGetFirstName() {
        assertEquals("John", customer.getFirstName());
    }

    @Test
    public void testSetFirstName() {
        customer.setFirstName("Jane");
        assertEquals("Jane", customer.getFirstName());
    }

    @Test
    public void testGetLastName() {
        assertEquals("Doe", customer.getLastName());
    }

    @Test
    public void testSetLastName() {
        customer.setLastName("Smith");
        assertEquals("Smith", customer.getLastName());
    }

    @Test
    public void testToString() {
        String expected = "Customer{" +
                "id=" + 1L +
                ", firstName='John'" +
                ", lastName='Doe'" +
                '}';
        assertEquals(expected, customer.toString());
    }
}
```

This test class includes tests for all getters, setters, and the `toString` method. Each test checks if the method works as expected by comparing the actual result with the expected result. The `setUp` method, annotated with `@BeforeEach`, initializes a `Customer` instance before each test.