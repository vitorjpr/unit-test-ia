Sure, here's a basic unit test class for your `Greeting` class using JUnit and Mockito:

```java
package hello.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class GreetingTest {
    private Greeting greeting;

    @BeforeEach
    public void setUp() {
        greeting = new Greeting(1L, "Hello, World!");
    }

    @Test
    public void testGetId() {
        assertEquals(1L, greeting.getId());
    }

    @Test
    public void testGetContent() {
        assertEquals("Hello, World!", greeting.getContent());
    }
}
```

This test class has two test methods. 

- `testGetId()` tests the `getId()` method of the `Greeting` class. It asserts that the id of the `Greeting` object is the same as the id we used to create the object in the `setUp()` method.

- `testGetContent()` tests the `getContent()` method of the `Greeting` class. It asserts that the content of the `Greeting` object is the same as the content we used to create the object in the `setUp()` method.

The `setUp()` method is annotated with `@BeforeEach`, which means it will be run before every test method. This method creates a new `Greeting` object that is used in each test method.