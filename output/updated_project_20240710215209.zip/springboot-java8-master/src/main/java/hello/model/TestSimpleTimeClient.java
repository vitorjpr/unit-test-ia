Here is a unit test for the SimpleTimeClient class using JUnit and Mockito:

```java
package hello.model;

import hello.declaration.TimeClient;
import org.junit.Before;
import org.junit.Test;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import static org.junit.Assert.*;

public class SimpleTimeClientTest {
    private SimpleTimeClient simpleTimeClient;

    @Before
    public void setup() {
        simpleTimeClient = new SimpleTimeClient();
    }

    @Test
    public void testSetTime() {
        simpleTimeClient.setTime(10, 30, 0);
        LocalTime expectedTime = LocalTime.of(10, 30, 0);
        LocalDateTime actualDateTime = simpleTimeClient.getLocalDateTime();
        assertEquals(expectedTime, actualDateTime.toLocalTime());
    }

    @Test
    public void testSetDate() {
        simpleTimeClient.setDate(1, 1, 2022);
        LocalDate expectedDate = LocalDate.of(1, 1, 2022);
        LocalDateTime actualDateTime = simpleTimeClient.getLocalDateTime();
        assertEquals(expectedDate, actualDateTime.toLocalDate());
    }

    @Test
    public void testSetDateAndTime() {
        simpleTimeClient.setDateAndTime(1, 1, 2022, 10, 30, 0);
        LocalDateTime expectedDateTime = LocalDateTime.of(1, 1, 2022, 10, 30, 0);
        LocalDateTime actualDateTime = simpleTimeClient.getLocalDateTime();
        assertEquals(expectedDateTime, actualDateTime);
    }

    @Test
    public void testGetLocalDateTime() {
        LocalDateTime now = LocalDateTime.now();
        simpleTimeClient.setDateAndTime(now.getDayOfMonth(), now.getMonthValue(), now.getYear(), now.getHour(), now.getMinute(), now.getSecond());
        LocalDateTime actualDateTime = simpleTimeClient.getLocalDateTime();
        assertEquals(now, actualDateTime);
    }

    @Test
    public void testToString() {
        LocalDateTime now = LocalDateTime.now();
        simpleTimeClient.setDateAndTime(now.getDayOfMonth(), now.getMonthValue(), now.getYear(), now.getHour(), now.getMinute(), now.getSecond());
        String actualString = simpleTimeClient.toString();
        assertEquals(now.toString(), actualString);
    }
}
```

This unit test covers all the methods in the SimpleTimeClient class. Each test method tests one of the SimpleTimeClient methods, ensuring that it works as expected. The setup method (@Before annotation) initializes the SimpleTimeClient object before each test, ensuring that each test is independent of the others.