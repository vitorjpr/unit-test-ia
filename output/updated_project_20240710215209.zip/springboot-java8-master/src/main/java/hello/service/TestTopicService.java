Here is a simple JUnit test class for the `TopicService` class. This test class is using Mockito to mock dependencies and the behavior of some methods. 

```java
package hello.service;

import hello.model.Topic;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

public class TopicServiceTest {

    @InjectMocks
    TopicService topicService;

    @Mock
    List<Topic> mockTopics;

    @BeforeEach
    public void init() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void getAllTopicsTest() {
        Topic topic1 = new Topic("spring", "Spring Framework", "Spring Framework Description");
        Topic topic2 = new Topic("java", "Core Java", "Java Description");
        when(mockTopics.toArray()).thenReturn(new Topic[]{topic1, topic2});

        List<Topic> result = topicService.getAllTopics();
        assertEquals(2, result.size());
    }

    @Test
    public void getTopicWithIdTest() {
        Topic topic1 = new Topic("spring", "Spring Framework", "Spring Framework Description");
        when(mockTopics.stream().filter(topic -> topic.getId().equals("spring")).findFirst().get()).thenReturn(topic1);

        Topic result = topicService.getTopicWithId("spring");
        assertEquals("Spring Framework", result.getName());
    }

    // Add similar tests for other methods
}
```

Note: This is a simple example and does not cover all methods in the `TopicService` class. You should write similar tests for other methods and add necessary assertions to make sure your code is working as expected. Also, this test assumes that the `topics` list can be mocked. If it can't (for example if it's final), you might need to adjust your approach.