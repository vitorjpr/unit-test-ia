Sure, below is a simple unit test for the `TimeClient` interface. Since interfaces cannot be instantiated, the tests are performed on an anonymous class that implements the `TimeClient` interface. Note that, the `setTime`, `setDate` and `setDateAndTime` methods cannot be tested since they don't have a body in the interface.

```java
package hello.declaration;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;

public class TimeClientTest {

    TimeClient timeClient = new TimeClient() {
        @Override
        public void setTime(int hour, int minute, int second) {
        }

        @Override
        public void setDate(int day, int month, int year) {
        }

        @Override
        public void setDateAndTime(int day, int month, int year, int hour, int minute, int second) {
        }

        @Override
        public LocalDateTime getLocalDateTime() {
            return LocalDateTime.of(2022, 3, 20, 15, 30);
        }
    };

    @Test
    public void testGetZoneId() {
        ZoneId zoneId = TimeClient.getZoneId("Europe/Paris");
        assertEquals("Europe/Paris", zoneId.getId());

        ZoneId defaultZoneId = TimeClient.getZoneId("Invalid/Zone");
        assertEquals(ZoneId.systemDefault(), defaultZoneId);
    }

    @Test
    public void testGetZonedDateTime() {
        ZonedDateTime zonedDateTime = timeClient.getZonedDateTime("Europe/Paris");
        assertEquals(LocalDateTime.of(2022, 3, 20, 15, 30), zonedDateTime.toLocalDateTime());
        assertEquals("Europe/Paris", zonedDateTime.getZone().getId());

        ZonedDateTime defaultZonedDateTime = timeClient.getZonedDateTime("Invalid/Zone");
        assertEquals(LocalDateTime.of(2022, 3, 20, 15, 30), defaultZonedDateTime.toLocalDateTime());
        assertEquals(ZoneId.systemDefault(), defaultZonedDateTime.getZone());
    }
}
```
This test suite tests the `getZoneId` and `getZonedDateTime` methods with both valid and invalid time zones.