```java
package hello.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class TestValue {

    private Value value;

    // This method is executed before each test. It is used to setup the test environment (e.g., read input data, initialize the class)
    @BeforeEach
    public void setUp() {
        value = new Value();
    }

    // Test the setId method
    @Test
    public void testSetId() {
        Long id = 1L;
        value.setId(id);
        assertEquals(id, value.getId(), "The id should be set correctly");
    }

    // Test the getId method
    @Test
    public void testGetId() {
        Long id = 1L;
        value.setId(id);
        Long returnedId = value.getId();
        assertEquals(id, returnedId, "The id should be retrieved correctly");
    }

    // Test the setQuote method
    @Test
    public void testSetQuote() {
        String quote = "Test quote";
        value.setQuote(quote);
        assertEquals(quote, value.getQuote(), "The quote should be set correctly");
    }

    // Test the getQuote method
    @Test
    public void testGetQuote() {
        String quote = "Test quote";
        value.setQuote(quote);
        String returnedQuote = value.getQuote();
        assertEquals(quote, returnedQuote, "The quote should be retrieved correctly");
    }

    // Test the toString method
    @Test
    public void testToString() {
        Long id = 1L;
        String quote = "Test quote";
        value.setId(id);
        value.setQuote(quote);
        String returnedString = value.toString();
        String expectedString = "Value{" +
                "id=" + id +
                ", quote='" + quote + '\'' +
                '}';
        assertEquals(expectedString, returnedString, "The toString method should return the correct string");
    }
}
```