```java
package hello.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class TestGreeting {

    private Greeting greeting;

    // This method is executed before each test. It is used to setup the test environment (e.g., read input data, initialize the class)
    @BeforeEach
    public void setup() {
        greeting = new Greeting(1L, "Hello, World!");
    }

    // Test method to check the getId() method of the Greeting class
    @Test
    public void testGetId() {
        // Assert that the expected id is equal to the actual id
        assertEquals(1L, greeting.getId(), "The id returned by getId() does not match the expected id");
    }

    // Test method to check the getContent() method of the Greeting class
    @Test
    public void testGetContent() {
        // Assert that the expected content is equal to the actual content
        assertEquals("Hello, World!", greeting.getContent(), "The content returned by getContent() does not match the expected content");
    }
}
```