```java
package hello.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class TestTopic {

    private Topic topic;

    // This method is executed before each test. It is used to setup the test environment (e.g., read input data, initialize the class)
    @BeforeEach
    public void setup() {
        topic = new Topic();
    }

    // Test method for getId
    @Test
    public void testGetId() {
        String id = "1";
        topic.setId(id);
        assertEquals(id, topic.getId(), "The id must be the same as the one set");
    }

    // Test method for setId
    @Test
    public void testSetId() {
        String id = "2";
        topic.setId(id);
        assertEquals(id, topic.getId(), "The id must be the same as the one set");
    }

    // Test method for getSubjectName
    @Test
    public void testGetSubjectName() {
        String subjectName = "Math";
        topic.setSubjectName(subjectName);
        assertEquals(subjectName, topic.getSubjectName(), "The subject name must be the same as the one set");
    }

    // Test method for setSubjectName
    @Test
    public void testSetSubjectName() {
        String subjectName = "Science";
        topic.setSubjectName(subjectName);
        assertEquals(subjectName, topic.getSubjectName(), "The subject name must be the same as the one set");
    }

    // Test method for getSubjectDescription
    @Test
    public void testGetSubjectDescription() {
        String subjectDescription = "This is a math subject";
        topic.setSubjectDescription(subjectDescription);
        assertEquals(subjectDescription, topic.getSubjectDescription(), "The subject description must be the same as the one set");
    }

    // Test method for setSubjectDescription
    @Test
    public void testSetSubjectDescription() {
        String subjectDescription = "This is a science subject";
        topic.setSubjectDescription(subjectDescription);
        assertEquals(subjectDescription, topic.getSubjectDescription(), "The subject description must be the same as the one set");
    }

    // Test method for Topic constructor
    @Test
    public void testTopicConstructor() {
        String id = "3";
        String subjectName = "English";
        String subjectDescription = "This is an English subject";
        Topic newTopic = new Topic(id, subjectName, subjectDescription);
        assertEquals(id, newTopic.getId(), "The id must be the same as the one set");
        assertEquals(subjectName, newTopic.getSubjectName(), "The subject name must be the same as the one set");
        assertEquals(subjectDescription, newTopic.getSubjectDescription(), "The subject description must be the same as the one set");
    }
}
```