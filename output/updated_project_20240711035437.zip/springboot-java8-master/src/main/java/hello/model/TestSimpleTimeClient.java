```java
package hello.model;

import hello.declaration.TimeClient;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class TestSimpleTimeClient {
    private SimpleTimeClient simpleTimeClient;

    @BeforeEach
    public void setup() {
        // Initialize SimpleTimeClient before each test
        simpleTimeClient = new SimpleTimeClient();
    }

    @Test
    public void testSetTime() {
        // Test setTime method
        simpleTimeClient.setTime(10, 30, 45);
        LocalDateTime expectedDateTime = LocalDateTime.now().withHour(10).withMinute(30).withSecond(45);
        assertEquals(expectedDateTime, simpleTimeClient.getLocalDateTime());
    }

    @Test
    public void testSetDate() {
        // Test setDate method
        simpleTimeClient.setDate(15, 10, 2020);
        LocalDateTime expectedDateTime = LocalDateTime.now().withDayOfMonth(15).withMonth(10).withYear(2020);
        assertEquals(expectedDateTime, simpleTimeClient.getLocalDateTime());
    }

    @Test
    public void testSetDateAndTime() {
        // Test setDateAndTime method
        simpleTimeClient.setDateAndTime(15, 10, 2020, 10, 30, 45);
        LocalDateTime expectedDateTime = LocalDateTime.of(2020, 10, 15, 10, 30, 45);
        assertEquals(expectedDateTime, simpleTimeClient.getLocalDateTime());
    }

    @Test
    public void testGetLocalDateTime() {
        // Test getLocalDateTime method
        LocalDateTime expectedDateTime = LocalDateTime.now();
        assertEquals(expectedDateTime, simpleTimeClient.getLocalDateTime());
    }

    @Test
    public void testToString() {
        // Test toString method
        String expectedString = simpleTimeClient.getLocalDateTime().toString();
        assertEquals(expectedString, simpleTimeClient.toString());
    }
}
```
Please note that the tests for `setTime`, `setDate`, and `getLocalDateTime` might fail sometimes because they are comparing the current time which might change between the time of setting and the time of assertion. To make the tests more reliable, you might want to mock the `LocalDateTime.now()` method to return a fixed time.