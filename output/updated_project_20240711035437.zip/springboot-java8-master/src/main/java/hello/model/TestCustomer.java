```java
package hello.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class TestCustomer {
    private Customer customer;

    // This method is executed before each test. It is used to setup the test environment (e.g., read input data, initialize the class)
    @BeforeEach
    public void setup() {
        customer = new Customer(1L, "John", "Doe");
    }

    // Test the getId method
    @Test
    public void testGetId() {
        assertEquals(1L, customer.getId(), "The ID must be 1");
    }

    // Test the setId method
    @Test
    public void testSetId() {
        customer.setId(2L);
        assertEquals(2L, customer.getId(), "The ID must be 2 after setting it to 2");
    }

    // Test the getFirstName method
    @Test
    public void testGetFirstName() {
        assertEquals("John", customer.getFirstName(), "The first name must be John");
    }

    // Test the setFirstName method
    @Test
    public void testSetFirstName() {
        customer.setFirstName("Jane");
        assertEquals("Jane", customer.getFirstName(), "The first name must be Jane after setting it to Jane");
    }

    // Test the getLastName method
    @Test
    public void testGetLastName() {
        assertEquals("Doe", customer.getLastName(), "The last name must be Doe");
    }

    // Test the setLastName method
    @Test
    public void testSetLastName() {
        customer.setLastName("Smith");
        assertEquals("Smith", customer.getLastName(), "The last name must be Smith after setting it to Smith");
    }

    // Test the toString method
    @Test
    public void testToString() {
        String expected = "Customer{id=1, firstName='John', lastName='Doe'}";
        assertEquals(expected, customer.toString(), "The toString method must return the correct representation of the object");
    }
}
```