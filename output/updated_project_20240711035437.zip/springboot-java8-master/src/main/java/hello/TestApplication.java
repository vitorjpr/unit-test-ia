```java
package hello;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.client.RestTemplate;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class TestApplication {

    @InjectMocks
    Application application;

    @Mock
    RestTemplateBuilder restTemplateBuilder;

    @Mock
    RestTemplate restTemplate;

    @Mock
    JdbcTemplate jdbcTemplate;

    @BeforeEach
    public void init() {
        MockitoAnnotations.initMocks(this);
    }

    // Test for restTemplate Bean
    @Test
    public void restTemplateTest() {
        when(restTemplateBuilder.build()).thenReturn(restTemplate);
        RestTemplate result = application.restTemplate(restTemplateBuilder);
        assertNotNull(result, "RestTemplate should not be null");
        assertEquals(restTemplate, result, "RestTemplate should match the mock");
    }

    // Test for run Bean
    @Test
    public void runTest() throws Exception {
        assertNotNull(application.run(restTemplate), "CommandLineRunner should not be null");
    }

    // Test for run method
    @Test
    public void runMethodTest() throws Exception {
        doNothing().when(jdbcTemplate).execute(anyString());
        doNothing().when(jdbcTemplate).batchUpdate(anyString(), anyList());
        application.run("");
        verify(jdbcTemplate, times(2)).execute(anyString());
        verify(jdbcTemplate, times(1)).batchUpdate(anyString(), anyList());
    }
}
```
This test class covers the three public methods in the original class. It uses Mockito to mock dependencies and verify that methods on those dependencies are called as expected. The `restTemplateTest` method tests the `restTemplate` bean method, `runTest` tests the `run` bean method, and `runMethodTest` tests the `run` method that implements `CommandLineRunner`.