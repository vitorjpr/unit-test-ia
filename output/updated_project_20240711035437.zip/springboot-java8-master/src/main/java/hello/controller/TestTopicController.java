Here is the JUnit test class for your Java code:

```java
package hello.controller;

import hello.model.Topic;
import hello.service.TopicService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

@SpringBootTest
public class TestTopicController {

    @InjectMocks
    private TopicController topicController;

    @Mock
    private TopicService topicService;

    @BeforeEach
    public void init() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testGetAllTopics() {
        // Arrange
        Topic topic = new Topic("id", "name", "description");
        when(topicService.getAllTopics()).thenReturn(Arrays.asList(topic));

        // Act
        List<Topic> result = topicController.getAllTopics();

        // Assert
        assertEquals(1, result.size());
        assertEquals(topic, result.get(0));
    }

    @Test
    public void testGetTopicWithID() {
        // Arrange
        Topic topic = new Topic("id", "name", "description");
        when(topicService.getTopicWithId("id")).thenReturn(topic);

        // Act
        Topic result = topicController.getTopicWithID("id");

        // Assert
        assertEquals(topic, result);
    }

    @Test
    public void testAddTopic() {
        // Arrange
        Topic topic = new Topic("id", "name", "description");

        // Act
        topicController.addTopic(topic);

        // Assert
        verify(topicService, times(1)).addTopic(topic);
    }

    @Test
    public void testUpdateTopic() {
        // Arrange
        Topic topic = new Topic("id", "name", "description");

        // Act
        topicController.updateTopic("id", topic);

        // Assert
        verify(topicService, times(1)).updateTopic("id", topic);
    }

    @Test
    public void testDeleteTopic() {
        // Act
        topicController.deleteTopic("id");

        // Assert
        verify(topicService, times(1)).deleteTopic("id");
    }

    @Test
    public void testFilterMinimumLengthForId() {
        // Arrange
        Topic topic = new Topic("id", "name", "description");
        when(topicService.filterMinimumLengthForId(1)).thenReturn(Arrays.asList(topic));

        // Act
        List<Topic> result = topicController.filterMinimumLengthForId(1);

        // Assert
        assertEquals(1, result.size());
        assertEquals(topic, result.get(0));
    }

    @Test
    public void testSortTopicsWithID() {
        // Arrange
        Topic topic = new Topic("id", "name", "description");
        when(topicService.sortTopicsWithID()).thenReturn(Arrays.asList(topic));

        // Act
        List<Topic> result = topicController.sortTopicsWithID();

        // Assert
        assertEquals(1, result.size());
        assertEquals(topic, result.get(0));
    }
}
```
This test class uses Mockito to mock the `TopicService` and inject it into the `TopicController` for testing. Each test method corresponds to a method in the `TopicController`, and verifies that the controller calls the appropriate service method with the correct arguments. The `assertEquals` calls in the test methods are used to verify that the controller returns the expected results.