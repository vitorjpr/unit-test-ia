Here is a JUnit test class for your HelloController class:

```java
package hello.controller;

import hello.declaration.TimeClient;
import hello.model.SimpleTimeClient;
import hello.service.TopicService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

@SpringBootTest
public class TestHelloController {

    @InjectMocks
    private HelloController helloController;

    @Mock
    private TopicService topicService;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.initMocks(this);
    }

    // Test for index method
    @Test
    public void testIndex() {
        TimeClient myTimeClient = new SimpleTimeClient();
        String expected = "Greetings from Spring Boot! ----------------------" +
                "Datetime now is " + String.valueOf(myTimeClient.toString()) + "----------------------" +
                "Datetime tomorrow will be " + String.valueOf(myTimeClient.getLocalDateTime().plusDays(1)) + "----------------------" +
                "Datetime of previous month was " + String.valueOf(myTimeClient.getLocalDateTime().minus(1, ChronoUnit.MONTHS)) + "----------------------" +
                "Is this a leap year ?  " + String.valueOf(LocalDate.now().isLeapYear()) + "----------------------" +
                "Default system zone id   " + String.valueOf(ZoneId.systemDefault()) + "-------------------" +
                "Time in California: " + myTimeClient.getZonedDateTime("Canada/Central").toString();
        String actual = helloController.index();
        assertEquals(expected, actual);
    }

    // Test for showStringOperation method
    @Test
    public void testShowStringOperation() {
        String join = "join";
        String makeDistinctAndSortCharacters = "makeDistinctAndSortCharacters";
        String splitAllIdWithColonSelectIDWithJavaKeywordThenSortThenJoin = "splitAllIdWithColonSelectIDWithJavaKeywordThenSortThenJoin";
        String findIdHavingCharacter = "findIdHavingCharacter";

        when(topicService.returnAllTopicIDWithStringSlicing()).thenReturn(join);
        when(topicService.makeDistinctAndSortCharacters(join)).thenReturn(makeDistinctAndSortCharacters);
        when(topicService.splitAllIdWithColonSelectIDWithJavaKeywordThenSortThenJoin(join)).thenReturn(splitAllIdWithColonSelectIDWithJavaKeywordThenSortThenJoin);
        when(topicService.findIdHavingCharacter()).thenReturn(findIdHavingCharacter);

        String expected = helloController.joinTemplate + join
                + helloController.makeDistinctAndSortCharactersTemplate + makeDistinctAndSortCharacters
                + helloController.splitAllIdWithColonSelectIDWithJavaKeywordThenSortThenJoinTemplate + splitAllIdWithColonSelectIDWithJavaKeywordThenSortThenJoin
                + helloController.findIdHavingCharacterTemplate + findIdHavingCharacter;
        String actual = helloController.showStringOperation();
        assertEquals(expected, actual);
    }

    // Test for showFileOperation method
    @Test
    public void testShowFileOperation() {
        String findAllFilesInPathAndSort = "findAllFilesInPathAndSort";
        String findParticularFileInPathAndSort = "findParticularFileInPathAndSort";
        String findParticularFileInPathAndSortWithWalkFunction = "findParticularFileInPathAndSortWithWalkFunction";
        String readFileWithStreamFunction = "readFileWithStreamFunction";

        when(topicService.findAllFilesInPathAndSort()).thenReturn(findAllFilesInPathAndSort);
        when(topicService.findParticularFileInPathAndSort()).thenReturn(findParticularFileInPathAndSort);
        when(topicService.findParticularFileInPathAndSortWithWalkFunction()).thenReturn(findParticularFileInPathAndSortWithWalkFunction);
        when(topicService.readFileWithStreamFunction()).thenReturn(readFileWithStreamFunction);

        String expected = helloController.findAllFilesInPathAndSortTemplate + findAllFilesInPathAndSort
                + helloController.findParticularFileInPathAndSortTemplate + findParticularFileInPathAndSort
                + helloController.findParticularFileInPathAndSortWithWalkFunctionTemplate + findParticularFileInPathAndSortWithWalkFunction
                + helloController.readFileWithStreamFunctionTemplate + readFileWithStreamFunction;
        String actual = helloController.showFileOperation();
        assertEquals(expected, actual);
    }
}
```
This test class uses Mockito to mock the TopicService dependency and uses JUnit 5 for the testing framework. Each public method in the HelloController class has a corresponding test method in the test class. The test methods use JUnit assertions to verify the behavior of the methods in the HelloController class. The setup method (@BeforeEach) initializes the mocks before each test is run.