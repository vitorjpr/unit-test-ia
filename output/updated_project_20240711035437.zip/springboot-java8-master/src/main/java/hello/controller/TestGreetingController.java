```java
package hello.controller;

import hello.model.Greeting;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
public class TestGreetingController {

    @Autowired
    private MockMvc mockMvc;

    private String url = "/";

    // This method is executed before each test. It is used to setup the test environment.
    @BeforeEach
    public void setup() {
        // setup code here if necessary
    }

    // Test the greeting method with default name
    @Test
    public void testGreetingDefaultName() throws Exception {
        MvcResult result = mockMvc.perform(MockMvcRequestBuilders.get(url))
                .andExpect(status().isOk())
                .andReturn();

        Greeting greeting = new Greeting(1, "Hello, World!");
        assertEquals(greeting.toString(), result.getResponse().getContentAsString());
    }

    // Test the greeting method with a specific name
    @Test
    public void testGreetingSpecificName() throws Exception {
        String name = "John";
        MvcResult result = mockMvc.perform(MockMvcRequestBuilders.get(url).param("name", name))
                .andExpect(status().isOk())
                .andReturn();

        Greeting greeting = new Greeting(2, "Hello, John!");
        assertEquals(greeting.toString(), result.getResponse().getContentAsString());
    }
}
```
This test class includes two test methods for the `greeting` method in the `GreetingController` class. The `testGreetingDefaultName` method tests the `greeting` method with the default name "World", and the `testGreetingSpecificName` method tests the `greeting` method with a specific name "John". The `assertEquals` method is used to compare the expected and actual results. The `@BeforeEach` annotation is used to specify that the `setup` method should be run before each test, but in this case, it is not necessary to setup anything before the tests.