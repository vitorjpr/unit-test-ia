Here is a unit test for your `Customer` class using JUnit and Mockito:

```java
package hello.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class CustomerTest {

    private Customer customer;

    @BeforeEach
    public void setUp() {
        customer = new Customer(1L, "John", "Doe");
    }

    @Test
    public void testGetId() {
        assertEquals(1L, customer.getId());
    }

    @Test
    public void testSetId() {
        customer.setId(2L);
        assertEquals(2L, customer.getId());
    }

    @Test
    public void testGetFirstName() {
        assertEquals("John", customer.getFirstName());
    }

    @Test
    public void testSetFirstName() {
        customer.setFirstName("Jane");
        assertEquals("Jane", customer.getFirstName());
    }

    @Test
    public void testGetLastName() {
        assertEquals("Doe", customer.getLastName());
    }

    @Test
    public void testSetLastName() {
        customer.setLastName("Smith");
        assertEquals("Smith", customer.getLastName());
    }

    @Test
    public void testToString() {
        String expected = "Customer{id=1, firstName='John', lastName='Doe'}";
        assertEquals(expected, customer.toString());
    }
}
```

This set of tests is simple but comprehensive for the `Customer` class. It tests all getter and setter methods, as well as the `toString()` method. Each test creates a `Customer` object, performs an operation, and then checks the result using an assertion. For `toString()`, it checks that the string representation of the `Customer` object is as expected.