Here are the unit tests for the provided Java code:

```java
package hello.model;

import hello.declaration.TimeClient;
import org.junit.Test;
import org.junit.Assert;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

public class SimpleTimeClientTest {

    @Test
    public void testSetTime() {
        SimpleTimeClient client = new SimpleTimeClient();
        client.setTime(13, 45, 20);
        LocalDateTime dateTime = client.getLocalDateTime();
        Assert.assertEquals(13, dateTime.getHour());
        Assert.assertEquals(45, dateTime.getMinute());
        Assert.assertEquals(20, dateTime.getSecond());
    }

    @Test
    public void testSetDate() {
        SimpleTimeClient client = new SimpleTimeClient();
        client.setDate(25, 12, 2022);
        LocalDateTime dateTime = client.getLocalDateTime();
        Assert.assertEquals(25, dateTime.getDayOfMonth());
        Assert.assertEquals(12, dateTime.getMonthValue());
        Assert.assertEquals(2022, dateTime.getYear());
    }

    @Test
    public void testSetDateAndTime() {
        SimpleTimeClient client = new SimpleTimeClient();
        client.setDateAndTime(25, 12, 2022, 13, 45, 20);
        LocalDateTime dateTime = client.getLocalDateTime();
        Assert.assertEquals(25, dateTime.getDayOfMonth());
        Assert.assertEquals(12, dateTime.getMonthValue());
        Assert.assertEquals(2022, dateTime.getYear());
        Assert.assertEquals(13, dateTime.getHour());
        Assert.assertEquals(45, dateTime.getMinute());
        Assert.assertEquals(20, dateTime.getSecond());
    }

    @Test
    public void testToString() {
        SimpleTimeClient client = new SimpleTimeClient();
        client.setDateAndTime(25, 12, 2022, 13, 45, 20);
        String expectedString = "2022-12-25T13:45:20";
        Assert.assertEquals(expectedString, client.toString());
    }
}
```

These tests cover all the public methods in the `SimpleTimeClient` class. The `testSetTime` method checks that the `setTime` method correctly sets the time. The `testSetDate` method checks that the `setDate` method correctly sets the date. The `testSetDateAndTime` method checks that the `setDateAndTime` method correctly sets both the date and time. The `testToString` method checks that the `toString` method correctly returns a string representation of the date and time.