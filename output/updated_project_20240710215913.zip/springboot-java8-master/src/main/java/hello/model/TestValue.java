Here is a basic unit test for the Value class using JUnit and Mockito. This test will ensure that the getters and setters are working as expected:

```java
package hello.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class ValueTest {
    private Value value;

    @BeforeEach
    public void setUp() throws Exception {
        value = new Value();
    }

    @Test
    public void testIdGetterSetter() {
        Long id = 1L;
        value.setId(id);
        assertEquals(id, value.getId(), "The ID getter or setter is not working correctly");
    }

    @Test
    public void testQuoteGetterSetter() {
        String quote = "Test Quote";
        value.setQuote(quote);
        assertEquals(quote, value.getQuote(), "The quote getter or setter is not working correctly");
    }

    @Test
    public void testToString() {
        Long id = 1L;
        String quote = "Test Quote";
        value.setId(id);
        value.setQuote(quote);
        String expectedString = "Value{id=" + id + ", quote='" + quote + "'}";
        assertEquals(expectedString, value.toString(), "The toString method is not working correctly");
    }
}
```

This unit test checks the functionality of the getId, setId, getQuote, setQuote, and toString methods. The `@BeforeEach` annotation ensures that a new Value object is created before each test, and the `@Test` annotation denotes each test method.