Sure, here is a simple unit test for your Greeting class using JUnit and Mockito. This test will ensure that the getId and getContent methods are working correctly.

```java
package hello.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class GreetingTest {

    private Greeting greeting;

    @BeforeEach
    public void setUp() {
        greeting = new Greeting(1L, "Hello, World");
    }

    @Test
    public void testGetId() {
        assertEquals(1L, greeting.getId());
    }

    @Test
    public void testGetContent() {
        assertEquals("Hello, World", greeting.getContent());
    }
}
```

In this test, we are creating a new instance of Greeting with id as 1 and content as "Hello, World". Then we are checking if the getId and getContent methods return the values that we used to create the Greeting instance.

Please note that you should have the JUnit and Mockito library in your classpath to run these tests.