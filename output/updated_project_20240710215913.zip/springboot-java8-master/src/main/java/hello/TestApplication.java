Here is a unit test for the Application class. Please note that this test uses Mockito to mock dependencies and JUnit for the test framework.

```java
package hello;

import hello.model.Quote;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.client.RestTemplate;

import static org.mockito.Mockito.*;

public class ApplicationTest {

    @InjectMocks
    Application application;

    @Mock
    RestTemplateBuilder restTemplateBuilder;

    @Mock
    RestTemplate restTemplate;

    @Mock
    JdbcTemplate jdbcTemplate;

    @BeforeEach
    public void init() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testRestTemplate() {
        when(restTemplateBuilder.build()).thenReturn(restTemplate);
        RestTemplate result = application.restTemplate(restTemplateBuilder);
        verify(restTemplateBuilder, times(1)).build();
        assertSame(result, restTemplate);
    }

    @Test
    public void testRun() throws Exception {
        CommandLineRunner runner = application.run(restTemplate);
        runner.run();
        verify(restTemplate, times(1)).getForObject(anyString(), eq(Quote.class));
    }

    @Test
    public void testJdbcTemplate() throws Exception {
        application.run();
        verify(jdbcTemplate, times(1)).execute("DROP TABLE customers IF EXISTS");
        verify(jdbcTemplate, times(1)).execute("CREATE TABLE customers(id SERIAL, first_name VARCHAR(255), last_name VARCHAR(255))");
        verify(jdbcTemplate, times(1)).batchUpdate(anyString(), anyList());
        verify(jdbcTemplate, times(1)).query(anyString(), any(Object[].class), any(RowMapper.class));
    }
}
```

Please note that this is a basic example and might need to be adjusted based on your exact needs. It is also important to note that unit tests should ideally not interact with the outside world (like databases or web services), so you might want to consider refactoring your code to make it more testable.