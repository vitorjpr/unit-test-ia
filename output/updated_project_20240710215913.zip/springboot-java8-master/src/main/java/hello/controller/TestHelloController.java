Here is a simple unit test for the HelloController class. I am using the Mockito library for mocking dependencies.

```java
package hello.controller;

import hello.declaration.TimeClient;
import hello.model.SimpleTimeClient;
import hello.service.TopicService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

@SpringBootTest
public class HelloControllerTest {

    @InjectMocks
    private HelloController helloController;

    @Mock
    private TopicService topicService;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testIndex() {
        TimeClient myTimeClient = new SimpleTimeClient();
        String response = helloController.index();
        assertNotNull(response);
    }

    @Test
    public void testShowStringOperation() {
        String mockString = "mockString";
        when(topicService.returnAllTopicIDWithStringSlicing()).thenReturn(mockString);
        when(topicService.makeDistinctAndSortCharacters(mockString)).thenReturn(mockString);
        when(topicService.splitAllIdWithColonSelectIDWithJavaKeywordThenSortThenJoin(mockString)).thenReturn(mockString);
        when(topicService.findIdHavingCharacter()).thenReturn(mockString);
        String response = helloController.showStringOperation();
        assertNotNull(response);
    }

    @Test
    public void testShowFileOperation() {
        String mockString = "mockString";
        when(topicService.findAllFilesInPathAndSort()).thenReturn(mockString);
        when(topicService.findParticularFileInPathAndSort()).thenReturn(mockString);
        when(topicService.findParticularFileInPathAndSortWithWalkFunction()).thenReturn(mockString);
        when(topicService.readFileWithStreamFunction()).thenReturn(mockString);
        String response = helloController.showFileOperation();
        assertNotNull(response);
    }
}
```
This test checks that the methods of the HelloController class return a non-null value. The TopicService methods are mocked to return a simple string for simplicity, but you can adjust the returned values and add more assertions as needed to make the tests more comprehensive.