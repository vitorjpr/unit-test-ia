Here is the unit test for your code. I'm using Mockito to mock dependencies and JUnit as the testing framework.

```java
package hello.controller;

import hello.model.Greeting;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.concurrent.atomic.AtomicLong;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

@SpringBootTest
public class GreetingControllerTest {

    @InjectMocks
    private GreetingController greetingController;

    @MockBean
    private AtomicLong counter;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testGreetingDefault() {
        when(counter.incrementAndGet()).thenReturn(1L);
        Greeting result = greetingController.greeting(null);
        assertEquals(new Greeting(1, "Hello, World!"), result);
        verify(counter, times(1)).incrementAndGet();
    }

    @Test
    public void testGreetingWithName() {
        when(counter.incrementAndGet()).thenReturn(1L);
        Greeting result = greetingController.greeting("John");
        assertEquals(new Greeting(1, "Hello, John!"), result);
        verify(counter, times(1)).incrementAndGet();
    }
}
```

Please note that these tests are designed to test the behavior of the `GreetingController`. The first test `testGreetingDefault` verifies the default behavior when no name is provided. The second test `testGreetingWithName` verifies the behavior when a name is provided. Both tests mock the `AtomicLong` counter to return a fixed value (1 in this case) and verify that the `incrementAndGet` method is called exactly once. 

Don't forget to add the necessary dependencies for JUnit and Mockito in your build.gradle or pom.xml file.