# Arquivos de Teste Criados

- TestApplication.java
- TestTopicService.java
- TestCustomPredicate.java
- TestTimeClient.java
- TestGreetingController.java
- TestHelloController.java
- TestTopicController.java
- TestCustomer.java
- TestTopic.java
- TestValue.java
- TestGreeting.java
- TestQuote.java
- TestSimpleTimeClient.java
