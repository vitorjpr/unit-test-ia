Sure, here is a comprehensive unit test for your Value class using JUnit and Mockito:

```java
package hello.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

public class ValueTest {
    private Value value;

    @BeforeEach
    public void setUp() {
        value = new Value();
    }

    @Test
    public void testId() {
        assertNull(value.getId());
        Long id = 1L;
        value.setId(id);
        assertEquals(id, value.getId());
    }

    @Test
    public void testQuote() {
        assertNull(value.getQuote());
        String quote = "Test Quote";
        value.setQuote(quote);
        assertEquals(quote, value.getQuote());
    }

    @Test
    public void testToString() {
        String quote = "Test Quote";
        Long id = 1L;
        value.setId(id);
        value.setQuote(quote);
        String expected = "Value{id=" + id + ", quote='" + quote + "\'}";
        assertEquals(expected, value.toString());
    }
}
```

This unit test covers all the methods in your `Value` class. It tests the `getId`, `setId`, `getQuote`, `setQuote` and `toString` methods. The `setUp` method is used to initialize the `Value` object before each test. The `testId` and `testQuote` methods test both the getter and setter methods for `id` and `quote` respectively. The `testToString` method tests the `toString` method.