Sure, here is a JUnit test for the SimpleTimeClient class. This test covers all methods in the SimpleTimeClient class:

```java
package hello.model;

import hello.declaration.TimeClient;
import org.junit.Before;
import org.junit.Test;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

import static org.junit.Assert.assertEquals;

public class SimpleTimeClientTest {

    private SimpleTimeClient simpleTimeClient;

    @Before
    public void setUp() {
        simpleTimeClient = new SimpleTimeClient();
    }

    @Test
    public void testSetTime() {
        int hour = 15;
        int minute = 30;
        int second = 45;
        simpleTimeClient.setTime(hour, minute, second);
        LocalDateTime dateTime = simpleTimeClient.getLocalDateTime();
        assertEquals(hour, dateTime.getHour());
        assertEquals(minute, dateTime.getMinute());
        assertEquals(second, dateTime.getSecond());
    }

    @Test
    public void testSetDate() {
        int day = 15;
        int month = 8;
        int year = 2022;
        simpleTimeClient.setDate(day, month, year);
        LocalDateTime dateTime = simpleTimeClient.getLocalDateTime();
        assertEquals(day, dateTime.getDayOfMonth());
        assertEquals(month, dateTime.getMonthValue());
        assertEquals(year, dateTime.getYear());
    }

    @Test
    public void testSetDateAndTime() {
        int day = 15;
        int month = 8;
        int year = 2022;
        int hour = 15;
        int minute = 30;
        int second = 45;
        simpleTimeClient.setDateAndTime(day, month, year, hour, minute, second);
        LocalDateTime dateTime = simpleTimeClient.getLocalDateTime();
        assertEquals(day, dateTime.getDayOfMonth());
        assertEquals(month, dateTime.getMonthValue());
        assertEquals(year, dateTime.getYear());
        assertEquals(hour, dateTime.getHour());
        assertEquals(minute, dateTime.getMinute());
        assertEquals(second, dateTime.getSecond());
    }

    @Test
    public void testToString() {
        int day = 15;
        int month = 8;
        int year = 2022;
        int hour = 15;
        int minute = 30;
        int second = 45;
        simpleTimeClient.setDateAndTime(day, month, year, hour, minute, second);
        String expected = "2022-08-15T15:30:45";
        assertEquals(expected, simpleTimeClient.toString());
    }
}
```
This test verifies that the setTime, setDate, setDateAndTime, and toString methods of the SimpleTimeClient class work as expected.