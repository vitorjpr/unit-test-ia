Sure, here is a simple unit test for the Topic class using JUnit and Mockito. 

```java
package hello.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class TopicTest {

    private Topic topic;

    @BeforeEach
    public void setUp() {
        topic = new Topic();
    }

    @Test
    public void testGetId() {
        String id = "1";
        topic.setId(id);
        assertEquals(id, topic.getId());
    }

    @Test
    public void testSetId() {
        String id = "1";
        topic.setId(id);
        assertEquals(id, topic.getId());
    }

    @Test
    public void testGetSubjectName() {
        String subjectName = "Math";
        topic.setSubjectName(subjectName);
        assertEquals(subjectName, topic.getSubjectName());
    }

    @Test
    public void testSetSubjectName() {
        String subjectName = "Math";
        topic.setSubjectName(subjectName);
        assertEquals(subjectName, topic.getSubjectName());
    }

    @Test
    public void testGetSubjectDescription() {
        String subjectDescription = "Mathematics subject";
        topic.setSubjectDescription(subjectDescription);
        assertEquals(subjectDescription, topic.getSubjectDescription());
    }

    @Test
    public void testSetSubjectDescription() {
        String subjectDescription = "Mathematics subject";
        topic.setSubjectDescription(subjectDescription);
        assertEquals(subjectDescription, topic.getSubjectDescription());
    }

    @Test
    public void testConstructor() {
        String id = "1";
        String subjectName = "Math";
        String subjectDescription = "Mathematics subject";
        Topic topic = new Topic(id, subjectName, subjectDescription);
        assertEquals(id, topic.getId());
        assertEquals(subjectName, topic.getSubjectName());
        assertEquals(subjectDescription, topic.getSubjectDescription());
    }
}
```
This test class covers all the getters, setters and constructor of the Topic class. Each test method sets a value and then asserts that the correct value is returned.