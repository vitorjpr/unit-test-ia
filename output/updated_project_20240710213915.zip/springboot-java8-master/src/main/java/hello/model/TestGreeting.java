Sure, here is a unit test for the `Greeting` class using JUnit and Mockito:

```java
package hello.model;

import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.Test;

public class GreetingTest {
    private static final long ID = 1L;
    private static final String CONTENT = "Hello, World!";

    private Greeting greeting;

    @Before
    public void setUp() {
        greeting = new Greeting(ID, CONTENT);
    }

    @Test
    public void testGetId() {
        assertEquals(ID, greeting.getId());
    }

    @Test
    public void testGetContent() {
        assertEquals(CONTENT, greeting.getContent());
    }
}
```

This test is simple but comprehensive for the `Greeting` class. It tests the `getId` and `getContent` methods, ensuring that they return the values that were passed into the constructor. 

Please note that we don't need Mockito here as there is no external dependency in the `Greeting` class which we need to mock for testing.