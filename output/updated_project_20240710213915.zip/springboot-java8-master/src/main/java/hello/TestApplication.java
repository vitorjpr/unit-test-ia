Below is a basic structure of unit tests for your Java code. It includes necessary imports and tests for some of the methods in your Application class. 

```java
package hello;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import hello.model.Customer;
import hello.model.Quote;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.client.RestTemplate;

@SpringBootTest
public class ApplicationTests {

    @InjectMocks
    private Application application;

    @Mock
    private RestTemplateBuilder restTemplateBuilder;

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private Logger log = LoggerFactory.getLogger(Application.class);

    @Mock
    private JdbcTemplate jdbcTemplate;

    @Test
    public void testRestTemplate() {
        when(restTemplateBuilder.build()).thenReturn(restTemplate);
        RestTemplate result = application.restTemplate(restTemplateBuilder);
        assertEquals(restTemplate, result);
    }

    @Test
    public void testRun() {
        List<Object[]> splitUpNames = Arrays.asList("John Woo", "Jeff Dean", "Josh Bloch", "Josh Long")
                .stream()
                .map(name -> name.split(" "))
                .collect(Collectors.toList());

        when(jdbcTemplate.batchUpdate("INSERT INTO customers(first_name, last_name) VALUES (?,?)", splitUpNames)).thenReturn(new int[]{1, 1, 1, 1});

        application.run("John Woo", "Jeff Dean", "Josh Bloch", "Josh Long");

        // Add more assertions here for other operations in the run() method
    }

    // Add more test methods here for other methods in the Application class
}
```

Please note that this is a basic structure of unit tests for your code, and you may need to add more test methods and assertions to make the tests more comprehensive. Also, please make sure to add necessary dependencies for unit testing (like JUnit and Mockito) in your project.