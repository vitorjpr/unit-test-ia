Here is the unit test for the provided code:

```java
package hello.controller;

import hello.model.Greeting;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.concurrent.atomic.AtomicLong;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@SpringBootTest
public class GreetingControllerTest {

    private GreetingController greetingController;
    private AtomicLong counter;

    @MockBean
    private Greeting greeting;

    @BeforeEach
    public void setup() {
        counter = new AtomicLong();
        greetingController = new GreetingController();
    }

    @Test
    public void testGreetingDefault() {
        when(greeting.getId()).thenReturn(counter.incrementAndGet());
        when(greeting.getContent()).thenReturn(String.format("Hello, %s!", "World"));

        Greeting result = greetingController.greeting("World");

        assertEquals(greeting.getId(), result.getId());
        assertEquals(greeting.getContent(), result.getContent());
    }

    @Test
    public void testGreetingWithName() {
        String name = "John";
        when(greeting.getId()).thenReturn(counter.incrementAndGet());
        when(greeting.getContent()).thenReturn(String.format("Hello, %s!", name));

        Greeting result = greetingController.greeting(name);

        assertEquals(greeting.getId(), result.getId());
        assertEquals(greeting.getContent(), result.getContent());
    }
}
```

This unit test includes two test cases:

1. `testGreetingDefault()`: This test checks if the default greeting "Hello, World!" is returned correctly when no name is provided.
2. `testGreetingWithName()`: This test checks if the greeting is formatted correctly when a name is provided.

Please note that the `@SpringBootTest` annotation is used to indicate that the context should be loaded for the test, and the `@MockBean` annotation is used to create a mock instance of the `Greeting` class. The `@BeforeEach` annotation is used to indicate that the `setup()` method should be run before each test case.