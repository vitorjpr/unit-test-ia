Here is a basic outline of the unit tests you can write for the `TopicController` class using JUnit and Mockito:

```java
package hello.controller;

import hello.model.Topic;
import hello.service.TopicService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.mockito.Mockito.*;

import java.util.Arrays;
import java.util.List;

public class TopicControllerTest {

    private MockMvc mockMvc;
    private TopicService topicServiceMock;

    @BeforeEach
    public void setup(WebApplicationContext wac) {
        this.topicServiceMock = mock(TopicService.class);
        this.mockMvc = MockMvcBuilders.standaloneSetup(new TopicController(topicServiceMock)).build();
    }

    @Test
    public void getAllTopics_ShouldReturnStatusOk() throws Exception {
        List<Topic> topics = Arrays.asList(new Topic("id", "name", "description"));
        when(topicServiceMock.getAllTopics()).thenReturn(topics);

        mockMvc.perform(get("/topic"))
                .andExpect(status().isOk());
    }

    @Test
    public void getTopicWithID_ShouldReturnStatusOk() throws Exception {
        Topic topic = new Topic("id", "name", "description");
        when(topicServiceMock.getTopicWithId(anyString())).thenReturn(topic);

        mockMvc.perform(get("/topic/id"))
                .andExpect(status().isOk());
    }

    @Test
    public void addTopic_ShouldReturnStatusOk() throws Exception {
        mockMvc.perform(post("/topic")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"id\": \"id\", \"name\": \"name\", \"description\": \"description\"}"))
                .andExpect(status().isOk());

        verify(topicServiceMock, times(1)).addTopic(any(Topic.class));
    }

    @Test
    public void updateTopic_ShouldReturnStatusOk() throws Exception {
        mockMvc.perform(put("/topic/id")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"id\": \"id\", \"name\": \"name\", \"description\": \"description\"}"))
                .andExpect(status().isOk());

        verify(topicServiceMock, times(1)).updateTopic(anyString(), any(Topic.class));
    }

    @Test
    public void deleteTopic_ShouldReturnStatusOk() throws Exception {
        mockMvc.perform(delete("/topic/id"))
                .andExpect(status().isOk());

        verify(topicServiceMock, times(1)).deleteTopic(anyString());
    }

    @Test
    public void filterMinimumLengthForId_ShouldReturnStatusOk() throws Exception {
        List<Topic> topics = Arrays.asList(new Topic("id", "name", "description"));
        when(topicServiceMock.filterMinimumLengthForId(anyInt())).thenReturn(topics);

        mockMvc.perform(get("/topic/minimum/length/1"))
                .andExpect(status().isOk());
    }

    @Test
    public void sortTopicsWithID_ShouldReturnStatusOk() throws Exception {
        List<Topic> topics = Arrays.asList(new Topic("id", "name", "description"));
        when(topicServiceMock.sortTopicsWithID()).thenReturn(topics);

        mockMvc.perform(get("/topic/sort"))
                .andExpect(status().isOk());
    }
}
```
This test class covers all the methods in the `TopicController` class and verifies that they return the expected HTTP status codes. It also verifies that the correct methods on the `TopicService` mock are called with the correct parameters. Note that the `@RequestBody` parameters are simulated by sending JSON in the request body.