Here is a sample JUnit test for the HelloController class. Please note that these tests are basic and may need to be expanded for more comprehensive coverage.

```java
package hello.controller;

import hello.declaration.TimeClient;
import hello.model.SimpleTimeClient;
import hello.service.TopicService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@SpringBootTest
public class HelloControllerTest {

    @InjectMocks
    HelloController helloController;

    @Mock
    TopicService topicService;

    @BeforeEach
    public void init() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testIndex() {
        SimpleTimeClient myTimeClient = new SimpleTimeClient();
        String result = helloController.index();
        assertNotNull(result);
        assertTrue(result.contains(myTimeClient.toString()));
    }

    @Test
    public void testShowStringOperation() {
        when(topicService.returnAllTopicIDWithStringSlicing()).thenReturn("testJoin");
        when(topicService.makeDistinctAndSortCharacters(anyString())).thenReturn("testDistinctAndSort");
        when(topicService.splitAllIdWithColonSelectIDWithJavaKeywordThenSortThenJoin(anyString())).thenReturn("testSplitAndJoin");
        when(topicService.findIdHavingCharacter()).thenReturn("testFindCharacter");

        String result = helloController.showStringOperation();
        assertNotNull(result);
        assertTrue(result.contains("testJoin"));
        assertTrue(result.contains("testDistinctAndSort"));
        assertTrue(result.contains("testSplitAndJoin"));
        assertTrue(result.contains("testFindCharacter"));
    }

    @Test
    public void testShowFileOperation() {
        when(topicService.findAllFilesInPathAndSort()).thenReturn("testFindAllFiles");
        when(topicService.findParticularFileInPathAndSort()).thenReturn("testFindParticularFile");
        when(topicService.findParticularFileInPathAndSortWithWalkFunction()).thenReturn("testFindWithWalkFunction");
        when(topicService.readFileWithStreamFunction()).thenReturn("testReadFile");

        String result = helloController.showFileOperation();
        assertNotNull(result);
        assertTrue(result.contains("testFindAllFiles"));
        assertTrue(result.contains("testFindParticularFile"));
        assertTrue(result.contains("testFindWithWalkFunction"));
        assertTrue(result.contains("testReadFile"));
    }
}
```
This test class uses Mockito to mock the TopicService and inject it into the HelloController. Each method is tested to ensure it returns a non-null result and that the result contains the expected strings. 

Note: Please ensure to add the necessary dependencies for JUnit and Mockito in your build.gradle or pom.xml file.